#' Control fitting and fitted-object storage
#'
#' `drm_control()` collects optimizer settings and storage choices for
#' [drmTMB()]. Use `optimizer` for settings passed to [stats::nlminb()], or
#' `optimizer_preset` for named `nlminb()` budgets that keep ordinary defaults
#' fast while making complex refits easier to write. Use the storage flags when
#' a fitted object should keep less R-side state, for
#' example during large-data experiments where the original data frame and TMB
#' automatic-differentiation object are expensive to retain.
#'
#' For optimizer-only settings, `control = list(eval.max = 1000)` remains
#' valid. When using `drm_control()`, put optimizer arguments inside
#' `optimizer = list(...)`; do not pass `eval.max` directly to `drm_control()`.
#' Under `engine = "julia"` the forwarded set is a closed whitelist:
#' `optimizer$g_tol` and `optimizer$algorithm` on the base bridge, plus
#' `optimizer$q4_vcov` on the bivariate q = 4 phylogenetic route. On that q4
#' route `optimizer$g_tol` becomes DRM.jl's outer-gradient tolerance
#' (`q4_g_tol`) and `optimizer$algorithm` is refused, because that route's
#' optimiser has no solver-selection setting. *Every* other `drm_control()`
#' field is rejected with an error naming it -- never silently ignored --
#' because it describes an `nlminb()`/TMB program that DRM.jl does not run;
#' use `engine = "tmb"` for those. The rejected set is derived from
#' `drm_control()` itself, so a control added here is rejected on the Julia
#' path without a matching edit to the bridge. The structured, bivariate q2
#' structured, and cross-family Julia routes are narrower still: they accept
#' only a default `control`, so even `optimizer$g_tol` is refused there.
#' Presets `"careful"` and `"robust"` expand to explicit `iter.max` and
#' `eval.max` controls for `nlminb()`. Values in `optimizer` override values from
#' the selected preset.
#'
#' When the selected preset uses the standard `nlminb()` budget and no explicit
#' optimizer controls, `drmTMB()` escalates the preset ladder
#' (`"default"` -> `"careful"` -> `"robust"`) when an attempt either raises an
#' error (such as a non-finite gradient) or does not converge cleanly (a nonzero
#' convergence code or a non-finite objective). The first cleanly-converged
#' attempt is returned; if no preset converges, the best (lowest-objective)
#' attempt is returned and the fit-time convergence warning flags it. Every
#' attempted preset is recorded in `fit$optimizer_attempts` and the selected one
#' in `fit$optimizer_used`.
#'
#' @param optimizer Named list passed to the `control` argument of
#'   [stats::nlminb()].
#' @param se Logical; compute standard errors and fixed-effect covariance with
#'   [TMB::sdreport()] after optimization. Set to `FALSE` to keep fitted
#'   coefficients, fitted values, residuals, predictions, simulations, and
#'   profile-likelihood paths while skipping Wald standard errors,
#'   [stats::vcov()], and Wald confidence intervals. Profile-likelihood
#'   intervals still require `keep_tmb_object = TRUE`.
#' @param se_report_covariance Logical; passed to the `getReportCovariance`
#'   argument of [TMB::sdreport()]. The default `TRUE` builds the full
#'   covariance matrix of every `ADREPORT`ed quantity. Models with a direct-SD
#'   surface (`sd_phylo(...) ~ .`) report one standard deviation *per group*, so
#'   this matrix is `n_group x n_group` and its memory cost grows with the square
#'   of the number of groups; at ten thousand tips it dominates the fit. Set to
#'   `FALSE` to keep per-quantity standard errors while skipping their joint
#'   covariance.
#' @param se_group_sd Logical; report delta-method standard errors for the
#'   *per-group* direct-SD surface (`sd_phylo(...) ~ .`). Defaults to `FALSE`.
#'   The surface has one standard deviation per group, so `ADREPORT`ing it makes
#'   the joint `ADREPORT` covariance `n_group x n_group`. Under `REML = TRUE` the
#'   fixed effects are integrated into the Laplace `random` block and
#'   [stats::vcov()] reads exactly that joint covariance, so at ten thousand tips
#'   a bivariate fit needs tens of gigabytes for it. The fitted per-group
#'   standard deviations themselves are always available (they are recomputed
#'   from the parameters); only their standard errors are opt-in. Set to `TRUE`
#'   to restore the pre-0.3.0 behaviour.
#' @param se_skip_delta_method Logical; passed to the `skip.delta.method`
#'   argument of [TMB::sdreport()]. Set to `TRUE` to skip standard errors for
#'   `ADREPORT`ed quantities entirely while retaining fixed-effect standard
#'   errors and [stats::vcov()]. This is the cheapest route to Wald inference on
#'   the fixed effects for large structured models.
#' @param keep_data Logical; keep the complete-case model data in the fitted
#'   object. Set to `FALSE` to drop `fit$data` and `fit$model$data` after
#'   fitting. Prediction, fitted values, residuals, simulation, and basic
#'   summaries still use the stored model matrices and response vectors.
#' @param keep_model_frame Logical; keep model frames in the fitted object. Set
#'   to `FALSE` to drop `fit$model$model_frame` and random-effect scale model
#'   frames after fitting. Prediction, fitted values, residuals, simulation,
#'   `sigma()`, `rho12()`, `corpairs()`, and `check_drm()` use stored model
#'   matrices, terms, response vectors, offsets, and response-name metadata.
#' @param keep_tmb_object Logical; keep the TMB automatic-differentiation object
#'   in `fit$obj`. Set to `FALSE` to reduce fitted-object size after
#'   optimization. `check_drm()` will then report the fixed-gradient check as a
#'   note because it cannot re-evaluate the gradient without `fit$obj`, and
#'   profile-likelihood confidence intervals will be unavailable.
#' @param sparse_fixed Logical; opt-in control for sparse fixed-effect
#'   design matrices. The first fitted path is limited to univariate Gaussian
#'   `mu` fixed effects with no random effects and intercept-only `sigma`.
#' @param aggregate_gaussian Logical; opt-in control for sufficient-
#'   statistic row aggregation in univariate Gaussian fixed-effect models. The
#'   first fitted path rejects random effects, structured effects, known
#'   sampling covariance, bivariate models, non-Gaussian families, non-unit
#'   likelihood weights, and combined sparse fixed-effect matrices.
#' @param logsigma_clamp Numeric `c(lo, hi)` band, or `NULL`. Bounds the
#'   per-observation Gaussian `log(sigma)` with an identity-in-band soft-clamp,
#'   a numerical guard against scale overflow on near-degenerate per-group scale
#'   models. The default `c(-12, 12)` is identity for any standardized response;
#'   widen it for legitimately huge-variance unstandardized data, or set `NULL`
#'   to disable the guard entirely. It is a numerical guard only and does not
#'   change identifiability.
#' @param logsigma_clamp_margin Positive number; the soft-clamp saturation
#'   margin beyond `logsigma_clamp` (default `3`, saturating to `[-15, 15]` for
#'   the default band). Ignored when `logsigma_clamp = NULL`.
#' @param optimizer_preset Optimizer-budget preset. `"default"` adds no
#'   optimizer controls, `"careful"` sets `iter.max = 1000` and
#'   `eval.max = 1000`, and `"robust"` sets `iter.max = 5000` and
#'   `eval.max = 5000`. The optimizer escalates this ladder automatically when a
#'   preset does not converge.
#' @param newton_polish Logical (default `TRUE`). [stats::nlminb()]'s own
#'   `rel.tol`/`x.tol` stopping rules trigger on a relative change in the
#'   objective or the step, not on the gradient norm, so on a flat or
#'   weakly-curved surface (for example a variance component identified by
#'   few groups) `nlminb()` can report convergence while the true gradient at
#'   that point is still far from zero (issue #1130). Rather than tightening
#'   `rel.tol`/`x.tol` -- which on the same fixture instead produced a
#'   spurious "singular convergence" code without reliably landing closer to
#'   the true optimum -- the default fixed `rel.tol`/`x.tol` (`nlminb()`'s
#'   own) are left alone, and a Newton polish step is applied to whatever
#'   `nlminb()` returns: the exact TMB gradient plus a finite-differenced
#'   Hessian of that gradient (`stats::optimHess()`) drive a few Newton steps
#'   until the gradient's max absolute component is at or below a small
#'   threshold, accepting a step only if it does not increase the objective.
#'   Cost is a handful of extra gradient evaluations at the reported optimum
#'   (skipped entirely once the gradient is already small); set to `FALSE` to
#'   restore the pre-0.7.1 behaviour of reporting `nlminb()`'s raw optimum
#'   unpolished.
#' @param multi_start Whole number `>= 1` (default `1`). With `multi_start > 1`,
#'   each optimizer preset is run from `multi_start` starting points -- the
#'   principled start plus reproducibly perturbed starts -- and the lowest-
#'   objective result is kept. Opt-in robustness for weakly identified models;
#'   `multi_start = 1` is the single-start fit and is unchanged. Joint models
#'   with both scale and zero-inflation predictors (for example `sigma ~ ...`
#'   together with `zi ~ ...` on Poisson or `nbinom2()` families) can admit
#'   multiple local optima; when a fit looks unstable or convergence
#'   checks flag a boundary, try `multi_start > 1` before changing the model.
#'   The starts run one after another unless `parallel` is set.
#' @param parallel,workers Backend and worker count for the `multi_start`
#'   starts only: `"none"` (default) runs them one after another,
#'   `"multicore"` forks Unix workers, and `"cluster"` uses socket (PSOCK)
#'   workers on any platform. A single fit, and `multi_start = 1`, always run
#'   on one core. Parallel starts each begin from the same initial TMB state,
#'   so with random effects they can differ from the serial run at the inner
#'   solver's tolerance; fixed-effect fits are identical. `workers = NULL` uses
#'   about half the detected cores, capped at `multi_start` and at 10. See
#'   [drmTMB-parallel].
#' @param fallback_optimizer `NULL` (default) or one [stats::optim()] method
#'   (`"BFGS"`, `"L-BFGS-B"`, `"Nelder-Mead"`, `"CG"`). When set, and no
#'   `nlminb()` preset converges, `drmTMB()` tries this optimizer as a final
#'   attempt; a different algorithm can succeed on a numerically awkward but
#'   identified problem. Opt-in; `NULL` keeps the `nlminb()`-only ladder.
#' @param start `NULL` (default) or a named list of starting values, keyed by
#'   public start labels. Three label families are supported:
#'   `"fixef:<dpar>:<column>"` for a fixed-effect coefficient (already on the
#'   model's internal/link scale, e.g. `log(sigma)` for the default `sigma`
#'   link); `"sd:<dpar>:<term>"` for a random-effect standard deviation, given
#'   on the natural (positive) scale and transformed internally via `log()`;
#'   and `"cor:<dpar>:<term>"` for a random-effect correlation, given on the
#'   natural `(-1, 1)` scale and transformed internally via `atanh()`. Labels
#'   are validated against the parsed formula and family; unknown labels
#'   error before optimization starts. A start only changes where the
#'   optimizer begins, never what is reported: unnamed components keep the
#'   ordinary family-builder default. Latent random-effect values (`u`) are
#'   not addressable through this contract.
#'
#' @return A `drm_control` object.
#' @export
#'
#' @examples
#' dat <- data.frame(y = rnorm(20), x = rnorm(20))
#' fit <- drmTMB(
#'   bf(y ~ x, sigma ~ 1),
#'   data = dat,
#'   control = drm_control(
#'     optimizer_preset = "careful",
#'     se = FALSE,
#'     keep_data = FALSE,
#'     keep_model_frame = FALSE,
#'     keep_tmb_object = FALSE
#'   )
#' )
drm_control <- function(
  optimizer = list(),
  se = TRUE,
  se_report_covariance = TRUE,
  se_skip_delta_method = FALSE,
  se_group_sd = FALSE,
  keep_data = TRUE,
  keep_model_frame = TRUE,
  keep_tmb_object = TRUE,
  sparse_fixed = FALSE,
  aggregate_gaussian = FALSE,
  logsigma_clamp = c(-12, 12),
  logsigma_clamp_margin = 3,
  optimizer_preset = c("default", "careful", "robust"),
  newton_polish = TRUE,
  multi_start = 1L,
  fallback_optimizer = NULL,
  start = NULL,
  parallel = c("none", "multicore", "cluster"),
  workers = NULL
) {
  parallel <- match.arg(parallel)
  optimizer_preset <- match.arg(optimizer_preset)
  newton_polish <- drm_control_flag(newton_polish, "newton_polish")
  if (
    !is.list(optimizer) ||
      (length(optimizer) > 0L &&
        (is.null(names(optimizer)) || any(names(optimizer) == "")))
  ) {
    cli::cli_abort("{.arg optimizer} must be a named list.")
  }
  optimizer_reserved <- intersect(
    names(optimizer),
    drm_control_reserved_names()
  )
  if (length(optimizer_reserved) > 0L) {
    cli::cli_abort(c(
      "{.arg optimizer} contains reserved {.pkg drmTMB} control name{?s}: {.arg {optimizer_reserved}}.",
      "i" = "Use {.arg optimizer} only for {.fn stats::nlminb} control settings.",
      "i" = "Use {.arg multi_start} for multi-start; future start, warm-start, map, fixed-parameter, and fallback-optimizer controls will use explicit {.pkg drmTMB} arguments after their contract is implemented."
    ))
  }
  optimizer <- drm_control_optimizer(optimizer, optimizer_preset)
  se <- drm_control_flag(se, "se")
  se_report_covariance <- drm_control_flag(
    se_report_covariance,
    "se_report_covariance"
  )
  se_skip_delta_method <- drm_control_flag(
    se_skip_delta_method,
    "se_skip_delta_method"
  )
  se_group_sd <- drm_control_flag(se_group_sd, "se_group_sd")
  keep_data <- drm_control_flag(keep_data, "keep_data")
  keep_model_frame <- drm_control_flag(keep_model_frame, "keep_model_frame")
  keep_tmb_object <- drm_control_flag(keep_tmb_object, "keep_tmb_object")
  sparse_fixed <- drm_control_flag(sparse_fixed, "sparse_fixed")
  aggregate_gaussian <- drm_control_flag(
    aggregate_gaussian,
    "aggregate_gaussian"
  )
  if (!is.null(logsigma_clamp)) {
    if (
      !is.numeric(logsigma_clamp) ||
        length(logsigma_clamp) != 2L ||
        any(!is.finite(logsigma_clamp)) ||
        logsigma_clamp[[1L]] >= logsigma_clamp[[2L]]
    ) {
      cli::cli_abort(
        "{.arg logsigma_clamp} must be NULL or a length-2 numeric {.code c(lo, hi)} with {.code lo < hi}."
      )
    }
  }
  if (
    !is.numeric(logsigma_clamp_margin) ||
      length(logsigma_clamp_margin) != 1L ||
      !is.finite(logsigma_clamp_margin) ||
      logsigma_clamp_margin <= 0
  ) {
    cli::cli_abort(
      "{.arg logsigma_clamp_margin} must be a single positive number."
    )
  }
  if (
    !is.numeric(multi_start) ||
      length(multi_start) != 1L ||
      !is.finite(multi_start) ||
      multi_start < 1 ||
      multi_start != as.integer(multi_start)
  ) {
    cli::cli_abort("{.arg multi_start} must be a single whole number >= 1.")
  }
  multi_start <- as.integer(multi_start)
  if (!is.null(workers)) {
    # Validate now; NULL stays NULL and is resolved when the starts run.
    workers <- resolve_parallel_workers(workers, "multicore")
  }
  if (!is.null(fallback_optimizer)) {
    valid_fallback <- c("BFGS", "L-BFGS-B", "Nelder-Mead", "CG")
    if (
      !is.character(fallback_optimizer) ||
        length(fallback_optimizer) != 1L ||
        !fallback_optimizer %in% valid_fallback
    ) {
      cli::cli_abort(c(
        "{.arg fallback_optimizer} must be NULL or one {.fn stats::optim} method.",
        "i" = "Valid methods: {.val {valid_fallback}}."
      ))
    }
  }
  start <- drm_control_validate_start(start)
  structure(
    list(
      optimizer = optimizer,
      se = se,
      se_report_covariance = se_report_covariance,
      se_skip_delta_method = se_skip_delta_method,
      se_group_sd = se_group_sd,
      keep_data = keep_data,
      keep_model_frame = keep_model_frame,
      keep_tmb_object = keep_tmb_object,
      sparse_fixed = sparse_fixed,
      aggregate_gaussian = aggregate_gaussian,
      logsigma_clamp = logsigma_clamp,
      logsigma_clamp_margin = logsigma_clamp_margin,
      optimizer_preset = optimizer_preset,
      newton_polish = newton_polish,
      multi_start = multi_start,
      fallback_optimizer = fallback_optimizer,
      start = start,
      parallel = parallel,
      workers = workers
    ),
    class = "drm_control"
  )
}

drm_control_validate_start <- function(start) {
  if (is.null(start)) {
    return(NULL)
  }
  if (!is.list(start) || is.data.frame(start)) {
    cli::cli_abort("{.arg start} must be NULL or a named list of public start labels.")
  }
  if (length(start) == 0L) {
    return(list())
  }
  labels <- names(start)
  if (
    is.null(labels) ||
      length(labels) != length(start) ||
      anyNA(labels) ||
      any(labels == "")
  ) {
    cli::cli_abort(
      "{.arg start} must name every element with a public start label, e.g. {.val fixef:mu:(Intercept)}."
    )
  }
  for (i in seq_along(start)) {
    value <- start[[i]]
    if (!is.numeric(value) || length(value) != 1L || !is.finite(value)) {
      cli::cli_abort(c(
        "{.arg start} values must be single finite numbers.",
        "x" = "Start label {.val {labels[[i]]}} has a non-scalar or non-finite value."
      ))
    }
  }
  start
}

drm_parse_control <- function(control) {
  if (inherits(control, "drm_control")) {
    return(control)
  }
  if (is.null(control)) {
    control <- list()
  }
  if (!is.list(control)) {
    cli::cli_abort(c(
      "{.arg control} must be a list or a {.cls drm_control} object.",
      "i" = "Use {.code control = list(eval.max = 1000)} for optimizer-only settings.",
      "i" = "Use {.code control = drm_control(...)} for storage controls."
    ))
  }
  reserved <- intersect(names(control), drm_control_reserved_names())
  if (length(reserved) > 0L) {
    cli::cli_abort(c(
      "{.arg control} contains reserved {.pkg drmTMB} control name{?s}: {.arg {reserved}}.",
      "i" = "{.code control = list(...)} is only for {.fn stats::nlminb} optimizer settings.",
      "i" = "Use {.code control = drm_control(...)} for implemented {.pkg drmTMB} controls such as {.arg se}, {.arg keep_data}, and {.arg keep_tmb_object}. Future warm starts need an explicit source-fit contract before they can be used.",
      "i" = "Use {.code control = list(eval.max = 1000)} only for optimizer settings."
    ))
  }
  drm_control(optimizer = control)
}

drm_control_reserved_names <- function() {
  unique(c(
    setdiff(names(formals(drm_control)), "optimizer"),
    "starts",
    "start_from",
    "warm_start",
    "warm_starts",
    "warm_start_from",
    "map",
    "fixed",
    "fallback_optimizers",
    "optimizer_fallback",
    "optimizer_fallbacks",
    "multistart"
  ))
}

drm_control_optimizer <- function(optimizer, optimizer_preset) {
  preset <- drm_control_optimizer_preset(optimizer_preset)
  c(preset[setdiff(names(preset), names(optimizer))], optimizer)
}

drm_control_optimizer_preset <- function(optimizer_preset) {
  switch(
    optimizer_preset,
    default = list(),
    careful = list(iter.max = 1000L, eval.max = 1000L),
    robust = list(iter.max = 5000L, eval.max = 5000L)
  )
}

drm_apply_storage_control <- function(fit, control) {
  fit$control <- control
  if (!isTRUE(control$keep_data)) {
    fit$data <- NULL
    fit$model$data <- NULL
    fit$model$input_data <- NULL
  }
  if (!isTRUE(control$keep_model_frame)) {
    fit <- drm_drop_model_frames(fit)
  }
  if (!isTRUE(control$keep_tmb_object)) {
    fit$obj <- NULL
  }
  fit
}

drm_drop_model_frames <- function(fit) {
  fit$model$model_frame <- NULL
  if (!is.null(fit$model$random_scale)) {
    fit$model$random_scale <- lapply(
      fit$model$random_scale,
      drm_drop_model_frame_components
    )
  }
  if (!is.null(fit$model$random$mu$cor_model)) {
    fit$model$random$mu$cor_model <- drm_drop_model_frame_components(
      fit$model$random$mu$cor_model
    )
  }
  fit
}

drm_drop_model_frame_components <- function(x) {
  if (!is.list(x)) {
    return(x)
  }
  if (!is.null(x$model_frame)) {
    x$model_frame <- NULL
  }
  if (!is.null(x$model_frame_list)) {
    x$model_frame_list <- NULL
  }
  x
}

drm_control_flag <- function(x, name) {
  if (!is.logical(x) || length(x) != 1L || is.na(x)) {
    cli::cli_abort("{.arg {name}} must be {.code TRUE} or {.code FALSE}.")
  }
  x
}
