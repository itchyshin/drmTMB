#' Check convergence and diagnostic flags for a drmTMB fit
#'
#' `check_drm()` runs a compact set of model-fit diagnostics. It is intended as
#' a first-pass guardrail before interpreting distributional models, especially
#' fits with random effects, known sampling covariance, phylogenetic location
#' effects, or bivariate residual correlation `rho12`.
#'
#' The current checks cover optimizer convergence, finite objective values,
#' optimizer evaluation counts, fixed-parameter gradients including the largest
#' gradient component label, whether
#' [TMB::sdreport()] was computed, skipped, or failed, Hessian status from
#' [TMB::sdreport()], the fixed-effect Hessian's minimum eigenvalue and
#' condition number at the optimum (`hessian_conditioning`; a comparable, but
#' not numerically identical, read of the same object underlying `pdHess`).
#' `hessian_conditioning` is computed from
#' [TMB::sdreport()]'s already-materialized fixed-effect covariance
#' (`sdr$cov.fixed`), never by evaluating the TMB C++ object directly, so it
#' is available for random-effect and REML fits (where the underlying
#' Hessian is Laplace-marginalized) and for a fit restored via `saveRDS()`/
#' `readRDS()`, and reports a `note` with a stated reason, not a bare `NA`,
#' only when `sdr$cov.fixed` itself is absent or incomplete (for example
#' `drm_control(se = FALSE)`, or a failed `sdreport()`), finite fixed-effect standard errors, standard errors that
#' are finite but inflated relative to the others despite a positive-definite
#' Hessian (a weakly identified, near-flat direction such as a boundary
#' correlation), dropped rows,
#' positive scale parameters, random-effect standard deviations near the lower
#' boundary, bivariate residual-correlation `rho12` values near the boundary,
#' Student-t `nu` boundary behaviour, skew-normal `nu` finite-value checks,
#' known sampling covariance summaries,
#' dense known-covariance storage scale, dense fixed-effect design size and
#' density, random-effect replication, and random-slope design variation. If a
#' univariate Gaussian fit includes one or more matched labelled
#' `mu`/`sigma` random-intercept covariance blocks, `check_drm()` also reports
#' group replication and whether either component is tiny relative to its
#' interpretation scale for each independent block. If a bivariate Gaussian fit
#' includes one or more matched same-response labelled `mu`/`sigma`
#' random-intercept covariance blocks, `check_drm()` reports one row per block.
#' If a bivariate Gaussian fit includes a matched
#' labelled `mu1`/`mu2` random-intercept covariance block, `check_drm()` reports
#' group replication and whether either group-level SD is tiny relative to the
#' matching residual scale. For a matched labelled `sigma1`/`sigma2` block, it
#' reports group replication and whether either log-`sigma` random-effect SD is
#' tiny. If a bivariate Gaussian fit includes an ordinary all-four q=4
#' `mu1`/`mu2`/`sigma1`/`sigma2` block, it reports group replication, location
#' SDs relative to residual scales, log-`sigma` SDs, and whether any latent
#' correlation is near the boundary. If a bivariate Gaussian fit includes
#' matching `mu1`/`mu2` phylogenetic location effects, `check_drm()` also reports
#' whether the fitted phylogenetic mean-mean correlation is near the boundary,
#' whether either phylogenetic SD is tiny relative to the matching residual
#' scale, and whether an ordinary group-level covariance block uses the same
#' grouping factor. Matching bivariate coordinate-spatial q=2, `animal()`, and
#' `relmat()` q=2 location effects receive the corresponding structured
#' replication, SD-ratio, and boundary-correlation diagnostics. If a bivariate
#' Gaussian fit includes a
#' phylogenetic, coordinate-spatial, animal-model, or `relmat()` q=4
#' `mu1`/`mu2`/`sigma1`/`sigma2` block, it reports level replication, location
#' SDs relative to residual scales, log-`sigma` SDs, and whether any latent
#' structured correlation is near the boundary. If a univariate
#' Gaussian fit includes `phylo(1 | species, tree = tree)` or
#' `phylo(1 + x | species, tree = tree)` in `mu`, it reports species
#' replication, the fitted phylogenetic SDs, and whether the smallest
#' phylogenetic SD is tiny relative to the residual scale. If a univariate
#' Gaussian fit includes `spatial(1 | site, coords = coords)` or
#' `spatial(1 + x | site, coords = coords)` in `mu`, it reports site
#' replication, fitted coordinate range, the spatial SDs, and whether the
#' smallest spatial SD is tiny relative to the residual scale. If a Gaussian
#' fit includes `sd_phylo(species) ~ x_species`,
#' `sd_phylo1(species) ~ x_species`, or
#' `sd_phylo2(species) ~ x_species`, it reports species replication and the
#' fitted direct-SD surface range. When that phylogenetic SD depends on
#' covariates (for example `sd(species, level = "phylogenetic") ~ x_species`),
#' the `phylo_sd_shared_shift` row reports `z_shared`, the size of any common
#' shift in the fitted phylogenetic effects in prior-SD units. Such a shift
#' adds shift x SD to every mean, a curved function of the SD covariates, so it
#' can stand in for curvature missing from the location formula and give the
#' likelihood more than one optimum. The row is a `note` when
#' `abs(z_shared) >= 2` and a `warning` when `abs(z_shared) >= 3`; then check
#' the mean for missing curvature, refit from other starting values, and
#' interpret location coefficients with care. If a univariate Gaussian fit used
#' `drm_control(aggregate_gaussian = TRUE)`, it reports original rows,
#' aggregation cells, compression ratio, and largest cell size. If a fit was
#' stored with
#' `drm_control(keep_tmb_object = FALSE)`, the
#' fixed-gradient check is reported as a note because the TMB
#' automatic-differentiation object is not available. If a fit used
#' `drm_control(se = FALSE)`, the `sdreport_status`, Hessian, and
#' finite-standard-error checks are reported as notes. If `sdreport()` was
#' requested but failed, those rows are warnings.
#'
#' Use `check_drm()` before interpreting coefficients, fitted values, or
#' response-scale quantities. A `note` records something to inspect, such as
#' dropped rows or a singly observed random-effect level. A `warning` means the
#' fitted model may still be useful but needs inspection before inference. An
#' `error` means at least one basic diagnostic failed. A Hessian or
#' `sdreport()` warning is therefore an inference and identifiability signal,
#' not automatic proof that fitted point estimates are unusable. For
#' programmatic checks, the returned object has `attr(x, "ok") == TRUE` only
#' when no rows have `warning` or `error` status.
#'
#' For native `drmTMB` fits, this is a stable reader schema: the
#' `drm_check` data frame has, in order, the character columns `check`,
#' `status`, `value`, and `message`. `status` is one of `"ok"`, `"note"`,
#' `"warning"`, or `"error"`. Its `"ok"` attribute is `TRUE` exactly when
#' no row has status `"warning"` or `"error"`.
#'
#' @section Fits from `engine = "julia"`:
#'
#' A fit produced by the DRM.jl bridge (`engine = "julia"`, class
#' `drmTMB_julia`) dispatches through this same generic and returns the same
#' four-column `drm_check` schema, but it reports a deliberately **different
#' and much shorter** set of rows. Almost every check listed above reads a
#' `TMB` object or a [TMB::sdreport()] that a bridge fit does not have, so a
#' clean `engine = "julia"` table is a narrower claim than a clean
#' `engine = "tmb"` table on the same model. The rows are:
#'
#' \describe{
#'   \item{`engine_route`}{Always a `note`. Names the engine, the DRM.jl
#'     route, and the estimator (`"engine=julia; route=<route>;
#'     estimator=<ML|REML>"`), and its message lists the native
#'     `engine = "tmb"` checks that did not run. Being a `note`, it never
#'     flips `attr(x, "ok")`: reporting which machinery ran is not itself a
#'     fault.}
#'   \item{`optimizer_convergence`}{Whether DRM.jl reported convergence. This
#'     is DRM.jl's own convergence flag, not `nlminb()`'s `convergence` code,
#'     and the two are not claimed to agree.}
#'   \item{`fixed_gradient`}{Route-aware. Only some DRM.jl routes store a
#'     gradient callback, and the bridge omits the gradient entirely rather
#'     than sending a fabricated one on a route without it; on such a route
#'     this row is a `note` naming the route, stationarity is **not** scored,
#'     and `attr(x, "ok")` does not reflect it. When a gradient is present the
#'     row reports `max|gradient|` and the largest component. In both cases the
#'     value string carries `source=`, naming which producer made the number in
#'     DRM.jl's own `grad_source` vocabulary (`"locscale"`, `"stored"`,
#'     `"forward"`, `"finite"`, `"none"`, `"unavailable"`) so that an exact
#'     analytic gradient, an automatic-differentiation gradient, and a finite
#'     difference accurate only to roughly `1e-6` relative do not print
#'     identically. The current bridge payload has exactly one gradient
#'     producer, the fit's own stored callback, so a gradient that crossed the
#'     bridge is reported as `source=stored`. When no gradient crossed, the
#'     bridge does not report which of the remaining five cases applies, so the
#'     row records `source=unknown` -- deliberately not one of DRM.jl's six
#'     values -- and points you at DRM.jl's own `check_drm(fit)` in Julia,
#'     whose `grad_source` field tells them apart. This is not TMB's
#'     `sdreport()` gradient and the two engines are not claimed to agree
#'     numerically. A source outside that vocabulary, or one that contradicts
#'     the payload (a producer named when no gradient crossed, or `"none"` /
#'     `"unavailable"` alongside one that did), aborts rather than being
#'     printed.}
#'   \item{`bridge_covariance`}{The DRM.jl analogue of `sdreport_status`:
#'     whether the fixed-effect covariance the bridge marshalled back is
#'     complete (`ok`), partial (some distributional parameters finite, others
#'     not, which some structured routes produce by design), or unavailable.
#'     [TMB::sdreport()] is not run for a bridge fit.}
#'   \item{`bridge_standard_errors`}{The DRM.jl analogue of
#'     `standard_errors_finite`: whether every fixed-effect standard error
#'     implied by that covariance is a finite real number. A complete
#'     covariance can still carry a negative variance on the diagonal, which
#'     `bridge_covariance` cannot see.}
#' }
#'
#' The `gradient_tolerance` argument applies as it does for a native fit; the
#' `rho_boundary` and `sd_boundary` arguments do not, because the
#' corresponding rows are not computed for a bridge fit.
#'
#' @param object A `drmTMB` fit.
#' @param gradient_tolerance Maximum absolute fixed-parameter gradient treated
#'   as acceptable.
#' @param rho_boundary Absolute residual or structured correlation value above
#'   which a bivariate Gaussian fit receives a warning.
#' @param sd_boundary Random-effect standard deviation below which a fit
#'   receives a warning that the variance component is near the lower
#'   boundary.
#' @param ... Reserved for future diagnostic options.
#'
#' @return A `drm_check` data frame. Its stable native reader columns are, in
#'   order, `check`, `status`, `value`, and `message`, all character. `status`
#'   uses only `"ok"`, `"note"`, `"warning"`, and `"error"`; its `"ok"`
#'   attribute is `TRUE` exactly when no row has status `"warning"` or
#'   `"error"`.
#' @export
#'
#' @examples
#' set.seed(1)
#' dat <- data.frame(y = rnorm(40), x = rnorm(40))
#' fit <- drmTMB(drm_formula(y ~ x, sigma ~ x), data = dat)
#' check_drm(fit)
check_drm <- function(object, ...) {
  UseMethod("check_drm")
}

#' Check whether a fit converged
#'
#' `is_converged()` is a compact programmatic flag for workflows that need a
#' yes/no answer before comparing, displaying, or post-processing a `drmTMB`
#' fit. By default it delegates to [convergence_status()]: it returns `TRUE`
#' when the status is `"converged"` or `"boundary"`, and `FALSE` when the
#' status is `"degenerate"`. A fit can therefore report optimizer code `0`
#' while still returning `FALSE` here when the likelihood geometry or
#' uncertainty diagnostics are degenerate; use [check_drm()] or
#' [convergence_status()] for detail.
#'
#' Set `include_hessian = TRUE` when the next step needs Wald-style
#' uncertainty. In that mode, `is_converged()` also requires successful
#' [TMB::sdreport()] output with `pdHess = TRUE` on top of the default
#' [convergence_status()] gate. A fit can therefore be `"converged"` while
#' still returning `FALSE` with `include_hessian = TRUE`; this marks an
#' inference-readiness problem, not automatic proof that point estimates are
#' unusable.
#'
#' Use [check_drm()] when you need the full diagnostic table and messages.
#'
#' @param object A `drmTMB` fit.
#' @param include_hessian Logical; require a positive-definite
#'   [TMB::sdreport()] Hessian in addition to optimizer convergence.
#' @param ... Reserved for future convergence options.
#'
#' @return A single logical value.
#' @export
#'
#' @examples
#' set.seed(20260531)
#' dat <- data.frame(y = rnorm(30), x = rnorm(30))
#' fit <- drmTMB(bf(y ~ x, sigma ~ 1), data = dat)
#' is_converged(fit)
#' is_converged(fit, include_hessian = TRUE)
is_converged <- function(object, ...) {
  UseMethod("is_converged")
}

#' @rdname is_converged
#' @export
is_converged.default <- function(object, ...) {
  cli::cli_abort("{.fn is_converged} is implemented for {.cls drmTMB} fits.")
}

#' @rdname is_converged
#' @export
is_converged.drmTMB <- function(object, include_hessian = FALSE, ...) {
  dots <- list(...)
  if (length(dots) > 0L) {
    cli::cli_abort(
      "{.arg ...} is reserved for future {.fn is_converged} options."
    )
  }
  if (
    !is.logical(include_hessian) ||
      length(include_hessian) != 1L ||
      is.na(include_hessian)
  ) {
    cli::cli_abort("{.arg include_hessian} must be `TRUE` or `FALSE`.")
  }

  status <- convergence_status(object)
  if (!identical(status, "converged") && !identical(status, "boundary")) {
    return(FALSE)
  }
  if (!include_hessian) {
    return(TRUE)
  }

  if (drm_is_mspl(object)) {
    return(isTRUE(object$mspl$numerical$hessian_positive_definite))
  }

  identical(drm_uncertainty_status(object), "ok") &&
    !is.null(object$sdr) &&
    isTRUE(object$sdr$pdHess)
}

#' Convergence status for a drmTMB fit
#'
#' `convergence_status()` returns a short character label for programmatic
#' workflows that need more detail than [is_converged()]. A fit can report
#' optimizer code `0` while the likelihood geometry is degenerate (no proper
#' maximum or non-finite uncertainty); such fits return `"degenerate"` even
#' when `multi_start` selected among several starts. `"boundary"` marks an
#' optimizer-converged fit with variance-component or residual-correlation
#' parameters near an interpretability boundary. [is_converged()] stays a
#' plain logical: it is `TRUE` for `"converged"` and `"boundary"`, and
#' `FALSE` for `"degenerate"`.
#'
#' @param object A `drmTMB` fit.
#' @param ... Reserved for future options.
#'
#' @return One of `"converged"`, `"boundary"`, or `"degenerate"`.
#' @export
#'
#' @examples
#' set.seed(20260916)
#' dat <- data.frame(y = rnorm(40), x = rnorm(40))
#' fit <- drmTMB(bf(y ~ x, sigma ~ 1), data = dat)
#' convergence_status(fit)
convergence_status <- function(object, ...) {
  UseMethod("convergence_status")
}

#' @rdname convergence_status
#' @export
convergence_status.default <- function(object, ...) {
  cli::cli_abort(
    "{.fn convergence_status} is implemented for {.cls drmTMB} fits."
  )
}

#' @rdname convergence_status
#' @export
convergence_status.drmTMB <- function(object, ...) {
  dots <- list(...)
  if (length(dots) > 0L) {
    cli::cli_abort(
      "{.arg ...} is reserved for future {.fn convergence_status} options."
    )
  }
  if (!drm_optimizer_converged(object)) {
    return("degenerate")
  }
  if (
    drm_inference_degenerate(object) ||
      drm_fixed_effect_rank_deficient(object) ||
      drm_standard_errors_pathological(object)
  ) {
    return("degenerate")
  }
  if (drm_inference_at_boundary(object)) {
    return("boundary")
  }
  "converged"
}

drm_optimizer_converged <- function(object) {
  objective_values <- if (drm_is_mspl(object)) {
    c(object$opt$objective, object$mspl$unpenalized_laplace_objective)
  } else {
    c(object$opt$objective, object$logLik)
  }
  identical(as.integer(object$opt$convergence), 0L) &&
    isTRUE(all(is.finite(objective_values)))
}

drm_inference_degenerate <- function(object) {
  if (identical(as.integer(object$opt$convergence), 7L)) {
    return(TRUE)
  }
  if (!drm_optimizer_converged(object)) {
    return(FALSE)
  }
  if (identical(object$control$se, FALSE)) {
    return(FALSE)
  }
  if (is.null(object$sdr) || !isTRUE(object$sdr$pdHess)) {
    return(TRUE)
  }
  vcov <- tryCatch(stats::vcov(object), error = function(e) NULL)
  if (is.null(vcov) || !is.matrix(vcov) || nrow(vcov) == 0L) {
    return(TRUE)
  }
  variances <- diag(vcov)
  standard_errors <- rep(NA_real_, length(variances))
  non_negative <- is.finite(variances) & variances >= 0
  standard_errors[non_negative] <- sqrt(variances[non_negative])
  !all(is.finite(standard_errors))
}

drm_standard_errors_pathological <- function(object) {
  row <- check_standard_errors_inflated(object)
  !is.null(row) && grepl("n_inflated=[1-9]", row$value, perl = TRUE)
}

drm_twin_rank_tol <- 1e-8

drm_fixed_effect_rank_deficient <- function(object) {
  X <- drm_fixed_effect_design_matrices(object)
  if (is.null(X) || length(X) == 0L) {
    return(FALSE)
  }
  for (block in X) {
    if (
      is.null(block) ||
        (!is.matrix(block) && !inherits(block, "Matrix"))
    ) {
      next
    }
    dims <- dim(block)
    if (is.null(dims) || length(dims) != 2L || dims[[2L]] <= 0L) {
      next
    }
    block_rank <- qr(block, tol = drm_twin_rank_tol)$rank
    if (block_rank < dims[[2L]]) {
      return(TRUE)
    }
  }
  FALSE
}

drm_fixed_effect_design_matrices <- function(object) {
  X <- object$model$X
  if (is.null(X) || length(X) == 0L || is.null(names(X))) {
    return(X)
  }
  random_scale <- object$model$random_scale
  if (!is.list(random_scale)) {
    return(X)
  }
  for (dpar in c("mu", "sigma")) {
    design_name <- paste0("sd_", dpar)
    sd_model <- random_scale[[dpar]]
    if (
      design_name %in% names(X) &&
        is.list(sd_model) &&
        length(sd_model$n_models) == 1L &&
        !is.na(sd_model$n_models) &&
        sd_model$n_models == 0L
    ) {
      X[[design_name]] <- NULL
    }
  }
  X
}

drm_inference_at_boundary <- function(object) {
  if (!drm_optimizer_converged(object) || drm_inference_degenerate(object)) {
    return(FALSE)
  }
  rho_row <- check_rho12_boundary(object, rho_boundary = 0.98)
  if (!is.null(rho_row) && identical(rho_row$status, "warning")) {
    return(TRUE)
  }
  sd_row <- check_random_effect_sd_boundary(object, sd_boundary = 1e-4)
  !is.null(sd_row) && identical(sd_row$status, "warning")
}

#' @rdname check_drm
#' @export
check_drm.drmTMB <- function(
  object,
  gradient_tolerance = 1e-3,
  rho_boundary = 0.98,
  sd_boundary = 1e-4,
  ...
) {
  dots <- list(...)
  if (length(dots) > 0L) {
    cli::cli_abort(
      "{.arg ...} is reserved for future {.fn check_drm} diagnostic options."
    )
  }
  validate_check_scalar(gradient_tolerance, "gradient_tolerance", lower = 0)
  validate_check_scalar(rho_boundary, "rho_boundary", lower = 0, upper = 1)
  validate_check_scalar(sd_boundary, "sd_boundary", lower = 0)

  rows <- list(
    check_optimizer_convergence(object),
    check_convergence_status(object),
    check_optimizer_budget(object),
    check_finite_objective(object),
    check_logsigma_clamp_active(object),
    check_fixed_gradient(object, gradient_tolerance = gradient_tolerance),
    check_sdreport_status(object),
    check_hessian(object),
    check_hessian_conditioning(object),
    check_standard_errors_finite(object),
    check_standard_errors_inflated(object),
    check_weakly_identified_fixed_effects(object),
    check_observations_per_parameter(object),
    check_fixed_effect_design_collinearity(object),
    check_fixed_effect_rank_deficiency(object),
    check_dropped_rows(object),
    check_scale_positive(object),
    check_random_effect_sd_boundary(object, sd_boundary = sd_boundary),
    check_interval_reliability_scope(object),
    check_rho12_boundary(object, rho_boundary = rho_boundary),
    check_student_nu(object),
    check_skew_normal_nu(object),
    check_known_v(object),
    check_fixed_effect_design_size(object),
    check_gaussian_aggregation(object),
    check_random_effect_replication(object, "mu"),
    check_random_effect_replication(object, "sigma"),
    check_random_effect_design(object, "mu"),
    check_random_effect_design(object, "sigma"),
    check_mu_sigma_random_effect_covariance(
      object,
      rho_boundary = rho_boundary
    ),
    check_biv_mu_sigma_random_effect_covariance(
      object,
      rho_boundary = rho_boundary
    ),
    check_biv_mu_random_effect_covariance(
      object,
      rho_boundary = rho_boundary
    ),
    check_biv_sigma_random_effect_covariance(
      object,
      rho_boundary = rho_boundary
    ),
    check_biv_q4_random_effect_covariance(
      object,
      rho_boundary = rho_boundary
    ),
    check_phylo_replication(object),
    check_phylo_mu_diagnostics(object),
    check_spatial_mu_diagnostics(object),
    check_mesh_spatial_mu_diagnostics(object),
    check_known_relatedness_mu_diagnostics(object),
    check_phylo_direct_sd_model(object),
    check_phylo_sd_shared_shift(object),
    check_biv_phylo_mu_covariance(object, rho_boundary = rho_boundary),
    check_biv_structured_q2_covariance(object, rho_boundary = rho_boundary),
    check_biv_structured_q4_covariance(object, rho_boundary = rho_boundary),
    check_scale_phylo_identifiability(object),
    check_penalized_fit(object)
  )
  rows <- Filter(Negate(is.null), rows)
  out <- do.call(rbind, rows)
  rownames(out) <- NULL
  class(out) <- c("drm_check", "data.frame")
  attr(out, "ok") <- !any(out$status %in% c("warning", "error"))
  attr(out, "n_checks_total") <- nrow(out)
  out
}

#' @export
`[.drm_check` <- function(x, i, j, drop = FALSE) {
  n_total <- attr(x, "n_checks_total")
  if (is.null(n_total)) {
    n_total <- nrow(x)
  }
  out <- NextMethod("[")
  if (!is.data.frame(out)) {
    return(out)
  }
  class(out) <- c("drm_check", "data.frame")
  attr(out, "n_checks_total") <- n_total
  attr(out, "ok") <- attr(x, "ok")
  out
}

#' @export
print.drm_check <- function(x, ...) {
  n_total <- attr(x, "n_checks_total")
  if (!is.null(n_total) && nrow(x) < n_total) {
    cat(sprintf("<drm_check: %d of %d checks shown>\n", nrow(x), n_total))
  } else {
    cat(sprintf("<drm_check: %d checks>\n", nrow(x)))
  }
  n_warn <- sum(x$status == "warning")
  n_error <- sum(x$status == "error")
  n_note <- sum(x$status == "note")
  cli::cli_text(
    "  ok: {sum(x$status == 'ok')}; notes: {n_note}; warnings: {n_warn}; errors: {n_error}"
  )
  print.data.frame(x, row.names = FALSE, ...)
  invisible(x)
}

check_row <- function(check, status, value, message) {
  data.frame(
    check = check,
    status = status,
    value = as.character(value),
    message = as.character(message),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

# Honest guidance for a weakly identified scale-side phylogenetic field.
# Returns NULL unless the model places a phylogenetic field on the scale (sigma);
# emits an "ok" row when the fit reached a positive-definite Hessian and a "note"
# (not a warning -- the Hessian check already warns) steering the user to a
# fixed-effect scale otherwise. See
# docs/design/171-scale-side-phylo-identifiability-model-a.md.
check_scale_phylo_identifiability <- function(object) {
  phylo_mu <- object$model$structured$phylo_mu
  if (is.null(phylo_mu) || !isTRUE(phylo_mu$has)) {
    return(NULL)
  }
  endpoints <- phylo_mu_endpoint_dpars(phylo_mu)
  has_scale_phylo <- any(sub("[0-9]+$", "", endpoints) == "sigma")
  if (!has_scale_phylo) {
    return(NULL)
  }
  pd_hess <- object$sdr$pdHess
  if (is.null(pd_hess)) {
    return(NULL)
  }
  if (isTRUE(pd_hess)) {
    return(check_row(
      "scale_phylo_identifiability",
      "ok",
      "scale-side phylogenetic field; pdHess = TRUE",
      "A phylogenetic field on the scale converged with a positive-definite Hessian."
    ))
  }
  check_row(
    "scale_phylo_identifiability",
    "note",
    "scale-side phylogenetic field; pdHess not TRUE",
    paste0(
      "This fit places a phylogenetic field on the scale (sigma) but did not reach ",
      "a positive-definite Hessian. A scale-side phylogenetic field is often weakly ",
      "identified, especially with about one observation per group. Consider ",
      "modelling the scale with fixed effects only while keeping phylogeny on the ",
      "mean, or supplying more observations per group. See ",
      "docs/design/171-scale-side-phylo-identifiability-model-a.md."
    )
  )
}

check_penalized_fit <- function(object) {
  if (is.null(object$penalty)) {
    return(NULL)
  }
  check_row(
    "penalized_map",
    "note",
    "penalized / MAP estimator (prior on the phylogenetic SD)",
    paste0(
      "This fit uses a penalized / maximum-a-posteriori estimator: a prior ",
      "regularises the phylogenetic SD. Standard errors are ",
      "credible-interval-shaped, and likelihood-ratio tests or AIC across ",
      "penalized fits are not standard. logLik() returns the unpenalized data ",
      "log-likelihood; the penalty contribution is stored as fit$phylo_penalty."
    )
  )
}

validate_check_scalar <- function(x, name, lower = -Inf, upper = Inf) {
  if (
    !is.numeric(x) ||
      length(x) != 1L ||
      is.na(x) ||
      !is.finite(x) ||
      x <= lower ||
      x >= upper
  ) {
    cli::cli_abort(
      "{.arg {name}} must be a finite numeric scalar between {lower} and {upper}."
    )
  }
  invisible(x)
}

check_optimizer_convergence <- function(object) {
  convergence <- object$opt$convergence
  ok <- identical(as.integer(convergence), 0L)
  message <- if (ok) {
    "nlminb convergence code is 0."
  } else {
    paste("nlminb convergence message:", object$opt$message)
  }
  check_row(
    "optimizer_convergence",
    if (ok) "ok" else "warning",
    convergence,
    message
  )
}

check_optimizer_budget <- function(object) {
  iterations <- object$opt$iterations
  evaluations <- object$opt$evaluations
  function_evaluations <- optimizer_evaluation_count(evaluations, "function")
  gradient_evaluations <- optimizer_evaluation_count(evaluations, "gradient")

  control <- object$control$optimizer
  if (is.null(control)) {
    control <- list()
  }
  iter_max <- optimizer_budget_limit(control, "iter.max")
  eval_max <- optimizer_budget_limit(control, "eval.max")

  hit_iter <- optimizer_budget_reached(iterations, iter_max)
  hit_eval <- optimizer_budget_reached(function_evaluations, eval_max)
  hit_budget <- hit_iter || hit_eval
  converged <- identical(as.integer(object$opt$convergence), 0L)

  value <- paste0(
    "iterations=",
    format_optimizer_count(iterations),
    "; function=",
    format_optimizer_count(function_evaluations),
    "; gradient=",
    format_optimizer_count(gradient_evaluations)
  )
  message <- if (hit_budget) {
    paste(
      "Optimizer reached a supplied evaluation or iteration limit;",
      "inspect convergence, gradients, and model structure before increasing",
      "`eval.max` or `iter.max`."
    )
  } else if (length(control) > 0L) {
    "Optimizer stayed below supplied evaluation and iteration limits."
  } else {
    "Optimizer evaluation counts recorded; no eval.max or iter.max control was supplied."
  }

  check_row(
    "optimizer_budget",
    if (hit_budget && !converged) {
      "warning"
    } else if (hit_budget) {
      "note"
    } else {
      "ok"
    },
    value,
    message
  )
}

optimizer_evaluation_count <- function(evaluations, name) {
  if (is.null(evaluations) || is.null(evaluations[[name]])) {
    return(NA_real_)
  }
  as.numeric(evaluations[[name]])
}

optimizer_budget_limit <- function(control, name) {
  if (is.null(control[[name]])) {
    return(NA_real_)
  }
  as.numeric(control[[name]])
}

optimizer_budget_reached <- function(count, limit) {
  length(count) == 1L &&
    length(limit) == 1L &&
    is.finite(count) &&
    is.finite(limit) &&
    count >= limit
}

format_optimizer_count <- function(x) {
  if (length(x) != 1L || !is.finite(x)) {
    return("NA")
  }
  as.character(as.integer(x))
}

check_finite_objective <- function(object) {
  values <- if (drm_is_mspl(object)) {
    c(object$opt$objective, object$mspl$unpenalized_laplace_objective)
  } else {
    c(object$opt$objective, object$logLik)
  }
  ok <- all(is.finite(values))
  check_row(
    "finite_objective",
    if (ok) "ok" else "error",
    format_check_number(object$opt$objective),
    if (ok) {
      if (drm_is_mspl(object)) {
        "Penalized and separately evaluated unpenalized Laplace objectives are finite."
      } else {
        "Objective and log-likelihood are finite."
      }
    } else {
      if (drm_is_mspl(object)) {
        "The penalized or unpenalized Laplace objective is not finite."
      } else {
        "Objective or log-likelihood is not finite."
      }
    }
  )
}

# Diagnostic-surface complement to the fit-time clamp-active warning: flag when
# the log(sigma) soft-clamp is active at the optimum, where the fit may have
# converged artificially on the flat saturated tail.
check_logsigma_clamp_active <- function(object) {
  spec <- object$model
  fields <- drm_active_logsigma_clamp_fields(spec)
  if (length(fields) == 0L) {
    return(check_row(
      "logsigma_clamp_active",
      "ok",
      NA,
      "The log-scale clamp does not apply to this model."
    ))
  }
  # This runs post-hoc on a stored fit, whose `obj$env$last.par` was left a
  # finite-difference step away from the optimum by `TMB::sdreport()` during the
  # fit. A bare `report()` defaults to `last.par`, so the clamp would be judged --
  # and its value printed -- off-optimum. Report at the fit's stored `tmb_state`,
  # which was captured before sdreport. Passing the parameter vector rather than
  # re-pinning matters: a pin would MUTATE the stored fit's TMB object as a side
  # effect of running a diagnostic, and a diagnostic must not change the object
  # it inspects.
  report <- tryCatch(
    object$obj$report(object$tmb_state$last.par.best),
    error = function(e) NULL
  )
  if (is.null(report)) {
    return(check_row(
      "logsigma_clamp_active",
      "note",
      NA,
      "Cannot check the log(sigma) clamp without the TMB object (keep_tmb_object = FALSE)."
    ))
  }
  info <- drm_logsigma_clamp_active(report, spec$tmb_data, fields = fields)
  if (is.null(info)) {
    return(check_row(
      "logsigma_clamp_active",
      "ok",
      NA,
      "The log-scale clamp is not active at the optimum."
    ))
  }
  if (identical(info$kind, "latent random-effect SD")) {
    if (identical(info$arm, "lower")) {
      return(check_row(
        "logsigma_clamp_active",
        "note",
        format_check_number(info$value),
        sprintf(
          "The fitted latent random-effect SD log predictor reached %.2f, below the clamp band lower bound %g; the SD may be near zero or weakly identified. Inspect the group-level design, replication, and SD profile before interpreting the scale contrast.",
          info$value, info$lo
        )
      ))
    }
    return(check_row(
      "logsigma_clamp_active",
      "warning",
      format_check_number(info$value),
      sprintf(
        "The fitted latent random-effect SD log predictor reached %.2f, above the clamp band upper bound %g; the scale fit may have converged artificially and estimates and SEs near the clamp are unreliable.",
        info$value, info$hi
      )
    ))
  }
  # Both clamp arms are reported (Dinnage audit C1). The upper arm keeps
  # warning strength: a scale running to +Inf is artificial convergence. The
  # lower arm is a note: sigma -> 0 is a legitimate result when the residual
  # scale is genuinely zero (for example a meta-analysis at tau = 0), but the
  # same arm also fires when the response sits on a very small numeric scale
  # and the scale coefficients are badly wrong, so it must not be silent.
  if (identical(info$arm, "lower")) {
    return(check_row(
      "logsigma_clamp_active",
      "note",
      format_check_number(info$value),
      sprintf(
        paste(
          "The fitted log(sigma) reached %.2f, below the clamp band lower bound %g;",
          "the scale ran to the lower clamp. This is expected when the residual",
          "scale is genuinely zero (for example a meta-analysis with tau = 0), but",
          "it also happens when the response is on a very small numeric scale and",
          "the scale coefficients are wrong: compare sigma() with the spread of the",
          "response and consider rescaling the response before refitting."
        ),
        info$value,
        info$lo
      )
    ))
  }
  check_row(
    "logsigma_clamp_active",
    "warning",
    format_check_number(info$value),
    sprintf(
      "The fitted log(sigma) reached %.2f, above the clamp band upper bound %g; the scale ran to the clamp and the fit may have converged artificially (estimates and SEs near the clamp are unreliable).",
      info$value,
      info$hi
    )
  )
}

check_fixed_gradient <- function(object, gradient_tolerance) {
  if (is.null(object$obj)) {
    return(check_row(
      "fixed_gradient",
      "note",
      NA_character_,
      paste(
        "TMB object was not retained;",
        "refit with drm_control(keep_tmb_object = TRUE) to check fixed gradients."
      )
    ))
  }
  gradient <- tryCatch(
    as.numeric(object$obj$gr(object$opt$par)),
    error = function(e) e
  )
  if (inherits(gradient, "error")) {
    return(check_row(
      "fixed_gradient",
      "warning",
      NA_character_,
      paste("Could not evaluate TMB gradient:", conditionMessage(gradient))
    ))
  }
  if (!all(is.finite(gradient))) {
    return(check_row(
      "fixed_gradient",
      "error",
      NA_character_,
      "At least one fixed-parameter gradient is not finite."
    ))
  }
  max_abs <- max(abs(gradient), 0)
  max_index <- if (length(gradient) > 0L) {
    which.max(abs(gradient))
  } else {
    NA_integer_
  }
  max_component <- fixed_gradient_component_label(object, gradient, max_index)
  ok <- max_abs <= gradient_tolerance
  check_row(
    "fixed_gradient",
    if (ok) "ok" else "warning",
    paste0(
      "max=",
      format_check_number(max_abs),
      "; component=",
      max_component
    ),
    if (ok) {
      paste0(
        "Maximum absolute fixed gradient is <= ",
        gradient_tolerance,
        "; largest component is ",
        max_component,
        "."
      )
    } else {
      paste0(
        "Maximum absolute fixed gradient is > ",
        gradient_tolerance,
        "; largest component is ",
        max_component,
        "."
      )
    }
  )
}

fixed_gradient_component_label <- function(object, gradient, index) {
  if (length(index) != 1L || is.na(index)) {
    return("none")
  }
  labels <- names(object$opt$par)
  if (is.null(labels) || length(labels) != length(gradient)) {
    labels <- names(gradient)
  }
  if (is.null(labels) || length(labels) != length(gradient)) {
    labels <- paste0("par", seq_along(gradient))
  }
  labels[is.na(labels) | !nzchar(labels)] <- paste0(
    "par",
    which(is.na(labels) | !nzchar(labels))
  )
  labels <- disambiguate_duplicate_labels(labels)
  labels[[index]]
}

disambiguate_duplicate_labels <- function(labels) {
  duplicated_labels <- labels %in% labels[duplicated(labels)]
  if (!any(duplicated_labels)) {
    return(labels)
  }
  sequence <- stats::ave(seq_along(labels), labels, FUN = seq_along)
  labels[duplicated_labels] <- paste0(
    labels[duplicated_labels],
    "[",
    sequence[duplicated_labels],
    "]"
  )
  labels
}

check_hessian <- function(object) {
  if (drm_is_mspl(object)) {
    pd_hess <- isTRUE(object$mspl$numerical$hessian_positive_definite)
    return(check_row(
      "hessian_positive_definite",
      if (pd_hess) "ok" else "warning",
      pd_hess,
      if (pd_hess) {
        "The separately evaluated MSPL outer Hessian is positive definite."
      } else {
        "The separately evaluated MSPL outer Hessian is not positive definite."
      }
    ))
  }
  if (is.null(object$sdr)) {
    return(check_row(
      "hessian_positive_definite",
      drm_uncertainty_check_status(object),
      NA_character_,
      paste(
        "Hessian status is unavailable because",
        drm_uncertainty_message(object)
      )
    ))
  }
  pd_hess <- isTRUE(object$sdr$pdHess)
  check_row(
    "hessian_positive_definite",
    if (pd_hess) "ok" else "warning",
    pd_hess,
    if (pd_hess) {
      "sdreport reports a positive-definite Hessian."
    } else {
      "sdreport does not report a positive-definite Hessian."
    }
  )
}

# Minimum eigenvalue and condition number of the fixed-effect Hessian at the
# optimum (drmTMB/DRM.jl issue #569). `check_hessian()` above reports only a
# bare `pdHess` boolean; this row makes "how near-singular" a comparable
# number rather than a yes/no. It is a genuinely different read of the same
# object than TMB's internal pdHess computation -- it is not claimed to be
# numerically identical, only comparable.
#
# THIS ROW NEVER CALLS THE TMB C++ OBJECT. An earlier version evaluated
# `object$obj$he(object$opt$par)` directly. That SEGFAULTED (uncatchable by
# `tryCatch()`, took the whole R session down) on any fit that had been
# through `saveRDS()`/`readRDS()`: the TMB external pointer reads dead on
# entry to `check_drm()` but is REVIVED before this row runs, and the
# revived pointer's AD tape is unusable for `he()` even though `gr()`
# tolerates it. Pointer-liveness is the wrong predicate to guard on (it
# reads live by the time this code runs), so no guard can fix it -- the only
# fix is to never make the call. Measured 2026-09-01/02 (see
# docs/dev-log/after-task/2026-09-01-b2-check-conditioning.md sec 13):
# `object$sdr$cov.fixed` is an already-materialized numeric matrix (no C++
# call at all), present after serialization, and gives the same condition
# number and an algebraically equivalent minimum eigenvalue to six
# significant figures on a well-conditioned fit (measured: cond(H) =
# 2.408905027 vs cond(cov) = 2.408903421; min_eig(H) = 180 vs
# 1/max_eig(cov) = 180.00012). This also closes what was a documented scope
# gap: `obj$he()` has no Laplace support, so this row was a permanent `note`
# with value `NA` for every random-effect or REML fit -- exactly the model
# class the R/Julia parity programme is mostly about. `sdr$cov.fixed` IS
# populated for those fits (measured on a random-intercept fit: 4x4,
# cond = 7.065, implied min_eig(H) = 39.908), so `hessian_conditioning` now
# reports a real number there too.
#
# For an MSPL fit, `hessian_conditioning_row()` still reuses the eigenvalues
# already computed by `drm_mspl_hessian_diagnostics()` (`optimHess()` on the
# unpenalized Laplace objective) -- that path was never the source of the
# crash and is unrelated to `sdr$cov.fixed`.
check_hessian_conditioning <- function(object) {
  if (drm_is_mspl(object)) {
    eig <- object$mspl$numerical$hessian_eigenvalues
    if (is.null(eig) || length(eig) == 0L || !all(is.finite(eig))) {
      return(check_row(
        "hessian_conditioning",
        "note",
        NA_character_,
        "Hessian eigenvalues are unavailable for this MSPL fit."
      ))
    }
    return(hessian_conditioning_row(
      eig,
      "the separately evaluated MSPL outer Hessian (optimHess on the unpenalized Laplace objective)"
    ))
  }
  if (is.null(object$sdr)) {
    return(check_row(
      "hessian_conditioning",
      "note",
      NA_character_,
      paste(
        "Hessian conditioning is unavailable because this fit has no",
        "TMB::sdreport() object: either drm_control(se = FALSE) was used, or",
        "sdreport() failed. If se = TRUE was already in force (the default),",
        "the design is usually rank-deficient: look for a duplicated predictor",
        "column or a factor level with no observations (drmTMB drops unused",
        "levels on entry since the Dinnage audit, Md-E), then refit."
      )
    ))
  }
  cov <- object$sdr$cov.fixed
  if (
    is.null(cov) ||
      !is.matrix(cov) ||
      nrow(cov) == 0L ||
      !all(is.finite(cov))
  ) {
    return(check_row(
      "hessian_conditioning",
      "note",
      NA_character_,
      paste(
        "Hessian conditioning is unavailable because sdr$cov.fixed is",
        "absent, empty, or contains non-finite entries (an incomplete",
        "sdreport() result); inspect sdreport_status and",
        "hessian_positive_definite before interpreting this fit's SEs."
      )
    ))
  }
  hessian_conditioning_cov_row(
    cov,
    "TMB's sdreport() fixed-effect covariance (sdr$cov.fixed), inverted"
  )
}

hessian_conditioning_ill_threshold <- 1e8

# Roundoff floor for TRUSTING the SIGN of `sdr$cov.fixed`'s most extreme
# (algebraically smallest) eigenvalue, in the COVARIANCE's own eigenvalue
# scale -- not the Hessian's. `cov.fixed` is an ordinary already-materialized
# double-precision matrix (TMB's own solve of the Hessian), decomposed here
# with `eigen()`, an ordinary dense symmetric LAPACK eigensolver -- the same
# kind of computation `check_known_v()` elsewhere in this file already
# tolerance-gates with a `sqrt(eps) * scale` floor for exactly this reason
# (backward-stability bounds eigenvalue error by a small multiple of
# `eps * ||matrix||_2` for this class of solver). Re-used here rather than
# the AD-Hessian-specific `eps`-only floor the earlier `obj$he()` version
# used: that floor was calibrated to AD's own (tighter) roundoff behaviour,
# which no longer applies once the matrix in hand is `cov.fixed`, not a
# freshly evaluated AD Hessian.
hessian_conditioning_cov_eps_multiplier <- sqrt(.Machine$double.eps)

# Computes the fixed-effect Hessian's conditioning FROM `sdr$cov.fixed`
# without ever forming or inverting the Hessian directly (no C++ call; see
# the comment above `check_hessian_conditioning()`).
#
# `cov.fixed`'s eigenvalues `mu_i` are the RECIPROCALS of the Hessian's
# eigenvalues (same eigenvectors, `H = cov^{-1}`, `mu_i = 1 / lambda_i`).
# Only the two ALGEBRAIC extremes of `mu` -- `mu_max` and `mu_min` -- can map
# to an extreme (smallest, most negative, or smallest positive) Hessian
# eigenvalue; every intermediate `mu` maps to an unremarkable, non-extreme
# Hessian eigenvalue and is never the one this diagnostic reports. That
# matters because the mapping is NOT scale-symmetric across a sign change:
# when `cov.fixed` has a genuinely negative eigenvalue (an indefinite
# Hessian; `pdHess = FALSE`), `mu_min` -- not `mu_max` -- is the one whose
# reciprocal exposes it, however small that reciprocal is in Hessian-scale
# (e.g. measured: `mu_min = -2.1e11` well beyond the tolerance floor below
# reciprocates to `min_eig(H) = -4.76e-12`, a numerically tiny value that
# would have been misread as roundoff dust had it been tested directly on
# the Hessian scale, exactly the failure this function avoids by testing
# reliability on `mu_min` BEFORE taking its reciprocal, not after).
#
# The reliability test is therefore on `mu_min` itself, at the covariance's
# own scale: only when `|mu_min|` clears `hessian_conditioning_cov_eps_multiplier
# * eps * max(|mu_max|, |mu_min|, 1)` is `mu_min`'s negative sign trusted; a
# `mu_min` at or below that floor is deferred to the ordinary `mu_max`-based
# (well-conditioned/positive-definite) formula, matching the same "unreliable
# sign, defer to ok" reasoning the earlier AD-Hessian version used, just
# anchored to the quantity that actually carries the roundoff here.
hessian_conditioning_cov_row <- function(cov, source) {
  eig_cov <- eigen(
    (cov + t(cov)) / 2,
    symmetric = TRUE,
    only.values = TRUE
  )$values
  mu_max <- max(eig_cov)
  mu_min <- min(eig_cov)
  max_abs_cov <- max(abs(eig_cov))
  min_abs_cov <- min(abs(eig_cov))
  tol_cov <- hessian_conditioning_cov_eps_multiplier *
    max(max_abs_cov, 1)

  mu_min_trusted_negative <- mu_min < -tol_cov
  min_eig <- if (mu_min_trusted_negative) 1 / mu_min else 1 / mu_max
  condition <- if (min_abs_cov <= 0) Inf else max_abs_cov / min_abs_cov

  status <- if (mu_min_trusted_negative) {
    "warning"
  } else if (condition > hessian_conditioning_ill_threshold) {
    "note"
  } else {
    "ok"
  }

  check_row(
    "hessian_conditioning",
    status,
    paste0(
      "min_eig=",
      format_check_number(min_eig),
      "; cond=",
      format_check_number(condition)
    ),
    paste0(
      "Minimum eigenvalue and condition number of ",
      source,
      ". These are a genuinely different read of the fit's conditioning than ",
      "TMB's internal pdHess flag -- comparable across fits, not claimed to be ",
      "numerically identical to any raw TMB gradient or Hessian quantity. ",
      if (identical(status, "warning")) {
        paste(
          "The covariance's own smallest eigenvalue is negative well beyond",
          "the roundoff floor, so the implied minimum Hessian eigenvalue is",
          "trusted as genuinely negative -- matching a non-PD Hessian; treat",
          "standard errors and correlations among the affected parameters as",
          "unreliable."
        )
      } else if (identical(status, "note")) {
        paste0(
          "The condition number exceeds ",
          hessian_conditioning_ill_threshold,
          ", signalling a near-flat, weakly identified direction; a clean",
          " pdHess is necessary, not sufficient. Treat standard errors and",
          " correlations among the affected parameters with caution."
        )
      } else {
        "This fit's Hessian conditioning is within the requested threshold."
      }
    )
  )
}

# Reused only by the MSPL path above, whose eigenvalues come directly from
# `drm_mspl_hessian_diagnostics()`'s `optimHess()` call (a Hessian evaluated
# once at fit time and stored, not `obj$he()`), so it is unaffected by, and
# not part of, the `obj$he()` removal described above.
hessian_conditioning_eps_multiplier <- 100

hessian_conditioning_row <- function(eig, source) {
  min_eig <- min(eig)
  max_abs_eig <- max(abs(eig))
  tol <- hessian_conditioning_eps_multiplier *
    .Machine$double.eps *
    max(max_abs_eig, 1)

  # Three regimes, in order of how much the sign/magnitude of `min_eig` can
  # be trusted:
  # 1. `min_eig < -tol`: robustly, resolvably negative -- the same signal as
  #    a non-PD Hessian, so it is a "warning" like `check_hessian()`.
  # 2. `abs(min_eig) <= tol`: at the roundoff floor. Its sign is not
  #    trustworthy and any condition number computed by dividing by it would
  #    itself be roundoff-dominated. Reported as "ok": `pdHess` already
  #    covers whether TMB itself judged this fit positive-definite, and
  #    fabricating a numerically unstable condition number here would be
  #    decoration, not signal.
  # 3. `min_eig > tol`: resolvably positive. A positive but ill-conditioned
  #    Hessian is a different, milder signal than case 1: a near-flat,
  #    weakly identified direction (the same phenomenon
  #    `check_standard_errors_inflated()` reports as a "note" despite
  #    `pdHess = TRUE`, e.g. a poorly identified Student-t `nu`), so it is a
  #    "note" and does not flip the fit's overall `ok` status.
  if (min_eig < -tol) {
    status <- "warning"
    condition <- Inf
  } else if (abs(min_eig) <= tol) {
    status <- "ok"
    condition <- max_abs_eig / max(abs(min_eig), .Machine$double.eps)
  } else {
    condition <- max_abs_eig / min_eig
    status <- if (condition > hessian_conditioning_ill_threshold) {
      "note"
    } else {
      "ok"
    }
  }

  check_row(
    "hessian_conditioning",
    status,
    paste0(
      "min_eig=",
      format_check_number(min_eig),
      "; cond=",
      format_check_number(condition)
    ),
    paste0(
      "Minimum eigenvalue and condition number of ",
      source,
      ". These are a genuinely different read of the fit's conditioning than ",
      "TMB's internal pdHess flag -- comparable across fits, not claimed to be ",
      "numerically identical to any raw TMB gradient or Hessian quantity. ",
      if (identical(status, "warning")) {
        paste(
          "The minimum eigenvalue is negative well beyond the roundoff",
          "floor, matching a non-PD Hessian; treat standard errors and",
          "correlations among the affected parameters as unreliable."
        )
      } else if (abs(min_eig) <= tol) {
        paste0(
          "The minimum eigenvalue is within a machine-epsilon-scaled floor ",
          "of zero (|min_eig| <= ",
          format_check_number(tol),
          "); its sign and any condition number computed from it are not ",
          "reliable, so this is reported as ok and defers to pdHess."
        )
      } else if (identical(status, "note")) {
        paste0(
          "The condition number exceeds ",
          hessian_conditioning_ill_threshold,
          " with a resolvably positive minimum eigenvalue, signalling a ",
          "near-flat, weakly identified direction; a clean pdHess is ",
          "necessary, not sufficient. Treat standard errors and correlations ",
          "among the affected parameters with caution."
        )
      } else {
        "This fit's Hessian conditioning is within the requested threshold."
      }
    )
  )
}

check_sdreport_status <- function(object) {
  status <- drm_uncertainty_status(object)
  check_row(
    "sdreport_status",
    switch(
      status,
      ok = "ok",
      skipped = "note",
      unsupported = "note",
      failed = "warning",
      "warning"
    ),
    status,
    drm_uncertainty_message(object)
  )
}

check_standard_errors_finite <- function(object) {
  vcov <- tryCatch(stats::vcov(object), error = function(e) e)
  if (inherits(vcov, "error")) {
    return(check_row(
      "standard_errors_finite",
      drm_uncertainty_check_status(object),
      NA_character_,
      paste(
        "Could not extract fixed-effect standard errors:",
        conditionMessage(vcov)
      )
    ))
  }

  variances <- diag(vcov)
  standard_errors <- rep(NA_real_, length(variances))
  non_negative <- is.finite(variances) & variances >= 0
  standard_errors[non_negative] <- sqrt(variances[non_negative])
  ok <- length(standard_errors) > 0L &&
    all(is.finite(standard_errors)) &&
    all(variances >= 0)
  finite_standard_errors <- standard_errors[is.finite(standard_errors)]
  value <- if (length(finite_standard_errors) == 0L) {
    NA_character_
  } else {
    paste0(
      "range=[",
      format_check_number(min(finite_standard_errors)),
      ",",
      format_check_number(max(finite_standard_errors)),
      "]"
    )
  }

  check_row(
    "standard_errors_finite",
    if (ok) "ok" else "warning",
    value,
    if (ok) {
      "All fixed-effect standard errors are finite."
    } else {
      "At least one fixed-effect standard error is non-finite; inspect Hessian status, identifiability, and model scaling."
    }
  )
}

# Flag a finite-but-pathological standard error on a fit that TMB reports as
# converged with a positive-definite Hessian (issue #19; A. Mizuno's point 6). A
# clean `pdHess` is necessary, not sufficient: a near-flat, weakly identified
# direction (typically a correlation or SD running to a boundary) leaves the
# numerical Hessian barely positive-definite while the Wald SE explodes. A
# parameter is flagged only when its SE is BOTH absolutely large AND vastly
# larger than the typical parameter's SE, so ordinary well-identified fits do not
# trip it. Non-finite SEs and a non-positive-definite Hessian are owned by
# `check_standard_errors_finite` and `check_hessian`, so this check defers when
# those already carry the signal.
inflated_standard_error_floor <- 50
inflated_standard_error_ratio <- 1000

check_standard_errors_inflated <- function(object) {
  if (is.null(object$sdr) || !isTRUE(object$sdr$pdHess)) {
    return(NULL)
  }
  vcov <- tryCatch(stats::vcov(object), error = function(e) NULL)
  if (is.null(vcov) || !is.matrix(vcov) || nrow(vcov) == 0L) {
    return(NULL)
  }
  variances <- diag(vcov)
  standard_errors <- rep(NA_real_, length(variances))
  non_negative <- is.finite(variances) & variances >= 0
  standard_errors[non_negative] <- sqrt(variances[non_negative])
  finite_standard_errors <- standard_errors[is.finite(standard_errors)]
  if (length(finite_standard_errors) == 0L) {
    return(NULL)
  }
  reference_se <- finite_standard_errors[
    finite_standard_errors < inflated_standard_error_floor
  ]
  if (length(reference_se) == 0L) {
    median_se <- min(finite_standard_errors)
  } else {
    median_se <- stats::median(reference_se)
  }
  inflated <- is.finite(standard_errors) &
    standard_errors >= inflated_standard_error_floor &
    standard_errors >= inflated_standard_error_ratio * median_se
  n_inflated <- sum(inflated)
  param_names <- rownames(vcov)
  if (is.null(param_names)) {
    param_names <- paste0("par", seq_along(standard_errors))
  }
  check_row(
    "standard_errors_inflated",
    if (n_inflated > 0L) "note" else "ok",
    paste0(
      "n_inflated=",
      n_inflated,
      "; max_se=",
      format_check_number(max(finite_standard_errors)),
      "; reference_median=",
      format_check_number(median_se),
      if (n_inflated > 0L) {
        paste0("; example=", param_names[which(inflated)[[1L]]])
      } else {
        ""
      }
    ),
    if (n_inflated > 0L) {
      paste(
        "At least one standard error is finite but extremely large despite a",
        "positive-definite Hessian (pdHess = TRUE), which signals a near-flat,",
        "weakly identified direction the Hessian did not resolve -- often a",
        "correlation or SD running to a boundary. Confirm with a likelihood",
        "profile (profile()) and consider a simpler model before interpreting",
        "the affected parameter; a clean Hessian is necessary, not sufficient."
      )
    } else {
      "No fixed-effect standard error is inflated relative to the others."
    }
  )
}

check_weakly_identified_fixed_effects <- function(object) {
  row <- check_standard_errors_inflated(object)
  if (is.null(row) || !grepl("n_inflated=[1-9]", row$value, perl = TRUE)) {
    return(NULL)
  }
  check_row(
    "weakly_identified_fixed_effects",
    "warning",
    row$value,
    paste(
      "At least one fixed-effect standard error is pathologically large",
      "relative to the reference scale; the fit is not identified enough for",
      "plain is_converged() to read TRUE and multi_start cannot clear this."
    )
  )
}

check_convergence_status <- function(object) {
  status <- convergence_status(object)
  check_row(
    "convergence_status",
    switch(
      status,
      converged = "ok",
      boundary = "note",
      degenerate = "note",
      "note"
    ),
    status,
    switch(
      status,
      converged = paste(
        "Optimizer convergence and uncertainty diagnostics are consistent with",
        "a proper interior optimum."
      ),
      boundary = paste(
        "The fit converged but variance-component or residual-correlation",
        "parameters are near an interpretability boundary; read",
        "convergence_status() and boundary rows before inference."
      ),
      degenerate = paste(
        "The optimizer reported success but the likelihood geometry or",
        "uncertainty is degenerate (no reliable maximum or non-finite",
        "standard errors). multi_start cannot clear this state;",
        "is_converged() is FALSE."
      ),
      "Convergence status could not be classified."
    )
  )
}

observations_per_parameter_threshold <- 10

check_observations_per_parameter <- function(object) {
  n_obs <- object$nobs
  n_par <- object$df
  if (
    is.null(n_obs) ||
      is.null(n_par) ||
      length(n_obs) != 1L ||
      length(n_par) != 1L ||
      !is.finite(n_obs) ||
      !is.finite(n_par) ||
      n_par <= 0
  ) {
    return(NULL)
  }
  ratio <- n_obs / n_par
  low <- ratio < observations_per_parameter_threshold
  check_row(
    "observations_per_parameter",
    if (low) "note" else "ok",
    paste0(
      "n_obs=",
      n_obs,
      "; n_par=",
      n_par,
      "; ratio=",
      format_check_number(ratio)
    ),
    if (low) {
      paste(
        "Fewer than",
        observations_per_parameter_threshold,
        "observations per estimated parameter; the diagnostic board does not",
        "become more cautious automatically at small n, so inspect effect",
        "sizes and uncertainty before interpreting tests."
      )
    } else {
      paste(
        "Observations per estimated parameter are at or above the small-sample",
        "note threshold (",
        observations_per_parameter_threshold,
        ").",
        sep = ""
      )
    }
  )
}

fixed_effect_collinearity_threshold <- 0.99

check_fixed_effect_design_collinearity <- function(
  object,
  r_threshold = fixed_effect_collinearity_threshold
) {
  X <- object$model$X
  if (is.null(X) || length(X) == 0L) {
    return(NULL)
  }
  max_abs_r <- NA_real_
  example <- NA_character_
  for (block in X) {
    if (
      is.null(block) ||
        (!is.matrix(block) && !inherits(block, "Matrix"))
    ) {
      next
    }
    cols <- colnames(block)
    if (is.null(cols)) {
      cols <- paste0("col", seq_len(ncol(block)))
    }
    numeric_cols <- which(vapply(
      seq_len(ncol(block)),
      function(j) {
        xj <- block[, j, drop = TRUE]
        is.numeric(xj) && stats::var(xj, na.rm = TRUE) > 0
      },
      logical(1L)
    ))
    if (length(numeric_cols) < 2L) {
      next
    }
    for (i in seq_len(length(numeric_cols) - 1L)) {
      for (j in (i + 1L):length(numeric_cols)) {
        ci <- numeric_cols[[i]]
        cj <- numeric_cols[[j]]
        r <- stats::cor(block[, ci], block[, cj], use = "complete.obs")
        if (!is.finite(r)) {
          next
        }
        abs_r <- abs(r)
        if (!is.finite(max_abs_r) || abs_r > max_abs_r) {
          max_abs_r <- abs_r
          example <- paste0(cols[[ci]], "~", cols[[cj]])
        }
      }
    }
  }
  if (!is.finite(max_abs_r)) {
    return(NULL)
  }
  high <- max_abs_r > r_threshold
  check_row(
    "fixed_effect_collinearity",
    if (high) "note" else "ok",
    paste0(
      "max_abs_r=",
      format_check_number(max_abs_r),
      if (high) paste0("; pair=", example) else ""
    ),
    if (high) {
      paste(
        "At least one pair of fixed-effect design columns has absolute",
        "correlation above",
        r_threshold,
        "; standard errors may be inflated even when the Hessian is",
        "positive-definite."
      )
    } else {
      "No fixed-effect design column pair exceeds the collinearity note threshold."
    }
  )
}

check_fixed_effect_rank_deficiency <- function(object) {
  X <- drm_fixed_effect_design_matrices(object)
  if (is.null(X) || length(X) == 0L) {
    return(NULL)
  }
  deficient <- character()
  for (i in seq_along(X)) {
    block <- X[[i]]
    if (
      is.null(block) ||
        (!is.matrix(block) && !inherits(block, "Matrix"))
    ) {
      next
    }
    dims <- dim(block)
    if (is.null(dims) || length(dims) != 2L || dims[[2L]] <= 0L) {
      next
    }
    block_rank <- qr(block, tol = drm_twin_rank_tol)$rank
    if (block_rank < dims[[2L]]) {
      name <- names(X)[[i]]
      if (is.null(name) || !nzchar(name)) {
        name <- paste0("X", i)
      }
      deficient <- c(
        deficient,
        paste0(name, ":rank=", block_rank, "/ncol=", dims[[2L]])
      )
    }
  }
  if (length(deficient) == 0L) {
    return(NULL)
  }
  check_row(
    "fixed_effect_rank_deficiency",
    "warning",
    paste(deficient, collapse = "; "),
    paste(
      "At least one fixed-effect design matrix is rank-deficient;",
      "coefficients and standard errors are not identified even when the",
      "optimizer reports convergence."
    )
  )
}

empty_dropped_groups <- function() {
  data.frame(
    variable = character(),
    n_lost = integer(),
    example = character(),
    stringsAsFactors = FALSE
  )
}

check_fit_input_data <- function(object) {
  keep <- object$model$keep
  if (is.null(keep)) {
    return(NULL)
  }
  data <- object$model$input_data
  if (!is.data.frame(data) || nrow(data) != length(keep)) {
    return(NULL)
  }
  data
}

check_random_grouping_variables <- function(object) {
  random <- object$model$random
  if (!is.list(random)) {
    return(character())
  }
  vars <- character()
  for (block in random) {
    if (is.list(block) && length(block$group_names) > 0L) {
      vars <- c(vars, unique(as.character(block$group_names)))
    }
  }
  unique(vars[nzchar(vars)])
}

check_dropped_group_levels <- function(object) {
  empty <- empty_dropped_groups()
  keep <- object$model$keep
  if (is.null(keep)) {
    return(empty)
  }
  data <- check_fit_input_data(object)
  if (is.null(data)) {
    return(empty)
  }
  vars <- check_random_grouping_variables(object)
  if (length(vars) == 0L) {
    return(empty)
  }
  rows <- list()
  for (var in vars) {
    if (!var %in% names(data)) {
      next
    }
    g <- data[[var]]
    if (all(is.na(g))) {
      next
    }
    levels <- if (is.factor(g)) {
      levels(g)
    } else {
      unique(as.character(g[!is.na(g)]))
    }
    lost <- character()
    for (le in levels) {
      rows_le <- which(!is.na(g) & as.character(g) == le)
      if (length(rows_le) == 0L) {
        next
      }
      if (!any(keep[rows_le])) {
        lost <- c(lost, le)
      }
    }
    if (length(lost) > 0L) {
      rows[[length(rows) + 1L]] <- data.frame(
        variable = var,
        n_lost = length(lost),
        example = lost[[1L]],
        stringsAsFactors = FALSE
      )
    }
  }
  if (length(rows) == 0L) {
    return(empty)
  }
  do.call(rbind, rows)
}

check_dropped_rows <- function(object) {
  keep <- object$model$keep
  if (is.null(keep)) {
    return(check_row(
      "dropped_rows",
      "note",
      NA_character_,
      "Original row filter is not stored on this fit."
    ))
  }
  dropped <- sum(!keep)
  dropped_groups <- check_dropped_group_levels(object)
  n_groups_lost <- if (nrow(dropped_groups) > 0L) {
    sum(dropped_groups$n_lost)
  } else {
    0L
  }
  group_value <- if (n_groups_lost > 0L) {
    paste0("; groups_lost=", n_groups_lost)
  } else {
    ""
  }
  group_message <- if (n_groups_lost > 0L) {
    first <- dropped_groups[1L, , drop = FALSE]
    paste0(
      " At least one grouping variable lost every row for one or more levels: ",
      first$variable[[1L]],
      " lost ",
      first$n_lost[[1L]],
      " level",
      if (first$n_lost[[1L]] == 1L) "" else "s",
      if (nzchar(first$example[[1L]])) paste0(" (for example ", first$example[[1L]], ")") else "",
      "."
    )
  } else {
    ""
  }
  check_row(
    "dropped_rows",
    if (dropped == 0L && n_groups_lost == 0L) "ok" else "note",
    paste0("nobs=", object$nobs, "; dropped=", dropped, group_value),
    if (dropped == 0L && n_groups_lost == 0L) {
      "No rows were dropped by model-frame or known-covariance filtering."
    } else {
      paste0(
        "Rows were dropped by complete-case or known-covariance filtering.",
        group_message
      )
    }
  )
}

check_gaussian_aggregation <- function(object) {
  aggregation <- if (is.list(object$model$aggregation)) {
    object$model$aggregation$gaussian
  } else {
    NULL
  }
  summary <- drm_gaussian_aggregation_summary(aggregation)
  if (is.null(summary)) {
    return(NULL)
  }
  row <- summary[1L, , drop = FALSE]
  ratio <- row$compression_ratio[[1L]]
  check_row(
    "gaussian_aggregation",
    if (ratio > 1) "ok" else "note",
    paste0(
      "original_rows=",
      row$original_rows[[1L]],
      "; aggregation_cells=",
      row$aggregation_cells[[1L]],
      "; compression_ratio=",
      format_check_number(ratio),
      "; largest_cell_n=",
      row$largest_cell_n[[1L]]
    ),
    if (ratio > 1) {
      "Gaussian aggregation compressed repeated fixed-effect likelihood rows before TMB optimization."
    } else {
      "Gaussian aggregation was enabled, but no fixed-effect likelihood rows were collapsed."
    }
  )
}

check_scale_positive <- function(object) {
  scale_values <- tryCatch(stats::sigma(object), error = function(e) e)
  if (inherits(scale_values, "error")) {
    return(check_row(
      "positive_scale",
      "warning",
      NA_character_,
      paste("Could not extract scale values:", conditionMessage(scale_values))
    ))
  }
  scale_values <- unlist(scale_values, use.names = FALSE)
  ok <- length(scale_values) > 0L &&
    all(is.finite(scale_values)) &&
    all(scale_values > 0)
  check_row(
    "positive_scale",
    if (ok) "ok" else "error",
    paste0("min=", format_check_number(min(scale_values, na.rm = TRUE))),
    if (ok) {
      "All fitted scale values are finite and positive."
    } else {
      "At least one fitted scale value is non-positive or non-finite."
    }
  )
}

check_random_effect_sd_boundary <- function(object, sd_boundary) {
  sd_values <- unlist(object$sdpars, use.names = TRUE)
  if (length(sd_values) == 0L) {
    return(NULL)
  }
  if (is.null(names(sd_values))) {
    names(sd_values) <- paste0("sd", seq_along(sd_values))
  }
  missing_names <- !nzchar(names(sd_values)) | is.na(names(sd_values))
  names(sd_values)[missing_names] <- paste0("sd", which(missing_names))

  ok <- all(is.finite(sd_values)) && all(sd_values > 0)
  if (!ok) {
    return(check_row(
      "random_effect_sd_boundary",
      "error",
      NA_character_,
      "At least one fitted random-effect standard deviation is non-positive or non-finite."
    ))
  }

  min_index <- which.min(sd_values)
  min_value <- sd_values[[min_index]]
  min_name <- names(sd_values)[[min_index]]
  near_boundary <- min_value < sd_boundary

  check_row(
    "random_effect_sd_boundary",
    if (near_boundary) "warning" else "ok",
    paste0(
      "min=",
      format_check_number(min_value),
      "; boundary=",
      format_check_number(sd_boundary),
      "; term=",
      min_name
    ),
    if (near_boundary) {
      "At least one fitted random-effect standard deviation is near the lower boundary at zero."
    } else {
      "All fitted random-effect standard deviations are finite, positive, and above the requested lower-boundary warning threshold."
    }
  )
}

# `check_drm()` reads the FIT. Interval reliability is a different question and
# this function does not answer it: a random-effect SD estimate can sit well
# above `sd_boundary` -- clearing every check above -- while `confint()` still
# warns that the interval for that same target reaches a variance boundary,
# because the profile discovers the bound while profiling and the percentile
# bootstrap discovers it in the resamples. Measured on a 10-group Gaussian fit:
# SD estimate 0.1936 (comfortably clear of the 1e-4 threshold, every check ok)
# with 43% of bootstrap draws on the bound and a profile boundary warning.
#
# Left silent, that all-clear reads as permission to report the interval. This
# row makes the gate the documentation tells users to run state the limit of its
# own scope rather than imply coverage it never assessed. It deliberately
# invents no threshold and re-fits nothing.
check_interval_reliability_scope <- function(object) {
  sd_values <- unlist(object$sdpars, use.names = TRUE)
  if (length(sd_values) == 0L) {
    return(NULL)
  }
  n_targets <- length(sd_values)
  check_row(
    "interval_reliability_scope",
    "note",
    paste0("sd_targets=", n_targets, "; assessed_here=0"),
    paste0(
      "This fit has ",
      n_targets,
      " random-effect standard-deviation target",
      if (n_targets == 1L) "" else "s",
      ". `check_drm()` assesses the fit, not interval reliability: a target can pass every check above and still return an interval that `confint()` warns about at a variance boundary. Before reporting an interval, call `confint()` and read `conf.status` and any boundary warning."
    )
  )
}

check_rho12_boundary <- function(object, rho_boundary) {
  if (
    !object$model$model_type %in%
      c("biv_gaussian", "biv_lognormal", "biv_student")
  ) {
    return(NULL)
  }
  rho <- rho12(object)
  max_abs <- max(abs(rho), 0)
  ok <- all(is.finite(rho)) && max_abs <= rho_boundary
  check_row(
    "rho12_boundary",
    if (ok) "ok" else "warning",
    format_check_number(max_abs),
    if (ok) {
      paste0(
        "All fitted residual correlations have absolute value <= ",
        rho_boundary,
        "."
      )
    } else {
      paste0(
        "At least one fitted residual correlation is close to +/-1 using boundary ",
        rho_boundary,
        ". A profile interval for residual rho12 at this boundary is usually identical to Wald; read conf.status on confint()."
      )
    }
  )
}

check_student_nu <- function(object) {
  if (!object$model$model_type %in% c("student", "biv_student")) {
    return(NULL)
  }
  nu <- tryCatch(predict(object, dpar = "nu"), error = function(e) e)
  if (inherits(nu, "error")) {
    return(check_row(
      "student_nu",
      "warning",
      NA_character_,
      paste("Could not extract Student-t nu values:", conditionMessage(nu))
    ))
  }
  if (!all(is.finite(nu)) || any(nu <= 2)) {
    return(check_row(
      "student_nu",
      "error",
      NA_character_,
      "At least one fitted Student-t nu value is non-finite or not above 2."
    ))
  }

  min_nu <- min(nu)
  max_nu <- max(nu)
  value <- paste0(
    "range=[",
    format_check_number(min_nu),
    ",",
    format_check_number(max_nu),
    "]"
  )
  if (min_nu < 2.05) {
    return(check_row(
      "student_nu",
      "warning",
      value,
      "At least one fitted Student-t nu value is very close to the finite-variance boundary at 2."
    ))
  }
  if (max_nu > 100) {
    return(check_row(
      "student_nu",
      "note",
      value,
      "At least one fitted Student-t nu value is large; compare against a Gaussian model because tails may be nearly Gaussian."
    ))
  }
  check_row(
    "student_nu",
    "ok",
    value,
    "All fitted Student-t nu values are finite and above the boundary at 2."
  )
}

check_skew_normal_nu <- function(object) {
  if (!identical(object$model$model_type, "skew_normal")) {
    return(NULL)
  }
  nu <- tryCatch(predict(object, dpar = "nu"), error = function(e) e)
  if (inherits(nu, "error")) {
    return(check_row(
      "skew_normal_nu",
      "warning",
      NA_character_,
      paste("Could not extract skew-normal nu values:", conditionMessage(nu))
    ))
  }
  if (!all(is.finite(nu))) {
    return(check_row(
      "skew_normal_nu",
      "error",
      NA_character_,
      "At least one fitted skew-normal nu value is non-finite."
    ))
  }

  max_abs <- max(abs(nu), 0)
  value <- paste0("max_abs=", format_check_number(max_abs))
  if (max_abs > 10) {
    return(check_row(
      "skew_normal_nu",
      "note",
      value,
      "At least one fitted skew-normal slant value is large; inspect the profile target, residual shape, and Gaussian or Student-t sensitivity models before interpreting skewness."
    ))
  }
  check_row(
    "skew_normal_nu",
    "ok",
    value,
    "All fitted skew-normal nu values are finite."
  )
}

check_known_v <- function(object) {
  if (!isTRUE(object$model$has_known_v)) {
    return(NULL)
  }
  known_type <- object$model$V_known_type
  known_diag <- known_v_diag(object)
  ok <- all(is.finite(known_diag)) && all(known_diag >= 0)
  if (identical(known_type, "matrix")) {
    V <- object$model$V_known
    eig <- eigen(
      (V + t(V)) / 2,
      symmetric = TRUE,
      only.values = TRUE
    )$values
    tol <- sqrt(.Machine$double.eps) * max(abs(eig), 1)
    rank <- sum(eig > tol)
    positive_eig <- eig[eig > tol]
    condition <- if (length(positive_eig) == 0L) {
      Inf
    } else {
      max(positive_eig) / min(positive_eig)
    }
    storage <- known_v_dense_storage_summary(V)
    ill_conditioned <- rank < length(eig) || condition > 1e8
    status <- if (!ok) {
      "error"
    } else if (ill_conditioned) {
      "warning"
    } else {
      "note"
    }
    return(check_row(
      "known_sampling_covariance",
      status,
      paste0(
        "type=matrix; n=",
        length(eig),
        "; storage=dense; density=",
        format_check_number(storage$density),
        "; size_mb=",
        format_check_number(storage$size_mb),
        "; rank=",
        rank,
        "; cond=",
        format_check_number(condition)
      ),
      if (identical(status, "error")) {
        "Known sampling covariance has a non-finite or negative diagonal entry."
      } else if (ill_conditioned) {
        paste(
          "Known sampling covariance is singular or severely ill-conditioned",
          "(rank-deficient or condition number above 1e8); its inverse is undefined",
          "or numerically amplified, so the GLS likelihood and its standard errors",
          "are not reliable. Drop duplicated or collinear rows, or supply a",
          "positive-definite V."
        )
      } else if (storage$density <= 0.25) {
        paste(
          "Known sampling covariance is recorded as a dense matrix with many zero entries;",
          "large block-structured V will need sparse or block-sparse storage before being treated as scalable."
        )
      } else {
        paste(
          "Known sampling covariance is recorded as a dense matrix with finite non-negative diagonal;",
          "treat this as a small-to-moderate path until sparse or block-sparse storage has benchmark evidence."
        )
      }
    ))
  }
  check_row(
    "known_sampling_covariance",
    if (ok) "ok" else "error",
    paste0(
      "type=",
      known_type,
      "; n=",
      length(known_diag),
      "; range=[",
      format_check_number(min(known_diag, na.rm = TRUE)),
      ",",
      format_check_number(max(known_diag, na.rm = TRUE)),
      "]"
    ),
    if (ok) {
      "Known sampling covariance is recorded through meta_V(V = V)."
    } else {
      "Known sampling variances contain non-finite or negative values."
    }
  )
}

known_v_dense_storage_summary <- function(V) {
  entries <- length(V)
  nonzero <- sum(!is.na(V) & V != 0)
  list(
    nonzero = nonzero,
    density = if (entries == 0L) NA_real_ else nonzero / entries,
    size_mb = as.numeric(utils::object.size(V)) / 1024^2
  )
}

check_fixed_effect_design_size <- function(object) {
  X <- object$model$X
  if (is.null(X) || length(X) == 0L) {
    return(NULL)
  }
  design <- fixed_effect_design_summary(X)
  if (nrow(design) == 0L) {
    return(NULL)
  }
  total_mb <- sum(design$size_mb)
  max_cols <- max(design$n_cols, 0L)
  largest_row <- design[which.max(design$size_mb), , drop = FALSE]
  largest <- largest_row$dpar[[1L]]
  if (is.na(largest) || !nzchar(largest)) {
    largest <- "unnamed"
  }
  largest_density <- largest_row$density[[1L]]
  largest_class <- largest_row$matrix_class[[1L]]
  has_sparse <- any(vapply(X, inherits, logical(1), "sparseMatrix"))
  sparse_candidate <- is.finite(largest_density) &&
    max_cols >= 30L &&
    largest_density <= 0.25
  note <- total_mb >= 25 || max_cols >= 30L
  value <- paste0(
    "total_mb=",
    format_check_number(total_mb),
    "; max_cols=",
    max_cols,
    "; largest=",
    largest,
    "; largest_class=",
    largest_class,
    "; largest_density=",
    format_check_number(largest_density)
  )
  check_row(
    "fixed_effect_design_size",
    if (note) "note" else "ok",
    value,
    if (has_sparse) {
      "Sparse fixed-effect design matrices are enabled for at least one fixed-effect block."
    } else if (sparse_candidate) {
      paste(
        "Dense fixed-effect design matrices are wide and mostly zero;",
        "high-cardinality factors or sparse interactions may dominate memory before TMB optimization and are candidates for future sparse fixed-effect matrices."
      )
    } else if (note) {
      paste(
        "Dense fixed-effect design matrices are large enough to inspect;",
        "high-cardinality factors or interactions may dominate memory before TMB optimization."
      )
    } else {
      "Dense fixed-effect design matrices are modest for this fit."
    }
  )
}

fixed_effect_design_summary <- function(X) {
  x_names <- names(X)
  if (is.null(x_names)) {
    x_names <- rep(NA_character_, length(X))
  }
  rows <- lapply(seq_along(X), function(i) {
    name <- x_names[[i]]
    if (is.na(name) || !nzchar(name)) {
      name <- paste0("X", i)
    }
    x <- X[[i]]
    dims <- dim(x)
    if (is.null(dims) || length(dims) != 2L) {
      return(NULL)
    }
    n_values <- prod(dims)
    n_nonzero <- fixed_effect_design_nonzero(x)
    density <- if (n_values == 0L) {
      NA_real_
    } else {
      n_nonzero / n_values
    }
    data.frame(
      dpar = name,
      matrix_class = class(x)[[1L]],
      n_rows = dims[[1L]],
      n_cols = dims[[2L]],
      n_nonzero = n_nonzero,
      density = density,
      size_mb = as.numeric(utils::object.size(x)) / 1024^2,
      stringsAsFactors = FALSE
    )
  })
  rows <- Filter(Negate(is.null), rows)
  if (length(rows) == 0L) {
    return(data.frame(
      dpar = character(),
      matrix_class = character(),
      n_rows = integer(),
      n_cols = integer(),
      n_nonzero = numeric(),
      density = numeric(),
      size_mb = numeric()
    ))
  }
  do.call(rbind, rows)
}

fixed_effect_design_nonzero <- function(x) {
  if (inherits(x, "sparseMatrix")) {
    return(Matrix::nnzero(x))
  }
  sum(x != 0, na.rm = TRUE)
}

check_random_effect_replication <- function(object, block) {
  if (
    !object$model$model_type %in%
      c(
        "gaussian",
        "student",
        "lognormal",
        "gamma",
        "beta",
        "beta_binomial",
        "nbinom2",
        "truncated_nbinom2",
        "binomial",
        "cumulative_logit",
        "skew_normal",
        "tweedie",
        "zero_one_beta"
      )
  ) {
    return(NULL)
  }
  re <- object$model$random[[block]]
  if (is.null(re) || re$n_re == 0L) {
    return(NULL)
  }
  min_counts <- vapply(
    seq_len(re$n_terms),
    function(k) {
      min(tabulate(re$index[, k], nbins = re$n_re)[re$index[, k]])
    },
    integer(1)
  )
  names(min_counts) <- re$labels
  min_count <- min(min_counts)
  check_row(
    paste0(block, "_random_effect_replication"),
    if (min_count < 2L) "note" else "ok",
    paste(names(min_counts), min_counts, sep = "=", collapse = "; "),
    if (min_count < 2L) {
      "At least one random-effect level has one fitted observation; interpret its conditional effect cautiously."
    } else {
      "Every random-effect level has at least two fitted observations."
    }
  )
}

check_random_effect_design <- function(object, block) {
  if (
    !object$model$model_type %in%
      c(
        "gaussian",
        "student",
        "lognormal",
        "gamma",
        "beta",
        "beta_binomial",
        "nbinom2",
        "truncated_nbinom2",
        "binomial",
        "cumulative_logit",
        "skew_normal",
        "tweedie",
        "zero_one_beta"
      )
  ) {
    return(NULL)
  }
  re <- object$model$random[[block]]
  if (is.null(re) || re$n_re == 0L) {
    return(NULL)
  }
  slope_terms <- which(
    !vapply(re$labels, random_effect_label_is_intercept, logical(1))
  )
  correlated_ranks <- random_effect_correlated_block_ranks(re)
  if (length(slope_terms) == 0L && length(correlated_ranks) == 0L) {
    return(NULL)
  }

  unique_counts <- vapply(
    slope_terms,
    function(k) {
      min(vapply(
        split(re$value[, k], re$index[, k]),
        random_effect_unique_n,
        integer(1)
      ))
    },
    integer(1)
  )
  names(unique_counts) <- re$labels[slope_terms]

  values <- character()
  if (length(unique_counts) > 0L) {
    values <- c(
      values,
      paste0(
        "min_unique=",
        paste(names(unique_counts), unique_counts, sep = "=", collapse = "; ")
      )
    )
  }
  if (length(correlated_ranks) > 0L) {
    values <- c(
      values,
      paste0(
        "min_rank=",
        paste(
          names(correlated_ranks),
          correlated_ranks,
          sep = "=",
          collapse = "; "
        )
      )
    )
  }

  weak_unique <- length(unique_counts) > 0L && any(unique_counts < 2L)
  weak_rank <- length(correlated_ranks) > 0L &&
    any(
      as.integer(sub("/.*", "", correlated_ranks)) <
        as.integer(sub(".*/", "", correlated_ranks))
    )
  ok <- !weak_unique && !weak_rank

  check_row(
    paste0(block, "_random_effect_design"),
    if (ok) "ok" else "note",
    paste(values, collapse = " | "),
    if (ok) {
      "Random-slope design values show within-group variation for implemented random-effect checks."
    } else {
      "At least one random-slope or correlated random-effect block has weak within-group design variation; interpret slope SDs or correlations cautiously."
    }
  )
}

registry_covariance_pair <- function(
  object,
  class,
  from_dpar = NULL,
  to_dpar = NULL
) {
  registry <- object$model$random$covariance_blocks
  if (
    !is.list(registry) ||
      is.null(registry$pairs) ||
      nrow(registry$pairs) == 0L
  ) {
    return(NULL)
  }

  pairs <- registry$pairs
  keep <- pairs$class == class
  if (!is.null(from_dpar)) {
    keep <- keep & pairs$from_dpar %in% from_dpar
  }
  if (!is.null(to_dpar)) {
    keep <- keep & pairs$to_dpar %in% to_dpar
  }
  pairs <- pairs[keep, , drop = FALSE]
  if (nrow(pairs) == 0L) {
    return(NULL)
  }
  if (nrow(pairs) != 1L) {
    return(list(complex = TRUE, n_pairs = nrow(pairs)))
  }

  pair <- pairs[1L, , drop = FALSE]
  registry <- object$model$random$covariance_blocks
  block <- registry$blocks[
    registry$blocks$block_id0 == pair$block_id0[[1L]],
    ,
    drop = FALSE
  ]
  members <- registry$members[
    registry$members$block_id0 == pair$block_id0[[1L]],
    ,
    drop = FALSE
  ]
  if (nrow(block) != 1L || nrow(members) == 0L) {
    return(list(complex = TRUE, n_pairs = nrow(pairs)))
  }

  list(
    complex = FALSE,
    pair = pair,
    block = block,
    members = members
  )
}

registry_covariance_member <- function(info, dpar) {
  member <- info$members[info$members$dpar == dpar, , drop = FALSE]
  if (nrow(member) != 1L) {
    return(NULL)
  }
  member
}

registry_member_group_counts <- function(member, n_groups) {
  if (!is.finite(n_groups) || n_groups < 1L) {
    return(integer())
  }
  index <- member$latent_index0[[1L]]
  index <- index[!is.na(index) & index >= 0L]
  tabulate((index %% n_groups) + 1L, nbins = n_groups)
}

registry_covariance_pair_rho_abs <- function(object, info) {
  cor_key <- covariance_block_corpars_key(info$pair$tmb_parameter[[1L]])
  cor_values <- object$corpars[[cor_key]]
  if (is.null(cor_values) || length(cor_values) == 0L) {
    return(NA_real_)
  }
  rho <- unname(cor_values[match(info$pair$parameter[[1L]], names(cor_values))])
  max_abs_finite_or_na(rho)
}

random_effect_covariance_near_boundary <- function(rho_abs, rho_boundary) {
  is.finite(rho_abs) && rho_abs > rho_boundary
}

# TRUE when the group-level correlation could not be read (mapped/fixed
# parameter, name mismatch, or sdreport skipped) and rho_abs is therefore
# non-finite. This is distinct from "near the boundary": an unavailable
# correlation is reported as a note, never a boundary warning. See #697.
random_effect_covariance_rho_unavailable <- function(rho_abs) {
  !is.finite(rho_abs)
}

# Shared note message for an unavailable group-level correlation.
random_effect_covariance_unavailable_message <- function() {
  paste(
    "The group-level correlation could not be extracted (it may be fixed via",
    "map, unmatched, or produced by a skipped sdreport). Inspect the sdreport",
    "and parameter mapping before interpreting the covariance."
  )
}

check_mu_sigma_random_effect_covariance <- function(object, rho_boundary) {
  if (!identical(object$model$model_type, "gaussian")) {
    return(NULL)
  }
  re_mu_sigma <- object$model$random$mu_sigma
  if (
    is.list(re_mu_sigma) &&
      !is.null(re_mu_sigma$n_cors) &&
      re_mu_sigma$n_cors > 1L
  ) {
    return(check_mu_sigma_random_effect_covariance_rows(
      object,
      re_mu_sigma,
      rho_boundary = rho_boundary
    ))
  }

  registry_pair <- registry_covariance_pair(
    object,
    class = "mean-scale",
    from_dpar = "mu",
    to_dpar = "sigma"
  )
  if (!is.null(registry_pair)) {
    if (isTRUE(registry_pair$complex)) {
      return(check_row(
        "mu_sigma_random_effect_covariance",
        "note",
        paste0("n_pairs=", registry_pair$n_pairs),
        "The fitted mu/sigma covariance block is more complex than the current diagnostic summary."
      ))
    }

    mu_member <- registry_covariance_member(registry_pair, "mu")
    sigma_member <- registry_covariance_member(registry_pair, "sigma")
    if (is.null(mu_member) || is.null(sigma_member)) {
      return(NULL)
    }

    group_counts <- registry_member_group_counts(
      sigma_member,
      registry_pair$block$n_groups[[1L]]
    )
    min_count <- min(group_counts)
    singleton_groups <- sum(group_counts < 2L)
    sd_mu <- unname(object$sdpars$mu[[mu_member$label[[1L]]]])
    sd_sigma <- unname(object$sdpars$sigma[[sigma_member$label[[1L]]]])
    residual_scale <- mean(stats::sigma(object), na.rm = TRUE)
    mu_sd_ratio <- sd_mu / residual_scale
    weak_replication <- min_count < 2L
    weak_sd <- !is.finite(mu_sd_ratio) ||
      !is.finite(sd_sigma) ||
      mu_sd_ratio < 0.05 ||
      sd_sigma < 0.05
    rho_abs <- registry_covariance_pair_rho_abs(object, registry_pair)
    near_rho_boundary <- random_effect_covariance_near_boundary(
      rho_abs,
      rho_boundary
    )
    rho_unavailable <- random_effect_covariance_rho_unavailable(rho_abs)

    return(check_row(
      "mu_sigma_random_effect_covariance",
      if (near_rho_boundary) {
        "warning"
      } else if (rho_unavailable || weak_replication || weak_sd) {
        "note"
      } else {
        "ok"
      },
      paste0(
        "term=",
        sigma_member$label[[1L]],
        "; rho_abs=",
        format_check_number(rho_abs),
        "; boundary=",
        format_check_number(rho_boundary),
        "; n_groups=",
        registry_pair$block$n_groups[[1L]],
        "; min_group_n=",
        min_count,
        "; singleton_groups=",
        singleton_groups,
        "; mu_sd_ratio=",
        format_check_number(mu_sd_ratio),
        "; sigma_log_sd=",
        format_check_number(sd_sigma)
      ),
      mu_sigma_re_diagnostic_message(
        near_rho_boundary,
        weak_replication,
        weak_sd,
        rho_unavailable
      )
    ))
  }

  if (is.null(re_mu_sigma) || re_mu_sigma$n_cors == 0L) {
    return(NULL)
  }
  check_mu_sigma_random_effect_covariance_rows(
    object,
    re_mu_sigma,
    rho_boundary = rho_boundary
  )
}

check_mu_sigma_random_effect_covariance_rows <- function(
  object,
  re_mu_sigma,
  rho_boundary
) {
  re_mu <- object$model$random$mu
  re_sigma <- object$model$random$sigma
  rows <- lapply(seq_len(re_mu_sigma$n_cors), function(cor_id) {
    sigma_rows <- which(re_mu_sigma$sigma_cross_cor_id0 == cor_id - 1L)
    if (length(sigma_rows) == 0L) {
      return(NULL)
    }

    sigma_terms <- unique(re_sigma$term_id0[sigma_rows] + 1L)
    mu_rows <- re_mu_sigma$sigma_cross_mu_index0[sigma_rows] + 1L
    mu_terms <- unique(re_mu$term_id0[mu_rows] + 1L)
    if (length(sigma_terms) != 1L || length(mu_terms) != 1L) {
      return(check_row(
        "mu_sigma_random_effect_covariance",
        "note",
        paste0("n_cors=", re_mu_sigma$n_cors, "; cor_id=", cor_id),
        "The fitted mu/sigma covariance block is more complex than the current diagnostic summary."
      ))
    }

    sigma_term <- sigma_terms[[1L]]
    mu_term <- mu_terms[[1L]]
    group_counts <- tabulate(
      re_sigma$index[, sigma_term],
      nbins = re_sigma$n_re
    )[sigma_rows]
    min_count <- min(group_counts)
    singleton_groups <- sum(group_counts < 2L)

    sd_mu <- unname(object$sdpars$mu[[re_mu$labels[[mu_term]]]])
    sd_sigma <- unname(object$sdpars$sigma[[re_sigma$labels[[sigma_term]]]])
    residual_scale <- mean(stats::sigma(object), na.rm = TRUE)
    mu_sd_ratio <- sd_mu / residual_scale
    weak_replication <- min_count < 2L
    weak_sd <- !is.finite(mu_sd_ratio) ||
      !is.finite(sd_sigma) ||
      mu_sd_ratio < 0.05 ||
      sd_sigma < 0.05
    rho_abs <- max_abs_finite_or_na(object$corpars$mu_sigma[[cor_id]])
    near_rho_boundary <- random_effect_covariance_near_boundary(
      rho_abs,
      rho_boundary
    )
    rho_unavailable <- random_effect_covariance_rho_unavailable(rho_abs)

    check_row(
      "mu_sigma_random_effect_covariance",
      if (near_rho_boundary) {
        "warning"
      } else if (rho_unavailable || weak_replication || weak_sd) {
        "note"
      } else {
        "ok"
      },
      paste0(
        "term=",
        re_sigma$labels[[sigma_term]],
        "; rho_abs=",
        format_check_number(rho_abs),
        "; boundary=",
        format_check_number(rho_boundary),
        "; n_groups=",
        length(sigma_rows),
        "; min_group_n=",
        min_count,
        "; singleton_groups=",
        singleton_groups,
        "; mu_sd_ratio=",
        format_check_number(mu_sd_ratio),
        "; sigma_log_sd=",
        format_check_number(sd_sigma)
      ),
      mu_sigma_re_diagnostic_message(
        near_rho_boundary,
        weak_replication,
        weak_sd,
        rho_unavailable
      )
    )
  })
  rows <- Filter(Negate(is.null), rows)
  if (length(rows) == 0L) {
    return(NULL)
  }
  do.call(rbind, rows)
}

mu_sigma_re_diagnostic_message <- function(
  near_rho_boundary,
  weak_replication,
  weak_sd,
  rho_unavailable = FALSE
) {
  if (near_rho_boundary) {
    return(paste(
      "The fitted mu/sigma group-level correlation is close to +/-1;",
      "profile, simulate, or simplify before interpreting the covariance."
    ))
  }
  if (rho_unavailable) {
    return(random_effect_covariance_unavailable_message())
  }
  if (weak_replication && weak_sd) {
    return(paste(
      "At least one group has fewer than two fitted observations and one",
      "component SD is tiny; interpret the mu/sigma group-level correlation cautiously."
    ))
  }
  if (weak_replication) {
    return(paste(
      "At least one group has fewer than two fitted observations;",
      "interpret the mu/sigma group-level correlation cautiously."
    ))
  }
  if (weak_sd) {
    return(paste(
      "At least one component SD is tiny on its interpretation scale;",
      "the mu/sigma group-level correlation may be weakly identified."
    ))
  }
  "Mu/sigma group-level covariance has replicated groups and non-negligible fitted component SDs."
}

check_biv_mu_random_effect_covariance <- function(object, rho_boundary) {
  if (!identical(object$model$model_type, "biv_gaussian")) {
    return(NULL)
  }
  registry_pair <- registry_covariance_pair(
    object,
    class = "mean-mean",
    from_dpar = "mu1",
    to_dpar = "mu2"
  )
  if (is.null(registry_pair)) {
    registry_pair <- registry_covariance_pair(
      object,
      class = "slope-slope",
      from_dpar = "mu1",
      to_dpar = "mu2"
    )
  }
  if (!is.null(registry_pair)) {
    if (isTRUE(registry_pair$complex)) {
      return(check_row(
        "biv_mu_random_effect_covariance",
        "note",
        paste0("n_pairs=", registry_pair$n_pairs),
        "The fitted bivariate mu covariance block is more complex than the current diagnostic summary."
      ))
    }

    first_member <- registry_covariance_member(registry_pair, "mu1")
    if (is.null(first_member)) {
      return(NULL)
    }
    n_group <- registry_pair$block$n_groups[[1L]]
    group_counts <- registry_member_group_counts(first_member, n_group)
    min_count <- min(group_counts)
    singleton_groups <- sum(group_counts < 2L)
    sd_ratios <- bivariate_mu_registry_sd_ratios(
      object,
      registry_pair$members
    )
    finite_sd_ratios <- sd_ratios[is.finite(sd_ratios)]
    min_sd_ratio <- if (length(finite_sd_ratios) > 0L) {
      min(finite_sd_ratios)
    } else {
      NA_real_
    }
    weak_sd <- any(finite_sd_ratios < 0.05)
    weak_replication <- min_count < 2L
    pair_class <- registry_pair$pair$class[[1L]]
    rho_abs <- registry_covariance_pair_rho_abs(object, registry_pair)
    near_rho_boundary <- random_effect_covariance_near_boundary(
      rho_abs,
      rho_boundary
    )
    rho_unavailable <- random_effect_covariance_rho_unavailable(rho_abs)

    return(check_row(
      "biv_mu_random_effect_covariance",
      if (near_rho_boundary) {
        "warning"
      } else if (rho_unavailable || weak_replication || weak_sd) {
        "note"
      } else {
        "ok"
      },
      paste0(
        "class=",
        pair_class,
        "; rho_abs=",
        format_check_number(rho_abs),
        "; boundary=",
        format_check_number(rho_boundary),
        "; n_groups=",
        n_group,
        "; min_group_n=",
        min_count,
        "; singleton_groups=",
        singleton_groups,
        "; min_sd_ratio=",
        format_check_number(min_sd_ratio)
      ),
      bivariate_mu_re_diagnostic_message(
        near_rho_boundary,
        weak_replication,
        weak_sd,
        rho_unavailable
      )
    ))
  }

  re <- object$model$random$mu
  if (is.null(re) || re$n_re == 0L || re$n_terms == 0L) {
    return(NULL)
  }
  if (!setequal(re$dpars, c("mu1", "mu2"))) {
    return(NULL)
  }

  n_group <- as.integer(re$n_re / re$n_terms)
  group_counts <- tabulate(re$index[, 1L], nbins = n_group)
  min_count <- min(group_counts)
  singleton_groups <- sum(group_counts < 2L)
  sd_ratios <- bivariate_mu_re_sd_ratios(object, re)
  finite_sd_ratios <- sd_ratios[is.finite(sd_ratios)]
  min_sd_ratio <- if (length(finite_sd_ratios) > 0L) {
    min(finite_sd_ratios)
  } else {
    NA_real_
  }
  weak_sd <- any(finite_sd_ratios < 0.05)
  weak_replication <- min_count < 2L
  rho_abs <- max_abs_finite_or_na(object$corpars$mu)
  near_rho_boundary <- random_effect_covariance_near_boundary(
    rho_abs,
    rho_boundary
  )
  rho_unavailable <- random_effect_covariance_rho_unavailable(rho_abs)

  check_row(
    "biv_mu_random_effect_covariance",
    if (near_rho_boundary) {
      "warning"
    } else if (rho_unavailable || weak_replication || weak_sd) {
      "note"
    } else {
      "ok"
    },
    paste0(
      "rho_abs=",
      format_check_number(rho_abs),
      "; boundary=",
      format_check_number(rho_boundary),
      "; ",
      "n_groups=",
      n_group,
      "; min_group_n=",
      min_count,
      "; singleton_groups=",
      singleton_groups,
      "; min_sd_ratio=",
      format_check_number(min_sd_ratio)
    ),
    bivariate_mu_re_diagnostic_message(
      near_rho_boundary,
      weak_replication,
      weak_sd,
      rho_unavailable
    )
  )
}

bivariate_mu_registry_sd_ratios <- function(object, members) {
  sdpars <- object$sdpars$mu
  if (is.null(sdpars) || length(sdpars) == 0L) {
    return(numeric())
  }
  sigma_values <- tryCatch(stats::sigma(object), error = function(e) e)
  if (inherits(sigma_values, "error") || !is.list(sigma_values)) {
    return(numeric())
  }
  residual_scale <- c(
    mu1 = mean(sigma_values$sigma1, na.rm = TRUE),
    mu2 = mean(sigma_values$sigma2, na.rm = TRUE)
  )
  sd_values <- unname(sdpars[match(members$label, names(sdpars))])
  sd_values / residual_scale[members$dpar]
}

bivariate_mu_re_sd_ratios <- function(object, re) {
  sdpars <- object$sdpars$mu
  if (is.null(sdpars) || length(sdpars) == 0L) {
    return(numeric())
  }
  sigma_values <- tryCatch(stats::sigma(object), error = function(e) e)
  if (inherits(sigma_values, "error") || !is.list(sigma_values)) {
    return(numeric())
  }
  residual_scale <- c(
    mu1 = mean(sigma_values$sigma1, na.rm = TRUE),
    mu2 = mean(sigma_values$sigma2, na.rm = TRUE)
  )
  sd_values <- unname(sdpars[match(re$labels, names(sdpars))])
  sd_values / residual_scale[re$dpars]
}

bivariate_mu_re_diagnostic_message <- function(
  near_rho_boundary,
  weak_replication,
  weak_sd,
  rho_unavailable = FALSE
) {
  if (near_rho_boundary) {
    return(paste(
      "At least one bivariate group-level correlation is close to +/-1;",
      "profile, simulate, or simplify before interpreting the covariance."
    ))
  }
  if (rho_unavailable) {
    return(random_effect_covariance_unavailable_message())
  }
  if (weak_replication && weak_sd) {
    return(paste(
      "At least one group has fewer than two fitted observations and at least",
      "one group-level SD is tiny relative to the matching residual scale;",
      "interpret bivariate group-level SDs and correlations cautiously."
    ))
  }
  if (weak_replication) {
    return(paste(
      "At least one group has fewer than two fitted observations;",
      "interpret bivariate group-level SDs and correlations cautiously."
    ))
  }
  if (weak_sd) {
    return(paste(
      "At least one group-level SD is tiny relative to the matching residual",
      "scale; the bivariate group-level correlation may be weakly identified."
    ))
  }
  "Bivariate group-level covariance has replicated groups and non-negligible fitted SDs relative to residual scales."
}

check_biv_mu_sigma_random_effect_covariance <- function(object, rho_boundary) {
  if (!identical(object$model$model_type, "biv_gaussian")) {
    return(NULL)
  }
  registry_pair <- registry_covariance_pair(
    object,
    class = "mean-scale",
    from_dpar = c("mu1", "mu2"),
    to_dpar = c("sigma1", "sigma2")
  )
  if (!is.null(registry_pair) && !isTRUE(registry_pair$complex)) {
    mu_member <- registry_covariance_member(
      registry_pair,
      registry_pair$pair$from_dpar[[1L]]
    )
    sigma_member <- registry_covariance_member(
      registry_pair,
      registry_pair$pair$to_dpar[[1L]]
    )
    if (is.null(mu_member) || is.null(sigma_member)) {
      return(NULL)
    }

    group_counts <- registry_member_group_counts(
      sigma_member,
      registry_pair$block$n_groups[[1L]]
    )
    min_count <- min(group_counts)
    singleton_groups <- sum(group_counts < 2L)
    sd_mu <- unname(object$sdpars$mu[[mu_member$label[[1L]]]])
    sd_sigma <- unname(object$sdpars$sigma[[sigma_member$label[[1L]]]])
    sigma_values <- tryCatch(stats::sigma(object), error = function(e) e)
    sigma_dpar <- sigma_member$dpar[[1L]]
    residual_scale <- if (
      inherits(sigma_values, "error") || !is.list(sigma_values)
    ) {
      NA_real_
    } else {
      mean(sigma_values[[sigma_dpar]], na.rm = TRUE)
    }
    mu_sd_ratio <- sd_mu / residual_scale
    weak_replication <- min_count < 2L
    weak_sd <- !is.finite(mu_sd_ratio) ||
      !is.finite(sd_sigma) ||
      mu_sd_ratio < 0.05 ||
      sd_sigma < 0.05
    rho_abs <- registry_covariance_pair_rho_abs(object, registry_pair)
    near_rho_boundary <- random_effect_covariance_near_boundary(
      rho_abs,
      rho_boundary
    )
    rho_unavailable <- random_effect_covariance_rho_unavailable(rho_abs)

    return(check_row(
      "biv_mu_sigma_random_effect_covariance",
      if (near_rho_boundary) {
        "warning"
      } else if (rho_unavailable || weak_replication || weak_sd) {
        "note"
      } else {
        "ok"
      },
      paste0(
        "term=",
        sigma_member$label[[1L]],
        "; rho_abs=",
        format_check_number(rho_abs),
        "; boundary=",
        format_check_number(rho_boundary),
        "; n_groups=",
        registry_pair$block$n_groups[[1L]],
        "; min_group_n=",
        min_count,
        "; singleton_groups=",
        singleton_groups,
        "; mu_sd_ratio=",
        format_check_number(mu_sd_ratio),
        "; sigma_log_sd=",
        format_check_number(sd_sigma)
      ),
      bivariate_mu_sigma_re_diagnostic_message(
        near_rho_boundary,
        weak_replication,
        weak_sd,
        rho_unavailable
      )
    ))
  }

  re_mu_sigma <- object$model$random$mu_sigma
  if (is.null(re_mu_sigma) || re_mu_sigma$n_cors == 0L) {
    return(NULL)
  }

  re_mu <- object$model$random$mu
  re_sigma <- object$model$random$sigma
  sigma_rows <- which(re_mu_sigma$sigma_cross_cor_id0 >= 0L)
  if (length(sigma_rows) == 0L) {
    return(NULL)
  }

  rows <- lapply(seq_len(re_mu_sigma$n_cors), function(cor_id) {
    sigma_rows <- which(re_mu_sigma$sigma_cross_cor_id0 == cor_id - 1L)
    if (length(sigma_rows) == 0L) {
      return(NULL)
    }

    sigma_terms <- unique(re_sigma$term_id0[sigma_rows] + 1L)
    mu_rows <- re_mu_sigma$sigma_cross_mu_index0[sigma_rows] + 1L
    mu_terms <- unique(re_mu$term_id0[mu_rows] + 1L)
    if (length(sigma_terms) != 1L || length(mu_terms) != 1L) {
      return(check_row(
        "biv_mu_sigma_random_effect_covariance",
        "note",
        paste0("n_cors=", re_mu_sigma$n_cors, "; cor_id=", cor_id),
        "The fitted bivariate mu/sigma covariance block is more complex than the current diagnostic summary."
      ))
    }

    sigma_term <- sigma_terms[[1L]]
    mu_term <- mu_terms[[1L]]
    group_counts <- tabulate(
      re_sigma$index[, sigma_term],
      nbins = re_sigma$n_re
    )[sigma_rows]
    min_count <- min(group_counts)
    singleton_groups <- sum(group_counts < 2L)

    sd_mu <- unname(object$sdpars$mu[[re_mu$labels[[mu_term]]]])
    sd_sigma <- unname(object$sdpars$sigma[[re_sigma$labels[[sigma_term]]]])
    sigma_values <- tryCatch(stats::sigma(object), error = function(e) e)
    response_id <- sub("^mu", "", re_mu$dpars[[mu_term]])
    sigma_dpar <- paste0("sigma", response_id)
    residual_scale <- if (
      inherits(sigma_values, "error") || !is.list(sigma_values)
    ) {
      NA_real_
    } else {
      mean(sigma_values[[sigma_dpar]], na.rm = TRUE)
    }
    mu_sd_ratio <- sd_mu / residual_scale
    weak_replication <- min_count < 2L
    weak_sd <- !is.finite(mu_sd_ratio) ||
      !is.finite(sd_sigma) ||
      mu_sd_ratio < 0.05 ||
      sd_sigma < 0.05
    rho_abs <- max_abs_finite_or_na(object$corpars$mu_sigma[[cor_id]])
    near_rho_boundary <- random_effect_covariance_near_boundary(
      rho_abs,
      rho_boundary
    )
    rho_unavailable <- random_effect_covariance_rho_unavailable(rho_abs)

    check_row(
      "biv_mu_sigma_random_effect_covariance",
      if (near_rho_boundary) {
        "warning"
      } else if (rho_unavailable || weak_replication || weak_sd) {
        "note"
      } else {
        "ok"
      },
      paste0(
        "term=",
        re_sigma$labels[[sigma_term]],
        "; rho_abs=",
        format_check_number(rho_abs),
        "; boundary=",
        format_check_number(rho_boundary),
        "; n_groups=",
        length(sigma_rows),
        "; min_group_n=",
        min_count,
        "; singleton_groups=",
        singleton_groups,
        "; mu_sd_ratio=",
        format_check_number(mu_sd_ratio),
        "; sigma_log_sd=",
        format_check_number(sd_sigma)
      ),
      bivariate_mu_sigma_re_diagnostic_message(
        near_rho_boundary,
        weak_replication,
        weak_sd,
        rho_unavailable
      )
    )
  })
  rows <- Filter(Negate(is.null), rows)
  if (length(rows) == 0L) {
    return(NULL)
  }
  do.call(rbind, rows)
}

bivariate_mu_sigma_re_diagnostic_message <- function(
  near_rho_boundary,
  weak_replication,
  weak_sd,
  rho_unavailable = FALSE
) {
  if (near_rho_boundary) {
    return(paste(
      "The fitted bivariate mu/sigma group-level correlation is close to +/-1;",
      "profile, simulate, or simplify before interpreting the covariance."
    ))
  }
  if (rho_unavailable) {
    return(random_effect_covariance_unavailable_message())
  }
  if (weak_replication && weak_sd) {
    return(paste(
      "At least one group has fewer than two fitted observations and one",
      "component SD is tiny; interpret the bivariate mu/sigma group-level",
      "correlation cautiously."
    ))
  }
  if (weak_replication) {
    return(paste(
      "At least one group has fewer than two fitted observations;",
      "interpret the bivariate mu/sigma group-level correlation cautiously."
    ))
  }
  if (weak_sd) {
    return(paste(
      "At least one component SD is tiny; the bivariate mu/sigma group-level",
      "correlation may be weakly identified."
    ))
  }
  "Bivariate mu/sigma group-level covariance has replicated groups and non-negligible fitted SDs."
}

check_biv_sigma_random_effect_covariance <- function(object, rho_boundary) {
  if (!identical(object$model$model_type, "biv_gaussian")) {
    return(NULL)
  }
  registry_pair <- registry_covariance_pair(
    object,
    class = "scale-scale",
    from_dpar = "sigma1",
    to_dpar = "sigma2"
  )
  if (!is.null(registry_pair)) {
    if (isTRUE(registry_pair$complex)) {
      return(check_row(
        "biv_sigma_random_effect_covariance",
        "note",
        paste0("n_pairs=", registry_pair$n_pairs),
        "The fitted bivariate sigma covariance block is more complex than the current diagnostic summary."
      ))
    }

    first_member <- registry_covariance_member(registry_pair, "sigma1")
    if (is.null(first_member)) {
      return(NULL)
    }
    n_group <- registry_pair$block$n_groups[[1L]]
    group_counts <- registry_member_group_counts(first_member, n_group)
    min_count <- min(group_counts)
    singleton_groups <- sum(group_counts < 2L)
    sdpars <- object$sdpars$sigma
    sd_values <- unname(sdpars[match(
      registry_pair$members$label,
      names(sdpars)
    )])
    finite_sd_values <- sd_values[is.finite(sd_values)]
    min_sd <- if (length(finite_sd_values) > 0L) {
      min(finite_sd_values)
    } else {
      NA_real_
    }
    weak_sd <- any(finite_sd_values < 0.05)
    weak_replication <- min_count < 2L
    rho_abs <- registry_covariance_pair_rho_abs(object, registry_pair)
    near_rho_boundary <- random_effect_covariance_near_boundary(
      rho_abs,
      rho_boundary
    )
    rho_unavailable <- random_effect_covariance_rho_unavailable(rho_abs)

    return(check_row(
      "biv_sigma_random_effect_covariance",
      if (near_rho_boundary) {
        "warning"
      } else if (rho_unavailable || weak_replication || weak_sd) {
        "note"
      } else {
        "ok"
      },
      paste0(
        "rho_abs=",
        format_check_number(rho_abs),
        "; boundary=",
        format_check_number(rho_boundary),
        "; ",
        "n_groups=",
        n_group,
        "; min_group_n=",
        min_count,
        "; singleton_groups=",
        singleton_groups,
        "; min_log_sigma_sd=",
        format_check_number(min_sd)
      ),
      bivariate_sigma_re_diagnostic_message(
        near_rho_boundary,
        weak_replication,
        weak_sd,
        rho_unavailable
      )
    ))
  }

  re <- object$model$random$sigma
  if (is.null(re) || re$n_re == 0L || re$n_terms == 0L) {
    return(NULL)
  }
  if (!setequal(re$dpars, c("sigma1", "sigma2"))) {
    return(NULL)
  }

  n_group <- as.integer(re$n_re / re$n_terms)
  group_counts <- tabulate(re$index[, 1L], nbins = n_group)
  min_count <- min(group_counts)
  singleton_groups <- sum(group_counts < 2L)
  sdpars <- object$sdpars$sigma
  sd_values <- unname(sdpars[match(re$labels, names(sdpars))])
  finite_sd_values <- sd_values[is.finite(sd_values)]
  min_sd <- if (length(finite_sd_values) > 0L) {
    min(finite_sd_values)
  } else {
    NA_real_
  }
  weak_sd <- any(finite_sd_values < 0.05)
  weak_replication <- min_count < 2L
  rho_abs <- max_abs_finite_or_na(object$corpars$sigma)
  near_rho_boundary <- random_effect_covariance_near_boundary(
    rho_abs,
    rho_boundary
  )
  rho_unavailable <- random_effect_covariance_rho_unavailable(rho_abs)

  check_row(
    "biv_sigma_random_effect_covariance",
    if (near_rho_boundary) {
      "warning"
    } else if (rho_unavailable || weak_replication || weak_sd) {
      "note"
    } else {
      "ok"
    },
    paste0(
      "rho_abs=",
      format_check_number(rho_abs),
      "; boundary=",
      format_check_number(rho_boundary),
      "; ",
      "n_groups=",
      n_group,
      "; min_group_n=",
      min_count,
      "; singleton_groups=",
      singleton_groups,
      "; min_log_sigma_sd=",
      format_check_number(min_sd)
    ),
    bivariate_sigma_re_diagnostic_message(
      near_rho_boundary,
      weak_replication,
      weak_sd,
      rho_unavailable
    )
  )
}

bivariate_sigma_re_diagnostic_message <- function(
  near_rho_boundary,
  weak_replication,
  weak_sd,
  rho_unavailable = FALSE
) {
  if (near_rho_boundary) {
    return(paste(
      "At least one bivariate scale-scale group-level correlation is close to +/-1;",
      "profile, simulate, or simplify before interpreting the covariance."
    ))
  }
  if (rho_unavailable) {
    return(random_effect_covariance_unavailable_message())
  }
  if (weak_replication && weak_sd) {
    return(paste(
      "At least one group has fewer than two fitted observations and at least",
      "one residual-scale random-effect SD is tiny; interpret the bivariate",
      "scale-scale group-level correlation cautiously."
    ))
  }
  if (weak_replication) {
    return(paste(
      "At least one group has fewer than two fitted observations;",
      "interpret the bivariate scale-scale group-level correlation cautiously."
    ))
  }
  if (weak_sd) {
    return(paste(
      "At least one residual-scale random-effect SD is tiny;",
      "the bivariate scale-scale group-level correlation may be weakly identified."
    ))
  }
  "Bivariate scale-scale covariance has replicated groups and non-negligible log-scale SDs."
}

check_biv_q4_random_effect_covariance <- function(object, rho_boundary) {
  if (!identical(object$model$model_type, "biv_gaussian")) {
    return(NULL)
  }
  registry <- object$model$random$covariance_blocks
  if (
    !is.list(registry) ||
      is.null(registry$blocks) ||
      nrow(registry$blocks) == 0L
  ) {
    return(NULL)
  }

  blocks <- registry$blocks[
    registry$blocks$implemented &
      registry$blocks$n_members == 4L &
      registry$blocks$level == "group",
    ,
    drop = FALSE
  ]
  if (nrow(blocks) == 0L) {
    return(NULL)
  }

  block_summaries <- lapply(seq_len(nrow(blocks)), function(i) {
    block <- blocks[i, , drop = FALSE]
    members <- registry$members[
      registry$members$block_id0 == block$block_id0[[1L]],
      ,
      drop = FALSE
    ]
    pairs <- registry$pairs[
      registry$pairs$block_id0 == block$block_id0[[1L]],
      ,
      drop = FALSE
    ]
    first_member <- members[order(members$member_id0), , drop = FALSE][1L, ]
    group_counts <- registry_member_group_counts(
      first_member,
      block$n_groups[[1L]]
    )
    location_sd_ratios <- bivariate_q4_location_sd_ratios(object, members)
    scale_sd_values <- bivariate_q4_scale_sd_values(object, members)
    correlations <- bivariate_q4_correlations(object, pairs)

    list(
      n_groups = block$n_groups[[1L]],
      min_group_n = min(group_counts),
      singleton_groups = sum(group_counts < 2L),
      min_location_sd_ratio = min_finite_or_na(location_sd_ratios),
      min_log_sigma_sd = min_finite_or_na(scale_sd_values),
      max_abs_cor = max_abs_finite_or_na(correlations)
    )
  })

  min_groups <- min(vapply(block_summaries, `[[`, numeric(1L), "n_groups"))
  min_group_n <- min(vapply(block_summaries, `[[`, numeric(1L), "min_group_n"))
  singleton_groups <- sum(vapply(
    block_summaries,
    `[[`,
    numeric(1L),
    "singleton_groups"
  ))
  min_location_sd_ratio <- min(vapply(
    block_summaries,
    `[[`,
    numeric(1L),
    "min_location_sd_ratio"
  ))
  min_log_sigma_sd <- min(vapply(
    block_summaries,
    `[[`,
    numeric(1L),
    "min_log_sigma_sd"
  ))
  max_abs_cor <- max(vapply(block_summaries, `[[`, numeric(1L), "max_abs_cor"))

  weak_group_count <- min_groups < 8L
  weak_replication <- min_group_n < 2L
  weak_location_sd <- is.finite(min_location_sd_ratio) &&
    min_location_sd_ratio < 0.05
  weak_scale_sd <- is.finite(min_log_sigma_sd) && min_log_sigma_sd < 0.05
  near_rho_boundary <- random_effect_covariance_near_boundary(
    max_abs_cor,
    rho_boundary
  )
  rho_unavailable <- random_effect_covariance_rho_unavailable(max_abs_cor)

  check_row(
    "biv_q4_random_effect_covariance",
    if (near_rho_boundary) {
      "warning"
    } else if (
      rho_unavailable ||
        weak_group_count ||
        weak_replication ||
        weak_location_sd ||
        weak_scale_sd
    ) {
      "note"
    } else {
      "ok"
    },
    paste0(
      "n_blocks=",
      nrow(blocks),
      "; min_groups=",
      min_groups,
      "; min_group_n=",
      min_group_n,
      "; singleton_groups=",
      singleton_groups,
      "; min_location_sd_ratio=",
      format_check_number(min_location_sd_ratio),
      "; min_log_sigma_sd=",
      format_check_number(min_log_sigma_sd),
      "; max_abs_cor=",
      format_check_number(max_abs_cor),
      "; boundary=",
      format_check_number(rho_boundary)
    ),
    bivariate_q4_re_diagnostic_message(
      near_rho_boundary,
      weak_group_count,
      weak_replication,
      weak_location_sd,
      weak_scale_sd,
      rho_unavailable
    )
  )
}

bivariate_q4_location_sd_ratios <- function(object, members) {
  location_members <- members[members$dpar %in% c("mu1", "mu2"), , drop = FALSE]
  if (nrow(location_members) == 0L) {
    return(NA_real_)
  }
  sdpars <- object$sdpars$mu
  sigma_values <- tryCatch(stats::sigma(object), error = function(e) e)
  if (
    is.null(sdpars) ||
      length(sdpars) == 0L ||
      inherits(sigma_values, "error") ||
      !is.list(sigma_values)
  ) {
    return(NA_real_)
  }
  residual_scale <- c(
    mu1 = mean(sigma_values$sigma1, na.rm = TRUE),
    mu2 = mean(sigma_values$sigma2, na.rm = TRUE)
  )
  sd_values <- unname(sdpars[match(location_members$label, names(sdpars))])
  sd_values / residual_scale[location_members$dpar]
}

bivariate_q4_scale_sd_values <- function(object, members) {
  scale_members <- members[
    members$dpar %in% c("sigma1", "sigma2"),
    ,
    drop = FALSE
  ]
  if (nrow(scale_members) == 0L) {
    return(NA_real_)
  }
  sdpars <- object$sdpars$sigma
  if (is.null(sdpars) || length(sdpars) == 0L) {
    return(NA_real_)
  }
  unname(sdpars[match(scale_members$label, names(sdpars))])
}

bivariate_q4_correlations <- function(object, pairs) {
  corpars <- object$corpars$re_cov
  if (is.null(corpars) || length(corpars) == 0L || nrow(pairs) == 0L) {
    return(NA_real_)
  }
  unname(corpars[match(pairs$parameter, names(corpars))])
}

min_finite_or_na <- function(x) {
  x <- x[is.finite(x)]
  if (length(x) == 0L) {
    return(NA_real_)
  }
  min(x)
}

max_finite_or_na <- function(x) {
  x <- x[is.finite(x)]
  if (length(x) == 0L) {
    return(NA_real_)
  }
  max(x)
}

max_abs_finite_or_na <- function(x) {
  x <- x[is.finite(x)]
  if (length(x) == 0L) {
    return(NA_real_)
  }
  max(abs(x))
}

bivariate_q4_re_diagnostic_message <- function(
  near_rho_boundary,
  weak_group_count,
  weak_replication,
  weak_location_sd,
  weak_scale_sd,
  rho_unavailable = FALSE
) {
  if (near_rho_boundary) {
    return(paste(
      "At least one latent q4 group-level correlation is close to +/-1;",
      "profile, simulate, or simplify before interpreting all six correlations."
    ))
  }
  if (rho_unavailable) {
    return(random_effect_covariance_unavailable_message())
  }
  weak <- c(
    if (weak_group_count) "few groups for a four-member covariance block",
    if (weak_replication) {
      "at least one group has fewer than two fitted observations"
    },
    if (weak_location_sd) {
      "at least one location SD is tiny relative to residual scale"
    },
    if (weak_scale_sd) "at least one log-sigma random-effect SD is tiny"
  )
  if (length(weak) > 0L) {
    return(paste(
      "Ordinary q4 location-scale covariance is fitted, but",
      paste(weak, collapse = "; "),
      "so interpret all six latent correlations cautiously."
    ))
  }
  "Ordinary q4 location-scale covariance has replicated groups, non-negligible fitted component SDs, and latent correlations away from the boundary."
}

random_effect_label_is_intercept <- function(label) {
  grepl("^\\(1 \\| [^)]+\\)$", label) || grepl(":(Intercept)$", label)
}

random_effect_unique_n <- function(x) {
  length(unique(x[is.finite(x)]))
}

random_effect_correlated_block_ranks <- function(re) {
  if (re$n_cors == 0L) {
    return(character())
  }
  term_cor_id <- vapply(
    seq_len(re$n_terms),
    function(k) {
      ids <- unique(re$re_cor_id0[re$term_id0 == k - 1L])
      ids <- ids[ids >= 0L]
      if (length(ids) == 0L) -1L else ids[[1L]]
    },
    integer(1)
  )
  out <- character()
  for (cor_id in unique(term_cor_id[term_cor_id >= 0L])) {
    cols <- which(term_cor_id == cor_id)
    group_id <- re$index[, cols[[1L]]]
    ranks <- vapply(
      split(seq_along(group_id), group_id),
      function(row) {
        qr(re$value[row, cols, drop = FALSE])$rank
      },
      integer(1)
    )
    out <- c(out, paste0(min(ranks), "/", length(cols)))
  }
  names(out) <- re$cor_labels[unique(term_cor_id[term_cor_id >= 0L]) + 1L]
  out
}

check_phylo_replication <- function(object) {
  if (!has_phylo_mu_effect(object)) {
    return(NULL)
  }
  index <- object$model$structured$phylo_mu$observation_node_index
  counts <- tabulate(match(index, unique(index)))
  min_count <- min(counts)
  check_row(
    "phylo_mu_replication",
    if (min_count < 2L) "note" else "ok",
    paste0("min_species_n=", min_count),
    if (min_count < 2L) {
      "At least one observed species has one fitted observation; phylogenetic SD may be weakly identified."
    } else {
      "Every observed species has at least two fitted observations."
    }
  )
}

# Fitted phylogenetic-SD values for the phylo_mu effect. A scalar `sd_phylo`
# model stores one SD per coefficient in `object$sdpars$mu`; a direct-SD surface
# model (`sd_phylo(...) ~ .`, `has_sd_phylo_model == 1`) has NO scalar SD -- it
# fits one SD per group, ADREPORTed/REPORTed as `sd_phylo_group` and surfaced in
# R as `object$sdpars[[dpar]]`. Reading the (absent) scalar for a surface model
# yields NA and mis-fires `phylo_mu_diagnostics` as an error (reported by
# A. Mizuno, 2026-07-08); summarise the fitted surface instead.
phylo_mu_diagnostic_sd_values <- function(object, phylo_mu) {
  sd_phylo <- object$model$random_scale$phylo
  is_surface <- is.list(sd_phylo) &&
    !is.null(sd_phylo$n_models) &&
    sd_phylo$n_models > 0L
  if (is_surface) {
    mu_dpars <- phylo_mu_endpoint_dpars(phylo_mu)
    surface_dpars <- Filter(
      function(d) {
        target <- sd_phylo$target_dpar[[d]]
        if (is.null(target) || is.na(target)) {
          target <- "mu"
        }
        target %in% mu_dpars
      },
      sd_phylo$dpars
    )
    if (length(surface_dpars) > 0L) {
      values <- unlist(
        lapply(surface_dpars, function(d) unname(object$sdpars[[d]])),
        use.names = FALSE
      )
      return(list(values = values, is_surface = TRUE, count = length(values)))
    }
  }
  sd_label <- phylo_mu_sd_labels(phylo_mu, object$model$model_type)
  values <- unname(object$sdpars$mu[match(sd_label, names(object$sdpars$mu))])
  list(values = values, is_surface = FALSE, count = length(sd_label))
}

check_phylo_mu_diagnostics <- function(object) {
  if (!has_phylo_mu_effect(object)) {
    return(NULL)
  }

  phylo_mu <- object$model$structured$phylo_mu
  index <- phylo_mu$observation_node_index
  counts <- tabulate(match(index, unique(index)))
  min_count <- if (length(counts) > 0L) min(counts) else NA_integer_
  n_species <- length(counts)
  weak_replication <- is.finite(min_count) && min_count < 2L

  sd_summary <- phylo_mu_diagnostic_sd_values(object, phylo_mu)
  sd_values <- sd_summary$values
  is_surface <- sd_summary$is_surface
  sd_count <- sd_summary$count
  finite_positive_sd <- length(sd_values) > 0L &&
    all(is.finite(sd_values)) &&
    all(sd_values > 0)

  residual_scale <- spatial_mu_residual_scale(object)
  sd_ratios <- if (finite_positive_sd && is.finite(residual_scale)) {
    sd_values / residual_scale
  } else {
    NA_real_
  }
  finite_sd_ratios <- sd_ratios[is.finite(sd_ratios)]
  has_scale_ratio <- length(finite_sd_ratios) > 0L
  min_sd <- if (finite_positive_sd) min(sd_values) else NA_real_
  min_sd_ratio <- if (has_scale_ratio) {
    min(finite_sd_ratios)
  } else {
    NA_real_
  }
  weak_sd <- !finite_positive_sd ||
    (has_scale_ratio && any(finite_sd_ratios < 0.05))
  finite_sd <- sd_values[is.finite(sd_values)]
  sd_text <- if (is_surface) {
    paste0(
      "; n_group=",
      sd_count,
      "; phylo_sd_range=[",
      format_check_number(min_finite_or_na(finite_sd)),
      ",",
      format_check_number(max_finite_or_na(finite_sd)),
      "]",
      "; median_phylo_sd=",
      format_check_number(
        if (length(finite_sd) > 0L) stats::median(finite_sd) else NA_real_
      ),
      if (has_scale_ratio) {
        paste0("; min_sd_ratio=", format_check_number(min_sd_ratio))
      } else {
        ""
      }
    )
  } else if (sd_count == 1L) {
    paste0(
      "; phylo_sd=",
      format_check_number(sd_values),
      if (has_scale_ratio) {
        paste0("; sd_ratio=", format_check_number(sd_ratios))
      } else {
        ""
      }
    )
  } else {
    paste0(
      "; n_coef=",
      sd_count,
      "; min_phylo_sd=",
      format_check_number(min_sd),
      if (has_scale_ratio) {
        paste0("; min_sd_ratio=", format_check_number(min_sd_ratio))
      } else {
        ""
      }
    )
  }

  check_row(
    "phylo_mu_diagnostics",
    if (!finite_positive_sd) {
      "error"
    } else if (weak_replication || weak_sd) {
      "note"
    } else {
      "ok"
    },
    paste0(
      "group=",
      phylo_mu$group,
      "; n_species=",
      n_species,
      "; min_species_n=",
      min_count,
      sd_text
    ),
    phylo_mu_diagnostic_message(
      finite_positive_sd,
      weak_replication,
      weak_sd,
      has_scale_ratio
    )
  )
}

phylo_mu_diagnostic_message <- function(
  finite_positive_sd,
  weak_replication,
  weak_sd,
  has_scale_ratio = TRUE
) {
  if (!finite_positive_sd) {
    return(paste(
      "The fitted phylogenetic SD is non-positive or non-finite;",
      "inspect convergence, tree input, and the fitted structured effect."
    ))
  }
  if (weak_replication && weak_sd) {
    return(paste(
      "At least one species has fewer than two fitted observations and the",
      "phylogenetic SD is tiny relative to residual scale; interpret the",
      "phylogenetic field cautiously."
    ))
  }
  if (weak_replication) {
    return(paste(
      "At least one species has fewer than two fitted observations;",
      "interpret conditional phylogenetic effects and SDs cautiously."
    ))
  }
  if (weak_sd) {
    return(paste(
      "The phylogenetic SD is tiny relative to residual scale; the structured",
      "phylogenetic field may be weakly identified."
    ))
  }
  if (!isTRUE(has_scale_ratio)) {
    return(paste(
      "The phylogenetic random effect has replicated species and a finite",
      "positive fitted SD."
    ))
  }
  paste(
    "The phylogenetic random effect has replicated species and a non-negligible",
    "fitted SD relative to residual scale."
  )
}

check_spatial_mu_diagnostics <- function(object) {
  if (!has_spatial_mu_effect(object)) {
    return(NULL)
  }

  spatial_mu <- object$model$structured$phylo_mu
  index <- spatial_mu$observation_node_index
  counts <- tabulate(match(index, unique(index)))
  min_count <- if (length(counts) > 0L) min(counts) else NA_integer_
  n_sites <- length(counts)
  weak_replication <- is.finite(min_count) && min_count < 2L

  sd_label <- phylo_mu_sd_labels(spatial_mu, object$model$model_type)
  sd_values <- unname(object$sdpars$mu[match(
    sd_label,
    names(object$sdpars$mu)
  )])
  finite_positive_sd <- length(sd_values) == length(sd_label) &&
    all(is.finite(sd_values)) &&
    all(sd_values > 0)

  residual_scale <- spatial_mu_residual_scale(object)
  sd_ratios <- if (finite_positive_sd && is.finite(residual_scale)) {
    sd_values / residual_scale
  } else {
    NA_real_
  }
  finite_sd_ratios <- sd_ratios[is.finite(sd_ratios)]
  has_scale_ratio <- length(finite_sd_ratios) > 0L
  min_sd <- if (finite_positive_sd) min(sd_values) else NA_real_
  min_sd_ratio <- if (has_scale_ratio) {
    min(finite_sd_ratios)
  } else {
    NA_real_
  }
  weak_sd <- !finite_positive_sd ||
    (has_scale_ratio && any(finite_sd_ratios < 0.05))

  coord_range <- spatial_mu$precision$range
  sd_text <- if (length(sd_label) == 1L) {
    paste0(
      "; spatial_sd=",
      format_check_number(sd_values),
      "; sd_ratio=",
      format_check_number(sd_ratios)
    )
  } else {
    paste0(
      "; n_coef=",
      length(sd_label),
      "; min_spatial_sd=",
      format_check_number(min_sd),
      "; min_sd_ratio=",
      format_check_number(min_sd_ratio)
    )
  }
  check_row(
    "spatial_mu_diagnostics",
    if (!finite_positive_sd) {
      "error"
    } else if (weak_replication || weak_sd) {
      "note"
    } else {
      "ok"
    },
    paste0(
      "group=",
      spatial_mu$group,
      "; n_sites=",
      n_sites,
      "; min_site_n=",
      min_count,
      "; coord_range=",
      format_check_number(coord_range),
      sd_text
    ),
    spatial_mu_diagnostic_message(
      finite_positive_sd,
      weak_replication,
      weak_sd
    )
  )
}

# Keep the mesh route distinct from the coordinate-spatial diagnostic above:
# its field is projected from vertices and its reported scale is the raw GMRF
# multiplier, not a coordinate-range or uniform marginal-SD estimate.
check_mesh_spatial_mu_diagnostics <- function(object) {
  mesh <- object$model$structured$mesh_spatial_mu
  if (is.null(mesh) || !isTRUE(mesh$has)) {
    return(NULL)
  }
  field_scale <- unname(object$sdpars$mu[[mesh$label]])
  finite_positive <- length(field_scale) == 1L && is.finite(field_scale) &&
    field_scale > 0
  check_row(
    "mesh_spatial_mu_diagnostics",
    if (finite_positive) "note" else "error",
    paste0(
      "group=", mesh$group,
      "; n_vertices=", mesh$n_re,
      "; kappa_fixed=", format_check_number(mesh$kappa_fixed),
      "; field_scale=", format_check_number(field_scale)
    ),
    if (finite_positive) {
      paste(
        "Fixed-kappa mesh spatial field has point-recovery evidence only for",
        "the exact tested n=128 and n=256 fixed-domain designs; intervals,",
        "coverage, projected marginal-SD inference, and range are not claimed."
      )
    } else {
      paste(
        "The fitted fixed-kappa mesh GMRF field scale is non-positive or non-finite;",
        "inspect convergence, the projected CRS, mesh-to-retained-row alignment,",
        "and the fixed kappa/mesh construction."
      )
    }
  )
}

spatial_mu_residual_scale <- function(object) {
  if (!object$model$model_type %in% c("gaussian", "biv_gaussian")) {
    return(NA_real_)
  }
  sigma_values <- tryCatch(stats::sigma(object), error = function(e) e)
  if (inherits(sigma_values, "error")) {
    return(NA_real_)
  }
  if (is.list(sigma_values)) {
    sigma_values <- unlist(sigma_values, use.names = FALSE)
  }
  mean(sigma_values, na.rm = TRUE)
}

spatial_mu_diagnostic_message <- function(
  finite_positive_sd,
  weak_replication,
  weak_sd
) {
  if (!finite_positive_sd) {
    return(paste(
      "The fitted spatial SD is non-positive or non-finite;",
      "inspect convergence, coordinate input, and the fitted structured effect."
    ))
  }
  if (weak_replication && weak_sd) {
    return(paste(
      "At least one spatial site has fewer than two fitted observations and",
      "the spatial SD is tiny relative to the residual scale; interpret the",
      "coordinate spatial field cautiously."
    ))
  }
  if (weak_replication) {
    return(paste(
      "At least one spatial site has fewer than two fitted observations;",
      "interpret conditional spatial effects and the spatial SD cautiously."
    ))
  }
  if (weak_sd) {
    return(paste(
      "The spatial SD is tiny relative to the residual scale; the coordinate",
      "spatial field may be weakly identified."
    ))
  }
  paste(
    "The coordinate spatial random intercept has replicated sites and a",
    "non-negligible fitted SD relative to the residual scale."
  )
}

check_known_relatedness_mu_diagnostics <- function(object) {
  structured_mu <- object$model$structured$phylo_mu
  type <- structured_mu_type(structured_mu)
  if (!type %in% c("animal", "relmat")) {
    return(NULL)
  }

  index <- structured_mu$observation_node_index
  counts <- tabulate(match(index, unique(index)))
  min_count <- if (length(counts) > 0L) min(counts) else NA_integer_
  weak_replication <- is.finite(min_count) && min_count < 2L
  sd_label <- phylo_mu_sd_labels(structured_mu, object$model$model_type)
  sd_values <- unname(object$sdpars$mu[match(
    sd_label,
    names(object$sdpars$mu)
  )])
  finite_positive_sd <- length(sd_values) == length(sd_label) &&
    all(is.finite(sd_values)) &&
    all(sd_values > 0)
  residual_scale <- spatial_mu_residual_scale(object)
  sd_ratios <- if (finite_positive_sd && is.finite(residual_scale)) {
    sd_values / residual_scale
  } else {
    NA_real_
  }
  finite_sd_ratios <- sd_ratios[is.finite(sd_ratios)]
  min_sd <- if (finite_positive_sd) min(sd_values) else NA_real_
  min_sd_ratio <- if (length(finite_sd_ratios) > 0L) {
    min(finite_sd_ratios)
  } else {
    NA_real_
  }
  weak_sd <- !finite_positive_sd ||
    any(finite_sd_ratios < 0.05)
  sd_text <- if (length(sd_label) == 1L) {
    paste0(
      "; structured_sd=",
      format_check_number(sd_values),
      "; sd_ratio=",
      format_check_number(sd_ratios)
    )
  } else {
    paste0(
      "; n_coef=",
      length(sd_label),
      "; min_structured_sd=",
      format_check_number(min_sd),
      "; min_sd_ratio=",
      format_check_number(min_sd_ratio)
    )
  }

  check_row(
    paste0(type, "_mu_diagnostics"),
    if (!finite_positive_sd) {
      "error"
    } else if (weak_replication || weak_sd) {
      "note"
    } else {
      "ok"
    },
    paste0(
      "group=",
      structured_mu$group,
      "; n_nodes=",
      structured_mu$n_re,
      "; n_observed=",
      length(unique(index)),
      "; min_group_n=",
      min_count,
      "; matrix_type=",
      structured_mu$precision$matrix_type,
      sd_text
    ),
    known_relatedness_mu_diagnostic_message(
      type,
      finite_positive_sd,
      weak_replication,
      weak_sd
    )
  )
}

known_relatedness_mu_diagnostic_message <- function(
  type,
  finite_positive_sd,
  weak_replication,
  weak_sd
) {
  label <- if (identical(type, "animal")) "animal-model" else "relatedness"
  if (!finite_positive_sd) {
    return(paste(
      "The fitted",
      label,
      "SD is non-positive or non-finite; inspect convergence and the supplied matrix."
    ))
  }
  if (weak_replication && weak_sd) {
    return(paste(
      "At least one observed level has fewer than two fitted observations and",
      "the",
      label,
      "SD is tiny relative to residual scale; interpret the structured effect cautiously."
    ))
  }
  if (weak_replication) {
    return(paste(
      "At least one observed level has fewer than two fitted observations;",
      "interpret conditional",
      label,
      "effects and the structured SD cautiously."
    ))
  }
  if (weak_sd) {
    return(paste(
      "The",
      label,
      "SD is tiny relative to residual scale; the structured effect may be weakly identified."
    ))
  }
  paste(
    "The",
    label,
    "random intercept has replicated observed levels and a non-negligible fitted SD relative to residual scale."
  )
}

check_phylo_direct_sd_model <- function(object) {
  sd_phylo <- object$model$random_scale$phylo
  if (
    !is.list(sd_phylo) ||
      is.null(sd_phylo$n_models) ||
      sd_phylo$n_models == 0L
  ) {
    return(NULL)
  }

  rows <- lapply(sd_phylo$dpars, function(dpar) {
    group <- unname(sd_phylo$group[[dpar]])
    target <- unname(sd_phylo$target_dpar[[dpar]])
    if (is.null(target) || is.na(target)) {
      target <- "mu"
    }
    group_levels <- sd_phylo$group_levels_list[[dpar]]
    observation_sd_row0 <- sd_phylo$observation_sd_row0_list[[dpar]]
    if (is.null(observation_sd_row0)) {
      observation_sd_row0 <- sd_phylo$observation_sd_row0
    }
    counts <- tabulate(
      observation_sd_row0 + 1L,
      nbins = length(group_levels)
    )
    min_count <- if (length(counts) > 0L) min(counts) else NA_integer_
    n_species <- length(group_levels)

    sd_values <- object$sdpars[[dpar]]
    finite_sd <- sd_values[is.finite(sd_values)]
    sd_min <- min_finite_or_na(finite_sd)
    sd_max <- max_finite_or_na(finite_sd)
    positive_sd <- finite_sd[finite_sd > 0]
    max_sd_ratio <- if (length(positive_sd) > 0L) {
      max(positive_sd) / min(positive_sd)
    } else {
      NA_real_
    }

    invalid_sd <- length(sd_values) == 0L ||
      length(finite_sd) != length(sd_values) ||
      any(sd_values <= 0, na.rm = TRUE)
    weak_replication <- is.finite(min_count) && min_count < 2L

    check_row(
      "phylo_direct_sd_model",
      if (invalid_sd) {
        "error"
      } else if (weak_replication) {
        "note"
      } else {
        "ok"
      },
      paste0(
        "dpar=",
        dpar,
        "; target=",
        target,
        "; group=",
        group,
        "; n_species=",
        n_species,
        "; min_species_n=",
        min_count,
        "; sd_range=[",
        format_check_number(sd_min),
        ",",
        format_check_number(sd_max),
        "]",
        "; max_sd_ratio=",
        format_check_number(max_sd_ratio)
      ),
      phylo_direct_sd_message(dpar, invalid_sd, weak_replication)
    )
  })

  do.call(rbind, rows)
}

phylo_direct_sd_message <- function(dpar, invalid_sd, weak_replication) {
  if (invalid_sd) {
    return(paste0(
      "The fitted ",
      dpar,
      " surface contains non-finite or non-positive values."
    ))
  }
  if (weak_replication) {
    return(paste(
      "At least one observed species has fewer than two fitted observations;",
      dpar,
      "recovery can be weak even when the fitted model converges."
    ))
  }
  paste(
    "The",
    dpar,
    "direct-SD model has replicated species and a finite",
    "positive fitted species-level SD surface."
  )
}

# Shared shift in the latent phylogenetic field when its SD depends on
# covariates. The latent field u has prior N(0, Q^-1) with the root fixed at 0,
# and the mean receives u_i * SD_i. A common shift delta in u therefore adds
# delta * SD_i(x) to the mean: a curved function of the SD covariates that can
# stand in for curvature missing from the location formula, producing separate
# optima. z = 1'Qu / sqrt(1'Q1) is the prior-precision-weighted shift in prior
# SD units (standard normal under the prior; z^2 / 2 is its prior cost). See
# docs/design/277-sd-phylo-root-offset-identifiability.md.
phylo_shared_shift_threshold_note <- 2
phylo_shared_shift_threshold_warning <- 3

phylo_shared_shift_statistic <- function(Q, u) {
  Q1 <- as.numeric(Matrix::rowSums(Q))
  one_Q_one <- sum(Q1)
  if (
    length(Q1) != length(u) ||
      !is.finite(one_Q_one) ||
      one_Q_one <= 0 ||
      any(!is.finite(u))
  ) {
    return(NULL)
  }
  one_Q_u <- sum(Q1 * u)
  list(
    shift = one_Q_u / one_Q_one,
    z = one_Q_u / sqrt(one_Q_one),
    prior_cost = one_Q_u^2 / (2 * one_Q_one)
  )
}

check_phylo_sd_shared_shift <- function(object) {
  sd_phylo <- object$model$random_scale$phylo
  if (
    !is.list(sd_phylo) ||
      is.null(sd_phylo$n_models) ||
      sd_phylo$n_models == 0L
  ) {
    return(NULL)
  }
  phylo_mu <- object$model$structured$phylo_mu
  Q <- phylo_mu$precision$precision
  latent <- object$random_effects$phylo_mu$latent
  if (is.null(Q) || is.null(latent)) {
    return(NULL)
  }
  n_node <- nrow(Q)
  endpoints <- phylo_mu_endpoint_dpars(phylo_mu)
  if (n_node < 1L || length(latent) != n_node * length(endpoints)) {
    return(NULL)
  }

  rows <- lapply(sd_phylo$dpars, function(dpar) {
    X <- sd_phylo$X_list[[dpar]]
    if (is.null(X) || NCOL(X) < 2L) {
      # An intercept-only SD scales the field by a constant, so a shared
      # shift is absorbed by the location intercept and cannot bend the mean.
      return(NULL)
    }
    target <- unname(sd_phylo$target_dpar[[dpar]])
    if (is.null(target) || is.na(target)) {
      target <- "mu"
    }
    k <- match(target, endpoints)
    if (is.na(k)) {
      return(NULL)
    }
    u <- unname(latent[(k - 1L) * n_node + seq_len(n_node)])
    stat <- phylo_shared_shift_statistic(Q, u)
    if (is.null(stat)) {
      return(NULL)
    }
    sd_values <- object$sdpars[[dpar]]
    finite_sd <- sd_values[is.finite(sd_values)]
    mean_shift <- stat$shift * c(
      min_finite_or_na(finite_sd),
      max_finite_or_na(finite_sd)
    )
    abs_z <- abs(stat$z)
    status <- if (abs_z >= phylo_shared_shift_threshold_warning) {
      "warning"
    } else if (abs_z >= phylo_shared_shift_threshold_note) {
      "note"
    } else {
      "ok"
    }
    check_row(
      "phylo_sd_shared_shift",
      status,
      paste0(
        "dpar=",
        dpar,
        "; target=",
        target,
        "; z_shared=",
        format_check_number(stat$z),
        "; latent_shift=",
        format_check_number(stat$shift),
        "; mean_shift_range=[",
        format_check_number(min(mean_shift)),
        ",",
        format_check_number(max(mean_shift)),
        "]"
      ),
      phylo_shared_shift_message(dpar, status)
    )
  })

  rows <- Filter(Negate(is.null), rows)
  if (length(rows) == 0L) {
    return(NULL)
  }
  do.call(rbind, rows)
}

phylo_shared_shift_message <- function(dpar, status) {
  if (identical(status, "ok")) {
    return(paste(
      "The fitted phylogenetic effects show no large shared shift, so the",
      dpar,
      "covariates are not visibly standing in for curvature in the mean."
    ))
  }
  paste(
    "The fitted phylogenetic effects share a large common shift. Because",
    dpar,
    "depends on covariates, that shift adds shift x SD to every mean, a curved",
    "function of those covariates, so the location coefficients may be",
    "compensating for curvature the mean model lacks, and other starts can",
    "reach a different optimum. Check the mean for missing curvature (for",
    "example quadratic terms), refit from other starting values, and interpret",
    "the location coefficients with care. See",
    "docs/design/277-sd-phylo-root-offset-identifiability.md."
  )
}

check_biv_phylo_mu_covariance <- function(object, rho_boundary) {
  if (
    !identical(object$model$model_type, "biv_gaussian") ||
      !has_phylo_mu_effect(object)
  ) {
    return(NULL)
  }

  phylo_mu <- object$model$structured$phylo_mu
  if (!identical(as.integer(phylo_mu$q), 2L)) {
    return(NULL)
  }

  rho <- object$corpars$phylo
  rho_finite <- length(rho) > 0L && all(is.finite(rho))
  rho_abs <- if (rho_finite) {
    max(abs(rho))
  } else {
    NA_real_
  }
  near_rho_boundary <- random_effect_covariance_near_boundary(
    rho_abs,
    rho_boundary
  )
  rho_unavailable <- random_effect_covariance_rho_unavailable(rho_abs)

  index <- phylo_mu$observation_node_index
  counts <- tabulate(match(index, unique(index)))
  min_count <- if (length(counts) > 0L) {
    min(counts)
  } else {
    NA_integer_
  }
  n_species <- length(counts)
  weak_replication <- is.finite(min_count) && min_count < 2L

  sd_ratios <- bivariate_phylo_mu_sd_ratios(object)
  finite_sd_ratios <- sd_ratios[is.finite(sd_ratios)]
  min_sd_ratio <- if (length(finite_sd_ratios) > 0L) {
    min(finite_sd_ratios)
  } else {
    NA_real_
  }
  weak_sd <- length(sd_ratios) == 0L ||
    length(finite_sd_ratios) != length(sd_ratios) ||
    any(finite_sd_ratios < 0.05)
  same_group_covariance <- bivariate_phylo_mu_has_same_group_covariance(object)

  check_row(
    "biv_phylo_mu_covariance",
    if (near_rho_boundary) {
      "warning"
    } else if (
      rho_unavailable || weak_replication || weak_sd || same_group_covariance
    ) {
      "note"
    } else {
      "ok"
    },
    paste0(
      "group=",
      phylo_mu$group,
      "; rho_abs=",
      format_check_number(rho_abs),
      "; boundary=",
      format_check_number(rho_boundary),
      "; n_species=",
      n_species,
      "; min_species_n=",
      min_count,
      "; min_sd_ratio=",
      format_check_number(min_sd_ratio),
      "; same_group_covariance=",
      tolower(as.character(same_group_covariance))
    ),
    bivariate_phylo_mu_diagnostic_message(
      near_rho_boundary,
      weak_replication,
      weak_sd,
      same_group_covariance,
      rho_unavailable
    )
  )
}

check_biv_structured_q2_covariance <- function(object, rho_boundary) {
  if (
    !identical(object$model$model_type, "biv_gaussian") ||
      !has_structured_mu_effect(object)
  ) {
    return(NULL)
  }

  structured_mu <- object$model$structured$phylo_mu
  if (!identical(as.integer(structured_mu$q), 2L)) {
    return(NULL)
  }
  structured_type <- structured_mu_type(structured_mu)
  if (identical(structured_type, "phylo")) {
    return(NULL)
  }

  cor_key <- structured_mu_correlation_key(structured_mu)
  correlations <- object$corpars[[cor_key]]
  rho_abs <- max_abs_finite_or_na(correlations)
  near_rho_boundary <- random_effect_covariance_near_boundary(
    rho_abs,
    rho_boundary
  )
  rho_unavailable <- random_effect_covariance_rho_unavailable(rho_abs)

  index <- structured_mu$observation_node_index
  counts <- tabulate(match(index, unique(index)))
  min_count <- if (length(counts) > 0L) {
    min(counts)
  } else {
    NA_integer_
  }
  n_levels <- length(counts)
  weak_replication <- is.finite(min_count) && min_count < 2L

  sd_ratios <- bivariate_structured_q2_sd_ratios(object, structured_mu)
  finite_sd_ratios <- sd_ratios[is.finite(sd_ratios)]
  min_sd_ratio <- if (length(finite_sd_ratios) > 0L) {
    min(finite_sd_ratios)
  } else {
    NA_real_
  }
  weak_sd <- length(sd_ratios) == 0L ||
    length(finite_sd_ratios) != length(sd_ratios) ||
    any(finite_sd_ratios < 0.05)

  check_row(
    paste0("biv_", structured_type, "_q2_covariance"),
    if (near_rho_boundary) {
      "warning"
    } else if (rho_unavailable || weak_replication || weak_sd) {
      "note"
    } else {
      "ok"
    },
    paste0(
      "group=",
      structured_mu$group,
      "; rho_abs=",
      format_check_number(rho_abs),
      "; boundary=",
      format_check_number(rho_boundary),
      "; n_levels=",
      n_levels,
      "; min_level_n=",
      min_count,
      "; min_sd_ratio=",
      format_check_number(min_sd_ratio)
    ),
    bivariate_structured_q2_diagnostic_message(
      structured_q4_diagnostic_title(structured_type),
      near_rho_boundary,
      weak_replication,
      weak_sd,
      rho_unavailable
    )
  )
}

check_biv_structured_q4_covariance <- function(object, rho_boundary) {
  if (
    !identical(object$model$model_type, "biv_gaussian") ||
      !has_structured_mu_effect(object)
  ) {
    return(NULL)
  }

  phylo_mu <- object$model$structured$phylo_mu
  if (!identical(as.integer(phylo_mu$q), 4L)) {
    return(NULL)
  }
  structured_type <- structured_mu_type(phylo_mu)
  cor_key <- structured_mu_correlation_key(phylo_mu)
  type_title <- structured_q4_diagnostic_title(structured_type)
  count_label <- if (identical(structured_type, "phylo")) {
    "n_species"
  } else {
    "n_levels"
  }
  min_count_label <- if (identical(structured_type, "phylo")) {
    "min_species_n"
  } else {
    "min_level_n"
  }

  index <- phylo_mu$observation_node_index
  counts <- tabulate(match(index, unique(index)))
  min_count <- if (length(counts) > 0L) min(counts) else NA_integer_
  n_levels <- length(counts)
  weak_level_count <- n_levels < 8L
  weak_replication <- is.finite(min_count) && min_count < 2L

  sd_summaries <- bivariate_phylo_q4_sd_summaries(object, phylo_mu)
  correlations <- object$corpars[[cor_key]]
  max_abs_cor <- max_abs_finite_or_na(correlations)

  weak_location_sd <- is.finite(sd_summaries$min_location_sd_ratio) &&
    sd_summaries$min_location_sd_ratio < 0.05
  weak_scale_sd <- is.finite(sd_summaries$min_log_sigma_sd) &&
    sd_summaries$min_log_sigma_sd < 0.05
  near_rho_boundary <- random_effect_covariance_near_boundary(
    max_abs_cor,
    rho_boundary
  )
  rho_unavailable <- random_effect_covariance_rho_unavailable(max_abs_cor)

  check_row(
    paste0("biv_", structured_type, "_q4_covariance"),
    if (near_rho_boundary) {
      "warning"
    } else if (
      rho_unavailable ||
        weak_level_count ||
        weak_replication ||
        weak_location_sd ||
        weak_scale_sd
    ) {
      "note"
    } else {
      "ok"
    },
    paste0(
      "group=",
      phylo_mu$group,
      "; block=",
      paste(unique(phylo_mu_endpoint_blocks(phylo_mu)), collapse = "/"),
      "; covariance_mode=",
      phylo_mu_covariance_mode(phylo_mu),
      "; q=4",
      "; ",
      count_label,
      "=",
      n_levels,
      "; ",
      min_count_label,
      "=",
      min_count,
      "; min_location_sd_ratio=",
      format_check_number(sd_summaries$min_location_sd_ratio),
      "; min_log_sigma_sd=",
      format_check_number(sd_summaries$min_log_sigma_sd),
      "; max_abs_cor=",
      format_check_number(max_abs_cor),
      "; boundary=",
      format_check_number(rho_boundary)
    ),
    bivariate_phylo_q4_diagnostic_message(
      type_title,
      near_rho_boundary,
      weak_level_count,
      weak_replication,
      weak_location_sd,
      weak_scale_sd,
      rho_unavailable
    )
  )
}

bivariate_structured_q2_sd_ratios <- function(object, structured_mu) {
  sdpars <- object$sdpars$mu
  if (is.null(sdpars) || length(sdpars) == 0L) {
    return(numeric())
  }
  labels <- phylo_mu_sd_labels(structured_mu, object$model$model_type)
  dpars <- phylo_mu_dpars(structured_mu)
  sd_values <- unname(sdpars[match(labels, names(sdpars))])
  sigma_values <- tryCatch(stats::sigma(object), error = function(e) e)
  if (inherits(sigma_values, "error") || !is.list(sigma_values)) {
    return(rep(NA_real_, length(sd_values)))
  }
  residual_scale <- c(
    mu1 = mean(sigma_values$sigma1, na.rm = TRUE),
    mu2 = mean(sigma_values$sigma2, na.rm = TRUE)
  )
  sd_values / residual_scale[dpars]
}

bivariate_structured_q2_diagnostic_message <- function(
  type_title,
  near_rho_boundary,
  weak_replication,
  weak_sd,
  rho_unavailable = FALSE
) {
  if (near_rho_boundary && (weak_replication || weak_sd)) {
    return(paste(
      "The fitted",
      tolower(type_title),
      "q2 location correlation is close to +/-1 and replication or",
      "structured SD evidence is weak; inspect profiles, simulation, or a",
      "simpler structured-effect model before interpreting it."
    ))
  }
  if (near_rho_boundary) {
    return(paste(
      "The fitted",
      tolower(type_title),
      "q2 location correlation is close to +/-1; inspect likelihood profiles",
      "or compare against a model without the structured covariance before",
      "interpreting it."
    ))
  }
  if (rho_unavailable) {
    return(random_effect_covariance_unavailable_message())
  }
  if (weak_replication && weak_sd) {
    return(paste(
      "At least one observed level has fewer than two fitted observations and",
      "at least one",
      tolower(type_title),
      "location SD is tiny relative to its matching residual scale; interpret",
      "the structured q2 correlation cautiously."
    ))
  }
  if (weak_replication) {
    return(paste(
      "At least one observed level has fewer than two fitted observations;",
      "interpret the structured q2 correlation cautiously."
    ))
  }
  if (weak_sd) {
    return(paste(
      "At least one",
      tolower(type_title),
      "location SD is tiny relative to its matching residual scale; the",
      "structured q2 correlation may be weakly identified."
    ))
  }
  paste(
    type_title,
    "q2 location covariance has replicated levels, non-negligible fitted",
    "component SDs, and a latent correlation away from the boundary."
  )
}

bivariate_phylo_q4_sd_summaries <- function(object, phylo_mu) {
  sdpars <- object$sdpars$mu
  labels <- phylo_mu_sd_labels(phylo_mu, object$model$model_type)
  dpars <- phylo_mu_dpars(phylo_mu)
  sd_values <- unname(sdpars[match(labels, names(sdpars))])

  location <- dpars %in% c("mu1", "mu2")
  scale <- dpars %in% c("sigma1", "sigma2")
  sigma_values <- tryCatch(stats::sigma(object), error = function(e) e)
  if (!inherits(sigma_values, "error") && is.list(sigma_values)) {
    residual_scale <- c(
      mu1 = mean(sigma_values$sigma1, na.rm = TRUE),
      mu2 = mean(sigma_values$sigma2, na.rm = TRUE)
    )
    location_ratios <- sd_values[location] / residual_scale[dpars[location]]
  } else {
    location_ratios <- rep(NA_real_, sum(location))
  }

  list(
    min_location_sd_ratio = min_finite_or_na(location_ratios),
    min_log_sigma_sd = min_finite_or_na(sd_values[scale])
  )
}

bivariate_phylo_q4_diagnostic_message <- function(
  type_title,
  near_rho_boundary,
  weak_level_count,
  weak_replication,
  weak_location_sd,
  weak_scale_sd,
  rho_unavailable = FALSE
) {
  if (near_rho_boundary) {
    return(paste(
      "At least one latent",
      tolower(type_title),
      "q4 correlation is close to +/-1;",
      "profile, simulate, or simplify before interpreting the structured correlations."
    ))
  }
  if (rho_unavailable) {
    return(random_effect_covariance_unavailable_message())
  }
  weak <- c(
    if (weak_level_count) {
      paste("few levels for a four-endpoint", tolower(type_title), "block")
    },
    if (weak_replication) {
      "at least one observed level has fewer than two fitted observations"
    },
    if (weak_location_sd) {
      paste(
        "at least one",
        tolower(type_title),
        "location SD is tiny relative to residual scale"
      )
    },
    if (weak_scale_sd) {
      paste("at least one", tolower(type_title), "log-sigma SD is tiny")
    }
  )
  if (length(weak) > 0L) {
    return(paste(
      type_title,
      "q4 location-scale covariance is fitted, but",
      paste(weak, collapse = "; "),
      "so interpret all six latent structured correlations cautiously."
    ))
  }
  paste(
    type_title,
    "q4 location-scale covariance has replicated levels, non-negligible fitted component SDs, and latent correlations away from the boundary."
  )
}

structured_q4_diagnostic_title <- function(structured_type) {
  switch(
    structured_type,
    phylo = "Phylogenetic",
    spatial = "Spatial",
    animal = "Animal-model",
    relmat = "relmat",
    structured_type
  )
}

bivariate_phylo_mu_has_same_group_covariance <- function(object) {
  blocks <- object$model$random$covariance_blocks
  if (
    is.null(blocks) ||
      is.null(blocks$blocks) ||
      is.null(blocks$members) ||
      nrow(blocks$blocks) == 0L ||
      nrow(blocks$members) == 0L
  ) {
    return(FALSE)
  }
  phylo_group <- object$model$structured$phylo_mu$group
  candidate_blocks <- blocks$blocks$block_id0[
    blocks$blocks$level == "group" &
      blocks$blocks$group == phylo_group &
      blocks$blocks$implemented
  ]
  if (length(candidate_blocks) == 0L) {
    return(FALSE)
  }
  any(vapply(
    candidate_blocks,
    function(block_id) {
      members <- blocks$members[blocks$members$block_id0 == block_id, ]
      all(c("mu1", "mu2") %in% members$dpar)
    },
    logical(1L)
  ))
}

bivariate_phylo_mu_sd_ratios <- function(object) {
  sdpars <- object$sdpars$mu
  if (is.null(sdpars) || length(sdpars) == 0L) {
    return(numeric())
  }
  phylo_label <- object$model$structured$phylo_mu$label
  phylo_names <- paste0(c("mu1:", "mu2:"), phylo_label)
  sd_values <- unname(sdpars[phylo_names])
  sigma_values <- tryCatch(stats::sigma(object), error = function(e) e)
  if (inherits(sigma_values, "error") || !is.list(sigma_values)) {
    return(rep(NA_real_, length(sd_values)))
  }
  residual_scale <- c(
    mu1 = mean(sigma_values$sigma1, na.rm = TRUE),
    mu2 = mean(sigma_values$sigma2, na.rm = TRUE)
  )
  sd_values / residual_scale
}

bivariate_phylo_mu_diagnostic_message <- function(
  near_rho_boundary,
  weak_replication,
  weak_sd,
  same_group_covariance = FALSE,
  rho_unavailable = FALSE
) {
  if (near_rho_boundary && same_group_covariance) {
    return(paste(
      "The fitted phylogenetic mean-mean correlation is close to +/-1, and",
      "the model also includes an ordinary group-level covariance for the",
      "same grouping factor; compare simpler structured-effect models before",
      "interpreting separate phylogenetic and non-phylogenetic correlations."
    ))
  }
  if (near_rho_boundary && (weak_replication || weak_sd)) {
    return(paste(
      "The fitted phylogenetic mean-mean correlation is close to +/-1 and",
      "replication or phylogenetic SD evidence is weak; the correlation is",
      "likely weakly identified, and a large standard error on it despite a",
      "clean Hessian (pdHess = TRUE) is the expected symptom, not evidence",
      "against it. Inspect profiles, species replication, or a simpler",
      "structured-effect model before interpreting this correlation."
    ))
  }
  if (near_rho_boundary) {
    return(paste(
      "The fitted phylogenetic mean-mean correlation is close to +/-1; a large",
      "standard error on it despite a clean Hessian (pdHess = TRUE) is the",
      "expected symptom of weak identification. Inspect likelihood profiles or",
      "compare against a model without the bivariate phylogenetic covariance",
      "before interpreting it."
    ))
  }
  if (same_group_covariance && (weak_replication || weak_sd)) {
    return(paste(
      "The model also includes an ordinary group-level covariance for the same",
      "grouping factor, and replication or phylogenetic SD evidence is weak;",
      "inspect profiles or simpler comparison models before interpreting",
      "phylogenetic and non-phylogenetic species correlations as cleanly",
      "separated."
    ))
  }
  if (rho_unavailable) {
    return(random_effect_covariance_unavailable_message())
  }
  if (weak_replication && weak_sd) {
    return(paste(
      "At least one observed species has fewer than two fitted observations",
      "and at least one phylogenetic location SD is tiny relative to its",
      "matching residual scale; interpret the phylogenetic correlation",
      "cautiously."
    ))
  }
  if (weak_replication) {
    return(paste(
      "At least one observed species has fewer than two fitted observations;",
      "interpret the phylogenetic mean-mean correlation cautiously."
    ))
  }
  if (weak_sd) {
    return(paste(
      "At least one phylogenetic location SD is tiny relative to its matching",
      "residual scale; the phylogenetic mean-mean correlation may be weakly",
      "identified."
    ))
  }
  if (same_group_covariance) {
    return(paste(
      "The model also includes an ordinary group-level covariance for the same",
      "grouping factor; inspect profiles or simpler comparison models before",
      "interpreting phylogenetic and non-phylogenetic species correlations as",
      "cleanly separated."
    ))
  }
  "Bivariate phylogenetic location covariance has replicated species and non-negligible fitted SDs relative to residual scales."
}

format_check_number <- function(x) {
  formatC(x, digits = 4L, format = "fg", flag = "#")
}
