validate_phylo_tree <- function(
  tree,
  species = NULL,
  tolerance = sqrt(.Machine$double.eps),
  require_ultrametric = TRUE
) {
  if (!inherits(tree, "phylo")) {
    cli::cli_abort(c(
      "{.arg tree} must be a phylogeny object.",
      "x" = "Use an object with class {.cls phylo}, branch lengths, and tip labels."
    ))
  }
  if (!is.list(tree)) {
    cli::cli_abort("{.arg tree} must be a list-like {.cls phylo} object.")
  }

  edge <- tree$edge
  edge_length <- tree$edge.length
  tip_label <- tree$tip.label
  n_node <- tree$Nnode

  if (
    !is.character(tip_label) ||
      length(tip_label) < 2L ||
      anyNA(tip_label) ||
      any(!nzchar(tip_label))
  ) {
    cli::cli_abort(
      "{.arg tree} must contain at least two non-missing tip labels."
    )
  }
  if (anyDuplicated(tip_label)) {
    duplicate <- tip_label[duplicated(tip_label)][[1L]]
    cli::cli_abort(c(
      "{.arg tree} tip labels must be unique.",
      "x" = "Duplicated tip label: {.val {duplicate}}."
    ))
  }
  n_tip <- length(tip_label)

  if (
    !is.numeric(n_node) ||
      length(n_node) != 1L ||
      is.na(n_node) ||
      n_node < 1L ||
      n_node != as.integer(n_node)
  ) {
    cli::cli_abort(
      "{.arg tree} must contain a scalar positive integer {.field Nnode}."
    )
  }
  n_node <- as.integer(n_node)
  n_total <- n_tip + n_node

  if (
    !is.matrix(edge) ||
      ncol(edge) != 2L ||
      nrow(edge) < 2L ||
      !is.numeric(edge) ||
      anyNA(edge)
  ) {
    cli::cli_abort("{.arg tree$edge} must be a two-column numeric matrix.")
  }
  if (any(edge != as.integer(edge)) || any(edge < 1L) || any(edge > n_total)) {
    cli::cli_abort("{.arg tree$edge} contains invalid node indices.")
  }
  edge <- matrix(as.integer(edge), ncol = 2L)

  if (
    !is.numeric(edge_length) ||
      length(edge_length) != nrow(edge) ||
      anyNA(edge_length) ||
      any(!is.finite(edge_length))
  ) {
    cli::cli_abort(
      "{.arg tree} must contain finite branch lengths for every edge."
    )
  }
  if (any(edge_length < 0)) {
    cli::cli_abort("{.arg tree} branch lengths must be non-negative.")
  }

  parent <- edge[, 1L]
  child <- edge[, 2L]
  if (any(parent <= n_tip)) {
    cli::cli_abort("{.arg tree} is invalid: tip nodes cannot be parent nodes.")
  }
  if (anyDuplicated(child)) {
    cli::cli_abort(
      "{.arg tree} is invalid: at least one node has more than one parent."
    )
  }

  root <- setdiff(unique(parent), child)
  if (length(root) != 1L) {
    cli::cli_abort("{.arg tree} must have exactly one root node.")
  }
  root <- root[[1L]]

  depths <- phylo_node_depths(edge, edge_length, n_total, root)
  if (anyNA(depths)) {
    cli::cli_abort("{.arg tree} must be connected from a single root.")
  }

  tip_depths <- depths[seq_len(n_tip)]
  height <- tip_depths[[1L]]
  scale <- max(1, abs(height), abs(tip_depths))
  is_ultrametric <- max(abs(tip_depths - height)) <= tolerance * scale
  # Ultrametricity is only required when a single scalar height normalization is
  # applied (the correlation scale). The raw branch-length Brownian precision is
  # well defined for non-ultrametric trees, so validation for that path only
  # rejects genuinely invalid depths (non-positive root-to-tip paths).
  if (require_ultrametric && !is_ultrametric) {
    # The message used to report `tolerance` alone -- but the test on the line
    # above is `<= tolerance * scale`, so the number shown was NOT the threshold
    # being applied. On a phylogeny hundreds of My deep that understated the real
    # bar by the tree height, and it misled a reader of this code into diagnosing
    # the check as an ABSOLUTE tolerance (it is not; measured 2026-09-04: a 1e-6
    # spread is rejected at height 1 and accepted at height 400). Report the
    # threshold actually used, what was actually observed, and a way forward.
    observed <- max(abs(tip_depths - height))
    cli::cli_abort(c(
      "{.arg tree} must be ultrametric.",
      "x" = "Root-to-tip distances differ by {.val {observed}}, above the tolerance of {.val {tolerance * scale}} for this tree.",
      "i" = "That tolerance is {.val {tolerance}} scaled by the tree height ({.val {scale}}), so it is relative, not absolute.",
      "i" = "Published trees often miss it by rounding or by Newick round-tripping alone. If the difference above is negligible for your tree, equalise the tip depths (for example {.code phytools::force.ultrametric()}) and refit.",
      "i" = "Check what you have with {.code range(ape::node.depth.edgelength(tree)[seq_len(ape::Ntip(tree))])} before changing anything -- a large difference is a real problem with the tree, not a tolerance to relax."
    ))
  }
  if (any(tip_depths <= 0)) {
    cli::cli_abort("{.arg tree} must have positive root-to-tip height.")
  }

  species_values <- if (is.null(species)) {
    NULL
  } else {
    as.character(species)
  }
  species_levels <- validate_phylo_species(species_values, tip_label)
  if (!is.null(species_levels)) {
    pruned_tips <- setdiff(tip_label, species_levels)
    if (length(pruned_tips) > 0L) {
      cli::cli_inform(c(
        "Pruning {.val {length(pruned_tips)}} phylogeny tip{?s} absent from the data.",
        "i" = "The fit uses the subtree induced by the observed species."
      ))
    }
  }
  species_index <- if (is.null(species_levels)) {
    NULL
  } else {
    match(species_levels, tip_label)
  }
  observation_species_index <- if (is.null(species_levels)) {
    NULL
  } else {
    match(species_values, species_levels)
  }

  list(
    n_tip = n_tip,
    n_node = n_node,
    root = root,
    tip_label = tip_label,
    height = height,
    is_ultrametric = is_ultrametric,
    node_depth = depths,
    species_levels = species_levels,
    species_index = species_index,
    observation_species_index = observation_species_index
  )
}

validate_phylo_species <- function(species, tip_label) {
  if (is.null(species)) {
    return(NULL)
  }
  species <- as.character(species)
  if (length(species) == 0L) {
    cli::cli_abort("{.arg species} must contain at least one observed species.")
  }
  if (anyNA(species) || any(!nzchar(species))) {
    cli::cli_abort("{.arg species} must not contain missing or empty labels.")
  }

  species_levels <- unique(species)
  missing <- setdiff(species_levels, tip_label)
  if (length(missing) > 0L) {
    cli::cli_abort(c(
      "All observed species must be represented in {.arg tree}.",
      "x" = "Missing tip label{?s}: {.val {missing}}."
    ))
  }
  species_levels
}

phylo_node_depths <- function(edge, edge_length, n_total, root) {
  children <- split(seq_len(nrow(edge)), edge[, 1L])
  depths <- rep(NA_real_, n_total)
  depths[[root]] <- 0
  stack <- root

  while (length(stack) > 0L) {
    node <- stack[[length(stack)]]
    stack <- stack[-length(stack)]
    child_edges <- children[[as.character(node)]]
    if (is.null(child_edges)) {
      next
    }
    for (edge_id in child_edges) {
      child <- edge[edge_id, 2L]
      depths[[child]] <- depths[[node]] + edge_length[[edge_id]]
      stack <- c(stack, child)
    }
  }

  depths
}

drm_phylo_tip_covariance <- function(
  tree,
  species = NULL,
  correlation = TRUE,
  tolerance = sqrt(.Machine$double.eps)
) {
  if (
    !is.logical(correlation) || length(correlation) != 1L || is.na(correlation)
  ) {
    cli::cli_abort("{.arg correlation} must be {.code TRUE} or {.code FALSE}.")
  }
  info <- validate_phylo_tree(
    tree,
    species = species,
    tolerance = tolerance,
    require_ultrametric = correlation
  )
  edge <- matrix(as.integer(tree$edge), ncol = 2L)
  parent <- integer(info$n_tip + info$n_node)
  parent[edge[, 2L]] <- edge[, 1L]
  nodes <- if (is.null(info$species_index)) {
    seq_len(info$n_tip)
  } else {
    info$species_index
  }
  labels <- if (is.null(info$species_levels)) {
    info$tip_label
  } else {
    info$species_levels
  }

  ancestors <- lapply(nodes, phylo_node_ancestors, parent = parent)
  covariance <- matrix(0, nrow = length(nodes), ncol = length(nodes))
  for (i in seq_along(nodes)) {
    for (j in seq_len(i)) {
      shared <- intersect(ancestors[[i]], ancestors[[j]])
      covariance[i, j] <- covariance[j, i] <- max(info$node_depth[shared])
    }
  }

  if (correlation) {
    covariance <- covariance / info$height
  }
  dimnames(covariance) <- list(labels, labels)
  covariance
}

drm_phylo_augmented_precision <- function(
  tree,
  species = NULL,
  correlation = TRUE,
  tolerance = sqrt(.Machine$double.eps)
) {
  if (
    !is.logical(correlation) || length(correlation) != 1L || is.na(correlation)
  ) {
    cli::cli_abort("{.arg correlation} must be {.code TRUE} or {.code FALSE}.")
  }
  info <- validate_phylo_tree(
    tree,
    species = species,
    tolerance = tolerance,
    require_ultrametric = correlation
  )
  edge <- matrix(as.integer(tree$edge), ncol = 2L)
  edge_length <- tree$edge.length
  if (any(edge_length <= 0)) {
    cli::cli_abort(
      "{.arg tree} branch lengths must be positive to build sparse precision."
    )
  }

  n_total <- info$n_tip + info$n_node
  included_nodes <- setdiff(seq_len(n_total), info$root)
  node_index <- integer(n_total)
  node_index[included_nodes] <- seq_along(included_nodes)
  n_aug <- length(included_nodes)

  rows <- integer(0)
  cols <- integer(0)
  values <- numeric(0)
  for (edge_id in seq_len(nrow(edge))) {
    parent <- edge[edge_id, 1L]
    child <- edge[edge_id, 2L]
    child_index <- node_index[[child]]
    weight <- 1 / edge_length[[edge_id]]

    rows <- c(rows, child_index)
    cols <- c(cols, child_index)
    values <- c(values, weight)

    if (parent != info$root) {
      parent_index <- node_index[[parent]]
      rows <- c(rows, parent_index, parent_index, child_index)
      cols <- c(cols, parent_index, child_index, parent_index)
      values <- c(values, weight, -weight, -weight)
    }
  }

  scale <- if (isTRUE(correlation)) {
    info$height
  } else {
    1
  }
  node_labels <- phylo_augmented_node_labels(included_nodes, info$tip_label)
  precision <- Matrix::drop0(Matrix::sparseMatrix(
    i = rows,
    j = cols,
    x = scale * values,
    dims = c(n_aug, n_aug),
    dimnames = list(node_labels, node_labels)
  ))

  tip_node_index <- node_index[seq_len(info$n_tip)]
  names(tip_node_index) <- info$tip_label
  species_node_index <- if (is.null(info$species_index)) {
    NULL
  } else {
    out <- tip_node_index[info$species_index]
    names(out) <- info$species_levels
    out
  }

  out <- list(
    precision = precision,
    log_det_precision = n_aug * log(scale) - sum(log(edge_length)),
    correlation = isTRUE(correlation),
    scale = scale,
    node_id = included_nodes,
    node_index = node_index,
    node_labels = node_labels,
    tip_label = info$tip_label,
    tip_node_index = tip_node_index,
    species_levels = info$species_levels,
    species_tip_index = info$species_index,
    species_node_index = species_node_index,
    observation_species_index = info$observation_species_index,
    root = info$root,
    height = info$height
  )
  class(out) <- "drm_phylo_precision"
  out
}

# Canonical character labels for relmat()/animal() ids (#1485). R writes a
# whole-number double id such as 100000 as "1e+05" whenever it coerces it
# (as.character(), dimnames<-, factor levels), while users and integer ids give
# "100000". Both spellings must match, so every side -- data ids, matrix
# dimnames, and pedigree id/dam/sire -- goes through this function: whole-number
# doubles are written as plain digits, and character labels in scientific
# notation that denote a whole number are rewritten the same way. Every other
# label is kept as is.
drm_id_labels <- function(x) {
  if (is.double(x) && !is.factor(x)) {
    out <- as.character(x)
    whole <- is.finite(x) & x == trunc(x) & abs(x) < 2^53
    out[whole] <- formatC(x[whole], format = "f", digits = 0L)
    return(out)
  }
  out <- as.character(x)
  sci <- !is.na(out) & grepl("^[-+]?[0-9.]+[eE][-+]?[0-9]+$", out)
  if (any(sci)) {
    num <- suppressWarnings(as.numeric(out[sci]))
    whole <- is.finite(num) & num == trunc(num) & abs(num) < 2^53
    out[sci][whole] <- formatC(num[whole], format = "f", digits = 0L)
  }
  out
}

drm_known_relatedness_precision <- function(
  matrix,
  group,
  matrix_type = c("precision", "covariance"),
  marker = "relmat",
  object = "Q",
  group_name = "id",
  tolerance = sqrt(.Machine$double.eps),
  reported_matrix_type = NULL
) {
  matrix_type <- match.arg(matrix_type)
  if (is.null(reported_matrix_type)) {
    reported_matrix_type <- matrix_type
  }
  group <- drm_id_labels(group)
  if (length(group) == 0L || anyNA(group) || any(!nzchar(group))) {
    cli::cli_abort(
      "{.fn {marker}} grouping variable {.field {group_name}} must contain non-missing labels."
    )
  }

  mat <- drm_standardize_relatedness_matrix(
    matrix,
    marker = marker,
    object = object
  )
  canonical <- drm_id_labels(rownames(mat))
  if (!anyDuplicated(canonical)) {
    dimnames(mat) <- list(canonical, canonical)
  }
  labels <- rownames(mat)
  observed <- unique(group)
  missing <- setdiff(observed, labels)
  if (length(missing) > 0L) {
    cli::cli_abort(c(
      "{.fn {marker}} matrix {.field {object}} does not cover every observed {.field {group_name}} level.",
      "x" = "Missing level{?s}: {.val {missing}}."
    ))
  }

  mat <- mat[labels, labels, drop = FALSE]
  mat_sparse <- Matrix::Matrix(mat, sparse = TRUE)
  if (!Matrix::isSymmetric(mat_sparse, tol = tolerance)) {
    cli::cli_abort(c(
      "{.fn {marker}} matrix {.field {object}} must be symmetric.",
      "x" = "Rows and columns should use the same relatedness scale and labels."
    ))
  }

  precision <- if (identical(matrix_type, "precision")) {
    drm_validate_known_precision_matrix(
      mat_sparse,
      marker = marker,
      object = object
    )
  } else {
    drm_covariance_to_known_precision(
      mat_sparse,
      marker = marker,
      object = object
    )
  }

  species_node_index <- match(observed, labels)
  names(species_node_index) <- observed
  out <- list(
    precision = precision$precision,
    log_det_precision = precision$log_det_precision,
    matrix_type = reported_matrix_type,
    object = object,
    node_labels = labels,
    species_levels = observed,
    species_node_index = species_node_index,
    observation_species_index = match(group, observed)
  )
  class(out) <- "drm_known_relatedness_precision"
  out
}

drm_pedigree_relatedness_precision <- function(
  pedigree,
  group,
  object = "pedigree",
  group_name = "id"
) {
  Ainv <- drm_pedigree_sparse_precision(pedigree, object = object)
  drm_known_relatedness_precision(
    Ainv,
    group = group,
    matrix_type = "precision",
    marker = "animal",
    object = object,
    group_name = group_name,
    # The caller still supplied a pedigree (a covariance-side input); only the
    # internal route to A^-1 changed, so the reported label must not move.
    reported_matrix_type = "covariance"
  )
}

# Sparse pedigree precision A^-1 via the Henderson (1976) / Quaas (1976) rules.
#
# Inbreeding F is Meuwissen & Luo (1992): O(n * ancestors), no dense A.
# A^-1 is then assembled from the Mendelian sampling variances. The dense
# chol2inv this originally replaced returned ~n^2 stored nonzeros; the
# post-#1422 path still formed dense A only to read diag(A) - 1. That step
# is gone.
#
# PROVENANCE: Quaas assembly mirrors gllvmTMB's .gllvm_pedigree_precision()
# (R/pedigree-precision.R). Meuwissen-Luo F follows HSquared.jl
# `_meuwissen_luo_inbreeding` (MIT; src/pedigree.jl at
# eee5f7aa7640abafa6b2efd2b71a66182db77459). See inst/COPYRIGHTS.
# drm_pedigree_additive_relationship() remains the dense tabular oracle
# for tests and simulation DGPs; it is not on the fit path.
drm_pedigree_sparse_precision <- function(pedigree, object = "pedigree") {
  ped <- drm_standardize_pedigree(pedigree, object = object)
  order <- drm_pedigree_topological_order(ped, object = object)
  ped <- ped[order, , drop = FALSE]
  inbreeding <- drm_pedigree_inbreeding_meuwissen_luo(ped, object = object)
  drm_pedigree_quaas_ainv(ped, inbreeding, object = object)
}

# Dense-F oracle used only by tests and the S4 identity ladder. Same Quaas
# assembly as the fit path; F comes from diag(A) - 1.
drm_pedigree_sparse_precision_dense_F <- function(
  pedigree,
  object = "pedigree"
) {
  A <- drm_pedigree_additive_relationship(pedigree, object = object)
  ids <- rownames(A)
  ped <- drm_standardize_pedigree(pedigree, object = object)
  ped <- ped[match(ids, ped$id), , drop = FALSE]
  drm_pedigree_quaas_ainv(ped, diag(A) - 1, object = object)
}

# Meuwissen & Luo (1992) inbreeding for a topologically ordered pedigree.
# Accumulate the T-row of A = T D T' over ancestors, youngest first via a
# max-heap on row indices: A_ii = sum_j L_ij^2 d_j, so F_i = A_ii - 1, with
# d_j = 0.5 - 0.25 (F_sire(j) + F_dam(j)) and unknown-parent F_0 = -1.
# One unknown parent => F_i = 0. Requires parents-before-offspring order.
#
# PROVENANCE: method is Meuwissen & Luo, Genet. Sel. Evol. 24:305-313 (1992).
# The T-row / max-heap walk matches HSquared.jl `_meuwissen_luo_inbreeding`
# (MIT). The fit path calls src/meuwissen_luo.c after load. The R walk
# below is a private same-algorithm reference for tests and A/B benches.
# HSquared.jl source is not vendored. No gllvmTMB or other GPL source is
# copied.
drm_pedigree_inbreeding_parent_index <- function(ped, object = "pedigree") {
  n <- nrow(ped)
  ids <- ped$id
  sire <- match(ped$sire, ids)
  dam <- match(ped$dam, ids)
  sire[is.na(sire)] <- 0L
  dam[is.na(dam)] <- 0L
  storage.mode(sire) <- "integer"
  storage.mode(dam) <- "integer"

  for (i in seq_len(n)) {
    s <- sire[[i]]
    d <- dam[[i]]
    if ((s != 0L && s >= i) || (d != 0L && d >= i)) {
      cli::cli_abort(c(
        "{.fn animal} pedigree {.field {object}} could not be ordered from ancestors to descendants.",
        "x" = "Individual {.val {ids[[i]]}} has a parent that is not available before the offspring."
      ))
    }
  }
  list(ids = ids, sire = sire, dam = dam)
}

drm_pedigree_inbreeding_meuwissen_luo <- function(ped, object = "pedigree") {
  idx <- drm_pedigree_inbreeding_parent_index(ped, object = object)
  F <- .Call("drm_meuwissen_luo_inbreeding", idx$sire, idx$dam, PACKAGE = "drmTMB")
  names(F) <- idx$ids
  F
}

# Private R reference of the same walk (bench / identity only).
drm_pedigree_inbreeding_meuwissen_luo_r <- function(ped, object = "pedigree") {
  idx <- drm_pedigree_inbreeding_parent_index(ped, object = object)
  n <- length(idx$ids)
  ids <- idx$ids
  sire <- idx$sire
  dam <- idx$dam

  F <- numeric(n)
  L <- numeric(n)
  heap <- integer(64L)
  heap_n <- 0L

  for (i in seq_len(n)) {
    s <- sire[[i]]
    d <- dam[[i]]
    if (s == 0L || d == 0L) {
      F[[i]] <- 0
      next
    }
    L[[i]] <- 1
    heap_n <- heap_n + 1L
    if (heap_n > length(heap)) {
      heap <- c(heap, integer(length(heap)))
    }
    heap[[heap_n]] <- i
    hi <- heap_n
    while (hi > 1L) {
      p <- hi %/% 2L
      if (heap[[p]] >= heap[[hi]]) {
        break
      }
      tmp <- heap[[p]]
      heap[[p]] <- heap[[hi]]
      heap[[hi]] <- tmp
      hi <- p
    }
    fi <- 0
    while (heap_n > 0L) {
      j <- heap[[1L]]
      last <- heap[[heap_n]]
      heap_n <- heap_n - 1L
      if (heap_n >= 1L) {
        heap[[1L]] <- last
        hi <- 1L
        repeat {
          left <- 2L * hi
          right <- left + 1L
          m <- hi
          if (left <= heap_n && heap[[left]] > heap[[m]]) {
            m <- left
          }
          if (right <= heap_n && heap[[right]] > heap[[m]]) {
            m <- right
          }
          if (m == hi) {
            break
          }
          tmp <- heap[[hi]]
          heap[[hi]] <- heap[[m]]
          heap[[m]] <- tmp
          hi <- m
        }
      }
      lj <- L[[j]]
      L[[j]] <- 0
      sj <- sire[[j]]
      dj_s <- if (sj == 0L) -1 else F[[sj]]
      dmj <- dam[[j]]
      dj_d <- if (dmj == 0L) -1 else F[[dmj]]
      fi <- fi + lj * lj * (0.5 - 0.25 * (dj_s + dj_d))
      if (sj != 0L) {
        if (L[[sj]] == 0) {
          heap_n <- heap_n + 1L
          if (heap_n > length(heap)) {
            heap <- c(heap, integer(length(heap)))
          }
          heap[[heap_n]] <- sj
          hi <- heap_n
          while (hi > 1L) {
            p <- hi %/% 2L
            if (heap[[p]] >= heap[[hi]]) {
              break
            }
            tmp <- heap[[p]]
            heap[[p]] <- heap[[hi]]
            heap[[hi]] <- tmp
            hi <- p
          }
        }
        L[[sj]] <- L[[sj]] + 0.5 * lj
      }
      if (dmj != 0L) {
        if (L[[dmj]] == 0) {
          heap_n <- heap_n + 1L
          if (heap_n > length(heap)) {
            heap <- c(heap, integer(length(heap)))
          }
          heap[[heap_n]] <- dmj
          hi <- heap_n
          while (hi > 1L) {
            p <- hi %/% 2L
            if (heap[[p]] >= heap[[hi]]) {
              break
            }
            tmp <- heap[[p]]
            heap[[p]] <- heap[[hi]]
            heap[[hi]] <- tmp
            hi <- p
          }
        }
        L[[dmj]] <- L[[dmj]] + 0.5 * lj
      }
    }
    F[[i]] <- fi - 1
  }
  names(F) <- ids
  F
}

# Vectorised Henderson / Quaas A^-1 given already-aligned F.
drm_pedigree_quaas_ainv <- function(ped, inbreeding, object = "pedigree") {
  ids <- ped$id
  n <- length(ids)
  dam_index <- match(ped$dam, ids)
  sire_index <- match(ped$sire, ids)

  index <- seq_len(n)
  has_dam <- !is.na(dam_index)
  has_sire <- !is.na(sire_index)
  dam_inbreeding <- ifelse(has_dam, inbreeding[dam_index], 0)
  sire_inbreeding <- ifelse(has_sire, inbreeding[sire_index], 0)

  # Mendelian sampling variance d_i, by how many parents are known.
  both <- has_dam & has_sire
  dam_only <- has_dam & !has_sire
  sire_only <- has_sire & !has_dam
  mendelian <- rep(1, n)
  mendelian[both] <- 0.5 -
    0.25 * (dam_inbreeding[both] + sire_inbreeding[both])
  mendelian[dam_only] <- 0.75 - 0.25 * dam_inbreeding[dam_only]
  mendelian[sire_only] <- 0.75 - 0.25 * sire_inbreeding[sire_only]

  invalid <- !is.finite(mendelian) | mendelian <= 0
  if (any(invalid)) {
    cli::cli_abort(c(
      "{.fn animal} pedigree {.field {object}} produced a non-positive Mendelian sampling variance.",
      "x" = "Individual{?s} {.val {ids[invalid]}} implied an inbreeding coefficient outside {.code [0, 1)}."
    ))
  }
  weight <- 1 / mendelian

  # Each animal contributes at most 9 entries; sparseMatrix sums duplicates.
  sire_child <- index[has_sire]
  sire_parent <- sire_index[has_sire]
  sire_weight <- weight[has_sire]
  dam_child <- index[has_dam]
  dam_parent <- dam_index[has_dam]
  dam_weight <- weight[has_dam]
  both_sire <- sire_index[both]
  both_dam <- dam_index[both]
  both_weight <- weight[both]

  precision <- Matrix::sparseMatrix(
    i = c(
      index,
      sire_child,
      sire_parent,
      sire_parent,
      dam_child,
      dam_parent,
      dam_parent,
      both_sire,
      both_dam
    ),
    j = c(
      index,
      sire_parent,
      sire_child,
      sire_parent,
      dam_parent,
      dam_child,
      dam_parent,
      both_dam,
      both_sire
    ),
    x = c(
      weight,
      -0.5 * sire_weight,
      -0.5 * sire_weight,
      0.25 * sire_weight,
      -0.5 * dam_weight,
      -0.5 * dam_weight,
      0.25 * dam_weight,
      0.25 * both_weight,
      0.25 * both_weight
    ),
    dims = c(n, n),
    dimnames = list(ids, ids)
  )
  Matrix::drop0(precision)
}

drm_pedigree_additive_relationship <- function(pedigree, object = "pedigree") {
  ped <- drm_standardize_pedigree(pedigree, object = object)
  order <- drm_pedigree_topological_order(ped, object = object)
  ped <- ped[order, , drop = FALSE]

  n <- nrow(ped)
  A <- matrix(0, nrow = n, ncol = n)
  rownames(A) <- colnames(A) <- ped$id
  dam_index <- match(ped$dam, ped$id)
  sire_index <- match(ped$sire, ped$id)

  for (i in seq_len(n)) {
    parents <- c(dam_index[[i]], sire_index[[i]])
    parents <- parents[!is.na(parents)]
    if (length(parents) > 0L && any(parents >= i)) {
      cli::cli_abort(c(
        "{.fn animal} pedigree {.field {object}} could not be ordered from ancestors to descendants.",
        "x" = "Individual {.val {ped$id[[i]]}} has a parent that is not available before the offspring."
      ))
    }

    if (i > 1L) {
      for (j in seq_len(i - 1L)) {
        dam_relatedness <- if (is.na(dam_index[[i]])) {
          0
        } else {
          A[dam_index[[i]], j]
        }
        sire_relatedness <- if (is.na(sire_index[[i]])) {
          0
        } else {
          A[sire_index[[i]], j]
        }
        A[i, j] <- A[j, i] <- 0.5 * (dam_relatedness + sire_relatedness)
      }
    }

    A[i, i] <- if (is.na(dam_index[[i]]) || is.na(sire_index[[i]])) {
      1
    } else {
      1 + 0.5 * A[dam_index[[i]], sire_index[[i]]]
    }
  }

  A
}

drm_standardize_pedigree <- function(pedigree, object = "pedigree") {
  if (!is.data.frame(pedigree)) {
    cli::cli_abort(c(
      "{.fn animal} pedigree {.field {object}} must be a data frame.",
      "x" = "Use columns {.field id}, {.field dam}, and {.field sire}; unknown parents can be {.code NA}, {.val \"\"}, or {.val \"0\"}."
    ))
  }

  required <- c("id", "dam", "sire")
  missing <- setdiff(required, names(pedigree))
  if (length(missing) > 0L) {
    cli::cli_abort(c(
      "{.fn animal} pedigree {.field {object}} must contain {.field id}, {.field dam}, and {.field sire} columns.",
      "x" = "Missing column{?s}: {.field {missing}}."
    ))
  }

  ped <- data.frame(
    id = drm_id_labels(pedigree$id),
    dam = drm_id_labels(pedigree$dam),
    sire = drm_id_labels(pedigree$sire),
    stringsAsFactors = FALSE
  )
  ped$dam <- drm_normalize_pedigree_parent(ped$dam)
  ped$sire <- drm_normalize_pedigree_parent(ped$sire)

  if (nrow(ped) < 2L) {
    cli::cli_abort(
      "{.fn animal} pedigree {.field {object}} must contain at least two individuals."
    )
  }
  if (anyNA(ped$id) || any(!nzchar(ped$id))) {
    cli::cli_abort(
      "{.fn animal} pedigree {.field {object}} {.field id} values must be non-missing labels."
    )
  }
  if (anyDuplicated(ped$id)) {
    duplicate <- ped$id[duplicated(ped$id)][[1L]]
    cli::cli_abort(c(
      "{.fn animal} pedigree {.field {object}} {.field id} values must be unique.",
      "x" = "Duplicated id: {.val {duplicate}}."
    ))
  }

  parents <- unique(stats::na.omit(c(ped$dam, ped$sire)))
  missing_parents <- setdiff(parents, ped$id)
  if (length(missing_parents) > 0L) {
    cli::cli_abort(c(
      "{.fn animal} pedigree {.field {object}} parents must appear in the {.field id} column.",
      "x" = "Missing parent id{?s}: {.val {missing_parents}}."
    ))
  }

  ped
}

drm_normalize_pedigree_parent <- function(parent) {
  parent[is.na(parent) | !nzchar(parent) | parent == "0"] <- NA_character_
  parent
}

drm_pedigree_topological_order <- function(ped, object = "pedigree") {
  unresolved <- seq_len(nrow(ped))
  resolved_ids <- character()
  out <- integer()

  while (length(unresolved) > 0L) {
    ready <- unresolved[
      (is.na(ped$dam[unresolved]) | ped$dam[unresolved] %in% resolved_ids) &
        (is.na(ped$sire[unresolved]) | ped$sire[unresolved] %in% resolved_ids)
    ]
    if (length(ready) == 0L) {
      stuck <- ped$id[unresolved]
      cli::cli_abort(c(
        "{.fn animal} pedigree {.field {object}} must not contain parent-offspring cycles.",
        "x" = "Could not resolve individual{?s}: {.val {stuck}}."
      ))
    }

    out <- c(out, ready)
    resolved_ids <- c(resolved_ids, ped$id[ready])
    unresolved <- setdiff(unresolved, ready)
  }

  out
}

drm_standardize_relatedness_matrix <- function(matrix, marker, object) {
  if (inherits(matrix, "Matrix")) {
    if (!methods::is(matrix, "dMatrix")) {
      cli::cli_abort(
        "{.fn {marker}} matrix {.field {object}} must be numeric."
      )
    }
    mat <- matrix
  } else {
    if (is.data.frame(matrix)) {
      matrix <- as.matrix(matrix)
    }
    if (!is.matrix(matrix) || !is.numeric(matrix)) {
      cli::cli_abort(c(
        "{.fn {marker}} matrix {.field {object}} must be a numeric square matrix.",
        "i" = "Use row and column names that match the grouping variable."
      ))
    }
    mat <- matrix
  }

  if (length(dim(mat)) != 2L || nrow(mat) != ncol(mat) || nrow(mat) < 2L) {
    cli::cli_abort(
      "{.fn {marker}} matrix {.field {object}} must be a square matrix with at least two rows."
    )
  }
  if (any(!is.finite(mat))) {
    cli::cli_abort(
      "{.fn {marker}} matrix {.field {object}} must contain finite numeric values."
    )
  }

  row_labels <- rownames(mat)
  col_labels <- colnames(mat)
  if (
    is.null(row_labels) ||
      is.null(col_labels) ||
      anyNA(row_labels) ||
      anyNA(col_labels) ||
      any(!nzchar(row_labels)) ||
      any(!nzchar(col_labels))
  ) {
    cli::cli_abort(
      "{.fn {marker}} matrix {.field {object}} must have non-empty row and column names."
    )
  }
  if (anyDuplicated(row_labels) || anyDuplicated(col_labels)) {
    cli::cli_abort(
      "{.fn {marker}} matrix {.field {object}} row and column names must be unique."
    )
  }
  if (!setequal(row_labels, col_labels)) {
    cli::cli_abort(c(
      "{.fn {marker}} matrix {.field {object}} row and column names must match.",
      "x" = "Rows without matching columns: {.val {setdiff(row_labels, col_labels)}}.",
      "x" = "Columns without matching rows: {.val {setdiff(col_labels, row_labels)}}."
    ))
  }
  mat[, row_labels, drop = FALSE]
}

drm_validate_known_precision_matrix <- function(matrix, marker, object) {
  precision <- Matrix::forceSymmetric(
    Matrix::Matrix(matrix, sparse = TRUE),
    uplo = "U"
  )
  chol_precision <- tryCatch(
    Matrix::Cholesky(precision, LDL = FALSE, perm = FALSE),
    error = function(e) NULL
  )
  if (is.null(chol_precision)) {
    cli::cli_abort(c(
      "{.fn {marker}} precision matrix {.field {object}} must be positive definite.",
      "x" = "Check the matrix scale, ordering, and any duplicated levels."
    ))
  }
  determinant <- tryCatch(
    Matrix::determinant(precision, logarithm = TRUE),
    error = function(e) NULL
  )
  if (
    is.null(determinant) ||
      !is.finite(as.numeric(determinant$modulus)) ||
      determinant$sign <= 0
  ) {
    cli::cli_abort(
      "{.fn {marker}} precision matrix {.field {object}} must have a positive finite determinant."
    )
  }
  list(
    precision = Matrix::drop0(precision),
    log_det_precision = as.numeric(determinant$modulus)
  )
}

drm_covariance_to_known_precision <- function(matrix, marker, object) {
  covariance <- as.matrix(Matrix::forceSymmetric(
    Matrix::Matrix(matrix, sparse = FALSE),
    uplo = "U"
  ))
  chol_covariance <- tryCatch(
    chol(covariance),
    error = function(e) NULL
  )
  if (is.null(chol_covariance)) {
    cli::cli_abort(c(
      "{.fn {marker}} covariance matrix {.field {object}} must be positive definite.",
      "x" = "For large or sparse relatedness models, supply a precision matrix instead."
    ))
  }
  precision <- chol2inv(chol_covariance)
  dimnames(precision) <- dimnames(covariance)
  list(
    precision = Matrix::drop0(Matrix::Matrix(precision, sparse = TRUE)),
    log_det_precision = -2 * sum(log(diag(chol_covariance)))
  )
}

drm_phylo_precision_nll <- function(effect, precision, log_sd = 0) {
  if (!inherits(precision, "drm_phylo_precision")) {
    cli::cli_abort(
      "{.arg precision} must come from {.fn drm_phylo_augmented_precision}."
    )
  }
  effect <- as.numeric(effect)
  n_effect <- length(effect)
  if (
    n_effect != nrow(precision$precision) ||
      anyNA(effect) ||
      any(!is.finite(effect))
  ) {
    cli::cli_abort(
      "{.arg effect} must be a finite numeric vector matching the precision size."
    )
  }
  if (
    !is.numeric(log_sd) ||
      length(log_sd) != 1L ||
      is.na(log_sd) ||
      !is.finite(log_sd)
  ) {
    cli::cli_abort("{.arg log_sd} must be a finite numeric scalar.")
  }

  quadratic <- sum(effect * as.numeric(precision$precision %*% effect))
  0.5 *
    (n_effect *
      log(2 * pi) +
      2 * n_effect * log_sd -
      precision$log_det_precision +
      exp(-2 * log_sd) * quadratic)
}

drm_phylo_correlated_precision_nll <- function(effect, precision, covariance) {
  if (!inherits(precision, "drm_phylo_precision")) {
    cli::cli_abort(
      "{.arg precision} must come from {.fn drm_phylo_augmented_precision}."
    )
  }
  if (
    !is.matrix(effect) ||
      !is.numeric(effect) ||
      nrow(effect) != nrow(precision$precision) ||
      anyNA(effect) ||
      any(!is.finite(effect))
  ) {
    cli::cli_abort(
      "{.arg effect} must be a finite numeric matrix with one row per phylogenetic precision node."
    )
  }
  if (
    !is.matrix(covariance) ||
      !is.numeric(covariance) ||
      nrow(covariance) != ncol(covariance) ||
      nrow(covariance) != ncol(effect) ||
      anyNA(covariance) ||
      any(!is.finite(covariance))
  ) {
    cli::cli_abort(
      "{.arg covariance} must be a finite square numeric matrix matching the effect columns."
    )
  }
  covariance_chol <- tryCatch(
    chol(covariance),
    error = function(e) NULL
  )
  if (is.null(covariance_chol)) {
    cli::cli_abort("{.arg covariance} must be positive definite.")
  }

  n_node <- nrow(effect)
  q <- ncol(effect)
  covariance_inverse <- chol2inv(covariance_chol)
  quadratic_matrix <- crossprod(
    effect,
    as.matrix(precision$precision %*% effect)
  )
  quadratic <- sum(covariance_inverse * quadratic_matrix)
  log_det_covariance <- 2 * sum(log(diag(covariance_chol)))

  0.5 *
    (n_node *
      q *
      log(2 * pi) +
      n_node * log_det_covariance -
      q * precision$log_det_precision +
      quadratic)
}

drm_phylo_q4_endpoint_pairs <- function(
  group,
  responses = c("y1", "y2"),
  block = "phylo"
) {
  if (
    !is.character(group) ||
      length(group) != 1L ||
      is.na(group) ||
      !nzchar(group)
  ) {
    cli::cli_abort("{.arg group} must be a single non-empty string.")
  }
  if (
    !is.character(responses) ||
      length(responses) != 2L ||
      anyNA(responses) ||
      any(!nzchar(responses))
  ) {
    cli::cli_abort(
      "{.arg responses} must contain two non-empty response names."
    )
  }
  if (
    !is.character(block) ||
      length(block) != 1L ||
      is.na(block) ||
      !nzchar(block)
  ) {
    cli::cli_abort("{.arg block} must be a single non-empty string.")
  }

  from_dpar <- c("mu1", "mu1", "mu1", "mu2", "mu2", "sigma1")
  to_dpar <- c("mu2", "sigma1", "sigma2", "sigma1", "sigma2", "sigma2")
  from_response <- phylo_endpoint_response(from_dpar, responses)
  to_response <- phylo_endpoint_response(to_dpar, responses)
  data.frame(
    level = "phylogenetic",
    group = group,
    block = block,
    from_dpar = from_dpar,
    to_dpar = to_dpar,
    from_coef = "(Intercept)",
    to_coef = "(Intercept)",
    from_response = from_response,
    to_response = to_response,
    class = c(
      "mean-mean",
      "mean-scale",
      "mean-scale",
      "mean-scale",
      "mean-scale",
      "scale-scale"
    ),
    parameter = paste0(
      "cor(",
      from_dpar,
      ":(Intercept),",
      to_dpar,
      ":(Intercept) | ",
      block,
      " | ",
      group,
      ")"
    ),
    estimate = NA_real_,
    min = NA_real_,
    max = NA_real_,
    n_values = 0L,
    link_estimate = NA_real_,
    link_min = NA_real_,
    link_max = NA_real_,
    modelled = FALSE,
    status = "planned",
    support_note = "planned_bivariate_phylogenetic_q4",
    stringsAsFactors = FALSE
  )
}

phylo_endpoint_response <- function(dpar, responses) {
  ifelse(grepl("1$", dpar), responses[[1L]], responses[[2L]])
}

phylo_augmented_node_labels <- function(node_id, tip_label) {
  labels <- paste0("node", node_id)
  tip <- node_id <= length(tip_label)
  labels[tip] <- tip_label[node_id[tip]]
  labels
}

phylo_node_ancestors <- function(node, parent) {
  out <- node
  while (parent[[node]] != 0L) {
    node <- parent[[node]]
    out <- c(out, node)
  }
  out
}
