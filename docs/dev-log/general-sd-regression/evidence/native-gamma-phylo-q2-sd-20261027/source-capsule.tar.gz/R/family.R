# The per-family `links = c(...)` fields in the constructors below are family
# constructor metadata. The canonical *runtime* link table is `drm_dpar_link()`
# in R/methods.R, keyed by model_type; every runtime link query routes through
# it (issue #713.2). When you add or change a family's links here, mirror the
# change in that switch so the constructor metadata and the runtime table stay
# consistent. See the header comment on `drm_dpar_link()` for why the two are
# documented-not-refactored rather than unified into a single source.

#' Bivariate Gaussian response family
#'
#' `biv_gaussian()` defines a two-response Gaussian distribution with formulas
#' for both locations, both residual standard deviations, and residual
#' correlation `rho12`. The residual-correlation link is recorded as
#' `"atanh_guarded"` because fitted response-scale correlations use
#' `rho12 = 0.999999 * tanh(eta_rho12)`.
#'
#' @return A `drm_family` object.
#' @export
#'
#' @examples
#' biv_gaussian()
biv_gaussian <- function() {
  structure(
    list(
      name = "biv_gaussian",
      family = "biv_gaussian",
      n_response = 2L,
      dpars = c("mu1", "mu2", "sigma1", "sigma2", "rho12"),
      links = c(
        mu1 = "identity",
        mu2 = "identity",
        sigma1 = "log",
        sigma2 = "log",
        rho12 = "atanh_guarded"
      )
    ),
    class = "drm_family"
  )
}

#' Bivariate lognormal response family
#'
#' `biv_lognormal()` defines an exact two-response lognormal distribution.
#' Its `rho12` is the residual correlation on the log-response scale, not a
#' raw-response correlation and not the frozen-margin association `eta`.
#'
#' @return A `drm_family` object.
#' @export
#'
#' @examples
#' biv_lognormal()
biv_lognormal <- function() {
  structure(
    list(
      name = "biv_lognormal",
      family = "biv_lognormal",
      n_response = 2L,
      dpars = c("mu1", "mu2", "sigma1", "sigma2", "rho12"),
      links = c(
        mu1 = "identity", mu2 = "identity", sigma1 = "log",
        sigma2 = "log", rho12 = "atanh_guarded"
      )
    ),
    class = "drm_family"
  )
}

#' Bivariate Student-t response family
#'
#' `biv_student()` defines an exact two-response elliptical Student-t
#' distribution with one shared degrees-of-freedom parameter `nu`. Its
#' `sigma1` and `sigma2` parameters are Student-t scales, and `rho12` is the
#' residual scatter correlation. The response covariance exists because the
#' fitted transform enforces `nu > 2`; its marginal standard deviations are
#' `sigma_j * sqrt(nu / (nu - 2))`.
#'
#' The first implementation allows fixed effects in `mu1` and `mu2`, with
#' intercept-only `sigma1`, `sigma2`, shared `nu`, and `rho12`. Random effects,
#' parameter predictors outside the locations, missing response pairs, and
#' interval inference are deferred.
#'
#' @return A `drm_family` object.
#' @export
#'
#' @examples
#' biv_student()
biv_student <- function() {
  structure(
    list(
      name = "biv_student",
      family = "biv_student",
      n_response = 2L,
      dpars = c("mu1", "mu2", "sigma1", "sigma2", "nu", "rho12"),
      links = c(
        mu1 = "identity", mu2 = "identity", sigma1 = "log",
        sigma2 = "log", nu = "logm2", rho12 = "atanh_guarded"
      )
    ),
    class = "drm_family"
  )
}

#' Student-t response family
#'
#' `student()` defines a one-response Student-t distribution with formulas for
#' location `mu`, residual scale `sigma`, and degrees of freedom `nu`.
#'
#' Here `sigma` is the Student-t **scale**, not the response standard deviation.
#' The density is the location-scale t evaluated at `z = (y - mu) / sigma`, so the
#' standard deviation of `y` is `SD[y] = sigma * sqrt(nu / (nu - 2))` for `nu > 2`
#' and is strictly larger than `sigma` (about 73% larger at `nu = 3`, shrinking to
#' `sigma` as `nu -> Inf`). The Student-t family uses this scale because the
#' location-scale t has no closed-form standard-deviation parameterization, and
#' both `drmTMB` and its `DRM.jl` twin fit `sigma` as the scale.
#'
#' The `nu` parameter uses a log link with a lower bound of 2:
#' `nu = 2 + exp(eta_nu)`. This keeps the fitted distribution in the
#' finite-variance region (`nu > 2`) while still allowing heavy tails. The lower
#' bound is a deliberate design choice, not a standard-deviation requirement: it
#' guarantees a finite variance and a well-defined `SD[y]`. The model therefore
#' **cannot** represent the very heavy tails of `nu <= 2` (for example a
#' Cauchy-like `nu = 1`); data that genuinely need `nu <= 2` would require lifting
#' the floor, which is not implemented. `check_drm()` warns when the fitted `nu`
#' approaches the boundary at 2, where the slant of the likelihood in `nu` is
#' weakly identified.
#' Ordinary `mu` random intercepts and independent numeric slopes such as
#' `(1 | id)` and `(0 + x | id)` are supported in the first Student-t
#' mixed-model slice; correlated slopes, `sigma` random effects, and `nu`
#' random effects remain separate planned gates.
#'
#' @return A `drm_family` object.
#' @export
#'
#' @examples
#' student()
student <- function() {
  structure(
    list(
      name = "student",
      family = "student",
      n_response = 1L,
      dpars = c("mu", "sigma", "nu"),
      links = c(mu = "identity", sigma = "log", nu = "logm2")
    ),
    class = "drm_family"
  )
}

#' Skew-normal response family
#'
#' `skew_normal()` defines a one-response skew-normal distribution with
#' formulas for location `mu`, residual standard deviation `sigma`, and
#' residual slant `nu`.
#'
#' The implemented family is univariate:
#' `mu = eta_mu`, `log(sigma) = eta_sigma`, and `nu = eta_nu`. The likelihood
#' transforms internally to the native Azzalini location `xi`, scale `omega`,
#' and slant `alpha = nu`, but user-facing methods keep the public moment
#' parameterization: [fitted()] returns `E[y] = mu`, [stats::sigma()] returns
#' `SD[y] = sigma`, and `predict(..., dpar = "nu")` returns the residual slant.
#' Positive `nu` gives right-skewed residuals, negative `nu` gives left-skewed
#' residuals, and `nu = 0` reduces to the Gaussian location-scale likelihood.
#'
#' Ordinary unlabelled random intercepts and independent numeric slopes such as
#' `(1 | id)` and `(0 + x | id)` may enter `mu`. Correlated or labelled `mu`
#' slopes, `sigma` or `nu` random effects, `sd(group)` scale formulas, structured
#' effects, known sampling covariance, bivariate skew-normal models, residual
#' `rho12`, and latent `skew(id)` syntax remain unsupported.
#'
#' @return A `drm_family` object.
#' @export
#'
#' @examples
#' skew_normal()
skew_normal <- function() {
  structure(
    list(
      name = "skew_normal",
      family = "skew_normal",
      n_response = 1L,
      dpars = c("mu", "sigma", "nu"),
      links = c(mu = "identity", sigma = "log", nu = "identity")
    ),
    class = "drm_family"
  )
}

#' Lognormal response family
#'
#' `lognormal()` defines a one-response positive continuous distribution with
#' formulas for log-location `mu` and log-scale `sigma`.
#'
#' The model is defined on the log response scale:
#' `log(y) ~ Normal(mu, sigma^2)`. The fitted distributional parameter `mu` is
#' therefore the mean of `log(y)`, not the arithmetic mean of `y`.
#' Ordinary `mu` random intercepts such as `(1 | id)` are supported in the
#' first positive-continuous mixed-model slice; the independent numeric slope
#' `(0 + x | id)` also fits but is a recovery-grade route only (trust the
#' point estimate, not the interval). One complete-data ordinary unlabelled
#' correlated intercept-slope block `(1 + x | id)` is also fitted at
#' `point_fit_recovery` (`mc-0720`) under the design-17 map for group-level
#' `sd0`, `sd1`, and `rho_re` (never residual `rho12`).
#'
#' @return A `drm_family` object.
#' @export
#'
#' @examples
#' lognormal()
lognormal <- function() {
  structure(
    list(
      name = "lognormal",
      family = "lognormal",
      n_response = 1L,
      dpars = c("mu", "sigma"),
      links = c(mu = "identity", sigma = "log")
    ),
    class = "drm_family"
  )
}

#' Tweedie response family
#'
#' `tweedie()` defines a one-response Tweedie compound Poisson-Gamma
#' distribution for non-negative continuous responses with exact zeros.
#'
#' The implemented contract is univariate:
#' `log(mu) = eta_mu`, `log(sigma) = eta_sigma`,
#' `nu = 1 + plogis(eta_nu)`, `phi = sigma^2`, `E[y] = mu`, and
#' `Var(y) = sigma^2 * mu^nu`, with `1 < nu < 2`. The public `sigma`
#' parameter is therefore the square root of the usual Tweedie dispersion
#' `phi`. Ordinary unlabelled random intercepts and independent numeric slopes
#' such as `(1 | id)` and `(0 + x | id)` may enter `mu`. Correlated or labelled
#' `mu` slopes, `sigma` or `nu` random effects, predictor-dependent `nu`,
#' bivariate Tweedie models, structured effects, zero-inflation aliases, and
#' hurdle aliases remain unsupported.
#'
#' @return A `drm_family` object.
#' @export
#'
#' @examples
#' tweedie()
tweedie <- function() {
  structure(
    list(
      name = "tweedie",
      family = "tweedie",
      n_response = 1L,
      dpars = c("mu", "sigma", "nu"),
      links = c(mu = "log", sigma = "log", nu = "logit12")
    ),
    class = "drm_family"
  )
}

#' Beta response family
#'
#' `beta_family()` defines a one-response distribution for continuous proportions
#' strictly inside `(0, 1)`, with formulas for mean `mu` and scale `sigma`.
#' Write `family = beta_family()`. Unqualified `beta()` is [base::beta()],
#' the Euler beta function, and is not a drmTMB family.
#'
#' The implemented contract is
#' `logit(mu) = eta_mu`, `log(sigma) = eta_sigma`, and internal precision
#' `phi = 1 / sigma^2`. Larger `sigma` therefore means more variation around
#' the mean, not more precision.
#' Ordinary unlabelled random intercepts and independent numeric slopes such as
#' `(1 | id)` and `(0 + x | id)` may enter the logit-`mu` predictor; `sigma`
#' remains fixed-effect in this first slice.
#'
#' @return A `drm_family` object.
#' @export
#'
#' @examples
#' beta_family()
beta_family <- function() {
  structure(
    list(
      name = "beta",
      family = "beta",
      n_response = 1L,
      dpars = c("mu", "sigma"),
      links = c(mu = "logit", sigma = "log")
    ),
    class = "drm_family"
  )
}

#' @keywords internal
#' @describeIn beta_family Deprecated alias; use [beta_family()] instead.
#'   Not exported (it would mask [base::beta()]). Call `drmTMB:::beta()` only
#'   if an old script still needs the alias.
beta <- function() {
  lifecycle::deprecate_warn("0.7.1", "beta()", "beta_family()")
  beta_family()
}

drm_family_call_parts <- function(fun) {
  if (is.symbol(fun) && identical(fun, quote(beta))) {
    return(list(pkg = NULL, name = "beta"))
  }
  if (
    is.call(fun) &&
      length(fun) == 3L &&
      (identical(fun[[1L]], quote(`::`)) || identical(fun[[1L]], quote(`:::`)))
  ) {
    return(list(
      pkg = as.character(fun[[2L]]),
      name = as.character(fun[[3L]]),
      ns_op = as.character(fun[[1L]])
    ))
  }
  NULL
}

drm_is_bare_euler_beta_call <- function(expr) {
  if (!is.call(expr) || length(expr) != 1L) {
    return(FALSE)
  }
  info <- drm_family_call_parts(expr[[1L]])
  if (is.null(info) || !identical(info$name, "beta")) {
    return(FALSE)
  }
  if (identical(info$pkg, "drmTMB")) {
    return(FALSE)
  }
  is.null(info$pkg) || info$pkg %in% c("base", "stats")
}

drm_is_unexported_drmtmb_beta_call <- function(expr) {
  if (!is.call(expr) || length(expr) != 1L) {
    return(FALSE)
  }
  info <- drm_family_call_parts(expr[[1L]])
  !is.null(info) &&
    identical(info$name, "beta") &&
    identical(info$pkg, "drmTMB") &&
    identical(info$ns_op, "::")
}

drm_abort_base_beta_as_family <- function() {
  cli::cli_abort(
    c(
      "{.code family = beta()} is {.code base::beta()}, the Euler beta function, not a {.pkg drmTMB} family.",
      "x" = "Unqualified {.code beta()} stopped masking {.code base::beta()} in 0.7.1.",
      "i" = "Use {.code family = beta_family()} for continuous proportions in (0, 1)."
    ),
    class = "drmTMB_base_beta_family_error"
  )
}

drm_eval_family_arg <- function(expr, env) {
  if (drm_is_bare_euler_beta_call(expr)) {
    drm_abort_base_beta_as_family()
  }
  if (drm_is_unexported_drmtmb_beta_call(expr)) {
    cli::cli_abort(
      c(
        "{.code drmTMB::beta()} is not an exported object.",
        "x" = "The 0.7.1 rename left the old constructor unexported so it would not mask {.code base::beta()}.",
        "i" = "Use {.code family = beta_family()}."
      ),
      class = "drmTMB_base_beta_family_error"
    )
  }
  family <- eval(expr, envir = env)
  if (is.function(family) && identical(family, base::beta)) {
    drm_abort_base_beta_as_family()
  }
  family
}

#' Zero-one beta response family
#'
#' `zero_one_beta()` defines a one-response distribution for continuous
#' proportions on `[0, 1]` when exact zeroes or ones are structural outcomes
#' rather than binomial denominator outcomes.
#'
#' The implemented fixed-effect contract is `logit(mu) = eta_mu`,
#' `log(sigma) = eta_sigma`, `logit(zoi) = eta_zoi`, and
#' `logit(coi) = eta_coi`. Here `zoi` is the probability that an observation
#' is exactly 0 or 1, and `coi` is the conditional probability of an exact 1
#' given that the observation is on the boundary. Interior observations follow
#' the same beta mean-scale contract as [beta_family()], with internal precision
#' `phi = 1 / sigma^2`.
#'
#' `fitted()` returns the unconditional response mean
#' `(1 - zoi) * mu + zoi * coi`. Ordinary unlabelled random intercepts and
#' independent numeric slopes such as `(1 | id)` and `(0 + x | id)` may enter
#' `mu`. The point-fit-only q1 gates additionally admit one ordinary
#' intercept-only random effect in `sigma`, `zoi`, or `coi`, separately, plus
#' one ordinary slope-only effect in any one of those parameters when the fixed
#' and random terms use the same raw symbol. Examples are
#' `zoi ~ x + (0 + x | id)` and `coi ~ x + (0 + x | id)`. The exact `coi`
#' admissions are that slope form and `coi ~ 1 + (1 | id)`, both with fixed
#' `sigma ~ 1` and `zoi ~ 1`. All of these routes carry point-fit recovery
#' evidence only. The two `sigma` routes now admit direct profiling, so
#' `confint(method = "profile")` reaches their SD target; that makes an
#' interval computable, not calibrated, and no interval, coverage, or broader
#' recovery claim is established for them. For the `zoi` and `coi` routes,
#' direct profiling, intervals, coverage, and broader recovery claims remain
#' unavailable. In the retained `coi` recovery rung (`M = 64`, 50 observations
#' per group), population-level point recovery remained stable when a few groups
#' had fewer than two observed zeroes or ones, but those groups can have weakly
#' identified conditional modes; inspect the within-group atom counts before
#' interpreting individual modes. Correlated or labelled effects,
#' intercept-plus-slope atom effects, transformed or mismatched `zoi` or `coi`
#' slope symbols, structured atom effects,
#' covariance blocks, and denominator syntax remain unsupported. One further
#' point-fit-only structured route is
#' available: an unlabelled q1 `phylo(1 | group, tree = tree)` intercept in
#' `mu`. It does not license other providers, slopes, labels, covariance,
#' q2-plus structured effects, profiling, intervals, coverage, or inference
#' claims.
#'
#' @return A `drm_family` object.
#' @export
#'
#' @examples
#' zero_one_beta()
zero_one_beta <- function() {
  structure(
    list(
      name = "zero_one_beta",
      family = "zero_one_beta",
      n_response = 1L,
      dpars = c("mu", "sigma", "zoi", "coi"),
      links = c(mu = "logit", sigma = "log", zoi = "logit", coi = "logit")
    ),
    class = "drm_family"
  )
}

#' Beta-binomial response family
#'
#' `beta_binomial()` defines a one-response denominator-aware distribution for
#' successes out of known trials. Use it with two-column count responses such as
#' `bf(cbind(successes, failures) ~ x, sigma ~ z)`, where
#' `trials_i = successes_i + failures_i`.
#'
#' The implemented contract is `logit(mu) = eta_mu`,
#' with optional ordinary unlabelled `mu` random intercepts,
#' `log(sigma) = eta_sigma`, and internal beta precision
#' `phi = 1 / sigma^2`. Conditional on a latent success probability
#' `p_i ~ Beta(mu_i * phi_i, (1 - mu_i) * phi_i)`, the observed successes
#' follow `Binomial(trials_i, p_i)`. Larger `sigma` means more extra-binomial
#' variation around the mean probability.
#'
#' The first mixed-model slice supports ordinary `mu` random intercepts and
#' independent numeric slopes such as
#' `bf(cbind(successes, failures) ~ x + (1 | id) + (0 + x | id),
#' sigma ~ z)`. Correlated slopes, labelled covariance blocks, `sigma` random
#' effects, `zoi`/`coi`, `meta_V(V = V)`, phylogenetic or spatial terms,
#' bivariate beta-binomial models, and a `successes/trials` response alias are
#' planned but not implemented.
#'
#' @return A `drm_family` object.
#' @export
#'
#' @examples
#' beta_binomial()
beta_binomial <- function() {
  structure(
    list(
      name = "beta_binomial",
      family = "beta_binomial",
      n_response = 1L,
      dpars = c("mu", "sigma"),
      links = c(mu = "logit", sigma = "log")
    ),
    class = "drm_family"
  )
}

#' Cumulative logit ordinal response family
#'
#' `cumulative_logit()` defines a one-response ordinal model for ordered
#' categories. The first implemented path uses a location formula `mu ~ ...`
#' and ordered cutpoints with a fixed latent logistic scale. The location
#' intercept is dropped internally, as in standard cumulative-link models,
#' because a free location intercept and free cutpoints are not jointly
#' identifiable.
#'
#' The implemented contract is
#' `Pr(y_i <= k) = logit^-1(theta_k - mu_i)`, with
#' `mu_i = X_mu[i, ] beta_mu` and
#' `theta[1] < theta[2] < ... < theta[K - 1]`. `fitted()` returns the expected
#' ordered-category score, `sum_k k * Pr(y_i = k)`. Ordinal scale or
#' discrimination formulas are planned but not exposed in this first
#' implementation.
#'
#' The response may be an ordered factor or an integer-coded category. Integer
#' codes are used at face value in increasing numeric order; `drmTMB` cannot
#' infer whether those numbers represent the scientific ordering the analyst
#' intended. Use an ordered factor when labels carry the biological ordering.
#'
#' @return A `drm_family` object.
#' @export
#'
#' @examples
#' cumulative_logit()
cumulative_logit <- function() {
  structure(
    list(
      name = "cumulative_logit",
      family = "cumulative_logit",
      n_response = 1L,
      dpars = c("mu"),
      links = c(mu = "identity")
    ),
    class = "drm_family"
  )
}

#' Negative binomial 2 response family
#'
#' `nbinom2()` defines a one-response count distribution with formulas for the
#' mean `mu` and overdispersion scale `sigma`.
#'
#' The implemented contract is
#' `log(mu) = eta_mu`, `log(sigma) = eta_sigma`, and
#' `Var(y) = mu + sigma^2 * mu^2`. Thus larger `sigma` means greater
#' extra-Poisson variation. Internally this is equivalent to the usual NB2
#' size parameter `size = 1 / sigma^2`. Ordinary non-zero-inflated NB2 models
#' also support one complete-data unlabelled `(1 + x | id)` ML-Laplace
#' correlated intercept-slope block on the log-mean (`mc-0719`), and
#' first-slice random intercepts on the log-`sigma` predictor,
#' such as `bf(count ~ x, sigma ~ z + (1 | id))`. Structured `sigma` effects
#' (`phylo`/`spatial`/`animal`/`relmat`) also fit as a point-recovery route
#' (trust the point estimate, not the interval; not yet coverage-verified).
#' NB2 `sigma` random slopes remain planned. Zero-inflated NB2 supports only
#' the point-fit-only IID control `bf(count ~ fixed_effects, sigma ~ 1 +
#' (1 | group), zi ~ 1)` under ML with complete responses; zero-inflated
#' sigma predictors, slopes, labels, and other random-effect combinations
#' remain unsupported.
#'
#' @return A `drm_family` object.
#' @export
#'
#' @examples
#' nbinom2()
nbinom2 <- function() {
  structure(
    list(
      name = "nbinom2",
      family = "nbinom2",
      n_response = 1L,
      dpars = c("mu", "sigma"),
      links = c(mu = "log", sigma = "log")
    ),
    class = "drm_family"
  )
}

#' Zero-truncated negative binomial 2 response family
#'
#' `truncated_nbinom2()` defines a one-response positive-count distribution
#' with formulas for the untruncated NB2 mean `mu` and overdispersion scale
#' `sigma`.
#'
#' Adding `hu ~ predictors` to the model formula fits the corresponding hurdle
#' NB2 model: `hu` is the probability of a hurdle zero, and nonzero counts are
#' drawn from the zero-truncated NB2 component.
#'
#' The implemented contract is
#' `log(mu) = eta_mu`, `log(sigma) = eta_sigma`, and the count response is
#' distributed as NB2 conditional on being greater than zero. The untruncated
#' NB2 variance is `Var(y) = mu + sigma^2 * mu^2`, with internal
#' `size = 1 / sigma^2`.
#'
#' Ordinary zero-truncated NB2 models support first-slice random intercepts and
#' independent numeric slopes in the log-mean predictor, such as
#' `bf(count ~ x + (1 | id) + (0 + x | id), sigma ~ z)`. Hurdle NB2 random
#' effects, correlated zero-truncated slopes, structured effects, and
#' overdispersion-side random effects remain planned.
#'
#' @return A `drm_family` object.
#' @export
#'
#' @examples
#' truncated_nbinom2()
truncated_nbinom2 <- function() {
  structure(
    list(
      name = "truncated_nbinom2",
      family = "truncated_nbinom2",
      n_response = 1L,
      dpars = c("mu", "sigma"),
      links = c(mu = "log", sigma = "log")
    ),
    class = "drm_family"
  )
}
