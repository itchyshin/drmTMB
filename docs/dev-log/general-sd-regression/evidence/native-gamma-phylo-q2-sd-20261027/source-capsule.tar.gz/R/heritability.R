#' Heritability, ICC, and repeatability accessors
#'
#' `heritability()`, `icc()`, and `repeatability()` are derived-quantity
#' accessors for structured-Gaussian `drmTMB` fits, ported term-for-term from
#' `DRM.jl`'s `src/heritability.jl` (design doc
#' `docs/design/259-heritability-icc-repeatability.md`). All three report the
#' share of total variance carried by one structured random-effect component
#' relative to a denominator on the working (log-SD) scale:
#'
#' * `heritability()`: `sigma^2_focal / (sum of ALL structured mean-component
#'   variances + residual variance)` -- the comparative-biology "phylogenetic
#'   signal" definition.
#' * `icc()` / `repeatability()`: `sigma^2_focal / (sigma^2_focal + residual
#'   variance)` -- the classic focal-vs-residual intraclass correlation.
#'   `repeatability()` is an alias for `icc()`.
#'
#' `heritability()` and `icc()` return the same value only when the fit has a
#' single structured mean component (no other components to net out of the
#' denominator).
#'
#' `summary()`'s derived rows, named `total_variance_share` and
#' `phylo_total_variance_share`, use the total-variance (heritability-style)
#' denominator, so they can differ from `icc()`/`repeatability()` here whenever
#' a fit has two or more structured components. Those rows were called
#' `repeatability` and `phylogenetic_signal` until 2026-09-03; they were renamed
#' so that one word no longer names two different quantities (D-213).
#'
#' Fits must be Gaussian, have a constant residual scale (`sigma ~ 1`) or a
#' closed-form marginal residual variance, and have at least one structured
#' mean random-effect component (`(1 | group)`, `phylo(...)`, `animal(...)`,
#' `relmat(...)`, or `spatial(...)`); a component modelled with
#' `sd(group) ~ ...` (location-scale-scale) does not define a single variance
#' component and is refused. When a fit has more than one structured
#' component, `component` must name one of them (see `object$sdpars$mu` for
#' the available labels). When `sigma` additionally carries an ordinary
#' random intercept, or a phylogenetic random intercept with a unit-diagonal
#' correlation (the default `phylo(...)` route), the residual entry of the
#' denominator is the *marginal* residual variance
#' `exp(2*b0 + 2*sum_k(omega_k^2))` -- `E[sigma^2]`, not the squared median
#' `exp(2*b0)` -- and its delta-method gradient is extended over those
#' `omega_k` positions too. A random slope on `sigma`, a structured
#' `sigma` effect without a verified unit-diagonal correlation (measured on
#' the rows the design uses), or a fit that carries a `sigma` random effect
#' while the `log(sigma)` soft clamp bent the assembled predictor for at
#' least one observation (`clamp_limited`), has no closed-form
#' marginal residual variance and is refused with a message
#' naming why; see
#' `docs/design/275-repeatability-scale-and-residual-variance.md`.
#'
#' Standard errors and confidence intervals use a delta method on the
#' working (log-SD) scale: a numeric gradient of the ratio in the log-SD
#' parameters, combined with the fixed-parameter covariance
#' (`object$sdr$cov.fixed`) via the quadratic form, then a Wald interval at
#' `level`, clamped to `[0, 1]`. This is a delta-method approximation; not a coverage claim.
#' See the design doc for the sanity-check evidence this slice carries.
#'
#' `method = "profile"` is accepted for call-site parity with `DRM.jl` but is
#' **not implemented** in this slice; it aborts naming `method = "delta"` as
#' the supported option.
#'
#' @param object A `drmTMB` fit.
#' @param component Optional character string naming the structured mean
#'   component (matching a name in `object$sdpars$mu`, e.g. `"(1 | id)"` or
#'   `"phylo(1 | species)"`; structured markers drop their non-grouping
#'   arguments such as `tree =`/`Ainv =`/`K =` from the label -- see the
#'   `@examples` phylo case below). Required when the fit has more than one
#'   structured component; ignored (and unnecessary) when the fit has exactly
#'   one.
#' @param level Confidence level for the Wald interval. Default `0.95`.
#' @param method Either `"delta"` (default) or `"profile"`. `"profile"` is
#'   accepted for signature parity only and always aborts in this slice.
#' @param ... Reserved for future extractor options.
#'
#' @return A one-row data frame (class `drm_heritability`) with columns
#'   `quantity`, `component`, `estimate`, `se`, `lower`, `upper`, `level`,
#'   and `method`.
#'
#' @examples
#' set.seed(20260525)
#' n_groups <- 20
#' n_per <- 8
#' grp <- factor(rep(seq_len(n_groups), each = n_per))
#' sd_g <- 1
#' sd_e <- 0.6
#' b_g <- rnorm(n_groups, sd = sd_g)
#' dat <- data.frame(y = 2 + b_g[grp] + rnorm(length(grp), sd = sd_e), grp = grp)
#' fit <- drmTMB(bf(y ~ 1 + (1 | grp), sigma ~ 1), data = dat)
#' icc(fit)
#' repeatability(fit)
#' heritability(fit)
#'
#' \donttest{
#' if (requireNamespace("ape", quietly = TRUE)) {
#'   # A structured (phylo) component: its sdpars$mu / component label drops
#'   # the tree argument entirely and is just "phylo(1 | species)".
#'   set.seed(20260601)
#'   n_tip <- 20
#'   phy <- ape::rcoal(n_tip)
#'   phy$tip.label <- paste0("sp_", seq_len(n_tip))
#'   A <- ape::vcv(phy, corr = TRUE)
#'   u <- as.vector(t(chol(A)) %*% rnorm(n_tip)) * 0.9
#'   species <- factor(rep(phy$tip.label, each = 4), levels = phy$tip.label)
#'   phylo_dat <- data.frame(
#'     y = 2 + u[rep(seq_len(n_tip), each = 4)] +
#'       rnorm(length(species), sd = 0.6),
#'     species = species
#'   )
#'   phylo_fit <- drmTMB(
#'     bf(y ~ 1 + phylo(1 | species, tree = phy), sigma ~ 1),
#'     data = phylo_dat
#'   )
#'   icc(phylo_fit, component = "phylo(1 | species)")
#' }
#' }
#'
#' @name heritability
NULL

#' @rdname heritability
#' @export
heritability <- function(object, ...) {
  UseMethod("heritability")
}

#' @rdname heritability
#' @export
heritability.drmTMB <- function(
  object,
  component = NULL,
  level = 0.95,
  method = c("delta", "profile"),
  ...
) {
  method <- match.arg(method)
  drm_variance_ratio(
    object,
    quantity = "heritability",
    component = component,
    level = level,
    method = method
  )
}

#' @rdname heritability
#' @export
icc <- function(object, ...) {
  UseMethod("icc")
}

#' @rdname heritability
#' @export
icc.drmTMB <- function(
  object,
  component = NULL,
  level = 0.95,
  method = c("delta", "profile"),
  ...
) {
  method <- match.arg(method)
  drm_variance_ratio(
    object,
    quantity = "icc",
    component = component,
    level = level,
    method = method
  )
}

#' @rdname heritability
#' @export
repeatability <- function(object, ...) {
  UseMethod("repeatability")
}

#' @rdname heritability
#' @export
repeatability.drmTMB <- function(
  object,
  component = NULL,
  level = 0.95,
  method = c("delta", "profile"),
  ...
) {
  method <- match.arg(method)
  drm_variance_ratio(
    object,
    quantity = "repeatability",
    component = component,
    level = level,
    method = method
  )
}

# ---------------------------------------------------------------------------
# engine = "julia" fence (parity leaf `uncited-accessors`, 2026-09-05).
#
# `drm_variance_ratio()` is a delta-method ratio on the WORKING scale: it reads
# the optimiser's parameter vector `object$opt$par` (which carries `log_sd_mu`
# and `beta_sigma`, i.e. log SDs) and the TMB `sdreport` joint covariance of
# those working parameters, then applies the Jacobian of
# `exp(2*log_sd) / (sum exp(2*log_sd) + exp(2*beta_sigma))`. A `drmTMB_julia`
# fit has NEITHER slot: `drm_julia_opt_slot()` (R/julia-bridge.R) stores only
# `convergence`, `iterations` and `message`, and the public `object$vcov` is
# SUBSET to the fixed-effect coefficients -- the structured `resd_*` log-SD
# rows and columns are dropped on the way out.
#
# Without a method, `heritability(julia_fit)` failed with a bare `UseMethod`
# dispatch error that named nothing and suggested nothing. These three methods
# make the fence visible and actionable instead. They are a REFUSAL, not an
# approximation: the point estimate would be computable from `sdpars` and
# `sigma()`, but the delta-method SE and interval -- the whole reason the
# accessor exists -- would not be.
#
# MEASURED, not assumed (DRM.jl aee371cc9, 2026-09-05, n = 360, G = 30,
# `bf(y ~ x + (1 | g), sigma ~ 1)`, gaussian): the ingredients ARE present one
# layer down. `drm_julia_vcov(fit$bridge$vcov, fit$bridge$coef_names)` returns
# the FULL 4 x 4 working-scale covariance whose `resd_g` row/column matches
# TMB's `sdreport` `log_sd_mu` entry (1.824454e-02 vs 1.824453e-02), and the
# h2 point estimate formed by hand from the julia fit's `sdpars`/`sigma()`
# agrees with `heritability(tmb_fit)$estimate` to 2.5e-12. So this fence is
# "not wired", not "not possible"; wiring it needs a name map from drmTMB's
# component labels to DRM.jl's `resd_*` spelling, the structured-SD scale
# conversion the bridge already applies elsewhere (tree height, #693), and the
# same random-slope / non-constant-sigma guards the native path carries.
# See docs/dev-log/evidence/julia-r-parity/uncited-accessors/.
drm_variance_ratio_julia_fence <- function(quantity) {
  cli::cli_abort(
    c(
      "{.fn {quantity}} is not available for an {.code engine = \"julia\"} fit.",
      "x" = "It is a delta-method ratio of working-scale (log-SD) variance components, and a {.cls drmTMB_julia} fit exposes neither the working-scale parameter vector ({.code fit$opt$par}) nor the covariance of its structured SDs ({.code fit$vcov} keeps fixed-effect coefficients only).",
      "i" = "Refit the same model with {.code engine = \"tmb\"} and call {.fn {quantity}} on that fit; the two engines agree on the underlying variance components (measured to 4e-12 on a Gaussian {.code (1 | g)} fixture, DRM.jl aee371cc9).",
      "i" = "For the among-axis structure of a q = 4 bivariate location-scale fit, {.fn coevolution_vc} and {.fn coevolution_summary} DO read an {.code engine = \"julia\"} fit."
    ),
    class = "drmTMB_variance_ratio_julia_unsupported"
  )
}

#' @rdname heritability
#' @export
heritability.drmTMB_julia <- function(object, ...) {
  drm_variance_ratio_julia_fence("heritability")
}

#' @rdname heritability
#' @export
icc.drmTMB_julia <- function(object, ...) {
  drm_variance_ratio_julia_fence("icc")
}

#' @rdname heritability
#' @export
repeatability.drmTMB_julia <- function(object, ...) {
  drm_variance_ratio_julia_fence("repeatability")
}

#' @export
print.drm_heritability <- function(x, ...) {
  cli::cli_text(
    "<{x$quantity[[1L]]}> component = {.val {x$component[[1L]]}}"
  )
  cli::cli_text(
    "  estimate: {format(x$estimate[[1L]], digits = 4)}"
  )
  if (identical(x$method[[1L]], "delta") && is.finite(x$se[[1L]])) {
    cli::cli_text(
      "  se: {format(x$se[[1L]], digits = 4)}  {x$level[[1L]] * 100}% CI: [{format(x$lower[[1L]], digits = 4)}, {format(x$upper[[1L]], digits = 4)}]"
    )
  }
  invisible(x)
}

# ---------------------------------------------------------------------------
# Shared implementation.
# ---------------------------------------------------------------------------

# Build the gated variance-component ratio (heritability / icc / repeatability)
# and its delta-method SE + Wald CI. `quantity` is one of "heritability",
# "icc", "repeatability"; "icc" and "repeatability" share the focal-vs-residual
# denominator, "heritability" uses the total-variance denominator.
drm_variance_ratio <- function(
  object,
  quantity,
  component,
  level,
  method
) {
  if (method == "profile") {
    cli::cli_abort(
      "{.arg method} = {.val profile} is not implemented for {.fn {quantity}}; use {.code method = \"delta\"}."
    )
  }
  if (!identical(object$model$model_type, "gaussian")) {
    cli::cli_abort(c(
      "{.fn {quantity}} requires a Gaussian {.field model_type} fit.",
      "i" = "This fit has {.val {object$model$model_type}}."
    ))
  }
  drm_variance_ratio_reject_random_slopes(object, quantity)
  sigma <- drm_constant_residual_sigma(object)
  if (!is.finite(sigma)) {
    cli::cli_abort(c(
      "{.fn {quantity}} requires a constant residual scale ({.code sigma ~ 1}) or a closed-form marginal residual variance.",
      "i" = drm_residual_sigma_na_reason_text(attr(sigma, "reason"))
    ))
  }
  sd_values <- object$sdpars$mu
  if (is.null(sd_values) || length(sd_values) == 0L) {
    cli::cli_abort(c(
      "{.fn {quantity}} requires at least one structured mean random-effect component.",
      "i" = "No {.code (1 | group)}, {.fn phylo}, {.fn animal}, {.fn relmat}, or {.fn spatial} term with a single scalar SD was found (a {.code sd(group) ~ ...} term does not define one)."
    ))
  }
  focal <- drm_variance_ratio_resolve_component(sd_values, component, quantity)
  positions <- drm_variance_ratio_positions(object, sd_values)
  if (anyNA(positions)) {
    cli::cli_abort(
      "{.fn {quantity}}: could not locate the working-scale parameter position for one or more structured components."
    )
  }
  resid_position <- which(names(object$opt$par) == "beta_sigma")
  if (length(resid_position) != 1L) {
    cli::cli_abort(
      "{.fn {quantity}}: could not locate a single residual scale parameter."
    )
  }

  if (quantity == "heritability") {
    denom_idx <- seq_along(sd_values)
  } else {
    denom_idx <- focal
  }

  # The residual denominator entry is exp(2*beta_sigma) when sigma is a
  # constant, or exp(2*beta_sigma + 2*sum_k(omega_k^2)) when sigma carries a
  # (already-validated, see drm_constant_residual_sigma() above) random
  # intercept / unit-diagonal phylogenetic random intercept -- the same
  # marginal-residual-variance fix as drm_derived_summary_rows(), extended
  # here to the delta-method gradient too (docs/design/275 section 5,
  # Fisher's 2026-09-14 ruling: "both the estimate and the delta-method SE
  # must change").
  sigma_extra_positions <- drm_sigma_residual_extra_positions(object)
  if (is.null(sigma_extra_positions)) {
    cli::cli_abort(
      "{.fn {quantity}}: could not locate the working-scale parameter position for the sigma random effect."
    )
  }
  resid_group <- if (length(sigma_extra_positions) == 0L) {
    list(positions = resid_position, value = function(t) exp(2 * t[[1L]]))
  } else {
    list(
      positions = c(resid_position, sigma_extra_positions),
      value = function(t) exp(2 * t[[1L]] + 2 * sum(exp(2 * t[-1L])))
    )
  }
  mu_groups <- lapply(positions[denom_idx], function(p) {
    list(positions = p, value = function(t) exp(2 * t[[1L]]))
  })
  denom_groups <- c(mu_groups, list(resid_group))
  focal_index <- match(focal, denom_idx)

  cov_fixed <- drm_sdreport_cov_fixed(object)
  drm_variance_ratio_check_cov_alignment(object, cov_fixed, quantity)

  fit <- drm_variance_ratio_delta(
    theta_hat = object$opt$par,
    cov_fixed = cov_fixed,
    denom_groups = denom_groups,
    focal_index = focal_index
  )

  crit <- stats::qnorm(1 - (1 - level) / 2)
  lower <- fit$estimate - crit * fit$se
  upper <- fit$estimate + crit * fit$se

  out <- data.frame(
    quantity = quantity,
    component = names(sd_values)[[focal]],
    estimate = fit$estimate,
    se = fit$se,
    lower = pmin(pmax(lower, 0), 1),
    upper = pmin(pmax(upper, 0), 1),
    level = level,
    method = "delta",
    stringsAsFactors = FALSE
  )
  class(out) <- c("drm_heritability", "data.frame")
  out
}

# Resolve `component` to an index into `sd_values`; default to the sole entry.
drm_variance_ratio_resolve_component <- function(sd_values, component, quantity) {
  if (is.null(component)) {
    if (length(sd_values) != 1L) {
      cli::cli_abort(c(
        "{.fn {quantity}}: this fit has {length(sd_values)} structured components.",
        "i" = "Pass {.arg component} naming one of: {.val {names(sd_values)}}."
      ))
    }
    return(1L)
  }
  match_idx <- match(component, names(sd_values))
  if (is.na(match_idx)) {
    cli::cli_abort(c(
      "{.fn {quantity}}: no structured component named {.val {component}}.",
      "i" = "Available components: {.val {names(sd_values)}}."
    ))
  }
  match_idx
}

# Refuse random slopes / correlated random effects on mu: they are not a
# variance share (an intercept-column SD and a per-unit-of-x slope-column SD
# are in different units, and DRM.jl's src/heritability.jl has no
# random-slope route to port here -- the correct behaviour is to refuse, not
# to silently sum incompatible variances or drop the intercept-slope
# correlation). Detected structurally from the fit's parameter structure, not
# by regexing the sdpars$mu label text:
#   (a) any `eta_cor_mu` entry in object$opt$par -- a correlated mu random
#       effect exists somewhere in the fit;
#   (b) object$model$random$mu$coef_names containing anything other than
#       "(Intercept)" -- a multi-column (slope) mu random-effect term, even
#       when uncorrelated (e.g. `(0 + x | g)`).
# See docs/design/259-heritability-icc-repeatability.md section 2 for the
# probe evidence behind (a)/(b) (object$model$random$mu$n_terms/coef_names/
# n_cors on a fitted `(1 + x | blk)` and `(0 + x | blk)` model).
drm_variance_ratio_reject_random_slopes <- function(object, quantity) {
  if ("eta_cor_mu" %in% names(object$opt$par)) {
    cli::cli_abort(c(
      "{.fn {quantity}} does not support correlated random effects on {.field mu}.",
      "i" = "Random slopes / correlated random effects are not a variance share; use scalar {.code (1 | g)} or structured intercepts."
    ))
  }
  random_mu <- object$model$random$mu
  if (is.list(random_mu) && isTRUE(random_mu$n_re > 0L)) {
    coef_names <- random_mu$coef_names
    slope_idx <- which(!is.na(coef_names) & coef_names != "(Intercept)")
    if (length(slope_idx) > 0L) {
      slope_terms <- unique(random_mu$labels[slope_idx])
      cli::cli_abort(c(
        "{.fn {quantity}} does not support random slopes on {.field mu}.",
        "x" = "This fit has a random-slope term: {.val {slope_terms}}.",
        "i" = "Random slopes / correlated random effects are not a variance share; use scalar {.code (1 | g)} or structured intercepts."
      ))
    }
  }
  invisible(NULL)
}

# Map each name in `sd_values` (== object$sdpars$mu) to its position in
# object$opt$par. Names matching a structured-marker prefix consume
# `log_sd_phylo` positions in order; every other name consumes `log_sd_mu`
# positions in order (see docs/design/259-heritability-icc-repeatability.md
# section 1 for why this reproduces split_tmb_sdpars()'s assignment order).
drm_variance_ratio_positions <- function(object, sd_values) {
  # split_tmb_sdpars() switches to a `mu:`/`sigma:` prefixed label once the
  # SAME structured term also has a sibling on the other endpoint
  # (R/drmTMB.R phylo_mu_sd_labels()/split_tmb_sdpars(), e.g.
  # "mu:phylo(1 | species)" when phylo() is on both mu and sigma) -- strip it
  # before matching the structured-marker prefix, or the term is misrouted to
  # the (empty) log_sd_mu pool and yields NA (2026-09-14 ruling, S2b item 2).
  nm <- sub("^(mu|sigma):", "", names(sd_values))
  structured_prefix <- "^(phylo|animal|relmat|spatial|phylo_interaction)\\("
  is_structured <- grepl(structured_prefix, nm)
  opt_names <- names(object$opt$par)
  mu_positions <- which(opt_names == "log_sd_mu")
  phylo_positions <- which(opt_names == "log_sd_phylo")
  positions <- rep(NA_integer_, length(nm))
  mu_rank <- 0L
  phylo_rank <- 0L
  for (i in seq_along(nm)) {
    if (is_structured[[i]]) {
      phylo_rank <- phylo_rank + 1L
      if (phylo_rank <= length(phylo_positions)) {
        positions[[i]] <- phylo_positions[[phylo_rank]]
      }
    } else {
      mu_rank <- mu_rank + 1L
      if (mu_rank <= length(mu_positions)) {
        positions[[i]] <- mu_positions[[mu_rank]]
      }
    }
  }
  positions
}

# Extra working-scale positions (beyond `beta_sigma`) that a random effect on
# sigma contributes to the marginal residual variance
# exp(2*beta_sigma + 2*sum_k(omega_k^2)); `integer(0)` when sigma has no
# random effect (drm_constant_residual_sigma()'s exp(b0) case, unchanged).
# `has_sigma_random_effects()` (R/methods.R:6216) has already been consulted
# by drm_constant_residual_sigma() before this is called, and any random
# slope on sigma or non-unit-diagonal structured sigma effect has already
# made that helper return NA (caught before this function runs) -- so by the
# time this runs, every position found here is an ordinary-random-intercept
# or unit-diagonal-phylogenetic omega_k, mirroring
# drm_variance_ratio_positions()'s rank-order matching against the *ordered*
# `log_sd_phylo` vector (phylo_mu_endpoint_dpars() lists mu- and sigma-
# endpoint terms in the same order split_tmb_sdpars() consumed them in).
# Returns `NULL` (an internal alignment failure) when
# has_sigma_random_effects(object) is TRUE but fewer matching positions exist
# than expected -- the caller aborts rather than silently truncating the
# gradient.
drm_sigma_residual_extra_positions <- function(object) {
  if (!has_sigma_random_effects(object)) {
    return(integer(0))
  }
  opt_names <- names(object$opt$par)
  positions <- integer(0)
  random_sigma <- object$model$random$sigma
  if (is.list(random_sigma) && isTRUE(random_sigma$n_re > 0L)) {
    log_sd_sigma_positions <- which(opt_names == "log_sd_sigma")
    n_terms <- random_sigma$n_terms
    if (length(log_sd_sigma_positions) < n_terms) {
      return(NULL)
    }
    positions <- c(positions, log_sd_sigma_positions[seq_len(n_terms)])
  }
  phylo_mu <- object$model$structured$phylo_mu
  if (isTRUE(phylo_mu$has)) {
    endpoint_dpars <- sub("[0-9]+$", "", phylo_mu_endpoint_dpars(phylo_mu))
    sigma_idx <- which(endpoint_dpars == "sigma")
    if (length(sigma_idx) > 0L) {
      log_sd_phylo_positions <- which(opt_names == "log_sd_phylo")
      if (length(log_sd_phylo_positions) < length(endpoint_dpars)) {
        return(NULL)
      }
      positions <- c(positions, log_sd_phylo_positions[sigma_idx])
    }
  }
  positions
}

# Guard against a silent misalignment between object$opt$par positions
# (what drm_variance_ratio_positions()/drm_sigma_residual_extra_positions()
# resolve the denom_groups positions against) and the row/column order of
# cov_fixed (object$sdr$cov.fixed): drm_variance_ratio_delta() indexes cov_fixed by
# those same integer positions, so if a future parameter-ordering change
# ever made the two vectors disagree, the delta SE would silently mix up
# variances/covariances instead of erroring. Verified identical today for
# both ML and REML fits (docs/design/259-heritability-icc-repeatability.md
# section 1), but asserted here rather than assumed (Rose's 2026-09-03
# verdict, "concrete safeguards" 4).
drm_variance_ratio_check_cov_alignment <- function(object, cov_fixed, quantity) {
  cov_names <- dimnames(cov_fixed)[[1L]]
  opt_names <- names(object$opt$par)
  if (is.null(cov_names) || !identical(cov_names, opt_names)) {
    cli::cli_abort(
      "{.fn {quantity}}: the fixed-parameter covariance matrix's row names do not match {.code names(object$opt$par)}; refusing to index it by position rather than risk silently misaligning the delta-method standard error."
    )
  }
  invisible(NULL)
}

# Numeric-gradient delta method for the ratio
# g(theta) = value(focal group) / sum(value(each denom group)), evaluated at
# theta_hat. Each entry of `denom_groups` is
# list(positions = <integer positions into theta_hat>,
#      value = function(theta_sub) -> scalar variance contribution);
# `focal_index` names which entry of `denom_groups` is the numerator.
#
# An ordinary (mu/phylo) component's group has ONE position and
# value = exp(2*theta) -- the original formula, unchanged. The residual
# group can have MORE than one position once sigma carries a random
# intercept or unit-diagonal phylogenetic random intercept, because the
# marginal residual variance exp(2*beta_sigma + 2*sum_k(omega_k^2))
# (docs/design/275-repeatability-scale-and-residual-variance.md section 5,
# Fisher's 2026-09-14 ruling) then depends on beta_sigma AND every omega_k;
# see drm_variance_ratio()'s `resid_group` for how that group is built.
# Returns list(estimate, se).
drm_variance_ratio_delta <- function(
  theta_hat,
  cov_fixed,
  denom_groups,
  focal_index
) {
  all_positions <- unique(unlist(lapply(denom_groups, `[[`, "positions")))
  theta_all <- unname(theta_hat[all_positions])
  slot_of <- stats::setNames(seq_along(all_positions), all_positions)

  group_values <- function(theta_vec) {
    vapply(denom_groups, function(g) {
      g$value(theta_vec[slot_of[as.character(g$positions)]])
    }, numeric(1))
  }

  ratio_fun <- function(theta_vec) {
    v <- group_values(theta_vec)
    v[[focal_index]] / sum(v)
  }
  estimate <- ratio_fun(theta_all)

  h <- 1e-5
  grad <- vapply(seq_along(theta_all), function(j) {
    plus <- theta_all
    plus[[j]] <- plus[[j]] + h
    minus <- theta_all
    minus[[j]] <- minus[[j]] - h
    (ratio_fun(plus) - ratio_fun(minus)) / (2 * h)
  }, numeric(1))

  cov_sub <- cov_fixed[all_positions, all_positions, drop = FALSE]
  variance <- as.numeric(t(grad) %*% cov_sub %*% grad)
  se <- if (is.finite(variance) && variance >= 0) sqrt(variance) else NA_real_

  list(estimate = estimate, se = se)
}
