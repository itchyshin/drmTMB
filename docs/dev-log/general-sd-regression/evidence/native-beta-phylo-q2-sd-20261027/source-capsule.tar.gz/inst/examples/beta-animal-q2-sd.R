# Model separate among-animal variation in intercepts and slopes.
# For k = 0,1: b_k = diag(exp(Z_k alpha_k)) u_k, u_k ~ N(0,A).
# The two fields are independent. Predictors z0,z1 are constant within animal;
# x varies within animal. The data below are synthetic.
library(drmTMB)
set.seed(2026102705L)
groups <- 64L
repeats <- 20L
ids <- sprintf("animal%03d", seq_len(groups))
index <- seq_len(groups)
diagonal <- seq(0.8, 1.3, length.out = groups)
A <- 0.25^abs(outer(index, index, "-")) *
  outer(sqrt(diagonal), sqrt(diagonal))
dimnames(A) <- list(ids, ids)
z0 <- rep(c(-1, 1), groups / 2L)
z1 <- rep(c(-1, 1), each = groups / 2L)
sd0 <- exp(log(0.5) + 0.5 * z0)
sd1 <- exp(log(0.4) - 0.5 * z1)
b0 <- sd0 * drop(t(chol(A)) %*% rnorm(groups))
b1 <- sd1 * drop(t(chol(A)) %*% rnorm(groups))
ii <- rep(index, each = repeats)
x <- rep(seq(-1.2, 1.2, length.out = repeats), groups)
eta <- 0.2 + 0.3 * x + b0[ii] + x * b1[ii]
mu <- 1e-12 + (1 - 2e-12) * plogis(eta)
# Beta precision phi = sigma^-2. The response variance also depends on mu.
sigma <- 0.35
phi <- sigma^-2
dat <- data.frame(
  y = rbeta(length(ii), mu * phi, (1 - mu) * phi),
  id = factor(ids[ii]), x = x, z0 = z0[ii], z1 = z1[ii]
)
fit <- drmTMB(
  bf(y ~ x + animal(1 + x | id, A = A), sigma ~ 1,
     sd(id, level = "animal", coef = "(Intercept)") ~ z0,
     sd(id, level = "animal", coef = "x") ~ z1),
  family = beta_family(), data = dat,
  control = drm_control(se = FALSE)
)
print(coef(fit, 'sd_animal(id, dpar = "mu", coef = "(Intercept)")'))
print(coef(fit, 'sd_animal(id, dpar = "mu", coef = "x")'))
slope_sd <- predict(fit, dpar = 'sd_animal(id, dpar = "mu", coef = "x")')
# A non-unit A diagonal contributes to marginal field variance:
# Var(b_gk) = fitted_sd_gk^2 * A[g,g]. Keep the supplied kernel scaling.
# Equivalent precision input uses the inverse of the full named matrix.
Ainv <- solve(A)
# Substitute animal(1 + x | id, Ainv = Ainv) in the same model to use it.
conditional_draw <- simulate(fit, nsim = 1L, seed = 2026102706L, re.form = NULL)
# Here sigma ~ 1 estimates one precision scale shared across observations.
# Evidence covers native complete-data point fitting with no random effect on
# sigma. Interval coverage and Julia parity remain unassessed.
# Fresh marginal draws of both fields remain open. For pedigree input with
# unobserved ancestors, see beta-animal-pedigree-q2-sd.R.
