# Native Beta intercept and slope SDs with unobserved pedigree ancestors.
# Each independent field has covariance D_k A D_k. SD predictors describe
# observed offspring; raw ancestor modes remain available, scaled ancestor
# effects are NA because ancestor SD predictors were not supplied.
library(drmTMB)
# Independent pedigree covariance; no package pedigree builder in the DGP.
beta_pedigree_q2_sd_fixture <- function() {
  set.seed(2026102707L)
  nf <- 16L; no <- 4L; nr <- 20L
  sire <- sprintf("sire%02d", seq_len(nf)); dam <- sprintf("dam%02d", seq_len(nf))
  offspring <- sprintf("offspring%03d", seq_len(nf * no))
  pedigree <- data.frame(id = c(sire, dam, offspring),
    sire = c(rep(NA_character_, 2L * nf), rep(sire, each = no)),
    dam = c(rep(NA_character_, 2L * nf), rep(dam, each = no)))
  ids <- pedigree$id; n <- length(ids)
  A <- matrix(0, n, n, dimnames = list(ids, ids))
  for (i in seq_len(n)) {
    s <- match(pedigree$sire[i], ids); d <- match(pedigree$dam[i], ids)
    if (i > 1L) for (j in seq_len(i - 1L)) {
      A[i, j] <- A[j, i] <- ((if (is.na(s)) 0 else A[s, j]) +
                            (if (is.na(d)) 0 else A[d, j])) / 2
    }
    A[i, i] <- 1 + if (is.na(s) || is.na(d)) 0 else A[s, d] / 2
  }
  z0 <- setNames(rep(c(-1, 1), length.out = length(offspring)), offspring)
  z1 <- setNames(rep(c(-1, 1), each = length(offspring) / 2L), offspring)
  u0 <- setNames(drop(t(chol(A)) %*% rnorm(n)), ids)
  u1 <- setNames(drop(t(chol(A)) %*% rnorm(n)), ids)
  b0 <- exp(log(.5) + .5 * z0) * u0[offspring]
  b1 <- exp(log(.4) - .5 * z1) * u1[offspring]
  ii <- rep(seq_along(offspring), each = nr)
  x <- rep(seq(-1.2, 1.2, length.out = nr), length(offspring))
  mu <- 1e-12 + (1 - 2e-12) * plogis(.2 + .3*x + b0[ii] + x*b1[ii])
  phi <- .35^-2
  dat <- data.frame(y = rbeta(length(ii), mu*phi, (1-mu)*phi), x = x,
    id = factor(offspring[ii], levels = rev(ids)), z0 = unname(z0[ii]), z1 = unname(z1[ii]))
  stopifnot(all(dat$y > 0 & dat$y < 1), min(mu*phi,(1-mu)*phi) > 1e-8)
  list(data = dat, pedigree = pedigree, A_full = A,
    A = A[rev(offspring), rev(offspring)], z0 = z0, z1 = z1,
    ancestors = c(sire, dam), offspring = offspring)
}

beta_pedigree_q2_sd_form <- function(pedigree = NULL, A = NULL, Ainv = NULL) {
  mu <- if (!is.null(pedigree)) y ~ x + animal(1 + x | id, pedigree = pedigree) else
    if (!is.null(Ainv)) y ~ x + animal(1 + x | id, Ainv = Ainv) else
      y ~ x + animal(1 + x | id, A = A)
  environment(mu) <- environment()
  bf(mu, sigma ~ 1,
    sd(id, level = "animal", coef = "(Intercept)") ~ z0,
    sd(id, level = "animal", coef = "x") ~ z1)
}

fx <- beta_pedigree_q2_sd_fixture()
fit <- drmTMB(beta_pedigree_q2_sd_form(fx$pedigree), family = beta_family(),
  data = fx$data, control = drm_control(se = FALSE))
keys <- c('sd_animal(id, dpar = "mu", coef = "(Intercept)")',
          'sd_animal(id, dpar = "mu", coef = "x")')
print(fit$opt$convergence)
print(lapply(keys, function(key) coef(fit, key)))
print(head(predict(fit, dpar = keys[2L])))
# sigma ~ 1 estimates one shared Beta precision scale, phi = sigma^-2.
# This synthetic example checks point fitting; interval calibration, Julia
# parity, inbred pedigrees and single-known-parent pedigrees are unassessed.
# Fresh marginal draws for both SD fields remain unavailable.
