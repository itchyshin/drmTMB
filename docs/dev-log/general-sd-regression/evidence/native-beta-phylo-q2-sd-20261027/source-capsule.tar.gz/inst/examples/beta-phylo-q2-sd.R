# Synthetic Beta model: among-tip variation can depend on group predictors.
# Two independent fields have covariance D_k K D_k; K uses shared ancestry
# divided by tree height, preserving the established phylo correlation scale.
library(drmTMB)

# Independent shared-ancestry correlation, not a package tree covariance helper.
beta_phylo_q2_sd_fixture <- function() {
  set.seed(2026102711L)
  n <- 64L; nr <- 20L; ids <- sprintf("tip%03d",seq_len(n))
  newick <- function(index,root=FALSE) {
    if(length(index)==1L) return(paste0(ids[index],":1.5"))
    half <- length(index)/2L
    paste0("(",newick(index[seq_len(half)]),",",newick(index[half+seq_len(half)]),")",if(root) ";" else ":0.1")
  }
  tree <- ape::read.tree(text=newick(seq_len(n),TRUE))
  bits <- lapply(0:(n-1L),function(i) rev(as.integer(intToBits(i))[seq_len(6L)]))
  K <- matrix(0,n,n,dimnames=list(ids,ids))
  for(i in seq_len(n)) for(j in seq_len(n)) {
    mismatch <- which(bits[[i]] != bits[[j]])
    K[i,j] <- if(i==j) 1 else (mismatch[1L]-1L)*.1/2
  }
  z0 <- setNames(rep(c(-1,1),n/2L),ids)
  z1 <- setNames(rep(c(-1,1),each=n/2L),ids)
  b0 <- exp(log(.5)+.5*z0)*drop(t(chol(K))%*%rnorm(n))
  b1 <- exp(log(.4)-.5*z1)*drop(t(chol(K))%*%rnorm(n))
  ii <- rep(seq_len(n),each=nr);x <- rep(seq(-1.2,1.2,length.out=nr),n)
  mu <- 1e-12+(1-2e-12)*plogis(.2+.3*x+b0[ii]+x*b1[ii]);phi <- .35^-2
  data <- data.frame(y=rbeta(length(ii),mu*phi,(1-mu)*phi),x=x,
    id=factor(ids[ii],levels=rev(ids)),z0=unname(z0[ii]),z1=unname(z1[ii]))
  stopifnot(all(data$y>0 & data$y<1),min(mu*phi,(1-mu)*phi)>1e-8)
  list(data=data,tree=tree,K=K,z0=z0,z1=z1)
}

beta_phylo_q2_sd_form <- function(tree,constant=FALSE,reverse_sd=FALSE) {
  f0 <- as.formula(paste('sd(id, level="phylogenetic", coef="(Intercept)") ~',if(constant) "1" else "z0"),env=environment())
  f1 <- as.formula(paste('sd(id, level="phylogenetic", coef="x") ~',if(constant) "1" else "z1"),env=environment())
  mu <- y ~ x + phylo(1+x|id,tree=tree)
  if(reverse_sd) bf(mu,sigma~1,f1,f0) else bf(mu,sigma~1,f0,f1)
}

fx <- beta_phylo_q2_sd_fixture()
fit <- drmTMB(beta_phylo_q2_sd_form(fx$tree), family=beta_family(),
  data=fx$data, control=drm_control(se=FALSE))
keys <- c('sd_phylo(id, dpar = "mu", coef = "(Intercept)")',
          'sd_phylo(id, dpar = "mu", coef = "x")')
print(lapply(keys, function(key) coef(fit,key)))
print(head(predict(fit,dpar=keys[2])))
print(fit$opt$convergence)
# sigma ~ 1 estimates one shared precision scale, phi = sigma^-2.
# Evidence is one synthetic point-fit check; coverage and Julia parity are
# unassessed. Only one unlabelled intercept plus one independent slope is added.
# Fresh marginal draws of both fields remain unavailable; conditional draws
# use simulate(fit, re.form=NULL).
