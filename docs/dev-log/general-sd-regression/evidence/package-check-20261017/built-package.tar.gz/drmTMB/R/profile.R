#' Confidence intervals for fitted model parameters
#'
#' `confint()` returns confidence intervals for a fitted `drmTMB` model. Wald
#' intervals are fast and are returned for fixed-effect coefficients and direct
#' response-scale parameter targets by default. Direct Wald targets include
#' constant residual-scale, random-effect standard-deviation, random-effect
#' correlation, and constant residual-correlation rows when the fitted TMB
#' parameter and `TMB::sdreport()` covariance are available.
#' Correlation Wald intervals are computed on the fitted TMB correlation-link
#' scale, equivalent to a guarded Fisher z/atanh transform, and then returned on
#' the correlation scale.
#' Bootstrap intervals simulate and refit direct targets. For positive scale and
#' SD targets, percentile endpoints are taken on the fitted log scale before
#' back-transforming to the response scale.
#' Profile-likelihood intervals are slower because nuisance parameters are
#' re-optimized; this first public profile path supports explicit fixed-effect,
#' constant distributional-scale, random-effect standard-deviation,
#' random-effect correlation, bivariate phylogenetic q=2 mean-mean
#' correlation, block-diagonal bivariate phylogenetic `mu1`/`mu2` and
#' `sigma1`/`sigma2` correlations, and constant residual-correlation targets.
#' For predictor-dependent scale, residual-correlation, or currently supported
#' `corpair()` formulae, supply `newdata` with `parm = "sigma"`,
#' `parm = "rho12"`, or the fitted `corpair(...)` dpar to profile the fitted
#' response-scale value for each supplied row. Row-specific `rho12` profile
#' intervals from a regression `rho12` formula are computable this way, but no
#' simulation has measured their coverage; treat them as interval-feasible,
#' not as a calibrated `level` interval (tracked as issue #802).
#'
#' Modelled missing-predictor bootstrap is not yet implemented: it requires
#' joint predictor simulation and refits that preserve the imputation model and
#' missingness pattern. Such requests fail before simulation. Positive predictor
#' scales use log-scale Wald intervals transformed by exp(); predictor mixture
#' probabilities use logit-scale intervals transformed by plogis(). Public
#' covariance and summary standard errors remain on the reported natural scale.
#'
#' Target names follow the profile target namespace. For fixed effects, use
#' names such as `"fixef:mu:x"`, `"fixef:sigma:(Intercept)"`, or
#' `"fixef:rho12:w"`. Compact coefficient labels from `summary(fit)`, such as
#' `"mu:x"`, are also accepted. Random-effect SD intervals are reported on the
#' SD scale, and random-effect correlation intervals are reported on the
#' correlation scale. For bivariate Gaussian and exact bivariate lognormal fits
#' with constant residual correlation, `parm = "rho12"` profiles the residual
#' correlation and reports the interval on the response correlation scale. For
#' fits with constant
#' `sigma`, `sigma1`, or `sigma2`, `parm = "sigma"` and friends report
#' response-scale intervals.
#'
#' The fastest routine route is `confint(fit)`, which uses Wald intervals for
#' fixed effects and direct response-scale targets. For long phylogenetic,
#' spatial, animal-model, or relatedness fits, profile only the needed
#' variance-component or correlation rows with the default
#' `profile_engine = "auto"` first; direct scalar scale, SD, and correlation
#' targets use the endpoint engine when no full-profile controls are supplied.
#' Use `profile_engine = "tmbprofile"` or `profile_precision = "fast"` when you
#' want the previous full-curve `TMB::tmbprofile()` route for comparison,
#' diagnostics, or control tuning.
#'
#' @param object A `drmTMB` fit.
#' @param parm Optional character or integer vector selecting interval targets.
#'   `NULL` selects all direct Wald-ready targets for Wald intervals. Profile
#'   intervals require explicit target names or target-set shortcuts. Supported
#'   shortcuts are `"fixed_effects"`, `"random_effects"`,
#'   `"variance_components"`, and `"correlations"`.
#' @param level Confidence level.
#' @param method Interval method: `"wald"`, `"profile"`, or `"bootstrap"`. If
#'   `newdata` is supplied and `method` is omitted, `method = "profile"` is
#'   used.
#' @param newdata Optional data frame for response-scale profile intervals for
#'   predictor-dependent `sigma`, `sigma1`, `sigma2`, `rho12`, or fitted
#'   `corpair()` values. Each row is profiled separately by profiling its
#'   fixed-effect linear predictor and then transforming the interval to the
#'   response scale.
#' @param trace Logical; passed to [TMB::tmbprofile()] when the `tmbprofile`
#'   profile engine is used.
#' @param profile_precision Profile-control shortcut. `"default"` leaves
#'   [TMB::tmbprofile()] controls unchanged. `"fast"` supplies
#'   `ystep = 0.5` and `ytol = 2` unless the caller supplies those controls in
#'   `...`, giving a quicker first-pass profile for long variance-component or
#'   correlation targets.
#' @param profile_maxit Optional positive whole number passed to
#'   [TMB::tmbprofile()] as `maxit` when `method = "profile"`. Use this as a
#'   per-target adaptive-step budget for long or exploratory profile runs.
#' @param profile_engine Profile engine for direct fitted-object targets.
#'   `"auto"` uses a scalar endpoint solver for direct scale, SD, and
#'   correlation targets when no [TMB::tmbprofile()] controls are supplied, and
#'   otherwise uses [TMB::tmbprofile()]. `"endpoint"` requires the scalar
#'   endpoint solver, while `"tmbprofile"` preserves the previous full-profile
#'   route for comparison and debugging.
#' @param profile_endpoint_max_eval Optional positive whole number limiting
#'   constrained endpoint evaluations per endpoint side when the scalar
#'   endpoint engine is used. This is a diagnostic escape hatch for long
#'   variance-component or correlation profiles; when the budget is reached the
#'   row is returned with `conf.status = "profile_failed"` and missing
#'   endpoints.
#' @param R Number of parametric-bootstrap refits when
#'   `method = "bootstrap"`.
#' @param seed Optional seed for bootstrap simulation.
#' @param parallel Profile or bootstrap backend: `"none"`, Unix
#'   `"multicore"`, or socket `"cluster"` (PSOCK, any platform including
#'   Windows). For profile intervals, targets or `newdata` rows are split
#'   across workers. For bootstrap intervals, refits are split across workers.
#'   Every backend returns the serial result; see [drmTMB-parallel].
#' @param workers Requested profile or bootstrap workers. If `NULL` and
#'   `parallel` is not `"none"`, `drmTMB` uses about half the detected CPU
#'   cores. Parallel execution is capped at the number of jobs and at 10
#'   workers.
#'   Keep BLAS and OpenMP threads at one while workers run; see
#'   [drmTMB-parallel].
#' @param refit_control Optional [drm_control()] object used for bootstrap
#'   refits. The default skips `TMB::sdreport()` and drops the TMB object because
#'   bootstrap intervals use refit point estimates.
#' @param sd_boundary,rho_boundary Boundary thresholds used by
#'   `method = "wald"` to flag intervals where the symmetric Wald interval is
#'   unreliable: a variance-component standard deviation within `sd_boundary` of
#'   zero, or a correlation within `rho_boundary` of `+/-1`, is returned with
#'   `conf.status = "wald_at_boundary"` and a warning pointing to
#'   `method = "profile"`. Defaults match [check_drm()] (`1e-4`, `0.98`).
#' @param small_sample_df Small-sample reference distribution for the
#'   `method = "wald"` interval. `"location"` (the default) references a
#'   t-quantile with `df = g - 1` -- a group-based, Satterthwaite-style
#'   between-group degrees of freedom -- for each *location-axis* (`mu`,
#'   `mu1`, `mu2`) structured random-effect SD target (`phylo`, `spatial`,
#'   `animal`, `relmat`) with a resolvable group count `g`, and keeps the
#'   ordinary normal quantile `z = qnorm((1 + level) / 2)` for every other
#'   target. This widens only the location-axis structured-RE SD intervals,
#'   which under-cover at small `g` under the normal quantile; the t-quantile
#'   lifts their coverage and converges back to `z` as `g` grows. Dispersion
#'   (`sigma`, `sigma1`, `sigma2`) structured SD targets are deliberately left
#'   at the normal quantile because they already over-cover; non-structured and
#'   fixed-effect targets are never widened; and a plain labelled covariance
#'   block such as `(1 + x | p | id)` is also left at the normal quantile by
#'   default, because the correction magnitude was calibrated for structured
#'   blocks only. `"none"` is the opt-out: it uses the normal quantile for
#'   *every* target and is byte-identical to the pre-default behaviour.
#'   `"group"` widens *every* resolvable SD target -- structured and
#'   labelled-covariance, location and dispersion axis alike; use it only when
#'   you deliberately want to t-reference the dispersion axis or a labelled
#'   covariance block too. Note
#'   that the t-quantile only widens the interval; it does not move its centre.
#'   The residual small-`g` gap is ML shrinkage bias in the variance-component
#'   point estimate (a job for REML), not a quantile problem, so the centre
#'   shift is handled by `bias_correct`.
#' @param bias_correct Small-sample point-estimate bias correction for the
#'   `method = "wald"` interval. `"location"` (the default) adds a
#'   simulation-calibrated shift `log(g / (g - 1))` to the log-scale point
#'   estimate -- before back-transforming -- of each *location-axis* (`mu`,
#'   `mu1`, `mu2`) structured random-effect SD target with a resolvable group
#'   count `g` (the same targets `small_sample_df = "location"` widens), and
#'   leaves every other target unshifted. The ML estimate of a structured-RE
#'   variance-component SD is biased low on the log scale by about
#'   `log(g / (g - 1))` -- a downward shrinkage that REML, or simply a larger
#'   `g`, removes asymptotically; this shift moves the interval centre up to
#'   counter that shrinkage. Used together with `small_sample_df = "location"`,
#'   the centre shift and the t(`df = g - 1`) width act independently, giving
#'   `exp((log(sigma_hat) + log(g / (g - 1))) +/- qt(p, g - 1) * se_log)` and
#'   lifting small-`g` coverage of location-axis structured-RE SD targets to
#'   nominal. `"none"` is the opt-out: it leaves every centre at the ML estimate
#'   and is byte-identical to the pre-default behaviour. `"group"` shifts
#'   *every* resolvable SD target -- structured and labelled-covariance, location
#'   and dispersion axis alike. The default deliberately excludes the dispersion
#'   axis (`sigma` SD intervals already over-cover, so the upward shift would
#'   push them further conservative) and plain labelled covariance blocks (whose
#'   correction magnitude is not yet simulation-calibrated).
#' @param bootstrap_re_form `re.form` passed through to [stats::simulate()]
#'   when `method = "bootstrap"`, with the same lme4 meanings as
#'   [simulate.drmTMB()]. The default, `NA`, redraws random effects for every
#'   replicate (marginal simulation), matching what a parametric bootstrap of
#'   the fitted data-generating process requires. Passing `NULL` instead holds
#'   random effects fixed at their conditional-mode estimate; this is a
#'   documented escape hatch for random-effect structures whose marginal draw
#'   is not yet implemented, and it makes the resulting intervals
#'   **anticonservative** because between-group variability is never
#'   resampled -- it is not a neutral alternative to the default. Earlier
#'   drmTMB versions gave `NULL` and `NA` the reverse meaning (#1487).
#' @param ... Additional arguments passed to [TMB::tmbprofile()] when
#'   `method = "profile"` and the `tmbprofile` profile engine is used.
#'   `drmTMB` supplies the profiled `obj`, `name`, `lincomb`, and `trace`
#'   arguments internally; set the profile target with `parm`.
#'
#' @return A data frame with columns `parm`, `level`, `lower`, `upper`,
#'   `scale`, `transformation`, `tmb_parameter`, `index`, `method`, and
#'   `profile.engine`, `conf.status`, `profile.boundary`, and
#'   `profile.message`. The returned `parm` values use the fully-qualified
#'   target names used by `profile_targets()`, such as `fixef:sigma:z`, even
#'   when the input `parm` used a compact label such as `sigma:z`. Normalize
#'   names before joining the result back to user-supplied compact labels.
#'   Successful rows currently use
#'   `conf.status = "wald"`, `"profile"`, or `"bootstrap"`. Failed numeric
#'   profile rows use `"profile_failed"` with missing endpoints; profile rows
#'   mark intervals that land near a lower SD boundary or correlation boundary.
#'   Bootstrap interval results carry a `"bootstrap.diagnostics"` attribute
#'   with one diagnostic row per refit and target, including refit convergence,
#'   target availability, draw use, and the refit message.
#'   For a plain matrix view of the `lower` and `upper` columns, use
#'   [as.matrix.drm_confint()].
#'
#' @section Default uncertainty story:
#' Use this recipe for ordinary first-week inference; it restates measured
#' behaviour and does **not** claim nominal coverage on every route.
#' \itemize{
#'   \item Fixed effects and other routine Wald-ready targets: start with
#'     \code{confint(fit)} (\code{method = "wald"}). It is the fastest
#'     fitted-object route when \code{TMB::sdreport()} succeeded.
#'   \item Random-effect SDs and other direct variance-component targets: prefer
#'     \code{confint(fit, parm = ..., method = "profile")} after
#'     \code{profile_targets(fit)} shows the row is profile-ready. Profile
#'     re-optimizes nuisance parameters and is slower than Wald.
#'   \item Always read \code{conf.status} and \code{profile.boundary} on the
#'     returned table. A usable profile interval that lands on a variance-component
#'     boundary warns with class \code{drmTMB_profile_boundary_warning}; treat
#'     that interval as indicative of scale, not as a calibrated
#'     \code{level} interval (see Boundary intervals below).
#'   \item A computable interval is not coverage certification. Check the
#'     exact cell in
#'     \href{https://itchyshin.github.io/drmTMB/articles/capability-and-limits.html}{Capabilities and limits}
#'     before reporting a route as inference-ready.
#' }
#'
#' For a short applied walkthrough, see the vignette
#' \emph{First-week intervals: fit, profile, and boundary}.
#'
#' @section Boundary intervals:
#' Every interval method is unreliable when a variance component approaches zero
#' or a correlation approaches `+/-1`, and each warns about its own case.
#'
#' `method = "wald"` flags a row with `conf.status = "wald_at_boundary"` and warns
#' (class `drmTMB_wald_boundary_warning`), because a symmetric Wald interval
#' undercovers under boundary (chi-square-mixture) inference. That warning
#' recommends `method = "profile"`.
#'
#' `method = "profile"` sets `profile.boundary = TRUE` and warns (class
#' `drmTMB_profile_boundary_warning`) when it returns a usable interval that
#' reaches a boundary. **A profile interval is not a repair for a boundary.**
#' Conditional on that flag, a seeded 10-group random-effect SD gate measured
#' coverage at 0.1021, 0.2387, and 0.8683 against a nominal 0.95, and 0 of 89 in a
#' fourth cell where boundary hits are rare (0.09% of fits). The mechanism is a
#' maximum likelihood random-effect SD biased 8.3%-15.8% low at small group counts,
#' which anchors the interval low so that it misses from above.
#'
#' Unconditionally -- across all fits, flagged or not -- the same gate measured
#' 0.9248 against a nominal 0.95 over 400,000 attempts. A flagged interval is the
#' bad case, not the typical one, and the flag is returned in the table so you can
#' tell which case you are in.
#'
#' Refitting the same design with `REML = TRUE` improved this without repairing
#' it: over 400,000 paired replicates, profile coverage moved from 0.9248 to
#' 0.9463 against a nominal 0.95, the SD point estimate's downward bias roughly
#' halved (pooled -10.9% under maximum likelihood to -4.6% under REML), and the
#' upper-to-lower miss asymmetry fell from 5.7:1 to 2.0:1. Coverage conditional
#' on the boundary flag improved but stayed well below nominal (0.74 to 0.83),
#' so a flagged interval remains the bad case under either estimator. The
#' default estimator is unchanged; this measurement covers the one design below
#' only.
#'
#' This is a property of profile intervals near a variance boundary rather than of
#' `drmTMB`: `lme4::lmer` on the same data-generating process and seeds agreed on
#' boundary incidence for 4000/4000 replicates and matched the conditional coverage
#' to four decimal places. Treat a flagged interval as indicative of scale, not as a
#' calibrated `level` interval, and prefer more groups where the design allows it.
#'
#' These figures come from one measured design: Gaussian, a single random intercept
#' on the mean, 10 groups, 4 or 10 observations per group, maximum likelihood. They
#' describe that corner, and are not a general statement about every family,
#' provider, or group count.
#'
#' `method = "bootstrap"` flags a row with `conf.status = "bootstrap_at_boundary"`
#' and warns (class `drmTMB_bootstrap_boundary_warning`) when at least 5% of the
#' retained resamples land on the target's bound. Resampling does not repair a
#' boundary: a percentile interval whose draws pile up at zero is reporting the
#' constraint rather than the sampling distribution. Measured on three Gaussian
#' random-intercept fits at `R = 200`, a true SD of 0 put 43% of draws on the
#' bound and a true SD of 0.25 put 5% there with a lower endpoint of exactly
#' zero, while a true SD of 0.9 put none there. The flag needs at least 20
#' retained draws to fire, because a share computed from a handful of resamples
#' is noise; `bootstrap.n` reports how many were retained.
#'
#' Rows with `conf.status = "profile_failed"` or `"clamp_limited"` also carry
#' `profile.boundary = TRUE`, but return missing endpoints and are not warned about
#' separately; read their `conf.status` and `profile.message` instead.
#'
#' `check_drm()` does **not** assess any of this. It reads the fit, so a target
#' whose point estimate sits well clear of zero passes every fit-level check
#' while its interval is still flagged here. `check_drm()` emits an
#' `interval_reliability_scope` note saying so; read `conf.status` before
#' reporting an interval.
#'
#' @section Profiling a structured `sigma` random-effect SD:
#' A profile of a `sigma`-axis random-effect SD under `phylo()`, `animal()`,
#' `relmat()`, `spatial()`, or `phylo_interaction()` is computable for
#' `zero_one_beta()`, `nbinom2()`, and `zi_nbinom2()`, but the maximum
#' likelihood point estimate it is built around is **biased low** for this
#' class of cell: eleven of twelve retained ML estimates fell below truth in
#' the sibling `nbinom2` provider cells (fit-level one-sided sign test
#' `p = 0.0032`; `p = 0.0625` at cell level, once the shared data-generating
#' process and random-number stream are respected). Two corrections that exist
#' elsewhere for this bias do not reach these routes: `bias_correct` shifts
#' only the `method = "wald"` centre and never a profile endpoint, and native
#' scale-side REML is unavailable here because `drm_validate_reml_spec()`
#' admits only Gaussian and binomial models. The profile interval therefore
#' inherits the bias of its centre uncorrected. These routes carry point-fit
#' recovery evidence only, and no seeded campaign has yet measured the
#' coverage of a profile interval built on them, so treat the endpoints as a
#' computed profile rather than calibrated inference.
#'
#' @section Ordinal cutpoints:
#' For a `cumulative_logit()` fit, the public ordinal targets are the ordered
#' latent-logistic cutpoints `"ordinal:cutpoint:<label>"`, not the internal
#' `"ordinal:theta_ord:<label>"` coordinates. Use
#' `confint(fit, parm = "ordinal:cutpoint:<label>", method = "profile")` to
#' obtain a pointwise likelihood-ratio interval on the cutpoint scale. The
#' constrained engine fixes the cumulative cutpoint while preserving strict
#' ordering of every threshold; it does not change the fitted likelihood.
#' These are not simultaneous bands or category-probability intervals, and
#' they are not yet calibrated coverage claims. Raw `theta_ord` entries remain
#' visible in [profile_targets()] only as internal diagnostics and reject
#' interval methods. The fixed-effect coefficients on `mu` (and on any other
#' fitted distributional parameter) remain available through the usual
#' `confint(fit, parm = "fixed_effects")` or `confint(fit, parm = "fixef:mu:x")`
#' calls.
#'
#' @examples
#' dat <- data.frame(y = c(0.2, 0.5, 1.1, 1.4), x = c(-1, 0, 1, 2))
#' fit <- drmTMB(bf(y ~ x, sigma ~ 1), data = dat)
#' confint(fit)
#' confint(fit, parm = "variance_components")
#' confint(fit, parm = "sigma", method = "profile")
#' # Use the full-profile engine when you need the older tmbprofile route:
#' # confint(fit, parm = "sigma", method = "profile",
#' #   profile_engine = "tmbprofile", profile_precision = "fast")
#' # Direct-target parametric bootstrap is available when refit cost is worth it:
#' # confint(fit, parm = "sigma", method = "bootstrap", R = 99)
#' # Bootstrap intervals for positive scale and SD targets use link-scale
#' # percentiles before back-transforming to the response scale.
#' @references
#' The small-sample corrections applied by `small_sample_df` and `bias_correct`
#' (whether the default `"location"` scope or the broader `"group"` scope) are
#' *motivated* by established mixed-model theory but are simulation-calibrated,
#' not derived: the `log(g / (g - 1))` SD-scale centre
#' shift is about **twice** the leading-order REML SD correction
#' (`0.5 * log(g / (g - 1))`), matching the larger ML shrinkage measured on these
#' structured/bivariate cells (their effective df is well below `g - 1`). The
#' magnitude's authority is the per-model-class simulation in
#' `docs/design/219-structured-re-small-sample-bias-correction.md`, not a single
#' source. Relevant references:
#'
#' Restricted maximum likelihood and the variance-component bias that motivates
#' the centre shift (REML debiases the variance by `g/(g-1)`; the shift here is on
#' the SD log scale and ~2x the leading-order REML SD term):
#'
#' Patterson, H. D., & Thompson, R. (1971). Recovery of inter-block information
#' when block sizes are unequal. Biometrika, 58(3), 545-554.
#' \doi{10.1093/biomet/58.3.545}
#'
#' Harville, D. A. (1977). Maximum likelihood approaches to variance component
#' estimation and to related problems. Journal of the American Statistical
#' Association, 72(358), 320-338. \doi{10.1080/01621459.1977.10480998}
#'
#' Searle, S. R., Casella, G., & McCulloch, C. E. (1992). Variance Components.
#' New York: Wiley. \doi{10.1002/9780470316856}
#'
#' Analytic and penalized first-order bias reduction of maximum likelihood
#' estimates (the general framework an additive log-scale shift instantiates):
#'
#' Cox, D. R., & Snell, E. J. (1968). A general definition of residuals. Journal
#' of the Royal Statistical Society, Series B, 30(2), 248-265.
#' \doi{10.1111/j.2517-6161.1968.tb00724.x}
#'
#' Firth, D. (1993). Bias reduction of maximum likelihood estimates. Biometrika,
#' 80(1), 27-38. \doi{10.1093/biomet/80.1.27}
#'
#' The t-quantile / between-group effective degrees of freedom used by
#' `small_sample_df`:
#'
#' Satterthwaite, F. E. (1946). An approximate distribution of estimates of
#' variance components. Biometrics Bulletin, 2(6), 110-114.
#' \doi{10.2307/3002019}
#'
#' Kenward, M. G., & Roger, J. H. (1997). Small sample inference for fixed
#' effects from restricted maximum likelihood. Biometrics, 53(3), 983-997.
#' \doi{10.2307/2533558}
#'
#' Boundary regime (a variance component at or near zero), where neither the
#' t-width nor the centre shift restores nominal coverage:
#'
#' Self, S. G., & Liang, K.-Y. (1987). Asymptotic properties of maximum
#' likelihood estimators and likelihood ratio tests under nonstandard
#' conditions. Journal of the American Statistical Association, 82(398),
#' 605-610. \doi{10.1080/01621459.1987.10478472}
#'
#' Stram, D. O., & Lee, J. W. (1994). Variance components testing in the
#' longitudinal mixed effects model. Biometrics, 50(4), 1171-1177.
#' \doi{10.2307/2533455}
#'
#' Parametric-bootstrap bias correction of mixed-model variance components, and
#' the general delicacy of bootstrap bias estimation (a single-level parametric
#' bootstrap does not recover the centre bias for these targets at small `g`):
#'
#' Kubokawa, T., & Nagashima, B. (2012). Parametric bootstrap methods for bias
#' correction in linear mixed models. Journal of Multivariate Analysis, 106,
#' 1-16. \doi{10.1016/j.jmva.2012.01.011}
#'
#' Efron, B., & Tibshirani, R. J. (1993). An Introduction to the Bootstrap. New
#' York: Chapman & Hall.
#'
#' Small-sample variance-component (repeatability) interval coverage in ecology
#' and evolution:
#'
#' Wolak, M. E., Fairbairn, D. J., & Paulsen, Y. R. (2012). Guidelines for
#' estimating repeatability. Methods in Ecology and Evolution, 3(1), 129-137.
#' \doi{10.1111/j.2041-210X.2011.00125.x}
#' @seealso The tier definitions and per-cell evidence behind these interval
#'   targets, including random-effect standard-deviation rows, are curated in
#'   \code{vignette("capability-and-limits", package = "drmTMB")}: `confint()`
#'   computes generically for any target, and the tier a given cell belongs to
#'   is a documentation-level curation, not a runtime guard.
#' @export
confint.drmTMB <- function(
  object,
  parm = NULL,
  level = 0.95,
  method = c("wald", "profile", "bootstrap"),
  newdata = NULL,
  trace = FALSE,
  profile_precision = c("default", "fast"),
  profile_maxit = NULL,
  profile_engine = c("auto", "endpoint", "tmbprofile"),
  profile_endpoint_max_eval = NULL,
  R = 199L,
  seed = NULL,
  parallel = c("none", "multicore", "cluster"),
  workers = NULL,
  refit_control = NULL,
  sd_boundary = 1e-4,
  rho_boundary = 0.98,
  small_sample_df = c("location", "none", "group"),
  bias_correct = c("location", "none", "group"),
  bootstrap_re_form = NA,
  ...
) {
  drm_abort_mspl_inference(object, "confint")
  if (identical(object$model$model_type, "biv_student")) {
    cli::cli_abort(
      "{.fn confint} is not implemented for model type {.val {object$model$model_type}}; interval and profile claims are deferred."
    )
  }
  profile_precision_missing <- missing(profile_precision)
  parallel_missing <- missing(parallel)
  method_missing <- missing(method)
  profile_engine <- match.arg(profile_engine)
  small_sample_df <- match.arg(small_sample_df)
  bias_correct <- match.arg(bias_correct)
  method <- validate_interval_method(
    method,
    c("wald", "profile", "bootstrap"),
    "confint()"
  )
  if (!is.null(newdata) && method_missing) {
    method <- "profile"
  }
  validate_profile_level(level)
  profile_precision <- resolve_profile_precision(
    profile_precision,
    missing_arg = profile_precision_missing
  )
  profile_maxit <- validate_profile_maxit(profile_maxit)
  profile_endpoint_max_eval <- validate_profile_endpoint_max_eval(
    profile_endpoint_max_eval
  )
  parallel <- resolve_bootstrap_parallel(
    parallel,
    missing_arg = parallel_missing
  )
  profile_dots <- list(...)

  if (identical(method, "wald")) {
    if (!is.null(newdata)) {
      cli::cli_abort(
        "{.arg newdata} is only used when {.code method = \"profile\"}."
      )
    }
    if (length(profile_dots) > 0L) {
      cli::cli_abort(
        "Additional arguments in {.arg ...} are only used when {.code method = \"profile\"}."
      )
    }
    if (!is.null(profile_endpoint_max_eval)) {
      cli::cli_abort(
        "{.arg profile_endpoint_max_eval} is only used when {.code method = \"profile\"}."
      )
    }
    return(drm_wald_confint(
      object,
      parm = parm,
      level = level,
      sd_boundary = sd_boundary,
      rho_boundary = rho_boundary,
      small_sample_df = small_sample_df,
      bias_correct = bias_correct
    ))
  }

  if (identical(method, "bootstrap")) {
    bootstrap_parallel <- parallel
    if (!is.null(newdata)) {
      cli::cli_abort(
        "{.arg newdata} is not used when {.code method = \"bootstrap\"}."
      )
    }
    if (length(profile_dots) > 0L) {
      cli::cli_abort(
        "Additional arguments in {.arg ...} are only used when {.code method = \"profile\"}."
      )
    }
    if (!is.null(profile_endpoint_max_eval)) {
      cli::cli_abort(
        "{.arg profile_endpoint_max_eval} is only used when {.code method = \"profile\"}."
      )
    }
    all_targets <- drm_profile_targets(object)
    targets <- profile_match_bootstrap_targets(all_targets, parm)
    return(drm_bootstrap_confint(
      object,
      targets = targets,
      level = level,
      R = R,
      seed = seed,
      parallel = bootstrap_parallel,
      workers = workers,
      refit_control = refit_control,
      re_form = bootstrap_re_form,
      sd_boundary = sd_boundary,
      rho_boundary = rho_boundary
    ))
  }

  if (!is.null(newdata)) {
    if (!is.null(profile_endpoint_max_eval)) {
      cli::cli_abort(c(
        "{.arg profile_endpoint_max_eval} is only available for direct fitted-object scalar targets.",
        i = "Use explicit fitted-object target names such as {.val sigma} or {.val sd:mu:(1 | id)}."
      ))
    }
    if (identical(profile_engine, "endpoint")) {
      cli::cli_abort(c(
        "{.code profile_engine = \"endpoint\"} is only available for direct fitted-object scalar targets.",
        i = "Use {.code profile_engine = \"tmbprofile\"} or {.code profile_engine = \"auto\"} for row-specific {.arg newdata} profiles."
      ))
    }
    profile_args <- profile_precision_args(
      profile_precision,
      profile_dots,
      profile_maxit = profile_maxit
    )
    return(do.call(
      drm_profile_response_newdata_confint,
      c(
        list(
          object = object,
          parm = parm,
          newdata = newdata,
          level = level,
          trace = trace,
          parallel = parallel,
          workers = workers
        ),
        profile_args
      )
    ))
  }

  if (is.null(parm)) {
    cli::cli_abort(c(
      "Profile confidence intervals currently require explicit target names.",
      i = "Use names such as {.val fixef:mu:x} or compact labels such as {.val mu:x}."
    ))
  }

  targets <- profile_match_confint_targets(
    drm_profile_targets(object),
    parm,
    fixed_only = FALSE
  )
  tmbprofile_controls <- profile_tmbprofile_controls_requested(
    profile_precision_missing = profile_precision_missing,
    profile_maxit = profile_maxit,
    dots = profile_dots
  )
  ordinal_cutpoints <- targets$target_class == "ordinal-cutpoint"
  if (
    identical(profile_engine, "auto") &&
      tmbprofile_controls &&
      any(ordinal_cutpoints)
  ) {
    cli::cli_abort(c(
      "Ordered cutpoint intervals use drmTMB's constrained profile engine, which does not accept {.fun TMB::tmbprofile} controls.",
      i = "Remove {.arg profile_precision}, {.arg profile_maxit}, and {.arg ...} when profiling {.val {targets$parm[ordinal_cutpoints]}}.",
      i = "Profile ordinary direct targets with TMB controls in a separate {.fn confint} call."
    ))
  }
  if (identical(profile_engine, "endpoint") && tmbprofile_controls) {
    cli::cli_abort(c(
      "{.code profile_engine = \"endpoint\"} does not use {.fun TMB::tmbprofile} controls.",
      i = "Remove {.arg profile_precision}, {.arg profile_maxit}, and {.arg ...}, or use {.code profile_engine = \"tmbprofile\"}."
    ))
  }
  if (identical(profile_engine, "auto") && tmbprofile_controls) {
    profile_engine <- "tmbprofile"
  }
  if (!is.null(profile_endpoint_max_eval)) {
    if (identical(profile_engine, "tmbprofile")) {
      cli::cli_abort(c(
        "{.arg profile_endpoint_max_eval} is only used by the scalar endpoint profile engine.",
        i = "Use {.code profile_engine = \"auto\"} or {.code profile_engine = \"endpoint\"} without {.fun TMB::tmbprofile} controls."
      ))
    }
    supported <- profile_endpoint_targets_supported(targets)
    if (!all(supported)) {
      unsupported <- paste(targets$parm[!supported], collapse = ", ")
      cli::cli_abort(c(
        "{.arg profile_endpoint_max_eval} can only be used with direct scalar scale, SD, and correlation profile targets.",
        x = "Unsupported target(s): {unsupported}."
      ))
    }
  }
  profile_args <- profile_precision_args(
    profile_precision,
    profile_dots,
    profile_maxit = profile_maxit
  )
  do.call(
    drm_profile_confint,
    c(
      list(
        object = object,
        parm = targets$parm,
        level = level,
        trace = trace,
        parallel = parallel,
        workers = workers,
        profile_engine = profile_engine,
        profile_endpoint_max_eval = profile_endpoint_max_eval
      ),
      profile_args
    )
  )
}

#' List confidence-interval targets for a fitted model
#'
#' `profile_targets()` shows the names that can be supplied to
#' [confint.drmTMB()]. The table also records whether each row is currently
#' ready for direct profile-likelihood intervals. This helps users inspect the
#' fitted object before starting an expensive profile. Full q4 unstructured
#' and phylogenetic correlation summaries are derived targets; direct SD and
#' scale targets can still fail on a weak, boundary-limited, or one-sided
#' profile.
#'
#' Use `ready_only = TRUE` for the fastest inspection path before calling
#' `confint(..., method = "profile")`. Use the `target_class` column to filter
#' fixed effects, random-effect SDs, residual correlations, and other
#' variance-component rows before a long profile run.
#'
#' @param object A `drmTMB` fit.
#' @param ready_only Logical; if `TRUE`, return only targets whose
#'   `profile_ready` column is `TRUE`.
#'
#' @return A data frame with columns `parm`, `target_class`, `dpar`, `term`,
#'   `tmb_parameter`, `index`, `estimate`, `link_estimate`, `scale`,
#'   `transformation`, `target_type`, `profile_ready`, and `profile_note`.
#'   `target_type` is `"direct"` for a target that maps to a single fitted TMB
#'   parameter, `"derived"` for a transformed or multi-parameter quantity, or
#'   `"constrained"` for a target that needs a model-specific constrained
#'   profile. `profile_ready = TRUE` means the target is direct or constrained
#'   and the fitted object retained the TMB object needed for
#'   [confint.drmTMB()] with `method = "profile"`. Common `profile_note`
#'   values are `"ready"`, `"tmb_object_required"`, `"missing_tmb_parameter"`,
#'   `"point_fit_only_zi_nbinom2_sigma_q1"`,
#'   `"point_fit_only_zero_one_beta_phylo_q1"`,
#'   `"point_fit_only_zero_one_beta_phylo_zoi_q1"`,
#'   `"point_fit_only_zero_one_beta_phylo_coi_q1"`,
#'   `"point_fit_only_zero_one_beta_animal_q1"`,
#'   `"point_fit_only_zero_one_beta_animal_zoi_q1"`,
#'   `"point_fit_only_zero_one_beta_animal_coi_q1"`,
#'   `"point_fit_only_zero_one_beta_relmat_q1"`,
#'   `"point_fit_only_zero_one_beta_relmat_zoi_q1"`,
#'   `"point_fit_only_zero_one_beta_relmat_coi_q1"`,
#'   `"point_fit_only_zero_one_beta_spatial_q1"`,
#'   `"point_fit_only_zero_one_beta_phylo_interaction_q1"`,
#'   `"point_fit_only_zero_one_beta_phylo_interaction_zoi_q1"`,
#'   `"point_fit_only_zero_one_beta_phylo_interaction_coi_q1"`,
#'   `"point_fit_only_zero_one_beta_zoi_q1"`,
#'   `"point_fit_only_zero_one_beta_coi_q1"`,
#'   `"derived_target"`, and
#'   `"derived_unstructured_correlation"`. A `point_fit_only_*` note records a
#'   direct point-estimate target that is deliberately unavailable to
#'   profiling: the zi-nbinom2 note covers the ordinary q1 scale route, and the
#'   zero-one-beta notes cover that bounded family's structured q1 mean route
#'   and its zero- and one-inflation routes.
#'   Derived variance-ratio summaries such as `total_variance_share` and
#'   `phylo_total_variance_share` are listed as point-estimate targets with
#'   `profile_ready = FALSE`.
#'
#' @examples
#' dat <- data.frame(y = c(0.2, 0.5, 1.1, 1.4), x = c(-1, 0, 1, 2))
#' fit <- drmTMB(bf(y ~ x, sigma ~ 1), data = dat)
#' profile_targets(fit)
#' profile_targets(fit, ready_only = TRUE)
#' @export
profile_targets <- function(object, ready_only = FALSE) {
  if (!inherits(object, "drmTMB") && !inherits(object, "drmTMB_julia")) {
    cli::cli_abort("{.arg object} must be a {.cls drmTMB} fit.")
  }
  if (
    !is.logical(ready_only) ||
      length(ready_only) != 1L ||
      is.na(ready_only)
  ) {
    cli::cli_abort(
      "{.arg ready_only} must be a single {.code TRUE} or {.code FALSE}."
    )
  }
  if (identical(object$model$model_type, "biv_student")) {
    return(empty_profile_targets())
  }

  targets <- drm_profile_targets(object)
  if (ready_only) {
    targets <- targets[targets$profile_ready, , drop = FALSE]
  }
  row.names(targets) <- NULL
  targets
}

#' Compute profile-likelihood curves for fitted model targets
#'
#' `profile()` computes and returns the full likelihood-profile curve for one
#' or more direct [profile_targets()]. It is a diagnostic companion to
#' [confint.drmTMB()]. Use [confint.drmTMB()] for interval tables, especially
#' with the fast endpoint engine; use `profile()` followed by `plot()` when you
#' need to see whether a target has a peaked, flat, one-sided, or boundary-like
#' likelihood shape.
#'
#' The returned x-axis values are transformed to the same scale shown by
#' [profile_targets()]. For example, SD and scale targets are shown on their
#' public positive scale, and correlation targets are shown on the correlation
#' scale. The y-axis diagnostic is likelihood-ratio distance,
#' `2 * (profile_nll - min(profile_nll))`, so a flatter curve indicates weaker
#' likelihood support around the fitted value.
#'
#' @param fitted A `drmTMB` fit.
#' @param parm Character or integer vector selecting direct profile targets.
#'   Use [profile_targets()] to inspect available names. Unlike
#'   [confint.drmTMB()], this helper always uses the full
#'   [TMB::tmbprofile()] curve because the curve itself is the diagnostic.
#' @param level Confidence level used for the likelihood-ratio cutoff and
#'   interval endpoint annotations.
#' @param trace Logical; passed to [TMB::tmbprofile()].
#' @param profile_precision Profile-control shortcut. `"default"` leaves
#'   [TMB::tmbprofile()] controls unchanged. `"fast"` supplies
#'   `ystep = 0.5` and `ytol = 2` unless the caller supplies those controls in
#'   `...`.
#' @param profile_maxit Optional positive whole number passed to
#'   [TMB::tmbprofile()] as `maxit`.
#' @param compare Logical; if `TRUE`, run a coarse first-pass profile and then
#'   the requested profile controls so the returned object can compare curve
#'   shape and elapsed time.
#' @param first_pass_ystep,first_pass_ytol Coarse [TMB::tmbprofile()] controls
#'   used only when `compare = TRUE`. The dense pass uses `profile_precision`,
#'   `profile_maxit`, and `...`.
#' @param parallel Parallel backend for profiling several targets. `"none"`
#'   (the default) profiles targets one after another. `"multicore"` profiles
#'   independent targets in forked worker processes with
#'   [parallel::mclapply()] on Unix-alikes; `"cluster"` uses socket (PSOCK)
#'   workers on any platform. The returned curves are identical to the serial
#'   result because every target starts from the same pinned optimum. A single target is always profiled
#'   serially. Keep `TMB::openmp()` and BLAS threads at one when using
#'   `"multicore"`; see [drmTMB-parallel].
#' @param workers Optional positive whole number of worker processes for
#'   `parallel = "multicore"`. `NULL` uses half the detected physical cores,
#'   capped at 10 and at the number of targets.
#' @param ... Additional arguments passed to [TMB::tmbprofile()]. `drmTMB`
#'   supplies the profiled `obj`, `name`, `lincomb`, and `trace` arguments
#'   internally; set the profile target with `parm`.
#'
#' @return A data frame with class `"profile.drmTMB"`. The main columns are
#'   `parm`, `profile_value`, `profile_value_link`, `objective`,
#'   `delta_objective`, `delta_deviance`, `estimate`, `profile_pass`,
#'   `elapsed`, `profile_source`, `conf.low`, `conf.high`, `conf.status`, and
#'   `profile.message`.
#'
#' @examples
#' dat <- data.frame(y = c(0.2, 0.5, 1.1, 1.4), x = c(-1, 0, 1, 2))
#' fit <- drmTMB(bf(y ~ x, sigma ~ 1), data = dat)
#' prof <- profile(fit, parm = "sigma", profile_precision = "fast")
#' head(prof)
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   plot(prof)
#' }
#' @export
profile.drmTMB <- function(
  fitted,
  parm,
  level = 0.95,
  trace = FALSE,
  profile_precision = c("default", "fast"),
  profile_maxit = NULL,
  compare = FALSE,
  first_pass_ystep = 0.5,
  first_pass_ytol = 2,
  parallel = c("none", "multicore", "cluster"),
  workers = NULL,
  ...
) {
  parallel <- resolve_bootstrap_parallel(
    parallel,
    missing_arg = missing(parallel)
  )
  drm_abort_mspl_inference(fitted, "profile")
  if (identical(fitted$model$model_type, "biv_student")) {
    cli::cli_abort(
      "{.fn profile} is not implemented for model type {.val {fitted$model$model_type}}; interval and profile claims are deferred."
    )
  }
  if (!inherits(fitted, "drmTMB")) {
    cli::cli_abort("{.arg fitted} must be a {.cls drmTMB} fit.")
  }
  if (missing(parm) || is.null(parm)) {
    cli::cli_abort(c(
      "{.arg parm} is required for profile-likelihood curves.",
      i = "Use {.fn profile_targets} to inspect available direct target names."
    ))
  }
  if (is.null(fitted$obj)) {
    cli::cli_abort(c(
      "Profile-likelihood curves require the TMB object retained in {.code fit$obj}.",
      i = "Refit with {.code drm_control(keep_tmb_object = TRUE)} before using {.fn profile}."
    ))
  }
  validate_profile_level(level)
  profile_precision <- resolve_profile_precision(
    profile_precision,
    missing_arg = missing(profile_precision)
  )
  profile_maxit <- validate_profile_maxit(profile_maxit)
  profile_args <- profile_precision_args(
    profile_precision,
    list(...),
    profile_maxit = profile_maxit
  )
  profile_check_tmbprofile_dots_list(profile_args)
  compare <- validate_profile_plot_flag(compare, "compare")
  first_pass_args <- profile_first_pass_args(
    profile_args,
    ystep = first_pass_ystep,
    ytol = first_pass_ytol
  )

  targets <- profile_match_targets(drm_profile_targets(fitted), parm)
  if (any(targets$target_class == "ordinal-cutpoint")) {
    cli::cli_abort(c(
      "Full profile curves for ordered cutpoints are not yet exported.",
      i = "Use {.fn confint} with {.code method = \"profile\"} and {.code profile_engine = \"auto\"} for the constrained interval."
    ))
  }
  plan <- profile_parallel_plan(
    nrow(targets),
    parallel = parallel,
    workers = workers
  )
  rows <- profile_lapply(seq_len(nrow(targets)), function(i) {
    target <- targets[i, , drop = FALSE]
    if (isTRUE(compare)) {
      return(rbind(
        do.call(
          drm_profile_curve,
          c(
            list(
              object = fitted,
              target = target,
              level = level,
              trace = trace,
              profile_pass = "coarse",
              profile_controls = profile_controls_label(first_pass_args)
            ),
            first_pass_args
          )
        ),
        do.call(
          drm_profile_curve,
          c(
            list(
              object = fitted,
              target = target,
              level = level,
              trace = trace,
              profile_pass = "dense",
              profile_controls = profile_controls_label(profile_args)
            ),
            profile_args
          )
        )
      ))
    }
    do.call(
      drm_profile_curve,
      c(
        list(
          object = fitted,
          target = target,
          level = level,
          trace = trace,
          profile_pass = "profile",
          profile_controls = profile_controls_label(profile_args)
        ),
        profile_args
      )
    )
  }, plan)
  out <- do.call(rbind, rows)
  row.names(out) <- NULL
  attr(out, "level") <- level
  class(out) <- c("profile.drmTMB", class(out))
  out
}

#' Plot profile-likelihood curves
#'
#' `plot()` for `"profile.drmTMB"` objects draws the likelihood-ratio curve
#' returned by [profile.drmTMB()]. The dotted horizontal line is the
#' likelihood-ratio cutoff for the stored confidence level, the solid vertical
#' line marks the fitted estimate, and dashed vertical lines mark profile
#' interval endpoints when they were extracted successfully. When the profile
#' object contains coarse and dense passes, colour and line type separate the
#' passes and the caption reports elapsed time for each.
#'
#' @param x A `"profile.drmTMB"` object returned by [profile.drmTMB()].
#' @param interval Logical; draw profile interval endpoint lines when finite
#'   `conf.low` and `conf.high` columns are available.
#' @param ... Reserved for future options.
#'
#' @return A `ggplot` object.
#' @examples
#' dat <- data.frame(y = c(0.2, 0.5, 1.1, 1.4), x = c(-1, 0, 1, 2))
#' fit <- drmTMB(bf(y ~ x, sigma ~ 1), data = dat)
#' prof <- profile(fit, parm = "sigma", profile_precision = "fast")
#' if (requireNamespace("ggplot2", quietly = TRUE)) {
#'   plot(prof)
#' }
#' @export
plot.profile.drmTMB <- function(x, interval = TRUE, ...) {
  dots <- list(...)
  if (length(dots) > 0L) {
    cli::cli_abort("{.arg ...} is reserved for future options.")
  }
  plot_profile_require_ggplot2()
  validate_profile_plot_data(x)
  interval <- validate_profile_plot_flag(interval, "interval")

  level <- unique(x$level)
  if (length(level) != 1L || !is.finite(level)) {
    cli::cli_abort(
      "{.arg x} must contain one finite confidence level in column {.val level}."
    )
  }
  cutoff <- stats::qchisq(level, df = 1)
  estimates <- unique(x[c("parm", "estimate")])
  intervals <- unique(x[c("parm", "conf.low", "conf.high", "conf.status")])
  intervals <- intervals[
    is.finite(intervals$conf.low) &
      is.finite(intervals$conf.high) &
      intervals$conf.status == "profile",
    ,
    drop = FALSE
  ]

  data <- x
  if (!any(is.finite(data$delta_deviance))) {
    messages <- unique(data$profile.message[!is.na(data$profile.message)])
    cli::cli_abort(c(
      "This profile has no valid likelihood-ratio curve to plot.",
      i = if (length(messages) > 0L) {
        paste0("Profile status: ", paste(messages, collapse = "; "), ".")
      }
    ))
  }
  data$.drmTMB_profile_parm <- data$parm
  estimates$.drmTMB_profile_parm <- estimates$parm
  intervals$.drmTMB_profile_parm <- intervals$parm
  has_pass_comparison <- length(unique(data$profile_pass)) > 1L

  mapping <- if (has_pass_comparison) {
    ggplot2::aes(
      x = .data[["profile_value"]],
      y = .data[["delta_deviance"]],
      colour = .data[["profile_pass"]],
      linetype = .data[["profile_pass"]]
    )
  } else {
    ggplot2::aes(
      x = .data[["profile_value"]],
      y = .data[["delta_deviance"]]
    )
  }

  out <- ggplot2::ggplot(data, mapping) +
    ggplot2::geom_hline(
      yintercept = cutoff,
      linetype = "dotted",
      colour = "grey55",
      linewidth = 0.35
    ) +
    ggplot2::geom_vline(
      data = estimates,
      mapping = ggplot2::aes(xintercept = .data[["estimate"]]),
      inherit.aes = FALSE,
      linewidth = 0.35,
      colour = "grey30"
    )
  if (isTRUE(interval) && nrow(intervals) > 0L) {
    out <- out +
      ggplot2::geom_vline(
        data = intervals,
        mapping = ggplot2::aes(xintercept = .data[["conf.low"]]),
        inherit.aes = FALSE,
        linetype = "dashed",
        linewidth = 0.3,
        colour = "grey45"
      ) +
      ggplot2::geom_vline(
        data = intervals,
        mapping = ggplot2::aes(xintercept = .data[["conf.high"]]),
        inherit.aes = FALSE,
        linetype = "dashed",
        linewidth = 0.3,
        colour = "grey45"
      )
  }
  line_args <- list(linewidth = 0.8, na.rm = TRUE)
  point_args <- list(
    size = 1.8,
    shape = 21,
    fill = "white",
    stroke = 0.6,
    na.rm = TRUE
  )
  if (!has_pass_comparison) {
    line_args$colour <- "#0072B2"
    point_args$colour <- "#0072B2"
  }
  out <- out +
    do.call(ggplot2::geom_line, line_args) +
    do.call(ggplot2::geom_point, point_args)
  if (has_pass_comparison) {
    out <- out +
      ggplot2::scale_colour_manual(
        values = c(coarse = "grey45", dense = "#0072B2", profile = "#0072B2"),
        breaks = unique(data$profile_pass)
      ) +
      ggplot2::scale_linetype_manual(
        values = c(coarse = "dashed", dense = "solid", profile = "solid"),
        breaks = unique(data$profile_pass)
      )
  }
  if (length(unique(data$parm)) > 1L) {
    out <- out +
      ggplot2::facet_wrap(~.drmTMB_profile_parm, scales = "free_x")
  }
  labels <- list(
    x = "Profiled target value",
    y = "Likelihood-ratio distance",
    caption = profile_plot_caption(data)
  )
  if (has_pass_comparison) {
    labels$colour <- "Profile pass"
    labels$linetype <- "Profile pass"
  }
  out + do.call(ggplot2::labs, labels)
}

utils::globalVariables(".data")

drm_profile_curve <- function(
  object,
  target,
  level,
  trace,
  profile_pass,
  profile_controls,
  ...
) {
  implemented_classes <- c(
    "fixed-effect",
    "distributional-scale",
    "random-effect-sd",
    "random-effect-correlation",
    "residual-correlation"
  )
  if (!isTRUE(target$profile_ready)) {
    cli::cli_abort(c(
      "Profile target {.val {target$parm}} is not ready for direct profiling.",
      i = "Inventory note: {.val {target$profile_note}}."
    ))
  }
  if (!target$target_class %in% implemented_classes) {
    cli::cli_abort(c(
      "Profile-likelihood curves are implemented for direct fixed-effect, constant distributional-scale, random-effect SD, random-effect correlation, and constant residual-correlation targets.",
      i = "Requested {.val {target$parm}} has target class {.val {target$target_class}}."
    ))
  }

  lincomb <- profile_lincomb(object, target)
  elapsed <- system.time({
    prof <- drm_tmbprofile(
      object = object,
      target_name = target$parm,
      lincomb = lincomb,
      trace = trace,
      ...
    )
  })[["elapsed"]]
  profile_data <- as.data.frame(prof)
  value_column <- setdiff(names(profile_data), "value")
  if (length(value_column) != 1L) {
    cli::cli_abort(
      "Internal error: profile curve must contain one profiled-value column."
    )
  }
  profile_value_link <- profile_data[[value_column]]
  objective <- profile_data$value
  clamp_trace <- drm_profile_direct_sd_clamp_trace(object, prof)
  bracket_overflow <- drm_tmbprofile_bracket_overflow(
    prof,
    baseline = unname(object$opt$objective)
  )
  # A bracket-overflow trace is not an approximate profile: one fabricated
  # objective value sets an invalid minimum. Suppress the whole curve so
  # downstream plotting cannot make it look like likelihood evidence.
  if (bracket_overflow) {
    objective[] <- NA_real_
    delta_objective <- rep(NA_real_, length(objective))
  } else {
    delta_objective <- objective - min(objective, na.rm = TRUE)
  }
  ci <- if (!bracket_overflow) {
    tryCatch(
      drm_tmbprofile_confint(prof, target_name = target$parm, level = level),
      error = function(err) err
    )
  }
  interval <- c(NA_real_, NA_real_)
  conf_status <- "profile_interval_unavailable"
  profile_message <- "interval_unavailable"
  if (!identical(clamp_trace$status, "not_applicable") &&
      !identical(clamp_trace$status, "ok")) {
    conf_status <- "clamp_limited"
    profile_message <- clamp_trace$status
  } else if (bracket_overflow) {
    conf_status <- "profile_failed"
    profile_message <- "tmbprofile_bracket_overflow"
  } else if (!inherits(ci, "error")) {
    interval <- profile_transform_interval(
      c(unname(ci[1L, "lower"]), unname(ci[1L, "upper"])),
      target
    )
    conf_status <- "profile"
    profile_message <- "ok"
  } else {
    profile_message <- conditionMessage(ci)
  }

  data.frame(
    parm = target$parm,
    target_class = target$target_class,
    dpar = target$dpar,
    term = target$term,
    level = level,
    profile_value = profile_transform_values(profile_value_link, target),
    profile_value_link = profile_value_link,
    objective = objective,
    delta_objective = delta_objective,
    delta_deviance = 2 * delta_objective,
    estimate = target$estimate,
    link_estimate = target$link_estimate,
    profile_pass = profile_pass,
    elapsed = unname(elapsed),
    profile_controls = profile_controls,
    profile_source = "TMB::tmbprofile via stats::profile.drmTMB",
    conf.low = interval[[1L]],
    conf.high = interval[[2L]],
    conf.status = conf_status,
    profile.message = profile_message,
    scale = target$scale,
    transformation = target$transformation,
    tmb_parameter = target$tmb_parameter,
    index = target$index,
    stringsAsFactors = FALSE
  )
}

profile_first_pass_args <- function(profile_args, ystep, ytol) {
  if (
    !is.numeric(ystep) ||
      length(ystep) != 1L ||
      !is.finite(ystep) ||
      ystep <= 0
  ) {
    cli::cli_abort("{.arg first_pass_ystep} must be one positive number.")
  }
  if (
    !is.numeric(ytol) ||
      length(ytol) != 1L ||
      !is.finite(ytol) ||
      ytol <= 0
  ) {
    cli::cli_abort("{.arg first_pass_ytol} must be one positive number.")
  }
  out <- profile_args
  out$ystep <- ystep
  out$ytol <- ytol
  out$maxit <- NULL
  out
}

profile_controls_label <- function(args) {
  if (length(args) == 0L) {
    return("TMB defaults")
  }
  paste(
    vapply(
      names(args),
      function(name) {
        value <- args[[name]]
        if (length(value) > 4L) {
          value <- c(value[seq_len(4L)], "...")
        }
        paste0(name, "=", paste(value, collapse = "/"))
      },
      character(1)
    ),
    collapse = ", "
  )
}

# Correlation back-transform guard. tanh(eta) can reach +/-1 in finite precision;
# capping at this value keeps correlations strictly inside (-1, 1) so downstream
# atanh round-trips stay finite. This must match the guard used by rho_response()
# and guarded_correlation_link() (methods.R) so the forward link and its inverse
# agree; the DRM.jl twin must mirror the same value (issue #713.6).
# Random-effect correlation targets use DRM_RE_CORR_GUARD (methods.R, 0.99999999,
# raised with src/drmTMB.cpp in #1190); DRM_CORR_GUARD is the residual/phylo
# guard.
DRM_CORR_GUARD <- 0.999999

# The shared "tanh" correlation transformation serves random-effect targets
# (guard DRM_RE_CORR_GUARD) and the phylogenetic correlation `eta_cor_phylo`
# (TMB's rho_phylo / rho_node keep 0.999999). Pick the guard from the TMB
# parameter the target profiles (#1190).
profile_correlation_guard <- function(tmb_parameter) {
  if (length(tmb_parameter) && identical(as.character(tmb_parameter[[1L]]), "eta_cor_phylo")) {
    DRM_CORR_GUARD
  } else {
    DRM_RE_CORR_GUARD
  }
}

profile_transform_values <- function(values, target) {
  switch(
    target$transformation,
    linear_predictor = values,
    ordered_cutpoint = values,
    exp = exp(values),
    plogis = stats::plogis(values),
    tanh = profile_correlation_guard(target$tmb_parameter) * tanh(values),
    rho12_tanh = rho_response(values),
    values
  )
}

profile_plot_caption <- function(data) {
  source <- unique(data$profile_source)
  if (length(source) != 1L) {
    source <- "TMB::tmbprofile"
  }
  elapsed <- unique(data[c("profile_pass", "elapsed", "profile_controls")])
  elapsed <- elapsed[
    order(match(
      elapsed$profile_pass,
      c("coarse", "dense", "profile")
    )),
  ]
  elapsed_text <- paste(
    sprintf(
      "%s %.2fs (%s)",
      elapsed$profile_pass,
      elapsed$elapsed,
      elapsed$profile_controls
    ),
    collapse = "; "
  )
  paste0("Source: ", source, ". Elapsed: ", elapsed_text, ".")
}

plot_profile_require_ggplot2 <- function() {
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    cli::cli_abort(c(
      "{.fn plot.profile.drmTMB} requires the {.pkg ggplot2} package.",
      i = "Install it with {.code install.packages(\"ggplot2\")}."
    ))
  }
  invisible(TRUE)
}

validate_profile_plot_data <- function(data) {
  if (!inherits(data, "profile.drmTMB") || !is.data.frame(data)) {
    cli::cli_abort(
      "{.arg x} must be a {.cls profile.drmTMB} object returned by {.fn profile}."
    )
  }
  required <- c(
    "parm",
    "level",
    "profile_value",
    "delta_deviance",
    "estimate",
    "conf.low",
    "conf.high",
    "conf.status"
  )
  missing <- setdiff(required, names(data))
  if (length(missing) > 0L) {
    cli::cli_abort(
      "{.arg x} is missing profile column{?s}: {.val {missing}}."
    )
  }
  numeric_columns <- c(
    "level",
    "profile_value",
    "delta_deviance",
    "estimate",
    "conf.low",
    "conf.high"
  )
  bad_numeric <- numeric_columns[
    !vapply(
      data[numeric_columns],
      is.numeric,
      logical(1)
    )
  ]
  if (length(bad_numeric) > 0L) {
    cli::cli_abort(
      "{.arg x} profile column{?s} must be numeric: {.val {bad_numeric}}."
    )
  }
  invisible(data)
}

validate_profile_plot_flag <- function(x, argument) {
  if (!is.logical(x) || length(x) != 1L || is.na(x)) {
    cli::cli_abort(
      "{.arg {argument}} must be a single {.code TRUE} or {.code FALSE}."
    )
  }
  x
}

validate_interval_method <- function(method, choices, caller) {
  if (
    !is.character(method) ||
      length(method) < 1L ||
      anyNA(method) ||
      !all(nzchar(method))
  ) {
    cli::cli_abort("{.arg method} must be a non-missing character value.")
  }
  if (length(method) > 1L) {
    if (all(method %in% choices)) {
      return(choices[[1L]])
    }
    cli::cli_abort("{.arg method} must be a single character value.")
  }

  if (
    method %in% c("bootstrap", "parametric_bootstrap") && !method %in% choices
  ) {
    cli::cli_abort(c(
      "{.arg method} = {.val {method}} is not implemented for {.fn {caller}} intervals yet.",
      i = "Current interval methods are {.val {choices}}.",
      i = "Use {.code method = \"profile\"} for direct profile-ready targets, or keep bootstrap intervals as a separate simulation/audit step."
    ))
  }

  matched <- pmatch(method, choices, duplicates.ok = FALSE)
  if (is.na(matched)) {
    cli::cli_abort(
      "{.arg method} must be one of {.val {choices}}."
    )
  }
  choices[[matched]]
}

resolve_profile_precision <- function(profile_precision, missing_arg = FALSE) {
  if (isTRUE(missing_arg)) {
    return("default")
  }
  match.arg(profile_precision, c("default", "fast"))
}

resolve_bootstrap_parallel <- function(parallel, missing_arg = FALSE) {
  if (isTRUE(missing_arg)) {
    return("none")
  }
  match.arg(parallel, c("none", "multicore", "cluster"))
}

validate_profile_maxit <- function(profile_maxit) {
  if (is.null(profile_maxit)) {
    return(NULL)
  }
  if (
    !is.numeric(profile_maxit) ||
      length(profile_maxit) != 1L ||
      is.na(profile_maxit) ||
      !is.finite(profile_maxit) ||
      profile_maxit < 1L ||
      profile_maxit != as.integer(profile_maxit)
  ) {
    cli::cli_abort(
      "{.arg profile_maxit} must be {.code NULL} or a positive whole number."
    )
  }
  as.integer(profile_maxit)
}

validate_profile_endpoint_max_eval <- function(profile_endpoint_max_eval) {
  if (is.null(profile_endpoint_max_eval)) {
    return(NULL)
  }
  if (
    !is.numeric(profile_endpoint_max_eval) ||
      length(profile_endpoint_max_eval) != 1L ||
      is.na(profile_endpoint_max_eval) ||
      !is.finite(profile_endpoint_max_eval) ||
      profile_endpoint_max_eval < 1L ||
      profile_endpoint_max_eval != as.integer(profile_endpoint_max_eval)
  ) {
    cli::cli_abort(
      "{.arg profile_endpoint_max_eval} must be a positive whole number or NULL."
    )
  }
  as.integer(profile_endpoint_max_eval)
}

profile_tmbprofile_controls_requested <- function(
  profile_precision_missing,
  profile_maxit,
  dots
) {
  !isTRUE(profile_precision_missing) ||
    !is.null(profile_maxit) ||
    length(dots) > 0L
}

profile_precision_args <- function(
  profile_precision = "default",
  dots,
  profile_maxit = NULL
) {
  profile_precision <- match.arg(profile_precision, c("default", "fast"))
  profile_check_tmbprofile_dots_list(dots)
  if (!is.null(profile_maxit)) {
    if ("maxit" %in% names(dots)) {
      cli::cli_abort(c(
        "Profile step budget was supplied twice.",
        x = "Use either {.arg profile_maxit} or {.arg maxit} in {.arg ...}, not both."
      ))
    }
    dots$maxit <- profile_maxit
  }
  if (identical(profile_precision, "default")) {
    return(dots)
  }
  if (!"ystep" %in% names(dots)) {
    dots$ystep <- 0.5
  }
  if (!"ytol" %in% names(dots)) {
    dots$ytol <- 2
  }
  dots
}

interval_status_levels <- function() {
  c(
    "wald",
    "profile",
    "bootstrap",
    "clamp_limited",
    "profile_ready",
    "newdata_required",
    "derived_interval_unavailable",
    "wald_unavailable",
    "bootstrap_unavailable",
    "target_unavailable",
    "profile_unavailable",
    "not_requested"
  )
}

interval_source_levels <- function() {
  c("wald", "profile", "bootstrap", "not_available")
}

# Target inventory for an `engine = "julia"` fit (#1156). `profile_targets()`
# used to return only `drm_julia_profile_targets()` -- the phylogenetic SD
# rows -- so a Julia fit of `y ~ x + phylo(1 | species), sigma ~ 1` listed one
# target while the same TMB fit listed six, even though `confint()` accepted
# the fixed-effect names in full (`drm_julia_confint()` already rbind()s the
# SD inventory with `drm_julia_wald_targets()`). Discovery now reports the
# same union the engine accepts, in the native row order: fixed-effect rows,
# the response-scale `sigma` alias, then the random-effect SD rows.
#
# The union is built HERE, not inside `drm_julia_profile_targets()`, because
# `drm_julia_confint()` and `drm_julia_bootstrap_confint()` rbind() that
# function's rows with the fixed-effect rows themselves; widening it would
# duplicate every fixed-effect row and make the one-target validator reject
# a valid `parm`. The `sigma` alias row stays Wald-only (`profile_ready =
# FALSE`, note `missing_tmb_parameter`), exactly as `drm_julia_wald_confint()`
# reports it; the native TMB fit additionally lists a derived
# `phylo_total_variance_share` row that the bridge has no counterpart for.
drm_julia_profile_target_union <- function(object) {
  out <- rbind(
    drm_julia_wald_targets(object),
    drm_julia_wald_scale_targets(object),
    drm_julia_profile_targets(object),
    # #1144: the ordinal rows of a `cumulative_logit()` bridge fit. Same
    # discoverable-but-not-ready treatment as the `sigma` alias row above --
    # the cutpoints are on the fit (`object$ordinal`) and the native engine
    # profiles them, but DRM.jl's bridge inference has no cutpoint target, so
    # discovery must list them and `confint()` must refuse them by name.
    # Empty for every family without an `ordinal` slot.
    drm_julia_cumulative_logit_targets(object)
  )
  out <- out[!duplicated(out$parm), , drop = FALSE]
  row.names(out) <- NULL
  if (nrow(out) == 0L) {
    return(empty_profile_targets())
  }
  validate_profile_targets(out)
}

drm_profile_targets <- function(object) {
  if (inherits(object, "drmTMB_julia")) {
    return(drm_julia_profile_target_union(object))
  }

  rows <- list()
  counters <- new.env(parent = emptyenv())

  add_rows <- function(new_rows) {
    if (!length(new_rows)) {
      return(invisible(NULL))
    }
    rows <<- c(rows, new_rows)
    invisible(NULL)
  }

  next_indices <- function(internal, n) {
    if (is.na(internal) || n == 0L) {
      return(rep(NA_integer_, n))
    }
    current <- if (exists(internal, envir = counters, inherits = FALSE)) {
      get(internal, envir = counters, inherits = FALSE)
    } else {
      0L
    }
    out <- current + seq_len(n)
    assign(internal, current + n, envir = counters)
    out
  }

  for (dpar in names(object$coefficients)) {
    beta <- object$coefficients[[dpar]]
    transformed <- profile_missing_predictor_transform(dpar, object)
    internal <- if (is.null(transformed)) profile_fixef_internal(dpar, object) else transformed$internal
    transformation <- if (is.null(transformed)) "linear_predictor" else transformed$transformation
    indices <- next_indices(internal, length(beta))
    add_rows(lapply(seq_along(beta), function(i) {
      status <- profile_direct_target_status(
        object,
        internal,
        indices[[i]]
      )
      new_profile_target_row(
        parm = paste0("fixef:", dpar, ":", names(beta)[[i]]),
        target_class = "fixed-effect",
        dpar = dpar,
        term = names(beta)[[i]],
        tmb_parameter = internal,
        index = indices[[i]],
        estimate = unname(beta[[i]]),
        link_estimate = if (is.null(transformed)) unname(beta[[i]]) else {
          positions <- which(names(object$opt$par) == internal)
          if (length(positions) >= indices[[i]]) unname(object$opt$par[positions[indices[[i]]]]) else
            switch(transformation, exp = log(unname(beta[[i]])), plogis = stats::qlogis(unname(beta[[i]])))
        },
        scale = if (is.null(transformed)) "link" else "response",
        transformation = transformation,
        target_type = "direct",
        profile_ready = status$profile_ready,
        profile_note = status$profile_note
      )
    }))
  }

  scale_dpars <- intersect(
    names(object$coefficients),
    c("sigma", "sigma1", "sigma2")
  )
  for (dpar in scale_dpars) {
    beta <- object$coefficients[[dpar]]
    if (
      length(beta) == 1L &&
        identical(names(beta), "(Intercept)") &&
        identical(drm_dpar_link(object, dpar), "log")
    ) {
      internal <- profile_fixef_internal(dpar, object)
      status <- profile_direct_target_status(object, internal, 1L)
      add_rows(list(new_profile_target_row(
        parm = dpar,
        target_class = "distributional-scale",
        dpar = dpar,
        term = "(constant)",
        tmb_parameter = internal,
        index = 1L,
        estimate = exp(unname(beta[[1L]])),
        link_estimate = unname(beta[[1L]]),
        scale = "response",
        transformation = "exp",
        target_type = "direct",
        profile_ready = status$profile_ready,
        profile_note = status$profile_note
      )))
    }
  }

  if ("rho12" %in% names(object$coefficients)) {
    beta <- object$coefficients$rho12
    if (length(beta) == 1L && identical(names(beta), "(Intercept)")) {
      status <- profile_direct_target_status(object, "beta_rho12", 1L)
      add_rows(list(new_profile_target_row(
        parm = "rho12",
        target_class = "residual-correlation",
        dpar = "rho12",
        term = "(constant)",
        tmb_parameter = "beta_rho12",
        index = 1L,
        estimate = rho_response(unname(beta[[1L]])),
        link_estimate = unname(beta[[1L]]),
        scale = "response",
        transformation = "rho12_tanh",
        target_type = "direct",
        profile_ready = status$profile_ready,
        profile_note = status$profile_note
      )))
    }
  }

  for (dpar in names(object$sdpars)) {
    values <- object$sdpars[[dpar]]
    for (i in seq_along(values)) {
      term <- names(values)[[i]]
      internal <- profile_sd_internal(object, dpar, term)
      is_direct <- !is.na(internal)
      index <- if (is_direct) {
        next_indices(internal, 1L)
      } else {
        NA_integer_
      }
      status <- if (is_direct) {
        if (
          identical(internal, "log_sd_phylo2") &&
            isTRUE(object$model$structured$mesh_spatial_mu$has)
        ) {
          list(
            profile_ready = FALSE,
            profile_note = "mesh_field_scale_intervals_unvalidated"
          )
        } else if (
          ((identical(internal, "log_sd_phylo") ||
            identical(internal, "log_sd_sigma")) &&
            count_point_fit_only_profile_restricted(object, dpar)) ||
            zero_one_beta_zoi_q1_profile_restricted(object, dpar, internal) ||
            zero_one_beta_coi_q1_profile_restricted(object, dpar, internal)
        ) {
          count_point_fit_only_profile_restricted_status(object, dpar)
        } else {
          profile_direct_target_status(object, internal, index)
        }
      } else {
        list(profile_ready = FALSE, profile_note = "derived_target")
      }
      add_rows(list(new_profile_target_row(
        parm = paste0("sd:", dpar, ":", term),
        target_class = "random-effect-sd",
        dpar = dpar,
        term = term,
        tmb_parameter = internal,
        index = index,
        estimate = unname(values[[i]]),
        link_estimate = log(unname(values[[i]])),
        scale = "response",
        transformation = if (is_direct) "exp" else "derived_group_scale",
        target_type = if (is_direct) "direct" else "derived",
        profile_ready = status$profile_ready,
        profile_note = status$profile_note
      )))
    }
  }

  registry_cor_rows <- profile_registry_cor_targets(object)
  add_rows(registry_cor_rows)
  add_rows(profile_derived_summary_targets(object))
  registry_cor_keys <- covariance_block_corpars_keys(
    object$model$random$covariance_blocks
  )
  for (dpar in names(object$corpars)) {
    values <- object$corpars[[dpar]]
    internal <- profile_cor_internal(dpar)
    is_structured_qgt2 <- dpar %in%
      c("phylo", "spatial", "animal", "relmat") &&
      isTRUE(object$model$structured$phylo_mu$has) &&
      identical(
        dpar,
        structured_mu_correlation_key(
          object$model$structured$phylo_mu
        )
      ) &&
      isTRUE(object$model$structured$phylo_mu$q > 2L) &&
      !phylo_mu_is_block_diagonal(object$model$structured$phylo_mu)
    # A modelled group or phylogenetic mu correlation stores one value per level
    # in corpars$mu / corpars$phylo (issue #698 and its phylogenetic sibling).
    # Those levels are a single fitted correlation regression profiled through
    # beta_cor_mu, so only the representative index participates here; per-level
    # entries must not spawn cor:mu:* / cor:phylo:* targets.
    cor_indices <- if (
      identical(dpar, "mu") &&
        corpair_model_is_group(object$model$random$mu$cor_model)
    ) {
      unique(object$model$random$mu$cor_model$target_cor)
    } else if (
      has_modelled_phylo_correlation(object$model) &&
        identical(dpar, structured_mu_correlation_key(
          object$model$structured$phylo_mu
        ))
    ) {
      unique(object$model$random$mu$cor_model$target_cor)
    } else {
      seq_along(values)
    }
    for (i in cor_indices) {
      if (paste(dpar, i, sep = ":") %in% registry_cor_keys) {
        next
      }
      if (random_effect_correlation_is_modelled(object, dpar, i)) {
        next
      }
      index <- i
      if (
        dpar %in%
          c("phylo", "spatial", "animal", "relmat") &&
          isTRUE(object$model$structured$phylo_mu$has) &&
          identical(
            dpar,
            structured_mu_correlation_key(
              object$model$structured$phylo_mu
            )
          ) &&
          isTRUE(object$model$structured$phylo_mu$q > 2L)
      ) {
        internal <- "theta_phylo"
      }
      if (is_structured_qgt2) {
        status <- list(
          profile_ready = FALSE,
          profile_note = "derived_unstructured_correlation"
        )
      } else {
        status <- profile_direct_target_status(
          object,
          internal,
          index
        )
      }
      add_rows(list(new_profile_target_row(
        parm = paste0("cor:", dpar, ":", names(values)[[i]]),
        target_class = "random-effect-correlation",
        dpar = dpar,
        term = names(values)[[i]],
        tmb_parameter = internal,
        index = index,
        estimate = unname(values[[i]]),
        link_estimate = if (is_structured_qgt2) {
          NA_real_
        } else {
          guarded_correlation_link(
            unname(values[[i]]),
            guard = profile_correlation_guard(internal)
          )
        },
        scale = "response",
        transformation = if (is_structured_qgt2) {
          "unstructured_corr"
        } else {
          "tanh"
        },
        target_type = if (is_structured_qgt2) "derived" else "direct",
        profile_ready = status$profile_ready,
        profile_note = status$profile_note
      )))
    }
  }

  if (!is.null(object$ordinal)) {
    theta <- object$ordinal$theta_raw
    cutpoints <- object$ordinal$cutpoints
    internal <- "theta_ord"
    indices <- next_indices(internal, length(theta))
    add_rows(lapply(seq_along(theta), function(i) {
      new_profile_target_row(
        parm = paste0("ordinal:theta_ord:", names(theta)[[i]]),
        target_class = "ordinal-cutpoint-internal",
        dpar = "ordinal",
        term = names(theta)[[i]],
        tmb_parameter = internal,
        index = indices[[i]],
        estimate = unname(theta[[i]]),
        link_estimate = unname(theta[[i]]),
        scale = "internal",
        transformation = "ordered_cutpoint",
        target_type = "direct",
        profile_ready = FALSE,
        profile_note = "internal_ordinal_parameter"
      )
    }))
    add_rows(lapply(seq_along(cutpoints), function(i) {
      status <- profile_direct_target_status(object, internal, indices[[i]])
      new_profile_target_row(
        parm = paste0("ordinal:cutpoint:", names(cutpoints)[[i]]),
        target_class = "ordinal-cutpoint",
        dpar = "ordinal",
        term = names(cutpoints)[[i]],
        tmb_parameter = internal,
        index = indices[[i]],
        estimate = unname(cutpoints[[i]]),
        link_estimate = unname(theta[[i]]),
        scale = "cutpoint",
        transformation = "ordered_cutpoint",
        target_type = "constrained",
        profile_ready = status$profile_ready,
        profile_note = status$profile_note
      )
    }))
  }

  out <- if (length(rows)) {
    do.call(rbind, rows)
  } else {
    empty_profile_targets()
  }
  row.names(out) <- NULL
  validate_profile_targets(out)
}

drm_profile_confint <- function(
  object,
  parm,
  level = 0.95,
  trace = FALSE,
  parallel = "none",
  workers = NULL,
  profile_engine = c("tmbprofile", "auto", "endpoint"),
  profile_endpoint_max_eval = NULL,
  ...
) {
  validate_profile_level(level)
  profile_engine <- match.arg(profile_engine)
  profile_check_tmbprofile_dots(...)
  if (is.null(object$obj)) {
    cli::cli_abort(c(
      "Profile confidence intervals require the TMB object retained in {.code fit$obj}.",
      i = "Refit with {.code drm_control(keep_tmb_object = TRUE)} before using {.code method = \"profile\"}."
    ))
  }
  targets <- profile_match_targets(drm_profile_targets(object), parm)
  endpoint_plan <- profile_endpoint_parallel_plan(
    targets = targets,
    parallel = parallel,
    workers = workers,
    profile_engine = profile_engine
  )
  plan <- if (identical(endpoint_plan$backend, "none")) {
    profile_parallel_plan(
      nrow(targets),
      parallel = parallel,
      workers = workers
    )
  } else {
    profile_serial_plan()
  }

  worker <- function(i) {
    drm_profile_target_confint(
      object = object,
      target = targets[i, , drop = FALSE],
      level = level,
      trace = trace,
      profile_engine = profile_engine,
      endpoint_plan = endpoint_plan,
      profile_endpoint_max_eval = profile_endpoint_max_eval,
      ...
    )
  }
  rows <- profile_lapply(seq_len(nrow(targets)), worker, plan)
  out <- do.call(rbind, rows)
  row.names(out) <- NULL
  warn_profile_boundary(out)
  drm_as_confint_table(out)
}

profile_serial_plan <- function() {
  list(backend = "none", workers = 1L)
}

profile_endpoint_parallel_plan <- function(
  targets,
  parallel,
  workers,
  profile_engine
) {
  if (
    nrow(targets) != 1L ||
      identical(profile_engine, "tmbprofile") ||
      !profile_endpoint_target_supported(targets)
  ) {
    return(profile_serial_plan())
  }
  plan <- profile_parallel_plan(2L, parallel = parallel, workers = workers)
  if (identical(plan$backend, "none") || plan$workers < 2L) {
    return(profile_serial_plan())
  }
  plan
}

profile_derived_summary_targets <- function(object) {
  rows <- drm_derived_summary_rows(object)
  if (nrow(rows) == 0L) {
    return(list())
  }
  lapply(seq_len(nrow(rows)), function(i) {
    row <- rows[i, , drop = FALSE]
    new_profile_target_row(
      parm = row$parm[[1L]],
      target_class = "derived-summary",
      dpar = row$dpar[[1L]],
      term = row$term[[1L]],
      tmb_parameter = NA_character_,
      index = NA_integer_,
      estimate = row$estimate[[1L]],
      link_estimate = NA_real_,
      scale = "response",
      transformation = "variance_ratio",
      target_type = "derived",
      profile_ready = FALSE,
      profile_note = "derived_target"
    )
  })
}

drm_profile_response_newdata_confint <- function(
  object,
  parm,
  newdata,
  level = 0.95,
  trace = FALSE,
  parallel = "none",
  workers = NULL,
  ...
) {
  validate_profile_level(level)
  profile_check_tmbprofile_dots(...)
  if (is.null(object$obj)) {
    cli::cli_abort(c(
      "Profile confidence intervals require the TMB object retained in {.code fit$obj}.",
      i = "Refit with {.code drm_control(keep_tmb_object = TRUE)} before using {.code method = \"profile\"}."
    ))
  }
  dpar <- profile_newdata_dpar(object, parm)
  if (!is.data.frame(newdata)) {
    cli::cli_abort("{.arg newdata} must be a data frame.")
  }
  if (nrow(newdata) < 1L) {
    cli::cli_abort("{.arg newdata} must contain at least one row.")
  }

  X <- drm_prediction_matrix(object, newdata, dpar)
  beta <- object$coefficients[[dpar]]
  if (!identical(colnames(X), names(beta))) {
    cli::cli_abort(c(
      "Could not align {.arg newdata} with the fitted {.val {dpar}} formula.",
      i = "Check that factor levels and predictor columns match the fitted model."
    ))
  }
  offset <- drm_prediction_offset(object, newdata, dpar)
  if (length(offset) != nrow(X)) {
    cli::cli_abort(
      "Internal error: response-scale profile offsets do not match {.arg newdata} rows."
    )
  }

  internal <- profile_fixef_internal(dpar, object)
  par_names <- names(object$opt$par)
  positions <- which(par_names == internal)
  if (length(positions) < ncol(X)) {
    cli::cli_abort(c(
      "Profile target {.val {dpar}} cannot be mapped to optimized parameters.",
      i = "Expected {ncol(X)} coefficient{?s} in TMB parameter {.val {internal}}."
    ))
  }

  labels <- profile_newdata_parm_labels(dpar, newdata)
  plan <- profile_parallel_plan(nrow(X), parallel = parallel, workers = workers)
  transformation <- profile_newdata_transformation(object, dpar)
  worker <- function(i) {
    lincomb <- rep(0, length(object$opt$par))
    lincomb[positions[seq_len(ncol(X))]] <- as.numeric(X[i, ])
    prof <- drm_tmbprofile(
      object = object,
      target_name = labels[[i]],
      lincomb = lincomb,
      trace = trace,
      ...
    )
    if (drm_tmbprofile_bracket_overflow(
      prof,
      baseline = unname(object$opt$objective)
    )) {
      return(data.frame(
        parm = labels[[i]],
        level = level,
        lower = NA_real_,
        upper = NA_real_,
        scale = "response",
        transformation = transformation,
        tmb_parameter = internal,
        index = NA_integer_,
        method = "profile",
        profile.engine = "tmbprofile",
        conf.status = "profile_failed",
        profile.boundary = TRUE,
        profile.message = "tmbprofile_bracket_overflow",
        stringsAsFactors = FALSE
      ))
    }
    ci <- drm_tmbprofile_confint(prof, target_name = labels[[i]], level = level)
    interval <- profile_transform_newdata_interval(
      c(unname(ci[1L, "lower"]), unname(ci[1L, "upper"])),
      object = object,
      dpar = dpar,
      offset = offset[[i]]
    )

    diagnostics <- profile_interval_diagnostics(
      interval,
      transformation = transformation
    )

    data.frame(
      parm = labels[[i]],
      level = level,
      lower = interval[[1L]],
      upper = interval[[2L]],
      scale = "response",
      transformation = transformation,
      tmb_parameter = internal,
      index = NA_integer_,
      method = "profile",
      profile.engine = "tmbprofile",
      conf.status = "profile",
      profile.boundary = diagnostics$boundary,
      profile.message = diagnostics$message,
      stringsAsFactors = FALSE
    )
  }
  rows <- profile_lapply(seq_len(nrow(X)), worker, plan)
  out <- do.call(rbind, rows)
  row.names(out) <- NULL
  warn_profile_boundary(out)
  drm_as_confint_table(out)
}

# The Wald path warns at a variance-component or correlation boundary and sends
# the user to `method = "profile"`. Measured coverage shows the profile route is
# also unreliable there -- conditional on `profile.boundary`, 10-group RE-SD
# coverage was 0.07-0.86 against a nominal 0.95 -- so leaving this direction
# silent steers users out of one bad regime into another. `lme4` reproduces the
# same numbers on the same seeds, so this is a property of profile intervals at
# a boundary, not of drmTMB's root-finder. Evidence:
# docs/dev-log/simulation-artifacts/2026-08-04-d117-10group-profile-gate/.
#
# Only usable intervals are flagged. `profile_failed` and `clamp_limited` rows
# return NA endpoints and already report themselves through `conf.status`;
# warning about their coverage would be meaningless.
warn_profile_boundary <- function(out) {
  if (is.null(out) || nrow(out) == 0L) {
    return(invisible(out))
  }
  at_boundary <- !is.na(out$profile.boundary) &
    out$profile.boundary &
    !is.na(out$conf.status) &
    out$conf.status == "profile" &
    is.finite(out$lower) &
    is.finite(out$upper)
  if (any(at_boundary)) {
    n_boundary <- sum(at_boundary)
    cli::cli_warn(
      c(
        "{cli::qty(n_boundary)}Profile interval{?s} for {.val {out$parm[at_boundary]}} {?is/are} at a variance-component or correlation boundary.",
        "!" = "{cli::qty(n_boundary)}Profile coverage is well below nominal there, so {?this interval is/these intervals are} not a reliable {.arg level} interval.",
        "i" = "See the {.strong Boundary intervals} section of {.code ?confint.drmTMB}."
      ),
      class = "drmTMB_profile_boundary_warning"
    )
  }
  invisible(out)
}

skew_normal_slant_targets <- function(object, targets) {
  if (!identical(object$model$model_type, "skew_normal")) {
    return(character())
  }
  targets$parm[targets$dpar == "nu"]
}

warn_skew_normal_slant_wald <- function(object, targets) {
  slant <- skew_normal_slant_targets(object, targets)
  if (length(slant) == 0L) {
    return(invisible(NULL))
  }
  cli::cli_warn(c(
    "!" = "{cli::qty(slant)}Wald confidence interval{?s} for the skew-normal slant ({.val {slant}}) {?is/are} miscalibrated near {.code nu = 0}, where the Azzalini information is near-singular.",
    "i" = "{cli::qty(slant)}Use {.code method = \"profile\"} (or {.code method = \"bootstrap\"}) for the slant interval{?s} instead."
  ))
  invisible(NULL)
}

drm_wald_confint <- function(
  object,
  parm,
  level,
  sd_boundary = 1e-4,
  rho_boundary = 0.98,
  small_sample_df = c("location", "none", "group"),
  bias_correct = c("location", "none", "group")
) {
  small_sample_df <- match.arg(small_sample_df)
  bias_correct <- match.arg(bias_correct)
  all_targets <- drm_profile_targets(object)
  if (!is.null(parm) && is.character(parm)) {
    ordinal_requested <- intersect(
      parm,
      all_targets$parm[all_targets$target_class == "ordinal-cutpoint"]
    )
    if (length(ordinal_requested) > 0L) {
      cli::cli_abort(c(
        "Wald confidence intervals are not available for ordered cutpoints.",
        i = "Use {.code method = \"profile\"} with {.val {ordinal_requested}} to obtain constrained response-scale cutpoint intervals."
      ))
    }
  }
  targets <- all_targets
  targets <- targets[wald_supported_targets(targets), , drop = FALSE]
  targets <- profile_match_confint_targets(
    targets,
    parm,
    fixed_only = FALSE
  )
  if (nrow(targets) == 0L) {
    return(empty_confint_table(method = "wald"))
  }
  warn_skew_normal_slant_wald(object, targets)

  # Small-sample bias correction shifts the log-scale point estimate of a
  # structured-RE SD target with a resolvable group count `g` by `+log(g/(g-1))`
  # BEFORE building the interval, moving the interval centre (and feeding the
  # shifted centre into the boundary check and back-transform); it is
  # independent of the t-width applied through `crit`. Three states:
  #   "location" (default): shift only LOCATION-axis (mu) structured SD targets;
  #     dispersion (sigma) and non-structured targets keep the ML centre.
  #   "group" (opt-in): shift every structured SD target (mu and sigma alike).
  #   "none" (opt-out): leave every centre at the ML estimate, byte-identical to
  #     the pre-default behaviour.
  bias_applied <- rep(FALSE, nrow(targets))
  if (!identical(bias_correct, "none")) {
    log_bias <- wald_target_log_bias(
      object,
      targets,
      location_only = identical(bias_correct, "location")
    )
    has_bias <- !is.na(log_bias)
    bias_applied <- has_bias
    targets$link_estimate[has_bias] <-
      targets$link_estimate[has_bias] + log_bias[has_bias]
  }

  z <- stats::qnorm((1 + level) / 2)
  # Critical-value vector: the ordinary normal quantile for every row, except
  # structured-RE SD rows that receive a t-quantile with df = g - 1. Three
  # states mirror `bias_correct`:
  #   "location" (default): widen only LOCATION-axis (mu) structured SD targets.
  #   "group" (opt-in): widen every structured SD target (mu and sigma alike).
  #   "none" (opt-out): leave `crit` exactly equal to `z` for every target,
  #     byte-identical to the pre-default behaviour.
  crit <- rep(z, nrow(targets))
  if (!identical(small_sample_df, "none")) {
    df <- wald_target_df(
      object,
      targets,
      location_only = identical(small_sample_df, "location")
    )
    has_df <- !is.na(df)
    crit[has_df] <- stats::qt((1 + level) / 2, df[has_df])
  }
  variances <- rep(NA_real_, nrow(targets))
  hessian_ready <- isTRUE(object$sdr$pdHess)
  if (hessian_ready) {
    cov_fixed <- drm_sdreport_cov_fixed(object)
    positions <- profile_target_opt_positions(object, targets)
    in_covariance <- !is.na(positions) & positions <= nrow(cov_fixed)
    variances[in_covariance] <- cov_fixed[
      cbind(positions[in_covariance], positions[in_covariance])
    ]
  } else if (is.null(object$sdr)) {
    drm_sdreport_cov_fixed(object)
  }
  se <- profile_wald_standard_errors(variances)
  interval_ready <- hessian_ready &
    is.finite(targets$link_estimate) &
    is.finite(se)
  lower <- rep(NA_real_, nrow(targets))
  upper <- rep(NA_real_, nrow(targets))
  if (any(interval_ready)) {
    link_lower <- targets$link_estimate[interval_ready] -
      crit[interval_ready] * se[interval_ready]
    link_upper <- targets$link_estimate[interval_ready] +
      crit[interval_ready] * se[interval_ready]
    transformed <- mapply(
      function(lo, hi, row) {
        profile_transform_interval(c(lo, hi), targets[row, , drop = FALSE])
      },
      link_lower,
      link_upper,
      which(interval_ready),
      SIMPLIFY = FALSE
    )
    lower[interval_ready] <- vapply(transformed, `[[`, numeric(1L), 1L)
    upper[interval_ready] <- vapply(transformed, `[[`, numeric(1L), 2L)
  }

  out <- data.frame(
    parm = targets$parm,
    level = level,
    lower = lower,
    upper = upper,
    scale = targets$scale,
    transformation = targets$transformation,
    tmb_parameter = targets$tmb_parameter,
    index = targets$index,
    method = "wald",
    profile.engine = NA_character_,
    conf.status = ifelse(interval_ready, "wald", "wald_unavailable"),
    profile.boundary = NA,
    profile.message = NA_character_,
    stringsAsFactors = FALSE
  )
  if (any(interval_ready & bias_applied)) {
    out$conf.status[interval_ready & bias_applied] <- "wald_bias_corrected"
  }

  # A Wald interval on a variance component near zero or a correlation near +/-1
  # is unreliable (boundary / chi-square-mixture inference). Keep the interval --
  # a boundary is a warning, not an auto-discard -- but flag it and point to the
  # profile method. Residual/distributional scale is regular and not flagged.
  at_boundary <- interval_ready &
    wald_boundary_targets(
      targets,
      sd_boundary = sd_boundary,
      rho_boundary = rho_boundary
    )
  at_boundary_no_bias <- at_boundary & !bias_applied
  out$conf.status[at_boundary_no_bias] <- "wald_at_boundary"
  is_rho12 <- targets$target_class == "residual-correlation"
  at_boundary_profile <- at_boundary & !is_rho12
  at_boundary_rho12 <- at_boundary & is_rho12
  if (any(at_boundary_profile)) {
    n_boundary <- sum(at_boundary_profile)
    cli::cli_warn(
      c(
        "{cli::qty(n_boundary)}Wald interval{?s} for {.val {targets$parm[at_boundary_profile]}} {?is/are} at a variance-component or correlation boundary.",
        "i" = "{cli::qty(n_boundary)}Wald coverage is unreliable on the boundary; use {.code confint(method = \"profile\")} for {?this/these} target{?s}."
      ),
      class = "drmTMB_wald_boundary_warning"
    )
  }
  if (any(at_boundary_rho12)) {
    n_boundary <- sum(at_boundary_rho12)
    cli::cli_warn(
      c(
        "{cli::qty(n_boundary)}Wald interval{?s} for {.val {targets$parm[at_boundary_rho12]}} {?is/are} at a residual-correlation boundary.",
        "i" = "{cli::qty(n_boundary)}Profile intervals for residual rho12 at this boundary are usually identical to Wald; read {.field conf.status} on the returned table instead of switching method."
      ),
      class = "drmTMB_wald_boundary_warning"
    )
  }

  row.names(out) <- NULL
  drm_as_confint_table(out)
}

# A structured random-effect SD target sits on the location (mu) axis when its
# `dpar` family is `mu` (`mu`, `mu1`, `mu2`), and on the dispersion (sigma) axis
# when its family is `sigma` (`sigma`, `sigma1`, `sigma2`). The trailing response
# index is stripped before matching, so q2/q4 endpoints share the family of
# their univariate counterpart. The DEFAULT small-sample correction is scoped to
# the location axis only; the dispersion axis already over-covers under the
# normal quantile and is left raw unless the caller opts in with `"group"`.
wald_sd_target_is_location_axis <- function(target) {
  dpar <- target$dpar[[1L]]
  if (is.na(dpar)) {
    return(FALSE)
  }
  family <- sub("[0-9]+$", "", dpar)
  identical(family, "mu")
}

# Small-sample (Satterthwaite-style) degrees of freedom for Wald SD intervals.
#
# Returns a numeric vector, one entry per row of `targets`. For each structured
# random-effect SD target with a resolvable group count `g`, the entry is
# `g - 1` (group-based between-group df). Every other target -- and any SD
# target whose group count cannot be matched to a unique source -- gets
# `NA_real_`. This never errors: an ambiguous or missing match falls back to
# NA, and the caller substitutes the ordinary normal quantile for those rows.
#
# `location_only = TRUE` (the path used by the DEFAULT correction) restricts the
# resolved df to location-axis (mu) *structured* (phylo/spatial/animal/relmat) SD
# targets: it skips dispersion (sigma) SD targets and the labelled
# covariance-block registry, so the default widens only the under-covering
# location-axis structured intervals whose magnitude was simulation-calibrated.
# `location_only = FALSE` reproduces the `small_sample_df = "group"` opt-in scope
# (every structured and labelled-covariance SD target on either axis).
#
# Group counts for structured SD targets (`phylo`/`spatial`/`animal`/`relmat`)
# live in `object$model$structured$phylo_mu$group_levels`, NOT in the labelled
# covariance-block registry (which is empty for these models) and NOT in the
# augmented `n_re` count (phylo's `n_re` includes internal tree nodes, so it
# overstates `g`). Labelled covariance-block SD targets instead carry a
# per-block `n_groups` column in the registry; those are matched via the
# registry members table.
wald_target_df <- function(object, targets, location_only = FALSE) {
  if (nrow(targets) == 0L) {
    return(numeric(0L))
  }
  df <- rep(NA_real_, nrow(targets))
  is_sd <- !is.na(targets$target_class) &
    targets$target_class == "random-effect-sd"
  if (!any(is_sd)) {
    return(df)
  }

  structured_g <- structured_sd_group_count(object)
  registry <- object$model$random$covariance_blocks

  for (i in which(is_sd)) {
    if (
      isTRUE(location_only) &&
        !wald_sd_target_is_location_axis(targets[i, , drop = FALSE])
    ) {
      next
    }
    g <- wald_sd_target_group_count(
      object = object,
      target = targets[i, , drop = FALSE],
      structured_g = structured_g,
      registry = registry,
      structured_only = location_only
    )
    if (is.finite(g) && g >= 2L) {
      df[i] <- g - 1
    }
  }
  df
}

# Small-sample log-scale bias correction for structured-RE SD Wald intervals.
#
# Returns a numeric vector, one entry per row of `targets`. For each structured
# random-effect SD target with a resolvable group count `g` (the SAME targets
# `wald_target_df()` identifies, via the same g-resolution path), the entry is
# `log(g / (g - 1))` -- the closed-form centre correction that lifts the
# downward ML shrinkage of the variance-component SD back toward its expectation
# on the log scale. Every other target -- and any SD target whose group count
# cannot be matched -- gets `NA_real_`, so the caller leaves its centre
# unshifted. This never errors: an ambiguous or missing match falls back to NA.
#
# `location_only = TRUE` (the path used by the DEFAULT correction) restricts the
# shift to location-axis (mu) *structured* (phylo/spatial/animal/relmat) SD
# targets, skipping dispersion (sigma) SD targets and the labelled
# covariance-block registry, matching `wald_target_df()`. `location_only = FALSE`
# reproduces the `bias_correct = "group"` opt-in scope.
wald_target_log_bias <- function(object, targets, location_only = FALSE) {
  if (nrow(targets) == 0L) {
    return(numeric(0L))
  }
  bias <- rep(NA_real_, nrow(targets))
  is_sd <- !is.na(targets$target_class) &
    targets$target_class == "random-effect-sd"
  if (!any(is_sd)) {
    return(bias)
  }

  structured_g <- structured_sd_group_count(object)
  registry <- object$model$random$covariance_blocks

  for (i in which(is_sd)) {
    if (
      isTRUE(location_only) &&
        !wald_sd_target_is_location_axis(targets[i, , drop = FALSE])
    ) {
      next
    }
    g <- wald_sd_target_group_count(
      object = object,
      target = targets[i, , drop = FALSE],
      structured_g = structured_g,
      registry = registry,
      structured_only = location_only
    )
    if (is.finite(g) && g >= 2L) {
      bias[i] <- log(g / (g - 1))
    }
  }
  bias
}

# Group count for the single structured-RE block (phylo/spatial/animal/relmat),
# or NA_real_ when there is no scalar structured location SD block to reference.
# `phylo_interaction` pairs two clades and has no single group count, so it is
# deliberately left as NA.
structured_sd_group_count <- function(object) {
  phylo_mu <- object$model$structured$phylo_mu
  if (!is.list(phylo_mu) || !isTRUE(phylo_mu$has)) {
    return(NA_real_)
  }
  type <- structured_mu_type(phylo_mu)
  if (!type %in% c("phylo", "spatial", "animal", "relmat")) {
    return(NA_real_)
  }
  g <- length(phylo_mu$group_levels)
  if (g < 1L) {
    return(NA_real_)
  }
  as.numeric(g)
}

structured_sd_term_matches_label <- function(term, label) {
  if (
    !is.character(term) ||
      !is.character(label) ||
      length(term) != 1L ||
      length(label) != 1L ||
      is.na(term) ||
      is.na(label)
  ) {
    return(FALSE)
  }
  term <- trimws(term)
  label <- trimws(label)
  if (!nzchar(term) || !nzchar(label)) {
    return(FALSE)
  }
  if (identical(term, label) || endsWith(term, label)) {
    return(TRUE)
  }
  term_sig <- structured_sd_term_signature(term)
  label_sig <- structured_sd_term_signature(label)
  if (is.null(term_sig) || is.null(label_sig)) {
    return(FALSE)
  }
  identical(term_sig$type, label_sig$type) &&
    identical(term_sig$group, label_sig$group)
}

structured_sd_term_signature <- function(term) {
  match <- regexec(
    "^\\s*([[:alnum:]_]+)\\s*\\((.*)\\)\\s*$",
    term,
    perl = TRUE
  )
  parts <- regmatches(term, match)[[1L]]
  if (length(parts) != 3L) {
    return(NULL)
  }
  pieces <- strsplit(parts[[3L]], "|", fixed = TRUE)[[1L]]
  if (length(pieces) < 2L) {
    return(NULL)
  }
  group <- trimws(paste(pieces[-1L], collapse = "|"))
  group <- trimws(sub(",.*$", "", group))
  if (!nzchar(group)) {
    return(NULL)
  }
  list(type = parts[[2L]], group = group)
}

# Resolve the group count for one SD target row. Tries the structured location
# block first (matched on the target term's structured label), then a labelled
# covariance-block registry match. Returns NA_real_ when no unique match exists.
#
# `structured_only = TRUE` (the path used by the DEFAULT correction) restricts
# resolution to the genuinely *structured* RE block (phylo/spatial/animal/relmat,
# resolved via `log_sd_phylo`) and skips the labelled covariance-block registry.
# The default is scoped to structured cells because the `log(g/(g-1))` magnitude
# was simulation-calibrated for those (design doc 219); a plain labelled
# covariance block such as `(1 + x | p | id)` resolves a registry `g` but its
# correction is not validated, so the default leaves it at the raw z-interval.
# `structured_only = FALSE` reproduces the `"group"` opt-in scope (structured and
# labelled-covariance blocks alike).
wald_sd_target_group_count <- function(
  object,
  target,
  structured_g,
  registry,
  structured_only = FALSE
) {
  tmb_parameter <- target$tmb_parameter[[1L]]
  term <- target$term[[1L]]

  if (
    !is.na(tmb_parameter) &&
      identical(tmb_parameter, "log_sd_phylo") &&
      is.finite(structured_g)
  ) {
    phylo_mu <- object$model$structured$phylo_mu
    label <- if (is.list(phylo_mu)) phylo_mu$label else NULL
    if (
      is.character(label) &&
        length(label) == 1L &&
        nzchar(label) &&
        structured_sd_term_matches_label(term, label)
    ) {
      return(structured_g)
    }
    return(NA_real_)
  }

  if (isTRUE(structured_only)) {
    return(NA_real_)
  }
  registry_sd_target_group_count(target, registry)
}

# Match a labelled covariance-block SD target to its registry block and return
# the block's `n_groups`. Only a single unique block match yields a count; zero
# or multiple matches return NA_real_.
registry_sd_target_group_count <- function(target, registry) {
  if (!is.list(registry) || is.null(registry$members)) {
    return(NA_real_)
  }
  members <- registry$members
  if (!is.data.frame(members) || nrow(members) == 0L) {
    return(NA_real_)
  }
  term <- target$term[[1L]]
  if (is.na(term) || !("label" %in% names(members))) {
    return(NA_real_)
  }
  hit <- which(!is.na(members$label) & members$label == term)
  if (length(hit) == 0L || !("n_groups" %in% names(members))) {
    return(NA_real_)
  }
  counts <- unique(members$n_groups[hit])
  counts <- counts[is.finite(counts)]
  if (length(counts) != 1L) {
    return(NA_real_)
  }
  as.numeric(counts[[1L]])
}

# Identify confint targets whose Wald interval sits at a variance-component or
# correlation boundary, where the symmetric Wald interval is unreliable. Scoped
# by `target_class`: random-effect / structured SDs near zero and any correlation
# near +/-1, but NOT the residual or distributional scale (regular asymptotics).
profile_sd_boundary_rows <- function(targets) {
  is_sd <- grepl("-sd$", targets$target_class)
  # These public summaries stay fixed-effect rows so coef()/vcov() retain them,
  # but their raw parameters are random-effect SDs, not regular residual scales.
  if (!is.null(targets$tmb_parameter)) {
    is_sd <- is_sd | (targets$target_class == "fixed-effect" &
      targets$tmb_parameter %in% c("log_sd_mi_group", "log_sd_mi_struct"))
  }
  is_sd
}

wald_boundary_targets <- function(
  targets,
  sd_boundary = 1e-4,
  rho_boundary = 0.98
) {
  if (nrow(targets) == 0L) {
    return(logical(0))
  }
  target_class <- targets$target_class
  estimate <- targets$estimate
  is_sd <- profile_sd_boundary_rows(targets)
  is_correlation <- grepl("correlation", target_class)
  finite <- is.finite(estimate)
  (is_sd & finite & estimate < sd_boundary) |
    (is_correlation & finite & abs(estimate) > rho_boundary)
}

# Fraction of retained bootstrap draws sitting on the target's bound: zero for a
# random-effect or structured SD, +/-1 for a correlation. Residual and
# distributional scales are regular and never flagged, matching
# `wald_boundary_targets()`.
bootstrap_boundary_share_at <- function(
  values,
  target,
  sd_boundary = 1e-4,
  rho_boundary = 0.98
) {
  values <- values[is.finite(values)]
  if (length(values) < bootstrap_boundary_min_draws) {
    return(0)
  }
  target_class <- target$target_class
  if (profile_sd_boundary_rows(target)) {
    return(mean(values < sd_boundary))
  }
  if (grepl("correlation", target_class)) {
    return(mean(abs(values) > rho_boundary))
  }
  0
}

# A percentile interval built from draws that repeatedly hit the bound is
# reporting the bound, not the sampling distribution. Calibrated against three
# Gaussian random-intercept fits at R = 200, measuring the share of retained
# draws with SD < `sd_boundary` and the resulting interval:
#
#   true SD 0.00   43.0% at bound   [0.000, 0.496]   flag
#   true SD 0.25    5.0% at bound   [0.000, 0.248]   flag -- endpoint IS the bound
#   true SD 0.90    0.0% at bound   [0.667, 1.162]   quiet
#
# One in twenty separates the two regimes: at 5% the lower endpoint has already
# collapsed to zero, and at 0% it has not. The middle case is a true positive,
# not over-warning -- reporting "[0, 0.248]" for a standard deviation without
# saying the lower end is a constraint is exactly the failure this guards.
bootstrap_boundary_share <- 0.05

# A share is only a statistic when there are draws to compute it from. At
# `R = 2` a single boundary draw reads as 50%, which is noise, not evidence --
# the plumbing tests in `test-profile-targets.R` deliberately run that small.
# Below this many retained draws the flag stays silent; `bootstrap.n` is already
# reported on every row, so a caller who used too few replicates can see it.
bootstrap_boundary_min_draws <- 20L

drm_bootstrap_confint <- function(
  object,
  targets,
  level,
  R,
  seed,
  parallel,
  workers,
  refit_control,
  re_form = NA,
  sd_boundary = 1e-4,
  rho_boundary = 0.98
) {
  validate_profile_level(level)
  R <- validate_bootstrap_replicates(R)
  if (isTRUE(object$model$missing_predictor$enabled) ||
      isTRUE(object$model$missing_predictor2$enabled)) {
    cli::cli_abort(c(
      "Bootstrap intervals for modelled missing predictors require joint predictor simulation and missingness-preserving refits.",
      "i" = "That workflow is not implemented; use Wald or a validated profile target while joint bootstrap remains under development."
    ), class = "drmTMB_joint_bootstrap_unavailable")
  }
  plan <- bootstrap_parallel_plan(R, parallel = parallel, workers = workers)
  refit_control <- bootstrap_refit_control(refit_control)
  if (!identical(plan$backend, "none")) {
    # Outer bootstrap workers already use the cores; never nest multi-start
    # workers inside them (see ?drmTMB-parallel).
    refit_control$parallel <- "none"
  }
  if (nrow(targets) == 0L) {
    return(empty_confint_table(method = "bootstrap"))
  }
  if (is.null(object$data)) {
    cli::cli_abort(c(
      "Bootstrap confidence intervals require the fitted model data.",
      i = "Refit with {.code drm_control(keep_data = TRUE)} before using {.code method = \"bootstrap\"}."
    ))
  }

  # Parametric bootstrap resamples the DATA-GENERATING process, so random
  # effects must be redrawn per replicate (`re.form = NA`, the simulate()
  # default, lme4 meaning since #1487). Holding them at the fitted MAP would
  # leave between-group variability unresampled and the resulting intervals
  # anticonservative -- which is precisely the defect this argument exists to
  # avoid. `re_form = NULL` is offered as a documented escape hatch for
  # structures whose marginal draw is not yet implemented; it is NOT a neutral
  # choice. The default is not passed on, so simulate() does not print its
  # one-time re.form message for a caller who never set it.
  simulations <- if (identical(re_form, NA)) {
    stats::simulate(object, nsim = R, seed = seed)
  } else {
    stats::simulate(object, nsim = R, seed = seed, re.form = re_form)
  }
  target_names <- targets$parm
  worker <- function(index) {
    bootstrap_refit_one(
      object = object,
      simulations = simulations,
      index = index,
      target_names = target_names,
      refit_control = refit_control
    )
  }
  rows <- bootstrap_lapply(seq_len(R), worker, plan)
  draws <- do.call(rbind, rows)
  row.names(draws) <- NULL
  draws$bootstrap.requested <- R
  draws$bootstrap.seed <- bootstrap_seed_label(seed)
  draws$bootstrap.parallel <- plan$backend
  draws$bootstrap.workers <- plan$workers
  draws$refit.optimizer_preset <- refit_control$optimizer_preset
  draws$refit.se <- refit_control$se
  draws$refit.keep_tmb_object <- refit_control$keep_tmb_object
  draws$target_requested_n <- as.integer(
    ave(draws$target_available, draws$bootstrap, FUN = length)
  )
  draws$target_available_n <- as.integer(
    ave(draws$target_available, draws$bootstrap, FUN = sum)
  )
  draws$draw_value <- NA_real_
  draws$draw_used <- FALSE

  probs <- c((1 - level) / 2, (1 + level) / 2)
  intervals <- vector("list", nrow(targets))
  # Share of retained resamples that collapsed onto the parameter's bound. This
  # is the bootstrap's own boundary signal: the Wald test reads the point
  # estimate and the profile test discovers the bound while profiling, so
  # neither is available or appropriate here. A percentile interval whose draws
  # pile up at zero is reporting the bound, not the sampling distribution.
  boundary_fraction <- rep(0, nrow(targets))
  for (i in seq_len(nrow(targets))) {
    target <- targets[i, , drop = FALSE]
    target_index <- draws$parm == target$parm
    target_draws <- draws[target_index, , drop = FALSE]
    draw_values <- bootstrap_percentile_draws(target_draws, target)
    finite <- is.finite(draw_values) & target_draws$refit_ok
    draws$draw_value[target_index] <- draw_values
    draws$draw_used[target_index] <- finite
    n_ok <- sum(finite)
    failed <- nrow(target_draws) - n_ok
    if (n_ok < 2L) {
      lower <- NA_real_
      upper <- NA_real_
      status <- "bootstrap_unavailable"
      message <- "fewer than two successful bootstrap refits"
    } else {
      qs <- bootstrap_percentile_interval(
        target_draws = target_draws[finite, , drop = FALSE],
        target = target,
        probs = probs
      )
      lower <- qs[[1L]]
      upper <- qs[[2L]]
      status <- "bootstrap"
      # Test on the NATURAL scale, not `draw_values`: the latter is the link
      # scale whenever the percentile is taken there, and "an SD near zero" is
      # only meaningful untransformed. This matches `wald_boundary_targets()`,
      # which reads `targets$estimate`.
      boundary_fraction[[i]] <- bootstrap_boundary_share_at(
        target_draws$estimate[finite],
        target,
        sd_boundary = sd_boundary,
        rho_boundary = rho_boundary
      )
      message <- paste0(n_ok, "/", nrow(target_draws), " successful refits")
    }
    intervals[[i]] <- data.frame(
      parm = target$parm,
      level = level,
      lower = lower,
      upper = upper,
      scale = target$scale,
      transformation = target$transformation,
      tmb_parameter = target$tmb_parameter,
      index = target$index,
      method = "bootstrap",
      profile.engine = NA_character_,
      conf.status = status,
      profile.boundary = NA,
      profile.message = message,
      bootstrap.n = n_ok,
      bootstrap.failed = failed,
      bootstrap.parallel = plan$backend,
      bootstrap.workers = plan$workers,
      stringsAsFactors = FALSE
    )
  }
  out <- do.call(rbind, intervals)
  row.names(out) <- NULL

  # A resampled interval is no more trustworthy at a variance-component or
  # correlation boundary than a Wald or profile one; percentile bootstrap on a
  # parameter pinned near its bound inherits the same conditional
  # undercoverage. The Wald and profile routes each flag this, so leaving the
  # bootstrap route silent made it the one unguarded way to obtain a
  # clean-looking boundary interval for a target the other two warn about.
  # The boundary test is a property of the FIT, not of the interval method, so
  # the same detector serves all three routes.
  at_boundary <- !is.na(out$conf.status) &
    out$conf.status == "bootstrap" &
    is.finite(out$lower) &
    is.finite(out$upper) &
    boundary_fraction >= bootstrap_boundary_share
  out$conf.status[at_boundary] <- "bootstrap_at_boundary"
  if (any(at_boundary)) {
    n_boundary <- sum(at_boundary)
    cli::cli_warn(
      c(
        "{cli::qty(n_boundary)}Bootstrap interval{?s} for {.val {out$parm[at_boundary]}} {?is/are} at a variance-component or correlation boundary.",
        "!" = "{cli::qty(n_boundary)}Bootstrap coverage is unreliable there, so {?this interval is/these intervals are} not a reliable {.arg level} interval.",
        "i" = "See the {.strong Boundary intervals} section of {.code ?confint.drmTMB}. Resampling does not repair a boundary."
      ),
      class = "drmTMB_bootstrap_boundary_warning"
    )
  }

  attr(out, "bootstrap.diagnostics") <- draws
  drm_as_confint_table(out)
}

validate_bootstrap_replicates <- function(R) {
  if (
    !is.numeric(R) ||
      length(R) != 1L ||
      is.na(R) ||
      !is.finite(R) ||
      R < 1L ||
      R != as.integer(R)
  ) {
    cli::cli_abort("{.arg R} must be a positive whole number.")
  }
  as.integer(R)
}

bootstrap_seed_label <- function(seed) {
  if (is.null(seed)) {
    return(NA_character_)
  }
  paste(seed, collapse = ",")
}

bootstrap_parallel_plan <- function(R, parallel, workers) {
  if (
    !is.character(parallel) ||
      length(parallel) != 1L ||
      is.na(parallel) ||
      !parallel %in% c("none", "multicore", "cluster")
  ) {
    cli::cli_abort(
      "{.arg parallel} must be one of {.val none}, {.val multicore}, or {.val cluster}."
    )
  }
  workers <- resolve_parallel_workers(workers, parallel)
  if (identical(parallel, "multicore") && .Platform$OS.type == "windows") {
    cli::cli_abort(c(
      "{.code parallel = \"multicore\"} is not available on Windows.",
      i = "Use {.code parallel = \"cluster\"} for socket (PSOCK) workers."
    ))
  }
  actual_workers <- if (identical(parallel, "none")) {
    1L
  } else {
    min(10L, R, workers)
  }
  list(backend = parallel, workers = actual_workers)
}

resolve_parallel_workers <- function(workers, parallel) {
  if (is.null(workers)) {
    if (identical(parallel, "none")) {
      return(1L)
    }
    cores <- suppressWarnings(parallel::detectCores(logical = FALSE))
    if (!is.finite(cores) || is.na(cores) || cores < 1L) {
      cores <- suppressWarnings(parallel::detectCores(logical = TRUE))
    }
    if (!is.finite(cores) || is.na(cores) || cores < 1L) {
      cores <- 2L
    }
    return(max(1L, as.integer(floor(cores / 2))))
  }
  if (
    !is.numeric(workers) ||
      length(workers) != 1L ||
      is.na(workers) ||
      !is.finite(workers) ||
      workers < 1L ||
      workers != as.integer(workers)
  ) {
    cli::cli_abort("{.arg workers} must be a positive whole number or NULL.")
  }
  as.integer(workers)
}

profile_parallel_plan <- function(n_task, parallel, workers) {
  bootstrap_parallel_plan(n_task, parallel = parallel, workers = workers)
}

bootstrap_refit_missing_control <- function(object) {
  missing_data <- object$model$missing_data
  if (!is.list(missing_data)) {
    return(NULL)
  }
  if (!identical(missing_data$response_policy, "include")) {
    return(NULL)
  }
  engine <- missing_data$engine
  if (!is.character(engine) || length(engine) != 1L || is.na(engine)) {
    engine <- "laplace"
  }
  miss_control(response = "include", predictor = "fail", engine = engine)
}

bootstrap_refit_control <- function(refit_control) {
  if (is.null(refit_control)) {
    return(drm_control(
      se = FALSE,
      keep_tmb_object = FALSE,
      optimizer_preset = "default"
    ))
  }
  drm_parse_control(refit_control)
}

profile_lapply <- function(indices, worker, plan) {
  drm_parallel_lapply(indices, worker, plan)
}

bootstrap_lapply <- function(indices, worker, plan) {
  drm_parallel_lapply(indices, worker, plan)
}

# One dispatcher for the "none" | "multicore" | "cluster" backends. Workers
# receive the same inputs as the serial lapply(), so every backend returns
# the same values. A fitted TMB object shipped to a socket worker arrives with
# a null external pointer; TMB re-tapes it on first use from the serialized
# data, parameters, and `last.par` state (TMB::MakeADFun's isNullPointer()
# check), so profile workers reproduce the serial curve without refitting.
drm_parallel_lapply <- function(indices, worker, plan) {
  if (identical(plan$backend, "none") || identical(plan$workers, 1L)) {
    return(lapply(indices, worker))
  }
  if (identical(plan$backend, "cluster")) {
    return(drm_cluster_lapply(indices, worker, plan$workers))
  }
  drm_mclapply_stop_on_error(
    parallel::mclapply(indices, worker, mc.cores = plan$workers)
  )
}

drm_cluster_lapply <- function(indices, worker, workers) {
  cl <- parallel::makePSOCKcluster(workers)
  on.exit(parallel::stopCluster(cl), add = TRUE)
  parallel::clusterCall(cl, drm_cluster_worker_init, drm_cluster_lib_paths())
  parallel::parLapply(cl, indices, worker)
}

# The library holding the drmTMB build this session loaded goes first, so
# socket workers load the same build even when it was attached with
# `library(drmTMB, lib.loc = ...)` rather than from `.libPaths()`.
drm_cluster_lib_paths <- function() {
  pkg_path <- tryCatch(
    getNamespaceInfo("drmTMB", "path"),
    error = function(err) NA_character_
  )
  own_lib <- if (is.character(pkg_path) && !is.na(pkg_path)) dirname(pkg_path)
  unique(c(own_lib, .libPaths()))
}

# Runs on each socket worker: use the caller's library paths so the worker
# loads the same drmTMB build, then attach its namespace and DLL.
drm_cluster_worker_init <- function(lib_paths) {
  .libPaths(lib_paths)
  suppressPackageStartupMessages(loadNamespace("drmTMB"))
  invisible(NULL)
}

# parallel::mclapply() turns a worker error into a "try-error" element and only
# warns.  The serial lapply() path aborts on the same error, so re-raise the
# first worker error to keep both paths failing the same way.
drm_mclapply_stop_on_error <- function(results) {
  failed <- vapply(results, inherits, logical(1L), what = "try-error")
  if (any(failed)) {
    err <- attr(results[[which(failed)[[1L]]]], "condition")
    if (inherits(err, "condition")) {
      stop(err)
    }
    stop(as.character(results[[which(failed)[[1L]]]]), call. = FALSE)
  }
  results
}

bootstrap_refit_one <- function(
  object,
  simulations,
  index,
  target_names,
  refit_control
) {
  out <- bootstrap_empty_draws(index, target_names)
  data <- bootstrap_response_data(object, simulations, index)
  refit <- tryCatch(
    {
      bootstrap_weights <- object$model$weights
      arguments <- list(
        formula = object$formula,
        family = object$family,
        data = data,
        control = refit_control
      )
      if (!object$model$model_type %in% c("biv_lognormal", "biv_student")) {
        arguments$weights <- bootstrap_weights
      }
      # Replicates now carry the seed fit's response NA mask (#1188), so they
      # must also be refitted under the seed fit's response policy. Under the
      # default `"drop"` an `"include"` fit's replicates would silently change
      # estimand: `"include"` keeps a masked row inside any latent structure
      # spanning rows, `"drop"` removes the row entirely.
      refit_missing <- bootstrap_refit_missing_control(object)
      if (!is.null(refit_missing)) {
        arguments$missing <- refit_missing
      }
      do.call(drmTMB, arguments)
    },
    error = function(err) err
  )
  if (inherits(refit, "error")) {
    out$refit_status <- "refit_error"
    out$refit_message <- conditionMessage(refit)
    return(out)
  }
  refit_ok <- isTRUE(refit$opt$convergence == 0L)
  refit_targets <- drm_profile_targets(refit)
  matched <- match(target_names, refit_targets$parm)
  has_target <- !is.na(matched)
  out$refit_convergence <- refit$opt$convergence
  out$refit_converged <- refit_ok
  out$target_available <- has_target
  out$refit_ok <- refit_ok & has_target
  out$refit_message <- if (refit_ok) "ok" else refit$opt$message
  out$refit_status <- ifelse(
    !refit_ok,
    "refit_nonconverged",
    ifelse(has_target, "ok", "target_missing")
  )
  out$estimate[has_target] <- refit_targets$estimate[matched[has_target]]
  out$link_estimate[has_target] <-
    refit_targets$link_estimate[matched[has_target]]
  out$estimate_finite <- is.finite(out$estimate)
  out$link_estimate_finite <- is.finite(out$link_estimate)
  out
}

bootstrap_empty_draws <- function(index, target_names) {
  data.frame(
    bootstrap = index,
    parm = target_names,
    estimate = NA_real_,
    link_estimate = NA_real_,
    refit_ok = FALSE,
    refit_convergence = NA_integer_,
    refit_converged = FALSE,
    target_available = FALSE,
    estimate_finite = FALSE,
    link_estimate_finite = FALSE,
    refit_status = "not_run",
    refit_message = "not run",
    stringsAsFactors = FALSE
  )
}

bootstrap_percentile_interval <- function(target_draws, target, probs) {
  if (bootstrap_uses_link_percentiles(target)) {
    link_quantiles <- stats::quantile(
      target_draws$link_estimate,
      probs = probs,
      names = FALSE,
      type = 8
    )
    return(profile_transform_interval(link_quantiles, target))
  }
  stats::quantile(
    target_draws$estimate,
    probs = probs,
    names = FALSE,
    type = 8
  )
}

bootstrap_percentile_draws <- function(target_draws, target) {
  if (bootstrap_uses_link_percentiles(target)) {
    return(target_draws$link_estimate)
  }
  target_draws$estimate
}

bootstrap_uses_link_percentiles <- function(target) {
  identical(target$transformation[[1L]], "exp")
}

# Re-apply the seed fit's response NA mask to a simulated replicate draw
# (#1188). `simulate()` draws over the FULL design, so a replicate built by
# overwriting the response column wholesale carries no missing values at all
# and refits on MORE rows than the seed fit ever observed. A bootstrap whose
# replicates are richer than the original necessarily understates uncertainty,
# and the narrowing grows with the missing fraction. Restoring the mask keeps
# every replicate on the seed fit's observed row count.
bootstrap_restore_response_mask <- function(values, missing_mask) {
  if (length(missing_mask) != length(values)) {
    return(values)
  }
  values[missing_mask] <- NA
  values
}

bootstrap_response_data <- function(object, simulations, index) {
  data <- object$data
  if (object$model$model_type %in% c("biv_gaussian", "biv_lognormal")) {
    response_names <- bivariate_response_names(object)
    sim_y1 <- paste0("sim_", index, "_y1")
    sim_y2 <- paste0("sim_", index, "_y2")
    if (!all(c(sim_y1, sim_y2) %in% names(simulations))) {
      cli::cli_abort(
        "Internal error: bivariate bootstrap simulations are missing response columns."
      )
    }
    mask_y1 <- is.na(data[[response_names[[1L]]]])
    mask_y2 <- is.na(data[[response_names[[2L]]]])
    data[[response_names[[1L]]]] <- bootstrap_restore_response_mask(
      simulations[[sim_y1]],
      mask_y1
    )
    data[[response_names[[2L]]]] <- bootstrap_restore_response_mask(
      simulations[[sim_y2]],
      mask_y2
    )
    return(data)
  }
  if (identical(object$model$model_type, "binomial")) {
    denominator <- object$model$denominator
    if (
      is.list(denominator) &&
        identical(denominator$encoding, "cbind(successes, failures)")
    ) {
      sim_col <- paste0("sim_", index)
      if (!sim_col %in% names(simulations)) {
        cli::cli_abort(
          "Internal error: bootstrap simulations are missing response column {.val {sim_col}}."
        )
      }
      # A cbind() response is missing when EITHER cell is missing, so the mask
      # is the union of the two columns' original NA patterns; the failure
      # column then inherits it through NA arithmetic.
      response_mask <- is.na(data[[denominator$success_name]]) |
        is.na(data[[denominator$failure_name]])
      successes <- bootstrap_restore_response_mask(
        simulations[[sim_col]],
        response_mask
      )
      data[[denominator$success_name]] <- successes
      data[[denominator$failure_name]] <- denominator$trials - successes
      return(data)
    }
  }
  response <- response_name_from_model_frame(
    object,
    "mu",
    fallback = NA_character_
  )
  if (
    !is.character(response) ||
      length(response) != 1L ||
      is.na(response) ||
      !response %in% names(data)
  ) {
    cli::cli_abort(
      "Bootstrap confidence intervals require a stored response column in the fitted data."
    )
  }
  sim_col <- paste0("sim_", index)
  if (!sim_col %in% names(simulations)) {
    cli::cli_abort(
      "Internal error: bootstrap simulations are missing response column {.val {sim_col}}."
    )
  }
  data[[response]] <- bootstrap_restore_response_mask(
    simulations[[sim_col]],
    is.na(data[[response]])
  )
  data
}

wald_supported_targets <- function(targets) {
  targets$target_type == "direct" &
    targets$target_class %in%
      c(
        "fixed-effect",
        "distributional-scale",
        "random-effect-sd",
        "random-effect-correlation",
        "residual-correlation"
      ) &
    targets$transformation %in%
      c("linear_predictor", "exp", "plogis", "tanh", "rho12_tanh")
}

bootstrap_supported_targets <- function(targets) {
  wald_supported_targets(targets)
}

profile_match_bootstrap_targets <- function(targets, parm) {
  unsupported <- profile_bootstrap_requested_unsupported_targets(targets, parm)
  if (nrow(unsupported) > 0L) {
    abort_unsupported_bootstrap_targets(unsupported)
  }
  if (is.numeric(parm)) {
    if (
      any(!is.finite(parm)) ||
        any(parm != as.integer(parm)) ||
        any(parm < 1L | parm > nrow(targets))
    ) {
      cli::cli_abort(
        "{.arg parm} numeric values must select rows from the available confidence-interval targets."
      )
    }
    return(targets[as.integer(parm), , drop = FALSE])
  }
  targets <- targets[bootstrap_supported_targets(targets), , drop = FALSE]
  profile_match_confint_targets(targets, parm, fixed_only = FALSE)
}

profile_bootstrap_requested_unsupported_targets <- function(targets, parm) {
  if (is.null(parm)) {
    return(targets[0L, , drop = FALSE])
  }
  if (is.numeric(parm)) {
    if (
      any(!is.finite(parm)) ||
        any(parm != as.integer(parm)) ||
        any(parm < 1L | parm > nrow(targets))
    ) {
      return(targets[0L, , drop = FALSE])
    }
    requested <- targets[as.integer(parm), , drop = FALSE]
    return(requested[!bootstrap_supported_targets(requested), , drop = FALSE])
  }
  if (!is.character(parm)) {
    return(targets[0L, , drop = FALSE])
  }

  aliases <- paste0(targets$dpar, ":", targets$term)
  expanded <- profile_expand_confint_target_sets(targets, parm)
  index <- match(expanded, targets$parm)
  missing_index <- is.na(index)
  if (any(missing_index)) {
    index[missing_index] <- match(expanded[missing_index], aliases)
  }
  index <- unique(index[!is.na(index)])
  if (length(index) == 0L) {
    return(targets[0L, , drop = FALSE])
  }
  requested <- targets[index, , drop = FALSE]
  requested[!bootstrap_supported_targets(requested), , drop = FALSE]
}

abort_unsupported_bootstrap_targets <- function(targets) {
  labels <- paste(targets$parm, collapse = ", ")
  target_types <- paste(unique(targets$target_type), collapse = ", ")
  notes <- paste(unique(targets$profile_note), collapse = ", ")
  cli::cli_abort(c(
    "Bootstrap confidence intervals currently support direct fitted-object targets only.",
    x = "Unsupported bootstrap target(s): {labels}.",
    i = "Requested target type(s): {target_types}; inventory note(s): {notes}.",
    i = "Use {.fn profile_targets} to inspect {.code target_type} and {.code profile_note} before choosing bootstrap targets."
  ))
}

profile_target_opt_positions <- function(object, targets) {
  opt_names <- names(object$opt$par)
  vapply(
    seq_len(nrow(targets)),
    function(i) {
      target <- targets[i, , drop = FALSE]
      internal <- target$tmb_parameter[[1L]]
      index <- target$index[[1L]]
      if (is.na(internal) || is.na(index)) {
        return(NA_integer_)
      }
      hits <- which(opt_names == internal)
      if (length(hits) < index) {
        return(NA_integer_)
      }
      hits[[index]]
    },
    integer(1L)
  )
}

profile_wald_standard_errors <- function(variances) {
  se <- rep(NA_real_, length(variances))
  ok <- is.finite(variances) & variances >= -sqrt(.Machine$double.eps)
  se[ok] <- sqrt(pmax(variances[ok], 0))
  se
}

empty_confint_table <- function(method = character()) {
  out <- data.frame(
    parm = character(),
    level = numeric(),
    lower = numeric(),
    upper = numeric(),
    scale = character(),
    transformation = character(),
    tmb_parameter = character(),
    index = integer(),
    method = rep(method, 0L),
    profile.engine = character(),
    conf.status = character(),
    profile.boundary = logical(),
    profile.message = character(),
    stringsAsFactors = FALSE
  )
  drm_as_confint_table(out)
}

#' Coerce a drmTMB confidence-interval table to a matrix
#'
#' Returns a two-column numeric matrix with row names taken from `parm`, in the
#' same shape as [stats::confint()] for ordinary linear models.
#'
#' @param x A `drm_confint` object from [confint.drmTMB()].
#' @param ... Ignored.
#' @return A numeric matrix with two columns (lower and upper interval limits).
#' @export
as.matrix.drm_confint <- function(x, ...) {
  if (!nrow(x)) {
    return(matrix(numeric(), nrow = 0L, ncol = 2L))
  }
  level <- x$level[[1L]]
  alpha <- (1 - level) / 2
  pct <- function(p) paste0(format(100 * p, trim = TRUE, scientific = FALSE), " %")
  mat <- cbind(x$lower, x$upper)
  colnames(mat) <- c(pct(alpha), pct(1 - alpha))
  rownames(mat) <- x$parm
  mat
}

drm_as_confint_table <- function(x) {
  class(x) <- c("drm_confint", "data.frame")
  x
}

drm_profile_target_confint <- function(
  object,
  target,
  level,
  trace,
  profile_engine = c("tmbprofile", "auto", "endpoint"),
  endpoint_plan = profile_serial_plan(),
  profile_endpoint_max_eval = NULL,
  ...
) {
  profile_engine <- match.arg(profile_engine)
  implemented_classes <- c(
    "fixed-effect",
    "distributional-scale",
    "random-effect-sd",
    "random-effect-correlation",
    "residual-correlation"
  )

  if (identical(target$target_class[[1L]], "ordinal-cutpoint")) {
    if (!identical(profile_engine, "auto")) {
      cli::cli_abort(c(
        "Ordered cutpoint intervals use drmTMB's constrained profile engine.",
        i = "Use {.code profile_engine = \"auto\"}; {.code endpoint} and {.code tmbprofile} profile raw TMB coordinates, not cumulative cutpoints."
      ))
    }
    if (!isTRUE(target$profile_ready[[1L]])) {
      cli::cli_abort(c(
        "Profile target {.val {target$parm}} is not ready for constrained profiling.",
        i = "Inventory note: {.val {target$profile_note}}."
      ))
    }
    return(drm_profile_ordinal_cutpoint_confint(object, target, level))
  }

  if (identical(target$target_class[[1L]], "ordinal-cutpoint-internal")) {
    cli::cli_abort(c(
      "Raw {.val ordinal:theta_ord:<label>} coordinates are internal ordinal diagnostics, not interval targets.",
      i = "Use the public cumulative cutpoint target {.val {paste0(\"ordinal:cutpoint:\", target$term[[1L]])}}."
    ))
  }

  # The endpoint engine must degrade to a per-row failure rather than aborting a
  # mixed-target batch. Handle it before the shared readiness / class checks
  # below (which cli_abort() and are the intended contract for the tmbprofile
  # engine) so an unsupported or not-ready target under profile_engine =
  # "endpoint" returns a failed row instead of taking down the whole confint().
  if (identical(profile_engine, "endpoint")) {
    if (!profile_endpoint_target_supported(target)) {
      return(drm_profile_failed_confint_row(
        target = target,
        level = level,
        profile_engine = "endpoint",
        message = "endpoint engine unsupported for this target class"
      ))
    }
    endpoint <- tryCatch(
      drm_profile_target_endpoint_confint(
        object = object,
        target = target,
        level = level,
        endpoint_plan = endpoint_plan,
        profile_endpoint_max_eval = profile_endpoint_max_eval
      ),
      error = function(err) err
    )
    if (inherits(endpoint, "error")) {
      return(drm_profile_failed_confint_row(
        target = target,
        level = level,
        profile_engine = "endpoint",
        message = conditionMessage(endpoint)
      ))
    }
    return(endpoint)
  }

  if (!isTRUE(target$profile_ready)) {
    cli::cli_abort(c(
      "Profile target {.val {target$parm}} is not ready for direct profiling.",
      i = "Inventory note: {.val {target$profile_note}}."
    ))
  }
  if (!target$target_class %in% implemented_classes) {
    cli::cli_abort(c(
      "Profile intervals are implemented for direct fixed-effect, constant distributional-scale, random-effect SD, random-effect correlation, and constant residual-correlation targets.",
      i = "Requested {.val {target$parm}} has target class {.val {target$target_class}}."
    ))
  }

  if (
    identical(profile_engine, "auto") &&
      profile_endpoint_target_supported(target)
  ) {
    endpoint <- tryCatch(
      drm_profile_target_endpoint_confint(
        object = object,
        target = target,
        level = level,
        endpoint_plan = endpoint_plan,
        profile_endpoint_max_eval = profile_endpoint_max_eval
      ),
      error = function(err) err
    )
    if (!inherits(endpoint, "error")) {
      return(endpoint)
    }
    if (!is.null(profile_endpoint_max_eval)) {
      return(drm_profile_failed_confint_row(
        target = target,
        level = level,
        profile_engine = "endpoint",
        message = conditionMessage(endpoint)
      ))
    }
  }

  profiled <- tryCatch(
    drm_profile_target_tmbprofile_confint(
      object = object,
      target = target,
      level = level,
      trace = trace,
      ...
    ),
    error = function(err) err
  )
  if (inherits(profiled, "error")) {
    return(drm_profile_failed_confint_row(
      target = target,
      level = level,
      profile_engine = "tmbprofile",
      message = conditionMessage(profiled)
    ))
  }
  profiled
}

drm_profile_failed_confint_row <- function(
  target,
  level,
  profile_engine,
  message,
  profile_boundary = NA
) {
  data.frame(
    parm = target$parm,
    level = level,
    lower = NA_real_,
    upper = NA_real_,
    scale = target$scale,
    transformation = target$transformation,
    tmb_parameter = target$tmb_parameter,
    index = target$index,
    method = "profile",
    profile.engine = profile_engine,
    conf.status = "profile_failed",
    profile.boundary = profile_boundary,
    profile.message = message,
    stringsAsFactors = FALSE
  )
}

# TMB::tmbprofile() can corrupt a flat-ridge bracket search with one isolated
# low objective value before it resets to the fitted-value neighbourhood in the
# opposite direction. This is a trace pattern, not an objective-gap cutoff:
# the preceding sweep is monotone, the low point lies below that whole sweep,
# and the following value returns to the sweep's range. Ordinary flat profiles
# and genuine lower basins do not have this three-part signature.
drm_tmbprofile_bracket_overflow <- function(
  profile,
  baseline = NULL,
  min_sweep_points = 3L
) {
  profile <- as.data.frame(profile)
  values <- profile$value
  if (is.null(baseline)) {
    baseline <- values[[1L]]
  }
  if (
    !is.numeric(values) ||
      length(values) < min_sweep_points + 2L ||
      any(!is.finite(values)) ||
      length(baseline) != 1L ||
      !is.finite(baseline)
  ) {
    return(FALSE)
  }
  sentinel <- seq.int(min_sweep_points + 1L, length(values) - 1L)
  any(vapply(sentinel, function(index) {
    sweep <- values[(index - min_sweep_points):(index - 1L)]
    reset <- values[[index + 1L]]
    all(diff(sweep) >= 0) &&
      values[[index]] < min(sweep) &&
      values[[index]] < baseline &&
      reset >= min(sweep) &&
      reset <= max(sweep)
  }, logical(1L)))
}

drm_profile_target_tmbprofile_confint <- function(
  object,
  target,
  level,
  trace,
  ...
) {
  lincomb <- profile_lincomb(object, target)
  prof <- drm_tmbprofile(
    object = object,
    target_name = target$parm,
    lincomb = lincomb,
    trace = trace,
    ...
  )
  clamp_trace <- drm_profile_direct_sd_clamp_trace(object, prof)
  if (!identical(clamp_trace$status, "not_applicable")) {
    if (!identical(clamp_trace$status, "ok")) {
      return(drm_profile_clamp_limited_confint_row(
        target = target,
        level = level,
        message = clamp_trace$status
      ))
    }
  }
  if (drm_tmbprofile_bracket_overflow(
    prof,
    baseline = unname(object$opt$objective)
  )) {
    return(drm_profile_failed_confint_row(
      target = target,
      level = level,
      profile_engine = "tmbprofile",
      message = "tmbprofile_bracket_overflow",
      profile_boundary = TRUE
    ))
  }
  ci <- drm_tmbprofile_confint(prof, target_name = target$parm, level = level)
  interval <- profile_transform_interval(
    c(unname(ci[1L, "lower"]), unname(ci[1L, "upper"])),
    target
  )
  # `TMB:::confint.tmbprofile` anchors at which.min(prof$value) -- the observed
  # grid minimum -- not at the fitted optimum. If the warm-started inner solve
  # inside `TMB::tmbprofile` found a lower objective than the fit, the anchor
  # has moved off the MLE (issue #1009). Both quantities are already in hand,
  # so this costs no extra model evaluations.
  profile_values <- prof$value[is.finite(prof$value)]
  profile_min_objective <- if (length(profile_values)) {
    min(profile_values)
  } else {
    NA_real_
  }
  diagnostics <- profile_interval_diagnostics(
    interval,
    transformation = target$transformation,
    estimate = target$estimate,
    profile_min_objective = profile_min_objective,
    fit_objective = unname(object$opt$objective)
  )
  conf_status <- profile_conf_status_from_diagnostics(diagnostics)
  if (identical(conf_status, "profile_failed")) {
    interval <- c(NA_real_, NA_real_)
  }

  data.frame(
    parm = target$parm,
    level = level,
    lower = interval[[1L]],
    upper = interval[[2L]],
    scale = target$scale,
    transformation = target$transformation,
    tmb_parameter = target$tmb_parameter,
    index = target$index,
    method = "profile",
    profile.engine = "tmbprofile",
    conf.status = conf_status,
    profile.boundary = diagnostics$boundary,
    profile.message = diagnostics$message,
    stringsAsFactors = FALSE
  )
}

drm_profile_clamp_limited_confint_row <- function(target, level, message) {
  data.frame(
    parm = target$parm,
    level = level,
    lower = NA_real_,
    upper = NA_real_,
    scale = target$scale,
    transformation = target$transformation,
    tmb_parameter = target$tmb_parameter,
    index = target$index,
    method = "profile",
    profile.engine = "tmbprofile",
    conf.status = "clamp_limited",
    profile.boundary = TRUE,
    profile.message = message,
    stringsAsFactors = FALSE
  )
}

drm_profile_target_endpoint_confint <- function(
  object,
  target,
  level,
  endpoint_plan = profile_serial_plan(),
  profile_endpoint_max_eval = NULL
) {
  result <- drm_profile_endpoint_result(
    object = object,
    target = target,
    level = level,
    endpoint_plan = endpoint_plan,
    max_eval = profile_endpoint_max_eval
  )
  interval <- result$interval
  diagnostics <- profile_interval_diagnostics(
    interval,
    transformation = target$transformation,
    estimate = target$estimate
  )
  conf_status <- profile_conf_status_from_diagnostics(diagnostics)
  if (identical(conf_status, "profile_failed")) {
    interval <- c(NA_real_, NA_real_)
  }

  data.frame(
    parm = target$parm,
    level = level,
    lower = interval[[1L]],
    upper = interval[[2L]],
    scale = target$scale,
    transformation = target$transformation,
    tmb_parameter = target$tmb_parameter,
    index = target$index,
    method = "profile",
    profile.engine = "endpoint",
    conf.status = conf_status,
    profile.boundary = diagnostics$boundary,
    profile.message = diagnostics$message,
    stringsAsFactors = FALSE
  )
}

profile_conf_status_from_diagnostics <- function(diagnostics) {
  # `profile_below_fit_objective` carries a variable gap-magnitude suffix
  # (see `profile_interval_diagnostics()`), so match on the stable prefix
  # rather than exact equality.
  if (
    identical(diagnostics$message, "nonfinite_interval") ||
      startsWith(diagnostics$message, "profile_below_fit_objective") ||
      identical(diagnostics$message, "point_estimate_outside_interval")
  ) {
    return("profile_failed")
  }
  "profile"
}

drm_profile_endpoint_result <- function(
  object,
  target,
  level,
  root_tol = 1e-4,
  max_bracket_steps = 40L,
  endpoint_plan = profile_serial_plan(),
  max_eval = NULL
) {
  if (!profile_endpoint_target_supported(target)) {
    cli::cli_abort(c(
      "Profile endpoint engine is only implemented for direct scalar scale, SD, and correlation targets.",
      i = "Requested {.val {target$parm}} has target class {.val {target$target_class}} and transformation {.val {target$transformation}}."
    ))
  }
  if (is.null(object$obj)) {
    cli::cli_abort(c(
      "Profile confidence intervals require the TMB object retained in {.code fit$obj}.",
      i = "Refit with {.code drm_control(keep_tmb_object = TRUE)} before using {.code method = \"profile\"}."
    ))
  }

  position <- profile_target_opt_positions(object, target)
  if (!is.finite(position) || is.na(position)) {
    cli::cli_abort(c(
      "Profile target {.val {target$parm}} cannot be mapped to an optimized scalar parameter.",
      i = "Check {.code profile_targets(fit)} before using {.code profile_engine = \"endpoint\"}."
    ))
  }
  position <- as.integer(position)

  drm_pin_tmb_object_to_optimum(object$obj, object$opt, object$tmb_state)
  theta_hat <- unname(object$opt$par[[position]])
  nll_hat <- unname(object$opt$objective)
  cutoff <- stats::qchisq(level, df = 1) / 2
  curvature_se <- profile_endpoint_curvature_se(object, position)
  control <- if (is.list(object$control) && is.list(object$control$optimizer)) {
    object$control$optimizer
  } else {
    list()
  }
  control <- profile_endpoint_inner_control(control)

  endpoint_worker <- function(direction) {
    evaluator <- profile_endpoint_evaluator(
      object = object,
      target_position = position,
      control = control
    )
    profile_endpoint_crossing(
      evaluator = evaluator,
      theta_hat = theta_hat,
      nll_hat = nll_hat,
      cutoff = cutoff,
      direction = direction,
      root_tol = root_tol,
      max_bracket_steps = max_bracket_steps,
      target_name = target$parm,
      curvature_se = curvature_se,
      max_eval = max_eval,
      allow_lower_boundary = identical(target$transformation, "exp")
    )
  }
  crossings <- profile_lapply(c(-1L, 1L), endpoint_worker, endpoint_plan)
  lower <- crossings[[1L]]
  upper <- crossings[[2L]]

  link_interval <- c(lower$theta, upper$theta)
  interval <- profile_transform_interval(link_interval, target)
  list(
    link_interval = link_interval,
    interval = interval,
    cutoff = cutoff,
    lower_root_error = lower$root_error,
    upper_root_error = upper$root_error,
    lower_n_eval = lower$n_eval,
    upper_n_eval = upper$n_eval,
    n_eval = lower$n_eval + upper$n_eval,
    curvature_se = curvature_se,
    lower_initial_step = lower$initial_step,
    upper_initial_step = upper$initial_step,
    lower_bracket_step = lower$bracket_step,
    upper_bracket_step = upper$bracket_step,
    lower_step_source = lower$step_source,
    upper_step_source = upper$step_source,
    endpoint_parallel = endpoint_plan$backend,
    endpoint_workers = endpoint_plan$workers,
    target_position = position
  )
}

profile_endpoint_target_supported <- function(target) {
  nrow(target) == 1L &&
    isTRUE(target$profile_ready[[1L]]) &&
    identical(target$target_type[[1L]], "direct") &&
    target$target_class[[1L]] %in%
      c(
        "distributional-scale",
        "random-effect-sd",
        "random-effect-correlation",
        "residual-correlation"
      ) &&
    target$transformation[[1L]] %in% c("exp", "tanh", "rho12_tanh")
}

# Reconstruct the internal ordered-cutpoint parameterization while fixing one
# cumulative cutpoint. For j > 1, theta_ord[j] is a log gap rather than the
# cumulative threshold itself, so profiling it with TMB::tmbprofile would answer
# a different question. Holding the later log gaps fixed and solving theta_ord[1]
# from c_j keeps every cutpoint ordered without changing the likelihood.
ordinal_cutpoint_constrained_par <- function(par_free, par_template, theta_positions, index, value) {
  theta_positions <- as.integer(theta_positions)
  index <- as.integer(index)
  if (index < 1L || index > length(theta_positions)) {
    cli::cli_abort("Internal error: ordinal cutpoint index is outside theta_ord.")
  }
  free_positions <- setdiff(seq_along(par_template), theta_positions[[1L]])
  if (length(par_free) != length(free_positions)) {
    cli::cli_abort("Internal error: constrained ordinal profile free parameter length is inconsistent.")
  }
  out <- par_template
  out[free_positions] <- par_free
  theta <- out[theta_positions]
  if (index == 1L) {
    theta[[1L]] <- value
  } else {
    backwards <- theta[seq.int(2L, index)]
    theta[[1L]] <- value - sum(exp(backwards))
  }
  out[theta_positions] <- theta
  out
}

ordinal_cutpoint_profile_evaluator <- function(object, target, control) {
  theta_positions <- which(names(object$opt$par) == "theta_ord")
  if (length(theta_positions) != length(object$ordinal$theta_raw)) {
    cli::cli_abort("Ordinal cutpoint profile cannot map theta_ord to the optimized parameter vector.")
  }
  par0 <- object$opt$par
  index <- as.integer(target$index[[1L]])
  free_positions <- setdiff(seq_along(par0), theta_positions[[1L]])
  start_free <- par0[free_positions]
  evaluate <- function(value, start) {
    compose <- function(pfree) {
      ordinal_cutpoint_constrained_par(
        par_free = pfree,
        par_template = par0,
        theta_positions = theta_positions,
        index = index,
        value = value
      )
    }
    fn_free <- function(pfree) object$obj$fn(compose(pfree))
    gr_free <- function(pfree) {
      full <- compose(pfree)
      gradient <- object$obj$gr(full)
      out <- gradient[free_positions]
      if (index > 1L) {
        theta <- full[theta_positions]
        affected <- theta_positions[seq.int(2L, index)]
        affected_free <- match(affected, free_positions)
        out[affected_free] <- out[affected_free] -
          gradient[[theta_positions[[1L]]]] * exp(theta[seq.int(2L, index)])
      }
      out
    }
    opt <- stats::nlminb(start, fn_free, gr_free, control = control)
    # #1144: the free optimum is Newton-polished (`drm_fit_spec()`), but this
    # constrained cutpoint solve stopped wherever `nlminb` alone stopped -- on
    # a random-intercept ordinal fit that is a gradient of ~1e-3 to 2e-3 at
    # BOTH endpoints against ~1e-8 at the fitted optimum, the same asymmetry
    # that biased the main endpoint solve (#1130, `profile_endpoint_evaluator`).
    # Polish both endpoints the same way, under the same `newton_polish`
    # control, so the constrained nll is compared like with like. The
    # `PROFILE_ENDPOINT_GRADIENT_TOL` guard below is unchanged.
    if (isTRUE(object$control$newton_polish)) {
      opt <- drm_newton_polish(opt, fn_free, gr_free)
    }
    if (is.finite(opt$objective) &&
      opt$objective < (object$opt$objective - 1e-3)) {
      cli::cli_abort(c(
        "Constrained ordinal-cutpoint profile fell below the fitted objective.",
        i = "This fails closed because the fitted optimum is not the profile minimum.",
        i = "Target {.val {target$parm}} fixed at {format(value, digits = 6)}."
      ))
    }
    gradient <- tryCatch(gr_free(opt$par), error = function(err) NA_real_)
    max_abs_gradient <- suppressWarnings(max(abs(gradient), na.rm = TRUE))
    if (!is.finite(max_abs_gradient)) max_abs_gradient <- NA_real_
    if (!profile_endpoint_convergence_accepted(opt, max_abs_gradient)) {
      cli::cli_abort(c(
        "Constrained ordinal-cutpoint optimization failed.",
        i = "Target {.val {target$parm}} fixed at {format(value, digits = 6)}.",
        i = "Optimizer convergence code: {format(opt$convergence)}.",
        i = "Maximum absolute gradient: {format(max_abs_gradient, digits = 4)}."
      ))
    }
    list(nll = unname(opt$objective), par = opt$par)
  }
  list(
    evaluate = evaluate,
    compose = function(par_free, value) {
      ordinal_cutpoint_constrained_par(
        par_free = par_free,
        par_template = par0,
        theta_positions = theta_positions,
        index = index,
        value = value
      )
    },
    start_free = start_free,
    theta_positions = theta_positions
  )
}

drm_profile_ordinal_cutpoint_confint <- function(object, target, level) {
  if (!identical(object$model$model_type, "cumulative_logit")) {
    cli::cli_abort("Constrained ordinal cutpoint profiles are only available for cumulative_logit() fits.")
  }
  if (!identical(object$estimator, "ML") || !is.null(object$penalty)) {
    cli::cli_abort(c(
      "Constrained ordinal cutpoint profiles require an unpenalized ML fit.",
      i = "MAP/penalized, REML, and MSPL objectives do not have this likelihood-ratio interval interpretation. Refit with {.code estimator = \"ml\"} and no {.code penalty}."
    ))
  }
  drm_pin_tmb_object_to_optimum(object$obj, object$opt, object$tmb_state)
  control <- if (is.list(object$control) && is.list(object$control$optimizer)) object$control$optimizer else list()
  control <- profile_endpoint_inner_control(control)
  evaluator <- ordinal_cutpoint_profile_evaluator(object, target, control)
  cutoff <- stats::qchisq(level, df = 1) / 2
  nll_hat <- unname(object$opt$objective)
  theta_hat <- unname(target$estimate[[1L]])
  at_fit <- tryCatch(
    evaluator$evaluate(theta_hat, evaluator$start_free),
    error = function(err) err
  )
  if (inherits(at_fit, "error") ||
    !is.finite(at_fit$nll) ||
    abs(at_fit$nll - nll_hat) > 1e-6) {
    detail <- if (inherits(at_fit, "error")) conditionMessage(at_fit) else {
      sprintf(
        "absolute objective gap = %.12g nll (constrained = %.12g; fitted = %.12g)",
        abs(at_fit$nll - nll_hat), at_fit$nll, nll_hat
      )
    }
    return(drm_profile_failed_confint_row(
      target, level, "ordinal_constrained",
      paste("fitted_cutpoint_objective_mismatch:", detail)
    ))
  }
  endpoint <- function(direction) {
    profile_endpoint_crossing(
      evaluator = evaluator,
      theta_hat = theta_hat,
      nll_hat = nll_hat,
      cutoff = cutoff,
      direction = direction,
      root_tol = 1e-4,
      max_bracket_steps = 40L,
      target_name = target$parm,
      curvature_se = NA_real_,
      remediation = "The constrained ordinal engine cannot use TMB::tmbprofile; inspect the fitted cutpoint and category support before retrying."
    )
  }
  result <- tryCatch(
    lapply(c(-1L, 1L), endpoint),
    error = function(err) err
  )
  if (inherits(result, "error")) {
    return(drm_profile_failed_confint_row(target, level, "ordinal_constrained", conditionMessage(result)))
  }
  interval <- c(result[[1L]]$theta, result[[2L]]$theta)
  diagnostics <- profile_interval_diagnostics(
    interval,
    transformation = target$transformation,
    estimate = target$estimate
  )
  status <- profile_conf_status_from_diagnostics(diagnostics)
  if (identical(status, "profile_failed")) interval <- c(NA_real_, NA_real_)
  data.frame(
    parm = target$parm,
    level = level,
    lower = interval[[1L]],
    upper = interval[[2L]],
    scale = target$scale,
    transformation = target$transformation,
    tmb_parameter = target$tmb_parameter,
    index = target$index,
    method = "profile",
    profile.engine = "ordinal_constrained",
    conf.status = status,
    profile.boundary = diagnostics$boundary,
    profile.message = diagnostics$message,
    stringsAsFactors = FALSE
  )
}

profile_endpoint_targets_supported <- function(targets) {
  vapply(
    seq_len(nrow(targets)),
    function(i) profile_endpoint_target_supported(targets[i, , drop = FALSE]),
    logical(1L)
  )
}

profile_endpoint_curvature_se <- function(object, position) {
  if (!drm_has_sdreport_covariance(object)) {
    return(NA_real_)
  }
  cov_fixed <- object$sdr$cov.fixed
  if (position > nrow(cov_fixed)) {
    return(NA_real_)
  }
  variance <- cov_fixed[position, position]
  if (!is.finite(variance) || variance <= 0) {
    return(NA_real_)
  }
  sqrt(variance)
}

# Gradient tolerance used when tolerating an nlminb code-1 ("false convergence")
# constrained endpoint solve (see profile_endpoint_convergence_accepted). Code 1
# is only accepted when the maximum absolute free-parameter gradient at the
# returned point is below this value; a code-1 stop with a large gradient means
# the inner solve halted short of the constrained minimum, which would inflate
# the profiled nll and narrow the interval (issue #705).
PROFILE_ENDPOINT_GRADIENT_TOL <- 1e-3

# Constrained endpoint refits pin one parameter away from its optimum, so they
# routinely need more iterations than the original free fit. Do not inherit the
# caller's (possibly speed-tuned) iteration budget: keep any tolerances but use a
# generous iteration/evaluation budget so profile-CI reliability does not depend
# on the original fit's iter.max / eval.max choice (issue #710.5).
profile_endpoint_inner_control <- function(control) {
  if (!is.list(control)) {
    control <- list()
  }
  iter_max <- control[["iter.max"]]
  eval_max <- control[["eval.max"]]
  control[["iter.max"]] <- max(1000L, if (is.null(iter_max)) 0L else iter_max)
  control[["eval.max"]] <- max(1000L, if (is.null(eval_max)) 0L else eval_max)
  control
}

# Acceptance predicate for a constrained endpoint nlminb solve. Extracted as a
# pure function so it can be unit-tested directly (issue #705). Code 0 (relative
# convergence) is always accepted; code 1 ("false convergence" / did-not-converge)
# is accepted only when the returned gradient is small, i.e. the solve is at a
# genuine constrained minimum despite the code-1 flag. Everything else is rejected.
profile_endpoint_convergence_accepted <- function(
  opt,
  max_abs_gradient,
  gradient_tol = PROFILE_ENDPOINT_GRADIENT_TOL
) {
  if (is.null(opt$convergence) || !is.finite(opt$objective)) {
    return(FALSE)
  }
  if (identical(as.integer(opt$convergence), 0L)) {
    return(TRUE)
  }
  if (identical(as.integer(opt$convergence), 1L)) {
    return(is.finite(max_abs_gradient) && max_abs_gradient <= gradient_tol)
  }
  FALSE
}

profile_endpoint_evaluator <- function(object, target_position, control) {
  par0 <- object$opt$par
  free <- seq_along(par0) != target_position
  start_free <- par0[free]

  evaluate <- function(theta, start) {
    full0 <- par0
    fn_free <- function(pfree) {
      full <- full0
      full[free] <- pfree
      full[[target_position]] <- theta
      object$obj$fn(full)
    }
    gr_free <- function(pfree) {
      full <- full0
      full[free] <- pfree
      full[[target_position]] <- theta
      object$obj$gr(full)[free]
    }
    # No free fixed parameters to re-optimize: the profiled parameter is the only
    # entry of `opt$par`. This happens for REML fits, where the mean and scale
    # coefficients are integrated into the Laplace `random` block, so the SD being
    # profiled is the sole fixed parameter. The constrained profile objective is
    # then simply the marginal NLL at the pinned target (the random effects are
    # integrated by the inner Laplace) -- no inner optimization, and no empty-vector
    # `nlminb` call (which errored with "'d' must be a nonempty numeric vector").
    if (length(start_free) == 0L) {
      return(list(nll = unname(fn_free(numeric(0))), par = numeric(0)))
    }
    solve_from <- function(start_values) {
      opt <- stats::nlminb(start_values, fn_free, gr_free, control = control)
      # #1130 CI follow-up: the free (unconstrained) optimum is Newton-polished
      # by default (`drm_fit_spec()`, `R/drmTMB.R`) to a gradient of ~1e-9-1e-14,
      # but this constrained endpoint solve was left at whatever `nlminb` alone
      # reached. Comparing a polished nll against an unpolished one biases the
      # profile: the unpolished (constrained) side stops with a higher nll than
      # its true constrained minimum, which narrows the reported interval (the
      # `plot.window(): need finite 'xlim' values` vignette failure was the
      # extreme case, where the endpoint's code-1 gradient exceeded
      # `PROFILE_ENDPOINT_GRADIENT_TOL` and the solve was rejected outright).
      # Polishing this side the same way keeps the comparison symmetric.
      # `drm_control(newton_polish = FALSE)` skips both sides, not just the
      # free fit, so the comparison stays symmetric in that direction too.
      if (isTRUE(object$control$newton_polish)) {
        opt <- drm_newton_polish(opt, fn_free, gr_free)
      }
      opt_gradient <- tryCatch(
        gr_free(opt$par),
        error = function(err) rep(NA_real_, length(opt$par))
      )
      max_abs_gradient <- suppressWarnings(max(abs(opt_gradient), na.rm = TRUE))
      if (!is.finite(max_abs_gradient)) {
        max_abs_gradient <- NA_real_
      }
      list(
        opt = opt,
        max_abs_gradient = max_abs_gradient,
        accepted = profile_endpoint_convergence_accepted(opt, max_abs_gradient)
      )
    }

    result <- solve_from(start)
    # A warm start from a distant bracket point can trigger a premature code-1
    # stop; retry once from the free optimum before giving up (issue #705).
    if (!result$accepted && !identical(start, start_free)) {
      result <- solve_from(start_free)
    }
    opt <- result$opt
    max_abs_gradient <- result$max_abs_gradient
    opt_message <- opt$message
    if (is.null(opt_message) || length(opt_message) == 0L) {
      opt_message <- "unknown"
    }
    if (!result$accepted) {
      cli::cli_abort(c(
        "Constrained endpoint optimization failed.",
        i = "Target internal value: {format(theta, digits = 6)}.",
        i = "Optimizer convergence code: {format(opt$convergence)}.",
        i = "Maximum absolute gradient: {format(max_abs_gradient, digits = 4)}.",
        x = "Optimizer message: {opt_message[[1L]]}"
      ))
    }
    list(nll = unname(opt$objective), par = opt$par)
  }

  list(evaluate = evaluate, start_free = start_free)
}

profile_endpoint_crossing <- function(
  evaluator,
  theta_hat,
  nll_hat,
  cutoff,
  direction,
  root_tol,
  max_bracket_steps,
  target_name,
  curvature_se = NA_real_,
  max_eval = NULL,
  allow_lower_boundary = FALSE,
  remediation = "Try {.code profile_engine = \"tmbprofile\"} for the full profile path."
) {
  n_eval <- 0L
  last_free <- evaluator$start_free
  eval_root <- function(theta) {
    if (!is.null(max_eval) && n_eval >= max_eval) {
      cli::cli_abort(c(
        "Endpoint profile evaluation budget was reached for target {.val {target_name}}.",
        i = "Budget: {max_eval} constrained endpoint evaluation(s) per side.",
        i = "Increase {.arg profile_endpoint_max_eval} or retry without the endpoint budget if this profile needs more refits."
      ))
    }
    n_eval <<- n_eval + 1L
    out <- evaluator$evaluate(theta, last_free)
    last_free <<- out$par
    out$nll - nll_hat - cutoff
  }

  at_hat <- -cutoff
  if (!is.finite(at_hat) || at_hat >= 0) {
    cli::cli_abort(c(
      "Could not start endpoint profile for target {.val {target_name}}.",
      i = "The fitted optimum did not evaluate below the likelihood-ratio cutoff."
    ))
  }

  step_info <- profile_endpoint_initial_step(
    theta_hat = theta_hat,
    direction = direction,
    cutoff = cutoff,
    curvature_se = curvature_se
  )
  step <- step_info$step
  initial_step <- step
  n_bracket_step <- 0L
  outer <- theta_hat + direction * step
  lower_boundary_floor <- log(sqrt(.Machine$double.eps))
  lower_boundary_result <- function() {
    list(
      theta = -Inf,
      root_error = NA_real_,
      n_eval = n_eval,
      initial_step = initial_step,
      bracket_step = step,
      n_bracket_step = n_bracket_step,
      step_source = paste(step_info$source, "lower_boundary", sep = "_")
    )
  }
  eval_or_boundary <- function(theta) {
    eval_root(theta)
  }
  outer_value <- eval_or_boundary(outer)
  if (is.list(outer_value)) {
    return(outer_value)
  }
  for (i in seq_len(max_bracket_steps)) {
    if (is.finite(outer_value) && outer_value >= 0) {
      break
    }
    if (
      direction < 0 &&
        isTRUE(allow_lower_boundary) &&
        outer <= lower_boundary_floor &&
        is.finite(outer_value) &&
        outer_value < 0
    ) {
      return(lower_boundary_result())
    }
    step <- step * 1.6
    n_bracket_step <- i
    outer <- theta_hat + direction * step
    outer_value <- eval_or_boundary(outer)
    if (is.list(outer_value)) {
      return(outer_value)
    }
  }
  if (
    direction < 0 &&
      isTRUE(allow_lower_boundary) &&
      outer <= lower_boundary_floor &&
      is.finite(outer_value) &&
      outer_value < 0
  ) {
    return(lower_boundary_result())
  }
  if (!is.finite(outer_value) || outer_value < 0) {
    cli::cli_abort(c(
      "Could not bracket profile endpoint for target {.val {target_name}}.",
      i = "This can indicate a flat, one-sided, or boundary-limited profile."
    ))
  }

  interval <- sort(c(theta_hat, outer))
  if (direction < 0) {
    f_lower <- outer_value
    f_upper <- at_hat
  } else {
    f_lower <- at_hat
    f_upper <- outer_value
  }
  root <- stats::uniroot(
    eval_root,
    interval = interval,
    f.lower = f_lower,
    f.upper = f_upper,
    tol = root_tol
  )
  root_error <- abs(root$f.root)
  if (!is.finite(root_error) || root_error > 5e-3) {
    advice <- if (is.null(remediation)) character() else {
      c(i = remediation)
    }
    cli::cli_abort(c(
      "Endpoint profile root for target {.val {target_name}} did not satisfy the likelihood-ratio equation closely enough.",
      i = "Absolute root error: {format(root_error, digits = 4)}.",
      advice
    ))
  }
  list(
    theta = root$root,
    root_error = root_error,
    n_eval = n_eval,
    initial_step = initial_step,
    bracket_step = step,
    n_bracket_step = n_bracket_step,
    step_source = step_info$source
  )
}

profile_endpoint_initial_step <- function(
  theta_hat,
  direction,
  cutoff = NA_real_,
  curvature_se = NA_real_
) {
  if (
    is.finite(cutoff) &&
      cutoff > 0 &&
      is.finite(curvature_se) &&
      curvature_se > 0
  ) {
    step <- sqrt(2 * cutoff) * curvature_se * 1.1
    if (is.finite(step) && step > sqrt(.Machine$double.eps)) {
      step_cap <- max(2, abs(theta_hat) * 0.5)
      if (step > step_cap) {
        return(list(step = step_cap, source = "curvature_capped"))
      }
      return(list(step = step, source = "curvature"))
    }
  }
  step <- max(0.25, abs(theta_hat) * 0.05)
  if (!is.finite(step) || step <= 0) {
    step <- 0.25
  }
  list(step = step, source = "fixed")
}

profile_check_tmbprofile_dots <- function(...) {
  profile_check_tmbprofile_dots_list(list(...))
}

profile_check_tmbprofile_dots_list <- function(dots) {
  if (!length(dots)) {
    return(invisible(NULL))
  }
  dot_names <- names(dots)
  if (is.null(dot_names)) {
    return(invisible(NULL))
  }
  controlled <- intersect(
    dot_names[nzchar(dot_names)],
    c("obj", "name", "lincomb", "trace")
  )
  if (length(controlled)) {
    cli::cli_abort(c(
      "Profile target selection is controlled by {.arg parm}.",
      x = "Do not pass {.arg {controlled}} through {.arg ...}.",
      i = "{.pkg drmTMB} profiles one target at a time by supplying {.arg obj}, {.arg name}, {.arg lincomb}, and {.arg trace} to {.fun TMB::tmbprofile} internally."
    ))
  }
  invisible(NULL)
}

drm_tmbprofile <- function(object, target_name, lincomb, trace, ...) {
  drm_pin_tmb_object_to_optimum(object$obj, object$opt, object$tmb_state)
  trace_state <- drm_profile_trace_object(object, target_name, lincomb)
  tryCatch(
    structure(
      TMB::tmbprofile(
        obj = trace_state$obj,
        name = target_name,
        lincomb = lincomb,
        trace = trace,
        ...
      ),
      drmTMB_profile_trace = trace_state$snapshot()
    ),
    error = function(err) {
      cli::cli_abort(
        c(
          "Profile likelihood failed while profiling target {.val {target_name}}.",
          i = "Check {.code profile_targets(fit)} to confirm the target is profile-ready.",
          i = "Try changing profile controls such as {.arg ystep}, {.arg ytol}, or {.arg parm.range}; then inspect {.code check_drm(fit)} if the profile still fails.",
          i = "This can indicate a boundary, one-sided, non-monotone, or failed-inner-optimization profile.",
          x = "Original error: {conditionMessage(err)}"
        ),
        parent = err
      )
    }
  )
}

# Issue #1387: TMB::tmbprofile() calls obj$fn() once per inner evaluation, so
# the trace must not keep a data-sized record per call.  Each evaluation keeps
# only its scalar objective and error message.  The only consumer of the fixed
# vector, the direct-SD clamp check below, is reduced on the fly into counts,
# so memory no longer grows as O(evaluations x length(par)).  Set
# `options(drmTMB.profile_trace_par = TRUE)` to retain the full per-evaluation
# `par` trail for debugging.
drm_profile_trace_object <- function(
  object,
  target_name,
  lincomb,
  keep_par = isTRUE(getOption("drmTMB.profile_trace_par", FALSE))
) {
  evaluations <- new.env(parent = emptyenv())
  evaluations$n <- 0L
  evaluations$objective <- numeric()
  evaluations$error <- character()
  evaluations$par <- list()
  clamp_band <- drm_profile_direct_sd_clamp_band(object)
  # Without direct-SD predictors the per-evaluation status reduces to a
  # finiteness check, so skip the parList() reconstruction on every call.
  has_direct_sd <- is.numeric(clamp_band) && drm_profile_has_direct_sd(object)
  evaluations$clamp <- if (is.numeric(clamp_band)) {
    c(active = 0L, unavailable = 0L)
  }
  obj <- object$obj
  original_fn <- obj$fn

  record_evaluation <- function(par) {
    index <- evaluations$n + 1L
    evaluations$n <- index
    evaluations$objective[[index]] <- NA_real_
    evaluations$error[[index]] <- NA_character_
    if (keep_par) {
      evaluations$par[[index]] <- stats::setNames(as.numeric(par), names(par))
    }
    if (is.numeric(clamp_band)) {
      status <- if (has_direct_sd) {
        drm_profile_direct_sd_clamp_par_status(object, par, clamp_band)
      } else if (!is.numeric(par) || !length(par) || any(!is.finite(par))) {
        NA
      } else {
        FALSE
      }
      if (is.na(status)) {
        evaluations$clamp[["unavailable"]] <- evaluations$clamp[["unavailable"]] + 1L
      } else if (status) {
        evaluations$clamp[["active"]] <- evaluations$clamp[["active"]] + 1L
      }
    }
    index
  }

  obj$fn <- function(par) {
    index <- record_evaluation(par)
    value <- tryCatch(
      original_fn(par),
      error = function(err) {
        evaluations$error[[index]] <- conditionMessage(err)
        stop(err)
      }
    )
    evaluations$objective[[index]] <- as.numeric(value)[1L]
    value
  }

  snapshot <- function() {
    out <- list(
      target_name = target_name,
      lincomb = as.numeric(lincomb),
      baseline = list(
        par = stats::setNames(
          as.numeric(object$opt$par),
          names(object$opt$par)
        ),
        objective = as.numeric(object$opt$objective)
      ),
      n_evaluations = evaluations$n,
      objective = evaluations$objective,
      error = evaluations$error,
      clamp = evaluations$clamp
    )
    if (keep_par) {
      out$evaluations <- lapply(seq_len(evaluations$n), function(i) {
        list(
          par = evaluations$par[[i]],
          objective = evaluations$objective[[i]],
          error = if (!is.na(evaluations$error[[i]])) evaluations$error[[i]]
        )
      })
    }
    out
  }

  list(obj = obj, snapshot = snapshot)
}

# Returns the two-element clamp band when the direct-SD clamp is active, the
# string "not_applicable" when it is off, or "trace_incomplete" when the band
# is malformed.
drm_profile_direct_sd_clamp_band <- function(object) {
  tmb_data <- object$model$tmb_data
  if (
    length(tmb_data$use_logsigma_clamp) != 1L ||
      !identical(as.integer(tmb_data$use_logsigma_clamp), 1L)
  ) {
    return("not_applicable")
  }
  band <- tmb_data$logsigma_clamp
  if (
    length(band) < 2L ||
      any(!is.finite(band[seq_len(2L)])) ||
      band[[1L]] >= band[[2L]]
  ) {
    return("trace_incomplete")
  }
  band
}

drm_profile_has_direct_sd <- function(object) {
  random_scale <- object$model$random_scale
  n_mu <- random_scale$mu$n_models
  n_phylo <- if (is.list(random_scale$phylo)) random_scale$phylo$n_models
  # Fall back to full classification whenever the structure is unexpected.
  if (length(n_mu) != 1L || is.na(n_mu)) {
    return(TRUE)
  }
  n_mu > 0L || (length(n_phylo) == 1L && !is.na(n_phylo) && n_phylo > 0L)
}

# TRUE when any raw direct-SD log-scale predictor at fixed vector `par` lies
# outside `band`, FALSE when none does, NA when it cannot be reconstructed.
drm_profile_direct_sd_clamp_par_status <- function(object, par, band) {
  if (!is.numeric(par) || !length(par) || any(!is.finite(par))) {
    return(NA)
  }
  par_list <- tryCatch(
    object$obj$env$parList(par),
    error = function(err) NULL
  )
  if (is.null(par_list)) {
    return(NA)
  }
  eta <- tryCatch(
    drm_direct_sd_logscale_values(par_list, object$model),
    error = function(err) NULL
  )
  if (is.null(eta) || !length(eta)) {
    return(FALSE)
  }
  values <- unlist(eta, use.names = FALSE)
  if (!length(values) || any(!is.finite(values))) {
    return(NA)
  }
  any(values < band[[1L]] | values > band[[2L]])
}

# A direct-SD clamp changes the likelihood whenever its raw group-level
# log-scale predictor is outside the identity band.  The full TMB profile API
# does not return every constrained optimizer state, but it does call obj$fn()
# for every fixed parameter vector it evaluates.  Direct-SD predictors depend
# only on that fixed vector, so tracing those calls is sufficient here.  The
# trace reduces each call to clamp counts as it happens (issue #1387); a trace
# that instead carries per-evaluation `par` entries is classified here.  Any
# reconstruction failure is deliberately unavailable rather than treated as no
# clamp contact.
drm_profile_direct_sd_clamp_trace <- function(object, profile) {
  band <- drm_profile_direct_sd_clamp_band(object)
  if (is.character(band)) {
    return(list(status = band))
  }
  trace <- attr(profile, "drmTMB_profile_trace", exact = TRUE)
  if (!is.list(trace) || !is.list(trace$baseline)) {
    return(list(status = "trace_incomplete"))
  }
  counts <- trace$clamp
  has_counts <- is.numeric(counts) &&
    all(c("active", "unavailable") %in% names(counts))
  if (!has_counts && !is.list(trace$evaluations)) {
    return(list(status = "trace_incomplete"))
  }
  entries <- list(trace$baseline)
  if (!has_counts) {
    entries <- c(entries, trace$evaluations)
  }
  active <- vapply(entries, function(entry) {
    drm_profile_direct_sd_clamp_par_status(object, entry$par, band)
  }, logical(1L))
  if (anyNA(active) || (has_counts && counts[["unavailable"]] > 0L)) {
    return(list(status = "trace_incomplete"))
  }
  if (any(active) || (has_counts && counts[["active"]] > 0L)) {
    return(list(status = "clamp_limited"))
  }
  list(status = "ok")
}

drm_tmbprofile_confint <- function(profile, target_name, level) {
  tryCatch(
    stats::confint(profile, level = level),
    error = function(err) {
      cli::cli_abort(
        c(
          "Could not extract a profile confidence interval for target {.val {target_name}}.",
          i = "The profile may not cross the likelihood-ratio threshold on both sides.",
          i = "Try a wider {.arg parm.range}, a smaller {.arg ystep}, or inspect the profile object interactively.",
          i = "This can indicate a boundary, one-sided, non-monotone, or failed-inner-optimization profile.",
          x = "Original error: {conditionMessage(err)}"
        ),
        parent = err
      )
    }
  )
}

profile_interval_diagnostics <- function(
  interval,
  transformation,
  estimate = NULL,
  sd_boundary = sqrt(.Machine$double.eps),
  correlation_boundary = 0.98,
  profile_min_objective = NULL,
  fit_objective = NULL,
  profile_below_fit_tol = 1e-3
) {
  interval <- as.numeric(interval)
  if (length(interval) != 2L || any(!is.finite(interval))) {
    return(list(boundary = TRUE, message = "nonfinite_interval"))
  }
  # A profile evaluation lower than the fitted objective means the profile's
  # warm-started inner optimizer found a better point than the fit did, which
  # moves `TMB:::confint.tmbprofile`'s which.min() anchor off the MLE. This is
  # a cause-level check (issue #1009): it fires before, and independently of,
  # whether the resulting interval happens to exclude the point estimate.
  #
  # Tolerance: 1e-3 nll units. A campaign-scale rescore of the 348,000-record
  # artifact this issue diagnosed (using the first profile-trace value as a
  # proxy for the fit, since the stored records do not retain the true fitted
  # objective) found the gap distribution is not dense near zero: the flagged
  # count is flat at 973 from tol = 0 through tol = 1e-6, then falls to 921 at
  # 1e-4 and 764 at 1e-3. So [1e-6, 1e-3] is where the ambiguous, plausibly
  # floating-point-noise records sit (~209 of them), and 1e-3 sits above that
  # band while still reproducing this issue's own headline count (764). Real
  # failures are not marginal once past that band: median gap 1.0 nll unit,
  # third quartile 639. At runtime this check compares against the true
  # `object$opt$objective`, not the proxy, so it should if anything be more
  # exact than this calibration, never less.
  #
  # A single status covers every gap above the tolerance, including the very
  # large ones. An earlier version of this check tried to split off a second
  # status for a `TMB::tmbprofile()` bracket-search overflow sentinel
  # (tracked separately as issue #1010) using a magnitude threshold at 1e6.
  # That threshold was wrong on its own terms (the smallest gap it was meant
  # to catch was 4,194,304, not the ~1e141 originally assumed), and rescoring
  # the full decade-by-decade distribution above 1e-3 showed there is no gap
  # to threshold in: counts are spread continuously from 1e-3 up past 1e100
  # (e.g. 155 in [100, 1e3), 43 in [1e4, 1e5), 8 in [1e5, 1e6), then 1 in
  # [1e6, 1e7), 2 in [1e7, 1e8), 26 in [1e8, 1e20), 42 in [1e20, 1e100), 14
  # above 1e100). A magnitude cut cannot separate a genuine second basin from
  # the #1010 sentinel because they are not magnitude-separated; the one
  # candidate threshold examined landed inside a decade holding exactly one
  # record. Separating the two would need a signature-based test instead --
  # e.g. detecting the sentinel's own pattern (some observed sentinel gaps
  # are exact powers of two, such as 2^22 and close to 2^28) or a
  # non-finite/overflowed intermediate earlier in the trace -- not a gap
  # threshold. That is future work if #1010 is not fixed upstream first.
  # Instead, the gap itself is reported in the message: an operator seeing
  # `gap=1.628e+237` versus `gap=0.5` can already tell the two apart, and the
  # message degrades gracefully (shrinks toward ordinary values) if #1010 is
  # fixed upstream.
  if (
    length(profile_min_objective) == 1L &&
      length(fit_objective) == 1L &&
      is.finite(profile_min_objective) &&
      is.finite(fit_objective) &&
      (fit_objective - profile_min_objective) > profile_below_fit_tol
  ) {
    gap <- fit_objective - profile_min_objective
    return(list(
      boundary = TRUE,
      message = sprintf(
        "profile_below_fit_objective (gap=%s nll)",
        trimws(formatC(gap, digits = 4, format = "g"))
      )
    ))
  }
  if (
    length(estimate) == 1L &&
      is.finite(estimate) &&
      (interval[[1L]] >= estimate || interval[[2L]] <= estimate)
  ) {
    return(list(boundary = TRUE, message = "point_estimate_outside_interval"))
  }
  if (
    transformation %in%
      c("exp", "derived_group_scale") &&
      min(interval) <= sd_boundary
  ) {
    return(list(boundary = TRUE, message = "near_sd_boundary"))
  }
  if (
    transformation %in%
      c("tanh", "rho12_tanh", "unstructured_corr") &&
      max(abs(interval)) >= correlation_boundary
  ) {
    return(list(boundary = TRUE, message = "near_correlation_boundary"))
  }
  list(boundary = FALSE, message = "ok")
}

profile_transform_interval <- function(interval, target) {
  switch(
    target$transformation,
    linear_predictor = interval,
    exp = exp(interval),
    plogis = stats::plogis(interval),
    tanh = profile_correlation_guard(target$tmb_parameter) * tanh(interval),
    rho12_tanh = rho_response(interval),
    interval
  )
}

profile_transform_newdata_interval <- function(interval, object, dpar, offset) {
  eta_interval <- interval + offset
  switch(
    drm_dpar_link(object, dpar),
    log = exp(eta_interval),
    atanh_guarded = rho_response(eta_interval),
    atanh_re_guarded = rho_response(eta_interval, guard = DRM_RE_CORR_GUARD),
    atanh_phylo_guarded = rho_response(eta_interval, guard = DRM_CORR_GUARD),
    cli::cli_abort(
      "Internal error: no response-scale profile transformation for {.val {dpar}}."
    )
  )
}

profile_newdata_transformation <- function(object, dpar) {
  switch(
    drm_dpar_link(object, dpar),
    log = "exp",
    atanh_guarded = "rho12_tanh",
    atanh_re_guarded = "random_effect_correlation_tanh",
    atanh_phylo_guarded = "random_effect_correlation_tanh",
    "unknown"
  )
}

profile_registry_cor_targets <- function(object) {
  registry <- object$model$random$covariance_blocks
  if (
    !is.list(registry) ||
      is.null(registry$pairs) ||
      nrow(registry$pairs) == 0L
  ) {
    return(list())
  }

  pairs <- registry$pairs
  pair_is_fitted <- !is.na(pairs$tmb_parameter) & !is.na(pairs$tmb_index)
  pairs <- pairs[pair_is_fitted, , drop = FALSE]
  if (nrow(pairs) == 0L) {
    return(list())
  }

  out <- lapply(seq_len(nrow(pairs)), function(i) {
    pair <- pairs[i, , drop = FALSE]
    dpar <- covariance_block_corpars_key(pair$tmb_parameter[[1L]])
    values <- object$corpars[[dpar]]
    index <- pair$tmb_index[[1L]]
    if (random_effect_correlation_is_modelled(object, dpar, index)) {
      return(NULL)
    }
    if (is.null(values) || index < 1L || index > length(values)) {
      cli::cli_abort(
        "Internal error: covariance-block registry pair has no profile target correlation."
      )
    }
    estimate <- unname(values[[index]])
    is_unstructured_corr <- identical(pair$tmb_parameter[[1L]], "theta_re_cov")
    status <- if (is_unstructured_corr) {
      list(
        profile_ready = FALSE,
        profile_note = "derived_unstructured_correlation"
      )
    } else {
      profile_direct_target_status(
        object,
        pair$tmb_parameter[[1L]],
        index
      )
    }
    new_profile_target_row(
      parm = paste0("cor:", dpar, ":", pair$parameter[[1L]]),
      target_class = "random-effect-correlation",
      dpar = dpar,
      term = pair$parameter[[1L]],
      tmb_parameter = pair$tmb_parameter[[1L]],
      index = index,
      estimate = estimate,
      link_estimate = if (is_unstructured_corr) {
        NA_real_
      } else {
        guarded_correlation_link(estimate, guard = DRM_RE_CORR_GUARD)
      },
      scale = "response",
      transformation = if (is_unstructured_corr) {
        "unstructured_corr"
      } else {
        "tanh"
      },
      target_type = if (is_unstructured_corr) "derived" else "direct",
      profile_ready = status$profile_ready,
      profile_note = status$profile_note
    )
  })
  out[!vapply(out, is.null, logical(1L))]
}

new_profile_target_row <- function(
  parm,
  target_class,
  dpar,
  term,
  tmb_parameter,
  index,
  estimate,
  link_estimate,
  scale,
  transformation,
  target_type,
  profile_ready,
  profile_note
) {
  data.frame(
    parm = parm,
    target_class = target_class,
    dpar = dpar,
    term = term,
    tmb_parameter = tmb_parameter,
    index = as.integer(index),
    estimate = as.numeric(estimate),
    link_estimate = as.numeric(link_estimate),
    scale = scale,
    transformation = transformation,
    target_type = target_type,
    profile_ready = as.logical(profile_ready),
    profile_note = profile_note,
    stringsAsFactors = FALSE
  )
}

empty_profile_targets <- function() {
  data.frame(
    parm = character(),
    target_class = character(),
    dpar = character(),
    term = character(),
    tmb_parameter = character(),
    index = integer(),
    estimate = numeric(),
    link_estimate = numeric(),
    scale = character(),
    transformation = character(),
    target_type = character(),
    profile_ready = logical(),
    profile_note = character(),
    stringsAsFactors = FALSE
  )
}

validate_profile_targets <- function(targets) {
  expected <- names(empty_profile_targets())
  if (!identical(names(targets), expected)) {
    cli::cli_abort("Internal error: profile target columns are inconsistent.")
  }
  if (nrow(targets) == 0L) {
    return(targets)
  }
  allowed_types <- c("direct", "derived", "constrained")
  bad_type <- !targets$target_type %in% allowed_types
  if (any(bad_type)) {
    cli::cli_abort(
      "Internal error: profile target type {.val {targets$target_type[bad_type][[1L]]}} is not supported."
    )
  }
  allowed_notes <- c(
    "ready",
    "tmb_object_required",
    "julia_bridge_payload_required",
    "missing_tmb_parameter",
    "point_fit_only_zi_nbinom2_sigma_q1",
    "point_fit_only_zero_one_beta_animal_q1",
    "point_fit_only_zero_one_beta_relmat_q1",
    "point_fit_only_zero_one_beta_spatial_q1",
    "point_fit_only_zero_one_beta_phylo_interaction_q1",
    "point_fit_only_zero_one_beta_phylo_q1",
    "point_fit_only_zero_one_beta_phylo_zoi_q1",
    "point_fit_only_zero_one_beta_phylo_coi_q1",
    "point_fit_only_zero_one_beta_animal_zoi_q1",
    "point_fit_only_zero_one_beta_animal_coi_q1",
    "point_fit_only_zero_one_beta_relmat_zoi_q1",
    "point_fit_only_zero_one_beta_relmat_coi_q1",
    "point_fit_only_zero_one_beta_phylo_interaction_zoi_q1",
    "point_fit_only_zero_one_beta_phylo_interaction_coi_q1",
    "point_fit_only_zero_one_beta_zoi_q1",
    "point_fit_only_zero_one_beta_coi_q1",
    "mesh_field_scale_intervals_unvalidated",
    "derived_target",
    "derived_unstructured_correlation",
    "internal_ordinal_parameter",
    # #1144: a public ordinal cutpoint on an `engine = "julia"` fit. Listed by
    # `profile_targets()` so it is discoverable, never ready -- DRM.jl's
    # bridge inference has no cutpoint target, so `confint()` refuses it and
    # names `engine = "tmb"` (R/julia-family-cumulative_logit.R).
    "julia_ordinal_cutpoint_native_only"
  )
  bad_note <- !targets$profile_note %in% allowed_notes
  if (any(bad_note)) {
    cli::cli_abort(
      "Internal error: profile target note {.val {targets$profile_note[bad_note][[1L]]}} is not supported."
    )
  }
  allowed_transformations <- c(
    "linear_predictor",
    "exp",
    "plogis",
    "rho12_tanh",
    "tanh",
    "variance_ratio",
    "derived_group_scale",
    "unstructured_corr",
    "ordered_cutpoint"
  )
  bad_transformation <- !targets$transformation %in% allowed_transformations
  if (any(bad_transformation)) {
    cli::cli_abort(
      "Internal error: profile target transformation {.val {targets$transformation[bad_transformation][[1L]]}} is not supported."
    )
  }
  if (any(targets$profile_ready & !targets$target_type %in% c("direct", "constrained"))) {
    cli::cli_abort("Internal error: only direct or constrained profile targets can be ready.")
  }
  duplicate <- duplicated(targets$parm)
  if (any(duplicate)) {
    cli::cli_abort(
      "Internal error: duplicate profile target name {.val {targets$parm[duplicate][[1L]]}}."
    )
  }
  targets
}

# Public missing-predictor summaries are already on their natural scale.
# Keep exact model metadata separate from ordinary coefficient name mapping.
profile_missing_predictor_transform <- function(dpar, object) {
  for (slot in seq_len(2L)) {
    key <- if (slot == 1L) "missing_predictor" else "missing_predictor2"
    predictor <- object$model[[key]]
    variable <- predictor$variable
    if (!is.character(variable) || length(variable) != 1L || is.na(variable)) next
    descriptor <- function(internal, transformation = "exp") {
      list(internal = internal, transformation = transformation)
    }
    scale_families <- c("gaussian", "beta", "zero_one_beta", "beta_binomial",
      "lognormal", "gamma", "nbinom2", "truncated_nbinom2", "tweedie")
    if (identical(dpar, paste0("sigma_mi_", variable)) &&
        isTRUE(predictor$family %in% scale_families)) {
      return(descriptor(if (slot == 1L) "log_sigma_mi" else "log_sigma_mi2"))
    }
    if (slot != 1L) next
    if (identical(predictor$family, "zero_one_beta")) {
      if (identical(dpar, paste0("zoi_mi_", variable))) return(descriptor("beta_zoi", "plogis"))
      if (identical(dpar, paste0("coi_mi_", variable))) return(descriptor("beta_coi", "plogis"))
    }
    if (isTRUE(predictor$random$enabled) &&
        identical(dpar, paste0("sd_mi_group_", variable))) return(descriptor("log_sd_mi_group"))
    if (isTRUE(predictor$structured$enabled) &&
        identical(dpar, paste0("sd_mi_", predictor$structured$type, "_", variable))) {
      return(descriptor("log_sd_mi_struct"))
    }
  }
  NULL
}

profile_fixef_internal <- function(dpar, object = NULL) {
  # Public blocks use the variable name; native parameters use model slots.
  # Match exact stored metadata, not a prefix (positive scales and mixture
  # probabilities have different public transformations).
  for (slot in seq_len(2L)) {
    key <- if (slot == 1L) "missing_predictor" else "missing_predictor2"
    predictor <- object$model[[key]]
    variable <- predictor$variable
    if (is.character(variable) && length(variable) == 1L &&
        !is.na(variable) && identical(dpar, paste0("mi_", variable))) {
      return(if (slot == 1L) "beta_mi" else "beta_mi2")
    }
  }
  if (
    any(startsWith(
      dpar,
      c("sd(", "sd1(", "sd2(", "sd_phylo(", "sd_phylo1(", "sd_phylo2(")
    ))
  ) {
    return("beta_sd_mu")
  }
  if (identical(dpar, "hu")) {
    return("beta_zi")
  }
  if (startsWith(dpar, "corpair(")) {
    return("beta_cor_mu")
  }
  paste0("beta_", dpar)
}

profile_sd_internal <- function(object, dpar, term) {
  registry <- object$model$random$covariance_blocks
  if (
    is.list(registry) &&
      nrow(qgt2_members <- qgt2_covariance_members(registry)) > 0L &&
      any(
        vapply(
          seq_len(nrow(qgt2_members)),
          function(i) {
            member <- qgt2_members[i, , drop = FALSE]
            identical(covariance_registry_member_sd_key(member), dpar) &&
              identical(member$label[[1L]], term)
          },
          logical(1L)
        )
      )
  ) {
    return("log_sd_re_cov")
  }
  if (
    identical(dpar, "mu") &&
      isTRUE(object$model$structured$mesh_spatial_mu$has) &&
      identical(term, object$model$structured$mesh_spatial_mu$label)
  ) {
    return("log_sd_phylo2")
  }
  if (
    identical(dpar, "mu") &&
      isTRUE(object$model$structured$phylo_mu2$has) &&
      term %in%
        phylo_mu_sd_labels(
          object$model$structured$phylo_mu2,
          object$model$model_type
        )
  ) {
    # Scoped second structured location field lives on its own internal scale.
    return("log_sd_phylo2")
  }
  if (
    dpar %in%
      c("mu", "sigma", "zoi", "coi") &&
      grepl(
        "phylo\\(|phylo_interaction\\(|spatial\\(|animal\\(|relmat\\(",
        term
      )
  ) {
    return("log_sd_phylo")
  }
  if (dpar %in% c("mu", "sigma", "zoi", "coi")) {
    return(paste0("log_sd_", dpar))
  }
  NA_character_
}

profile_cor_internal <- function(dpar) {
  if (identical(dpar, "mu")) {
    return("eta_cor_mu")
  }
  if (
    dpar %in%
      c("phylo", "phylo_interaction", "spatial", "animal", "relmat")
  ) {
    return("eta_cor_phylo")
  }
  paste0("eta_cor_", dpar)
}

profile_internal_is_active <- function(object, internal, index) {
  if (is.na(internal) || is.na(index)) {
    return(FALSE)
  }
  if (is.null(object$obj)) {
    return(FALSE)
  }
  sum(names(object$opt$par) == internal) >= index
}

profile_direct_target_status <- function(object, internal, index) {
  ready <- profile_internal_is_active(object, internal, index)
  list(
    profile_ready = ready,
    profile_note = profile_ready_note(
      ready,
      object = object,
      internal = internal,
      index = index
    )
  )
}

zi_nbinom2_sigma_q1_profile_restricted <- function(object, dpar) {
  structured <- object$model$structured$phylo_mu
  re_sigma <- object$model$random$sigma
  identical(object$model$model_type, "zi_nbinom2") &&
    identical(dpar, "sigma") &&
    !isTRUE(structured$has) &&
    identical(re_sigma$n_terms, 1L) &&
    isTRUE(re_sigma$n_re > 0L) &&
    identical(re_sigma$coef_names[[1L]], "(Intercept)") &&
    is.na(re_sigma$covariance_labels[[1L]])
}

count_point_fit_only_profile_restricted <- function(object, dpar) {
  zi_nbinom2_sigma_q1_profile_restricted(object, dpar) ||
    (identical(object$model$model_type, "zero_one_beta") &&
      dpar %in% c("mu", "zoi", "coi") && isTRUE(object$model$structured$phylo_mu$has) &&
      structured_mu_type(object$model$structured$phylo_mu) %in% c("phylo", "animal", "relmat", "spatial", "phylo_interaction") &&
      identical(structured_mu_q(object$model$structured$phylo_mu), 1L) &&
      identical(phylo_mu_endpoint_dpars(object$model$structured$phylo_mu), dpar))
}

count_point_fit_only_profile_restricted_status <- function(object, dpar) {
  if (zero_one_beta_zoi_q1_profile_restricted(object, dpar, "log_sd_zoi")) {
    return(list(
      profile_ready = FALSE,
      profile_note = "point_fit_only_zero_one_beta_zoi_q1"
    ))
  }
  if (zero_one_beta_coi_q1_profile_restricted(object, dpar, "log_sd_coi")) {
    return(list(
      profile_ready = FALSE,
      profile_note = "point_fit_only_zero_one_beta_coi_q1"
    ))
  }
  if (zi_nbinom2_sigma_q1_profile_restricted(object, dpar)) {
    return(list(
      profile_ready = FALSE,
      profile_note = "point_fit_only_zi_nbinom2_sigma_q1"
    ))
  }
  if (identical(object$model$model_type, "zero_one_beta")) {
    provider <- structured_mu_type(object$model$structured$phylo_mu)
    if (identical(provider, "phylo") && identical(dpar, "zoi")) {
      return(list(
        profile_ready = FALSE,
        profile_note = "point_fit_only_zero_one_beta_phylo_zoi_q1"
      ))
    }
    if (identical(provider, "phylo") && identical(dpar, "coi")) {
      return(list(
        profile_ready = FALSE,
        profile_note = "point_fit_only_zero_one_beta_phylo_coi_q1"
      ))
    }
    if (dpar %in% c("zoi", "coi")) {
      return(list(
        profile_ready = FALSE,
        profile_note = paste0(
          "point_fit_only_zero_one_beta_", provider, "_", dpar, "_q1"
        )
      ))
    }
    return(list(
      profile_ready = FALSE,
      profile_note = paste0("point_fit_only_zero_one_beta_", provider, "_q1")
    ))
  }
  cli::cli_abort(
    "Internal error: no point-fit-only profile note for {.val {object$model$model_type}} {.val {dpar}}."
  )
}

zero_one_beta_zoi_q1_profile_restricted <- function(object, dpar, internal) {
  identical(object$model$model_type, "zero_one_beta") &&
    identical(dpar, "zoi") &&
    identical(internal, "log_sd_zoi") &&
    is.list(object$model$random$zoi) &&
    identical(object$model$random$zoi$n_terms, 1L) &&
    identical(object$model$random$zoi$n_cors, 0L) &&
    identical(object$model$random$mu$n_re, 0L) &&
    identical(object$model$random$sigma$n_re, 0L)
}

zero_one_beta_coi_q1_profile_restricted <- function(object, dpar, internal) {
  identical(object$model$model_type, "zero_one_beta") &&
    identical(dpar, "coi") && identical(internal, "log_sd_coi") &&
    is.list(object$model$random$coi) && identical(object$model$random$coi$n_terms, 1L) &&
    identical(object$model$random$coi$n_cors, 0L) &&
    identical(object$model$random$mu$n_re, 0L) &&
    identical(object$model$random$sigma$n_re, 0L) &&
    identical(object$model$random$zoi$n_re, 0L)
}

profile_ready_note <- function(
  profile_ready,
  object = NULL,
  internal = NA,
  index = NA
) {
  if (isTRUE(profile_ready)) {
    return("ready")
  }
  if (!is.null(object) && is.null(object$obj)) {
    return("tmb_object_required")
  }
  "missing_tmb_parameter"
}

profile_match_targets <- function(targets, parm) {
  if (missing(parm) || is.null(parm)) {
    cli::cli_abort(c(
      "Profile targets must be supplied explicitly.",
      i = "Use {.code drmTMB:::drm_profile_targets(fit)$parm} to inspect available targets."
    ))
  }
  if (is.numeric(parm)) {
    if (
      any(!is.finite(parm)) ||
        any(parm != as.integer(parm)) ||
        any(parm < 1L | parm > nrow(targets))
    ) {
      cli::cli_abort(
        "{.arg parm} numeric values must select rows from the available profile targets."
      )
    }
    return(targets[as.integer(parm), , drop = FALSE])
  }
  if (!is.character(parm)) {
    cli::cli_abort(
      "{.arg parm} must be a character or integer vector of profile targets."
    )
  }
  index <- match(parm, targets$parm)
  missing_index <- is.na(index)
  if (any(missing_index)) {
    available <- paste(utils::head(targets$parm, 10L), collapse = ", ")
    cli::cli_abort(c(
      "Unknown profile target{?s}: {.val {parm[missing_index]}}.",
      i = "First available targets: {available}."
    ))
  }
  targets[index, , drop = FALSE]
}

profile_match_confint_targets <- function(targets, parm, fixed_only) {
  if (is.null(parm)) {
    return(targets)
  }
  parm <- profile_expand_confint_target_sets(targets, parm)
  if (is.numeric(parm)) {
    if (
      any(!is.finite(parm)) ||
        any(parm != as.integer(parm)) ||
        any(parm < 1L | parm > nrow(targets))
    ) {
      cli::cli_abort(
        "{.arg parm} numeric values must select rows from the available confidence-interval targets."
      )
    }
    return(targets[as.integer(parm), , drop = FALSE])
  }
  if (!is.character(parm)) {
    cli::cli_abort(
      "{.arg parm} must be a character or integer vector of confidence-interval targets."
    )
  }

  aliases <- paste0(targets$dpar, ":", targets$term)
  index <- match(parm, targets$parm)
  missing_index <- is.na(index)
  if (any(missing_index)) {
    alias_matches <- lapply(parm[missing_index], function(one) which(aliases == one))
    ambiguous_ordinal <- vapply(
      alias_matches,
      function(rows) {
        length(rows) > 1L && any(targets$dpar[rows] == "ordinal")
      },
      logical(1L)
    )
    if (any(ambiguous_ordinal)) {
      ambiguous <- parm[missing_index][ambiguous_ordinal]
      labels <- sub("^ordinal:", "", ambiguous)
      public_targets <- paste0("ordinal:cutpoint:", labels)
      cli::cli_abort(c(
        "Ordinal confidence-interval alias{?es} {.val {ambiguous}} {?is/are} ambiguous.",
        i = "Use the public cutpoint target{?s} {.val {public_targets}} rather than an internal {.val ordinal:theta_ord:<label>} coordinate."
      ))
    }
    index[missing_index] <- vapply(
      alias_matches,
      function(rows) if (length(rows)) rows[[1L]] else NA_integer_,
      integer(1L)
    )
  }
  missing_index <- is.na(index)
  if (any(missing_index)) {
    available <- paste(utils::head(targets$parm, 10L), collapse = ", ")
    detail <- if (fixed_only) {
      "Use coefficient labels from summary(fit) or full names such as {.val fixef:mu:x}."
    } else {
      "Use full profile target names such as {.val fixef:mu:x}."
    }
    cli::cli_abort(c(
      "Unknown confidence-interval target{?s}: {.val {parm[missing_index]}}.",
      i = detail,
      i = "First available targets: {available}."
    ))
  }
  targets[index, , drop = FALSE]
}

profile_expand_confint_target_sets <- function(targets, parm) {
  if (!is.character(parm)) {
    return(parm)
  }
  alias_rows <- list(
    fixed_effects = targets$target_class == "fixed-effect",
    `fixed-effects` = targets$target_class == "fixed-effect",
    random_effects = targets$target_class %in%
      c("random-effect-sd", "random-effect-correlation"),
    `random-effects` = targets$target_class %in%
      c("random-effect-sd", "random-effect-correlation"),
    variance_components = targets$target_class %in%
      c("distributional-scale", "random-effect-sd"),
    `variance-components` = targets$target_class %in%
      c("distributional-scale", "random-effect-sd"),
    correlations = targets$target_class %in%
      c("random-effect-correlation", "residual-correlation")
  )
  expanded <- unlist(
    lapply(parm, function(one) {
      rows <- alias_rows[[one]]
      if (is.null(rows)) {
        return(one)
      }
      targets$parm[rows]
    }),
    use.names = FALSE
  )
  unique(expanded)
}

profile_newdata_dpar <- function(object, parm) {
  if (is.null(parm)) {
    cli::cli_abort(c(
      "{.arg parm} must name one distributional parameter when {.arg newdata} is supplied.",
      i = "Use {.val sigma}, {.val sigma1}, {.val sigma2}, {.val rho12}, or a fitted {.fn corpair} dpar."
    ))
  }
  if (!is.character(parm) || length(parm) != 1L || is.na(parm)) {
    cli::cli_abort(
      "{.arg parm} must be one distributional-parameter name when {.arg newdata} is supplied."
    )
  }

  scale_or_residual <- intersect(
    c("sigma", "sigma1", "sigma2", "rho12"),
    names(object$coefficients)
  )
  scale_or_residual <- scale_or_residual[vapply(
    scale_or_residual,
    function(dpar) drm_dpar_link(object, dpar) %in% c("log", "atanh_guarded"),
    logical(1)
  )]
  corpair <- names(object$coefficients)[
    startsWith(names(object$coefficients), "corpair(")
  ]
  corpair <- corpair[vapply(
    corpair,
    function(dpar) {
      drm_dpar_link(object, dpar) %in% c("atanh_re_guarded", "atanh_phylo_guarded")
    },
    logical(1)
  )]
  supported <- c(scale_or_residual, corpair)
  if (!parm %in% supported) {
    available <- if (length(supported)) {
      paste(supported, collapse = ", ")
    } else {
      "none for this fitted model"
    }
    cli::cli_abort(c(
      "Response-scale profile intervals with {.arg newdata} are implemented for fitted scale, residual-correlation, and q2 ordinary or phylogenetic {.fn corpair} parameters.",
      i = "Requested {.val {parm}}; available for this fit: {available}."
    ))
  }
  parm
}

profile_newdata_parm_labels <- function(dpar, newdata) {
  labels <- row.names(newdata)
  default_labels <- as.character(seq_len(nrow(newdata)))
  if (
    is.null(labels) ||
      anyNA(labels) ||
      any(!nzchar(labels)) ||
      identical(labels, default_labels)
  ) {
    labels <- default_labels
  }
  paste0(dpar, "[", labels, "]")
}

profile_target_positions <- function(targets, labels) {
  aliases <- paste0(targets$dpar, ":", targets$term)
  positions <- match(aliases, labels)
  if (anyNA(positions)) {
    cli::cli_abort(
      "Internal error: confidence-interval targets do not match fitted coefficient labels."
    )
  }
  positions
}

profile_lincomb <- function(object, target) {
  par_names <- names(object$opt$par)
  positions <- which(par_names == target$tmb_parameter)
  if (length(positions) < target$index) {
    cli::cli_abort(c(
      "Profile target {.val {target$parm}} cannot be mapped to optimized parameters.",
      i = "Expected index {target$index} in TMB parameter {.val {target$tmb_parameter}}."
    ))
  }
  out <- rep(0, length(object$opt$par))
  out[positions[[target$index]]] <- 1
  out
}

validate_profile_level <- function(level) {
  if (
    !is.numeric(level) ||
      length(level) != 1L ||
      !is.finite(level) ||
      level <= 0 ||
      level >= 1
  ) {
    cli::cli_abort("{.arg level} must be one number between 0 and 1.")
  }
}
