# Native Gamma spatial SDs with independent intercept and numeric slope fields.
# Cov(b_k)=D_k K D_k; K=exp(-distance/median-positive-distance)+1e-6 I.
# The SD predictors are constant within sites; x varies within sites.
library(drmTMB)

# Independently generated fixed exponential coordinate covariance.
gamma_spatial_q2_sd_fixture <- function() {
  set.seed(2026102801L)
  n <- 64L; nr <- 20L; ids <- sprintf("site%03d",seq_len(n))
  coords <- as.matrix(expand.grid(easting=0:7,northing=0:7))
  rownames(coords) <- ids
  dx <- outer(coords[,1],coords[,1],"-");dy <- outer(coords[,2],coords[,2],"-")
  distance <- sqrt(dx^2+dy^2)
  range <- median(distance[upper.tri(distance) & distance>0])
  K <- exp(-distance/range);diag(K) <- diag(K)+1e-6
  dimnames(K) <- list(ids,ids)
  z0 <- setNames(rep(c(-1,1),n/2L),ids)
  z1 <- setNames(rep(c(-1,1),each=n/2L),ids)
  b0 <- exp(log(.5)+.5*z0)*drop(t(chol(K))%*%rnorm(n))
  b1 <- exp(log(.4)-.5*z1)*drop(t(chol(K))%*%rnorm(n))
  ii <- rep(seq_len(n),each=nr);x <- rep(seq(-1.2,1.2,length.out=nr),n)
  mu <- exp(.2+.3*x+b0[ii]+x*b1[ii]);phi <- .35^-2
  data <- data.frame(y=rgamma(length(ii),shape=phi,rate=phi/mu),x=x,
    id=factor(ids[ii],levels=rev(ids)),z0=unname(z0[ii]),z1=unname(z1[ii]))
  stopifnot(all(is.finite(data$y)),all(data$y>0))
  list(data=data,coords=coords[rev(ids),,drop=FALSE],K=K,range=range,z0=z0,z1=z1)
}

gamma_spatial_q2_sd_form <- function(coords,constant=FALSE,reverse_sd=FALSE) {
  f0 <- as.formula(paste('sd(id, level="spatial", coef="(Intercept)") ~',if(constant) "1" else "z0"),env=environment())
  f1 <- as.formula(paste('sd(id, level="spatial", coef="x") ~',if(constant) "1" else "z1"),env=environment())
  mu <- y ~ x + spatial(1+x|id,coords=coords)
  if(reverse_sd) bf(mu,sigma~1,f1,f0) else bf(mu,sigma~1,f0,f1)
}

fx <- gamma_spatial_q2_sd_fixture()
fit <- drmTMB(gamma_spatial_q2_sd_form(fx$coords), family=Gamma(link="log"),
  data=fx$data, control=drm_control(se=FALSE))
keys <- c('sd_spatial(id, dpar = "mu", coef = "(Intercept)")',
          'sd_spatial(id, dpar = "mu", coef = "x")')
print(lapply(keys, function(key) coef(fit,key)))
print(head(predict(fit,dpar=keys[2L])))
print(fit$opt$convergence)
# sigma~1 estimates one shape-related scale: shape=sigma^-2.
# K is not normalized. Marginal field SD is predicted_sd*sqrt(1+1e-6).
# Native complete-data point fitting only; coverage and Julia parity unassessed.
# Meshes, labelled/correlated blocks, multiple slopes and extra random layers
# remain outside this route. Fresh marginal two-field simulation is unavailable.
