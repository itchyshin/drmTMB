# Model separate variation in intercepts and slopes among related groups.
# For k = 0,1: b_k = diag(exp(Z_k alpha_k)) u_k, u_k ~ N(0,K).
# The two fields are independent. Predictors z0,z1 are constant within groups;
# x varies within groups. The data below are synthetic.
library(drmTMB)
set.seed(2026102709L)
groups <- 64L
repeats <- 20L
ids <- sprintf("relmat%03d", seq_len(groups))
index <- seq_len(groups)
diagonal <- seq(0.8, 1.3, length.out = groups)
K <- 0.25^abs(outer(index, index, "-")) *
  outer(sqrt(diagonal), sqrt(diagonal))
dimnames(K) <- list(ids, ids)
z0 <- rep(c(-1, 1), groups / 2L)
z1 <- rep(c(-1, 1), each = groups / 2L)
sd0 <- exp(log(0.5) + 0.5 * z0)
sd1 <- exp(log(0.4) - 0.5 * z1)
b0 <- sd0 * drop(t(chol(K)) %*% rnorm(groups))
b1 <- sd1 * drop(t(chol(K)) %*% rnorm(groups))
ii <- rep(index, each = repeats)
x <- rep(seq(-1.2, 1.2, length.out = repeats), groups)
eta <- 0.2 + 0.3 * x + b0[ii] + x * b1[ii]
mu <- 1e-12 + (1 - 2e-12) * plogis(eta)
# Beta precision phi = sigma^-2. The response variance also depends on mu.
sigma <- 0.35
phi <- sigma^-2
dat <- data.frame(
  y = rbeta(length(ii), mu * phi, (1 - mu) * phi),
  id = factor(ids[ii]), x = x, z0 = z0[ii], z1 = z1[ii]
)
fit <- drmTMB(
  bf(y ~ x + relmat(1 + x | id, K = K), sigma ~ 1,
     sd(id, level = "relmat", coef = "(Intercept)") ~ z0,
     sd(id, level = "relmat", coef = "x") ~ z1),
  family = beta_family(), data = dat,
  control = drm_control(se = FALSE)
)
print(coef(fit, 'sd_relmat(id, dpar = "mu", coef = "(Intercept)")'))
print(coef(fit, 'sd_relmat(id, dpar = "mu", coef = "x")'))
slope_sd <- predict(fit, dpar = 'sd_relmat(id, dpar = "mu", coef = "x")')
# A non-unit K diagonal contributes to marginal field variance:
# Var(b_gk) = fitted_sd_gk^2 * K[g,g]. Keep the supplied kernel scaling.
# Equivalent precision input uses the inverse of the full named matrix.
Q <- solve(K)
# Substitute relmat(1 + x | id, Q = Q) in the same model to use it.
conditional_draw <- simulate(fit, nsim = 1L, seed = 2026102710L, re.form = NULL)
# Here sigma ~ 1 estimates one precision scale shared across observations.
# Evidence covers native complete-data point fitting with no random effect on
# sigma. Interval coverage and Julia parity remain unassessed.
# Fresh marginal draws of both fields remain unavailable. This example uses one
# unlabelled intercept-plus-one-slope relmat term. A separate native Beta route
# covers one structured intercept with a predictor-dependent SD. Slope-only,
# multiple slopes, other random layers and missing-data routes remain refused.
print(fit$opt$convergence)
