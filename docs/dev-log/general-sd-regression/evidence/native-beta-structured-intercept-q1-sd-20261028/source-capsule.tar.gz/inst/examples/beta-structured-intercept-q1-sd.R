# Predictor-dependent SD for one related-matrix Beta random intercept.
# Synthetic responses; the named covariance is defined independently of drmTMB.
library(drmTMB)
set.seed(2026102810L)
ids <- sprintf("site%03d", seq_len(64L))
d <- seq(0.8, 1.3, length.out = length(ids))
K <- 0.25^abs(outer(seq_along(ids), seq_along(ids), "-")) *
  outer(sqrt(d), sqrt(d))
dimnames(K) <- list(ids, ids)
z <- stats::setNames(rep(c(-1, 1), each = 32L), ids)
u <- stats::setNames(drop(t(chol(K)) %*% rnorm(64L)), ids)
group <- rep(ids, each = 20L)
x <- rep(seq(-1.2, 1.2, length.out = 20L), 64L)
eta <- 0.2 + 0.3 * x + exp(log(0.5) + 0.5 * z[group]) * u[group]
mu <- 1e-12 + (1 - 2e-12) * plogis(eta)
phi <- 0.35^-2
dat <- data.frame(y = rbeta(length(group), mu * phi, (1 - mu) * phi),
  x = x, id = factor(group, levels = rev(ids)), z = unname(z[group]))

fit <- drmTMB(bf(y ~ x + relmat(1 | id, K = K), sigma ~ 1,
  sd(id, level = "relmat") ~ z), family = beta_family(), data = dat,
  control = drm_control(se = FALSE))
coef(fit, "sd_relmat(id)")
head(predict(fit, dpar = "sd_relmat(id)"))
# These predictions are SD loadings s_g relative to raw K. The marginal
# intercept SD for site g is s_g * sqrt(K[g, g]).

# For coordinates, pair spatial(1 | id, coords = coords) with
# sd(id, level = "spatial") ~ z. Match coordinate row names to site IDs;
# the package fixes the range from those coordinates.
