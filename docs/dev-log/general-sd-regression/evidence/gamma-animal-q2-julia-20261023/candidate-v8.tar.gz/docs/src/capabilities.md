# Detailed capabilities and limits

Use this page **after** choosing a scientific route, not as a first tutorial.
For a first distributional model, start with [Getting started](getting-started.md).
For a tree, start with [Phylogenetic structured effects](tutorials/phylogenetic-models.md).
For Gaussian meta-analysis with supplied sampling variances, start with
[Mean effects and residual heterogeneity](tutorials/meta-analysis.md).

This is the detailed map of what `DRModels.jl` can fit today. It is deliberately
conservative: “tested” means the route has a worked example and routine checks
for the listed use; “implemented, untested” means it is not yet a recommended
analysis route; and “not available” means the request cannot currently be fit
with DRModels.jl.

Status legend:

- **Tested**: suitable for the listed use after your routine model checks.
- **Impl, untested**: not yet a recommended analysis route.
- **Not available**: this request cannot currently be fit with DRModels.jl.

Use [What can I fit today?](model-guides/model-map.md) for a model-building
route, and [Getting started](getting-started.md) for runnable syntax.

## Response families

Each family below can be fitted with fixed effects. The family-level tests use
simulated data with known parameters; comparisons with the optional R bridge are
run separately.

| Family | Mean-axis random effects | Status and boundary |
|---|---|---|
| Gaussian | intercepts, slopes, correlated, crossed, and structured effects | **Tested** |
| Student-t | intercepts and slopes | **Tested** |
| SkewNormal | ordinary mean intercepts and one independent numeric mean slope | **Tested** in Julia for one predictor-dependent coefficient SD, with fixed `sigma ~ 1` and `nu ~ 1`, complete responses, and group-constant SD predictors. Intercept and slope routes have synthetic recovery and independent likelihood oracles; slope additionally has prediction, marginal-simulation, and bootstrap-refit smoke checks. Interval coverage is not calibrated; correlated and structured effects are not established. |
| Poisson | intercepts, slopes, crossed, and phylogenetic effects | **Tested** |
| NegBinomial2 | intercepts, slopes, crossed, and phylogenetic effects | **Tested** |
| TruncatedNegBinomial2 | intercepts and one independent mean slope | **Tested** fixed effects and ordinary IID SD regression; see below |
| TruncatedPoisson | one ordinary mean intercept or one selected independent numeric mean slope with predictor-dependent SD | **Tested** for ordinary IID intercept and slope routes; select a slope with `coef(x)`. SD predictors must be constant within groups; missing or `NaN` responses are dropped with a warning; correlated and structured effects and a `hu` combination are not supported on this route |
| Beta | intercepts, slopes, crossed, and phylogenetic effects | **Tested**; crossed random effects have numerical tests but no complete worked analysis |
| BetaBinomial | intercepts, slopes, crossed, and phylogenetic effects | **Tested**; constant `sigma` only |
| Binomial | intercepts, selected slope routes, crossed, and phylogenetic effects | **Tested**; see the specific SD-regression and slope boundaries below |
| Gamma | intercepts, slopes, crossed, phylogenetic, and coordinate-spatial effects | **Tested**; predictor-dependent SDs include one Julia coordinate-spatial mean intercept with a synthetic recovery and constant-SD equivalence check. Cross-engine spatial parity is not established; crossed random effects have numerical tests but no complete worked analysis |
| LogNormal | intercepts, slopes, phylogenetic, and known-matrix effects | **Tested**; `animal` and coordinate-spatial effects are refused |
| ZeroOneBeta | intercepts and independent mean slopes | **Tested** for one ordinary mean intercept or one independent numeric mean slope with a predictor-dependent SD; see the family boundary below |
| Tweedie | one ordinary mean intercept, one selected independent numeric mean slope, or one related-matrix mean intercept with predictor-dependent SD | **Tested** for synthetic recovery and an independent likelihood oracle; the slope requires `coef(x)`, and SD predictors must be constant within groups with fixed `sigma`/`nu` formulas. The related-matrix route uses the supplied `K`; other structured and correlated SD effects are not established. Interval coverage is not calibrated. |
| CumulativeLogit (ordinal) | one ordinary mean intercept or one independent numeric mean slope with predictor-dependent SD | **Tested** for coefficient recovery and prediction; select slope targets with `coef(x)`. The route requires complete outcomes and uses 41-node adaptive Gauss–Hermite quadrature; correlated and structured SD effects are not established, and interval coverage is not calibrated. |

**Count modifiers** `zi` (zero-inflation) and `hu` (hurdle): implemented in the
Poisson/NB2 paths; **Tested**.

**Beta boundary modifiers** `zoi` / `coi` (zero-/one-inflation): the
`ZeroOneBeta()` family handles the boundary mass; **Tested**.

## Distributional (location–scale) sub-models

A formula per distributional parameter is the core grammar: `bf(...)` gives
the mean, scale, and any additional parameter supported by the chosen family
their own formulas.

| Capability | Status and boundary |
|---|---|
| Gaussian mean μ and scale σ formulas | **Tested**; both intercepts and slopes are recovered. |
| Non-Gaussian `sigma` or dispersion formula | **Tested** for families with a dispersion model. |
| Student-t `nu` (degrees of freedom) formula | **Tested**. |
| Random effect on the Gaussian scale axis, `sigma ~ (1\|g)` | **Tested**. By default each group's effect is integrated by 32-node Gauss–Hermite quadrature. That is close to exact for small groups but loses accuracy as groups grow. In our checks with 150 to 400 rows per group, a default fit's log-likelihood differed from drmTMB's by up to about 4 units, sometimes above and sometimes below, and in two of those checks its random-effect SD estimate was about twice drmTMB's. Pass `marginal = :Laplace` to use the Laplace approximation that drmTMB uses; it then gives the same log-likelihood, estimates and standard errors as drmTMB, and stays within 0.01 units of the exact value at those group sizes. Use it for large groups or when you compare results with drmTMB. `:Laplace` needs a fixed-effect mean and maximum likelihood; other models refuse it. `lrtest` accepts a `:Laplace` fit against the fixed-effect model `sigma ~ 1`, but refuses to compare it with a default-integrator fit of a random-effect model. Parametric bootstrap intervals for the random-effect SD are not valid on this route yet, under either integrator, because the replicates do not redraw the random effect on `sigma`; use profile or Wald intervals for that SD. |
| `sigma(fit)` and `corpairs(fit)` | **Tested** post-fit accessors. |

## Location–scale–scale models (LSS, `sd()`)

A third submodel can put a linear predictor on the log standard deviation of a
random effect: `sd(group) ~ z` or `sd(species, phylogenetic) ~ z`.

| Capability | Status and boundary |
|---|---|
| Gaussian IID LSS `sd(group) ~ z` | **Tested** under ML and opt-in REML for an ordinary intercept, or for one independent numeric mean slope selected with `coef(x)`. SD predictors must be constant within group. Correlated and multi-component slopes are not admitted on this route. |
| Gaussian phylogenetic LSS `sd(species, phylogenetic) ~ z` | **Tested** under ML and opt-in REML; large phylogenetic fits use the sparse engine. |
| Gaussian sparse phylogenetic LSS | **Tested.** Request `sparse = true` or `algorithm = :sparse_lbfgs`. |
| Gaussian multi-component LSS | **Tested** for multi-IID and IID-plus-phylogenetic structures. |
| Gaussian LSS with incomplete responses | **Tested** for `missing` or `NaN` outcomes on supported LSS routes. |
| Bernoulli/Binomial IID mean-effect LSS | **Tested** for an ordinary intercept and an independent numeric slope, each with its own group-level SD formula; the intercept and slope may share a grouping variable when selected explicitly. The intercept has rowwise SD prediction, profile and bootstrap plumbing; the slope has a scalar-integral oracle, recovery smoke test and bootstrap smoke test. Slope SDs describe the random coefficient, not its observation-specific contribution. Calibration is not established; correlated blocks and structured covariance routes are outside this IID row. |
| Bernoulli/Binomial crossed IID SD regression | **Tested in Julia** for two independent ordinary intercepts on distinct grouping variables, each with its own SD formula. Checks include synthetic recovery, a dense fixed-parameter Laplace oracle, target-specific rowwise prediction, and one marginal bootstrap-refit smoke test. Larger crossed layouts, nested effects, slopes in this two-group route, and interval calibration are not established. |
| Bernoulli/Binomial correlated-block SD regression | **Tested in Julia** for one ordinary intercept-slope block with separate coefficient-specific SD formulas and constant correlation. The route has an independent two-dimensional normal-integration oracle and constant-SD equivalence checks. Predictor-dependent correlation and multiple correlated blocks are not included; interval coverage is not calibrated. |
| Bernoulli/Binomial phylogenetic SD regression | **Tested in Julia** for one phylogenetic mean intercept with `sd(species, phylogenetic) ~ z`, alone or with one ordinary intercept and its own SD formula. The mixed route has a dense Laplace likelihood oracle, a seeded marginal-draw oracle, and one converged bootstrap-refit smoke test. The phylogenetic SD uses raw branch-length covariance by default. Recovery and interval coverage are not calibrated; additional structured providers and more complex combinations remain outside this evidence. |
| Bernoulli/Binomial animal SD regression | **Tested in native TMB and Julia** for one animal mean intercept `animal(1 | g)` or one slope-only animal coefficient `animal(0 + x | g)`. Native TMB selects the target with `sd(g, level = "animal")`; Julia uses `sd(g, animal)`. The native slope test checks synthetic recovery, rowwise coefficient-SD prediction, conditional and marginal simulation, save/reload, constant-SD likelihood equivalence, and the slope's row-level contribution. Julia adds a dense Laplace oracle for `D A D` and a bootstrap smoke check. Both require complete responses and a positive-definite relatedness matrix; native TMB aligns it by dimnames, while Julia uses first-seen group order. The reported `sd` is the random coefficient SD, not `abs(x) × sd`. Multi-coefficient animal blocks, additional effects, other structured markers, and interval calibration are not established. |
| Bernoulli/Binomial related-matrix SD regression | **Tested in Julia** for one mean intercept `relmat(1 | id)` with `sd(id, relmat) ~ z`. Uses the supplied positive-definite `K` without normalization, so the latent covariance is `D K D`; matrix ordering follows first-seen `id`. Checks include synthetic recovery, rowwise prediction and prediction SEs, dense Laplace oracle, constant-SD equivalence, seeded marginal simulation and one bootstrap-refit smoke test. Complete responses are required. Native TMB parity and interval calibration are not established. |
| Poisson IID mean-effect LSS | **Tested** for one ordinary intercept or one independent numeric slope. Both routes accept fixed `offset(...)` terms. The intercept has rowwise SD prediction, profile/bootstrap plumbing and an independent fixed-parameter integral; the slope has a recovery smoke, rowwise prediction and an independent quadrature oracle. SD predictors must be constant within group. Calibration is not established; correlated blocks, `zi`/`hu`, missing responses and REML are refused. |
| Poisson related-matrix SD regression | **Tested in Julia** for one mean intercept `relmat(1 | id)` with `sd(id, relmat) ~ z`, including fixed row offsets. Includes synthetic coefficient recovery, rowwise SD prediction and prediction-SE smoke, a dense Laplace oracle, constant-SD equivalence, seeded marginal-simulation check, and one bootstrap-refit smoke test. The offset case has an independent dense Laplace and marginal-simulation oracle. The supplied positive-definite `K` is normalized to a correlation matrix, matching the existing constant-SD Julia Poisson route; this does not establish native TMB parity for non-unit-diagonal `K`. Complete responses are required. Interval coverage is not calibrated. |
| Poisson animal SD regression | **Tested in Julia** for one mean intercept or one animal slope-only coefficient with `sd(g, animal) ~ z`, using covariance `A` or intercept precision `Ainv`; fixed row offsets are supported. Julia normalizes `A` to a unit-diagonal correlation matrix; it uses `Ainv` directly as precision, giving latent covariance `D Ainv⁻¹ D`. Direct Julia `Ainv` rows and columns follow first-seen group order. Existing checks include recovery, a dense Laplace objective, group-SD prediction, marginal simulation, save/reload, constant-SD equivalence, and precision/covariance-route agreement. New offset fixtures cover intercept, slope, `A`, and `Ainv`; the intercept offset also has an independent dense oracle. A same-data R `engine = "julia"` versus native-TMB fixture checks SD coefficients, log likelihood, and named group-SD predictions for `Ainv`. This is one parity fixture, not broad engine parity. Complete responses and group-constant SD predictors are required. Interval coverage is not calibrated. |
| Poisson phylogenetic SD regression | **Tested in Julia** for one phylogenetic mean intercept with `sd(species, phylogenetic) ~ z`, including fixed row offsets. The offset case checks fitted means against the offset-inclusive predictor and matches an independent dense Laplace oracle. Cross-engine parity and interval calibration are not established. |
| NB2 IID mean-effect LSS | **Tested** for one ordinary intercept or one independent numeric slope. The intercept has rowwise SD prediction and prediction-SE output, positive/negative recovery, constant-SD equivalence, a fixed-parameter integral oracle, and a bootstrap refit. The slope has synthetic recovery, rowwise SD output, an independent likelihood oracle using the row-specific slope loading, and a same-data comparison with native TMB. Both require complete data and fixed `sigma ~ 1`; SD predictors must be constant within group. Calibration is not established; correlated blocks, offsets, `zi`, missing responses and REML are refused on the ordinary route. A separate animal-intercept route accepts covariance `A` or precision `Ainv` for the unit-diagonal animal correlation matrix; a focused synthetic test checks same-data coefficient, likelihood, and group-SD agreement under reordered observations. Pedigree input and interval coverage are not established. Fixed-effect `hu` is supported only for the narrow Julia hurdle-intercept cell below. |
| Hurdle NB2 IID mean-effect LSS | **Tested in Julia** for one ordinary mean random intercept or one selected independent numeric mean slope with a group-level SD formula, fixed-effect `hu`, fixed `sigma ~ 1`, complete non-negative integer responses, and group-constant SD predictors. Checks include signed synthetic recovery, an independent scalar-integral oracle, the zero-SD likelihood limit, group/row coefficient-SD outputs, marginal simulation and one bootstrap refit retaining `nAGQ`. For a slope `(0 + x | g)`, use `sd(g, coef(x)) ~ z`; the SD is for the coefficient and the row contribution is `x_i b_g`. Zeros inform `hu`, not the mean SD; groups with no positive counts add no information about that SD. Random effects in `hu`, `zi`, structured/correlated effects, offsets, missing responses, and REML are not covered; interval coverage is not calibrated. |
| Gamma IID mean-effect LSS `sd(group) ~ z` | **Tested** for one ordinary intercept and one independent numeric slope. The intercept route has rowwise SD prediction and SE output, constant-SD equivalence, an independent quadrature oracle, and a bootstrap refit; the slope route has a synthetic recovery smoke, rowwise SD output, and an independent quadrature oracle. Both require fixed `sigma ~ 1`, complete responses, and group-constant SD predictors. Calibration is not established; correlated blocks, structured effects, and other marginal routes are refused. |
| Gamma structured mean-effect SD regression | **Tested in Julia** for one `relmat(1 | g)` with `sd(g, relmat) ~ z`, one animal intercept `animal(1 | g)`, one slope-only animal coefficient `animal(0 + x | g)`, or an independent animal intercept-and-slope pair `animal(1 + x | g)` with separate `sd(g, animal, coef(intercept)) ~ z0` and `sd(g, animal, coef(x)) ~ z1` targets; fixed `sigma ~ 1`, complete responses, and group-constant SD predictors are required. For the combined pair, all-zero `x` is refused, as is constant `x` with identical SD designs because the variance components are confounded; other group-varying designs remain eligible. Additional structured terms are refused. Julia normalizes supplied `K` or `A` to unit diagonal. Native TMB candidates support animal intercept and slope-only cells but retain the supplied `A` scale. The reported multiplier therefore has the same scale across engines only when `diag(A) = 1`; non-unit-diagonal cross-engine parity is unverified. The combined route models independent latent intercept and slope fields and includes their joint data Hessian terms. Its checks include synthetic recovery, a dense joint-Laplace oracle, constant-design objective comparison against an independent dense oracle, selected group-SD prediction, seeded marginal simulation, serialization, and one bootstrap-refit smoke test. Single-field animal routes also have constant-SD equivalence and bootstrap checks. For a slope, `sd` is the coefficient SD and each row contributes `xᵢ b_g`. The fitter bounds `log(sigma)` to `[-4, 4]` and withholds Wald standard errors at or within one Hessian step of that boundary. Other Gamma structured provider and coefficient combinations and interval calibration are not established. |
| Gamma phylogenetic mean-effect SD regression | **Tested in Julia** for one `phylo(1 | species)` intercept with `sd(species, phylogenetic) ~ z`, fixed `sigma ~ 1`, complete responses, and a group-constant SD predictor. Uses the sparse augmented-tree Laplace fit and raw branch-length covariance; the marginal tip SD is the fitted multiplier times the square root of the corresponding raw covariance diagonal. Checks include signed coefficient recovery, constant-SD equivalence, shuffled-row identity, public SD prediction, save/reload, a sparse-tree simulation covariance oracle, predictor-dependent marginal simulation, and one bootstrap-refit smoke test. Cross-engine parity and interval coverage are not established. |
| Beta IID mean-effect LSS `sd(group) ~ z` | **Tested** for one ordinary intercept or one independent numeric slope with fixed `sigma ~ 1`, complete responses, and group-constant SD predictors. The intercept has synthetic recovery, rowwise SD prediction and prediction SEs, constant-SD equivalence, an independent fixed-parameter quadrature oracle, and a bootstrap refit. The slope has synthetic recovery, coefficient-SD prediction, save/reload checks, and one same-data comparison with native TMB. Calibration is not established; correlated blocks, structured effects, and other marginal routes are refused. |
| Student-t IID mean-effect LSS `sd(group) ~ z` | **Tested** for one ordinary mean intercept or one independent numeric mean slope, fixed `sigma ~ 1` and `nu ~ 1`, and group-constant SD predictors. The slope SD refers to the random coefficient, not its observation-specific contribution. The intercept has synthetic recovery, rowwise SD prediction and prediction-SE smoke, constant-SD equivalence, and an independent fixed-parameter quadrature oracle; the slope has a signed recovery check, rowwise coefficient-SD prediction, and an independent fixed-parameter quadrature oracle. Calibration is not established; correlated blocks, structured effects, distributional slopes, and `marginal = :Laplace` are refused. |
| BetaBinomial IID mean-effect LSS `sd(group) ~ z` | **Tested in Julia** for one ordinary mean random intercept or one independent numeric mean slope, fixed `sigma ~ 1`, complete responses, and group-constant SD predictors. Intercept and slope routes have synthetic coefficient recovery, rowwise coefficient-SD predictions, constant-SD equivalence for the intercept, and fixed-parameter integration checks. Coverage calibration is not established; correlated blocks, structured effects, and other marginal methods are refused. |
| Tweedie IID mean-intercept LSS `sd(group) ~ z` | **Tested in Julia** for one ordinary mean random intercept, group-constant SD predictors, and fixed-effect mean, dispersion, and power submodels. The route has synthetic coefficient recovery, rowwise SD prediction, and constant-SD equivalence. Missing outcomes follow the existing drop-and-warn policy. Calibration is not established; slopes, correlated blocks, and structured effects are not implemented. |
| CumulativeLogit IID mean-intercept LSS `sd(group) ~ z` | **Tested in Julia** for one ordinary location random intercept, complete outcomes, and group-constant SD predictors. Includes signed synthetic recovery, rowwise SD prediction, marginal simulation, and constant-SD equivalence. The SD is on the cumulative-logit link scale and uses 41-node adaptive Gauss–Hermite quadrature. Coverage calibration is not established; slopes, correlated blocks, and structured effects are not included in this route. |
| LogNormal IID mean-effect LSS `sd(group) ~ z` | **Tested in Julia** for one ordinary mean intercept or one independent numeric mean slope, fixed `sigma ~ 1`, complete responses, and group-constant SD predictors. The slope SD describes the random coefficient; its row contribution is `xᵢ b_g`. Both routes use the exact Gaussian-on-log-response marginal with the LogNormal Jacobian and include synthetic recovery, rowwise SD prediction, marginal simulation, constant-SD equivalence, and an independent covariance likelihood check. Coverage calibration is not established; correlated blocks and structured SD effects are not included. |
| TruncatedNegBinomial2 IID mean-effect LSS | **Tested in Julia** for one ordinary mean intercept or one independent numeric mean slope, fixed `sigma ~ 1`, complete positive integer responses, and group-level SD predictors. Both have signed synthetic recovery; the slope has rowwise coefficient-SD output and an independent scalar-integral likelihood oracle. The intercept also has a bootstrap-refit smoke check that retains `nAGQ`. Structured effects, offsets, `hu`, and SD-by-`sigma` models are refused; interval coverage is not calibrated. |
| TruncatedPoisson IID mean-intercept LSS `sd(group) ~ z` | **Tested in Julia** for one ordinary mean random intercept with group-constant SD predictors. It includes signed synthetic recovery, rowwise SD prediction and prediction-SE smoke, marginal simulation, a bootstrap-refit smoke, and an independent scalar normal-integral likelihood oracle. Missing or `NaN` responses follow the package's observed-row drop-and-warn policy. Slopes, structured effects, `hu`, and interval-coverage calibration are not established. |
| Other supported response families | Predictor-dependent random-effect SD regression is not implemented or tested for every registered family, endpoint, effect shape, provider, and engine. Existing fixed-effect and constant-SD support does not establish SD-regression support. |
| ZeroOneBeta IID mean-effect SD regression | **Tested in Julia** for one ordinary mean intercept or one independent numeric mean slope, with fixed `sigma ~ 1`, `zoi ~ 1`, and `coi ~ 1`, complete responses, and group-constant SD predictors. The intercept retains the existing 32-node likelihood and constant-SD equivalence; the slope uses adaptive quadrature, a synthetic recovery check, and an independent normal-integral oracle. Calibration is not established; correlated and structured effects are not included. |


## Random-effect structures

### Plain (unstructured) random effects on the mean

| Structure | Status and boundary |
|---|---|
| Gaussian random intercept `(1\|g)` | **Tested** |
| Gaussian random slope `(x\|g)` | **Tested** |
| Correlated intercept and slope | **Tested** |
| Multiple, crossed, or nested grouping factors | **Tested** |
| Poisson crossed random effects | **Tested** with sparse Laplace integration |

### Structured random effects with a known relatedness matrix (closed-form Gaussian)

A structured intercept `u ~ N(0, σ_s² K)` keeps the Gaussian marginal exactly
Gaussian and is fit in closed form (PGLS / matrix-determinant lemma).

| Marker | Supplies | Status |
|---|---|---|
| `relmat(1\|id)` | user matrix `K` | **Tested** |
| `animal(1\|id)` | additive-relatedness `A` | **Tested** |
| `phylo(1\|species)` on the **mean** | tree (`AugmentedPhy` or Newick) | **Tested** |
| `spatial(1\|site)` | coordinates; `K(ρ)=exp(-d/ρ)`, with ρ estimated | **Tested** |
| `temporal(1\|id, time, ar1)` / `temporal(1\|id, time, ou)` on the **mean** (drmTMB `temporal(1 \| id, time = …, structure = "ar1"/"ou")`) | an integer occasion (AR1) or numeric elapsed-time (OU) column | **Tested** (`test/test_temporal_ar1.jl`, `test/test_temporal_ou.jl`): dense-oracle likelihood to 1e-10, recovery, and a GLLVModels.jl logLik cross-check to 1e-13. ML, `sigma ~ 1`, optional same-id `(1\|id)` only; other families, `sigma` terms, slopes, REML and other structured terms are refused by name. `fitted`/`predict` are population-level (drmTMB's `fitted` is conditional; conditional effects are in `ranef`); `simulate`/`bootstrap_ci` draw a fresh temporal chain. Wald SEs and intervals are reported for every coordinate (drmTMB: AR1 mean coefficients only; OU Wald refused), and `bootstrap_ci` covers every coordinate (drmTMB refuses the temporal bootstrap); these are extensions with no interval calibration claimed. drmTMB parity: 8 cells (AR1 and OU, with and without `(1\|id)`, including the drmTMB article's two datasets) matched logLik to ≤ 1e-11 and every estimate to ≤ 1e-8 relative in the measured run (Julia 1.12.6, Linux, Totoro); the tests enforce 1e-8 absolute (logLik) and 1e-6 relative (`test/test_parity_temporal.jl`; worked example: [Temporal AR1, OU and Toeplitz effects](tutorials/temporal-random-effects.md)). |
| `phylo(1\|species) + temporal(1\|species, elapsed, ou)` on the **mean**, `drm(...; tree)` (drmTMB `phylo(1 \| species, tree = tree) + temporal(1 \| species, time = elapsed, structure = "ou")`) | an **ultrametric** Newick tree (or `AugmentedPhy`) whose tips are exactly the observed species; zero-length branches allowed; numeric elapsed time | **Tested** (`test/test_temporal_phylo_ou.jl`): additive phylogenetic stable intercept (tip-correlation scale, as drmTMB) + independent OU path per species + noise; dense-oracle likelihood ≤ 9.2e-13 (random θ, decay and stable-SD extremes), zero-length branches and the pruning pass on non-ultrametric trees exact to 1e-10, dense-oracle modes, recovery smoke, full-model `simulate` (Julia 1.10.12). drmTMB's rules are refused by name (OU only, same grouping, no `(1\|species)`, ≥ 3 species with ≥ 2 times, ≥ 3 lags, tips = species, ultrametric tree). drmTMB parity: 2 cells (the drmTMB commit is recorded in each cell's `expected.meta.toml`): logLik ≤ 5.5e-12, estimates ≤ 2.1e-11 relative, conditional fitted ≤ 2.3e-12 (Julia 1.10.12). No interval claim: profile `confint` warns that the intervals are uncalibrated, as drmTMB's does. drmTMB refuses Wald and bootstrap intervals for this fit; DRModels.jl returns them as an extension, without a calibration claim, and does not warn that they are uncalibrated. Temporal boundary diagnostic in `check_drm(fit).temporal_boundary`. Worked example: [Temporal AR1, OU and Toeplitz effects](tutorials/temporal-random-effects.md). |
| `temporal(1\|id, occ, homtoep)` on the **mean** (drmTMB `temporal(1 \| id, time = occ, structure = "homtoep")`) | a complete panel: every `id` observed at the same 3–12 equally spaced integer occasions, at least as many ids as occasions (missing responses dropped first, as drmTMB) | **Tested** (`test/test_temporal_homtoep.jl`): within-series covariance σ²R, R a free positive-definite Toeplitz correlation matrix parameterised by partial autocorrelations (Durbin–Levinson); σ is the TOTAL SD and, as in drmTMB, no process SD, residual SD or `(1\|id)` (not identified). BigFloat dense-oracle likelihood ≤ 4e-15 relative (partial autocorrelations up to ±0.995) and a 2048-bit Yule–Walker reference ≤ 3e-14 at atanh PACs up to ±40, dense Schur check of the parameterisation, recovery, `simulate` lag covariances, whitened residuals (`type = :quantile`) against a dense Cholesky (Julia 1.10.12). drmTMB's panel rules refused by name. **Inference scope:** as drmTMB, mean-coefficient profile intervals; `vcov`, `stderror`, Wald `confint`, `predict(se = true)` and profiles of σ or the lag correlations are refused (`confint` and `profile_curve`, as drmTMB's `profile()`; `parameter_surface` too, which has no drmTMB counterpart); `coeftable` shows `NaN` SEs. As an extension (drmTMB refuses the temporal bootstrap), `bootstrap_ci` / `bootstrap_summary` / `bootstrap_result` give mean-coefficient percentile intervals, without a calibration claim. drmTMB parity: 3 cells (the drmTMB commit is recorded in each cell's `expected.meta.toml`): logLik ≤ 9.6e-12, lag correlations ≤ 4.9e-10, Pearson residuals ≤ 1e-6, profile endpoints ≤ 6.6e-6 (Julia 1.10.12). No calibration claim of its own. Worked example: [Temporal AR1, OU and Toeplitz effects](tutorials/temporal-random-effects.md). |
| One `phylo`/`relmat`/`animal` marker **plus** ordinary `(1\|h)` or `(0 + x\|h)` bars on the mean | tree / `K` / `A` | **Tested**, ML only; matches drmTMB `engine = "tmb"` on nine test datasets. Independent blocks; the marker SD is on the correlation scale. REML, `(1 + x\|h)`, range-estimated `spatial()`, `penalty` and sparse algorithms are refused by name. With `meta_V(v)` added, the `meta_V` row below fits it. |

The Gaussian table above describes the simple intercept route. It does not rule
out the supported non-Gaussian phylogenetic mean models or the more specific
phylogenetic location--scale routes below; those routes have their own family
and inference boundaries.

### Non-Gaussian phylogenetic random intercept on the mean (sparse Laplace)

A `phylo(1|species)` intercept on the mean for non-Gaussian families uses the
verified sparse augmented-state Laplace engine.

| Family | Status |
|---|---|
| Poisson | **Tested** |
| NegBinomial2 | **Tested** |
| Gamma | **Tested** |
| Binomial | **Tested** |
| Beta | **Tested**; its gradient tolerance is deliberately looser than 1e-6 |
| BetaBinomial | **Tested**; constant `sigma` only |
| CumulativeLogit (ordinal) | **Tested**; intercept-only |

## Location–scale with a phylogenetic random effect on the scale (q=2 route)

A shared random effect on **both** the mean and log-dispersion axes uses a q=2
augmented Laplace calculation and exact O(p) outer gradient. The full fit,
gradient, Wald summaries, and profile-likelihood intervals have regular
package-test coverage.

| Capability | Status |
|---|---|
| Coupled mean and log-dispersion axes for NB2 and Gamma | **Tested** through the public `drm()` interface |
| Beta and Beta-binomial kernels | Not available through the public coupled location–scale interface |
| Poisson and lognormal leaves | **Implemented, untested**; do not rely on them for fitted location–scale models |

!!! note
    For **non-Gaussian** responses, coupled location–scale random effects are
    currently available only for NB2 and Gamma. Other non-Gaussian families can
    place structured or ordinary random effects on the mean axis, not the scale
    axis.

    **Gaussian has a separate, tested scale-phylogeny route.** Write
    `bf(y ~ … + phylo(1|sp), sigma ~ phylo(1|sp))` for the default separate
    mean- and scale-phylogeny effects. A scale-only phylogeny is also supported.
    `phylo_coupled = true` opts into a free mean–scale phylogenetic correlation;
    the plain two-`phylo` syntax does not do this. Retrieve the two standard
    deviations with `gaussian_locscale_phylo_sds(fit)`; a coupled fit records the
    correlation in `fit.scales[:lambda_cor]`. On the scale-only and separate
    blocks, `profile_ci = true` adds profile intervals for the standard
    deviations; the coupled block computes none.

    This Gaussian route requires a common grouping factor and one phylogenetic
    structured component; it cannot be combined with additional random effects or
    `meta_V`. `method = :REML` is available for the scale-only, separate and
    coupled blocks, and is refused for the iid `sigma ~ (1|g)` route. On these
    three blocks REML is one joint Laplace approximation over the phylogenetic
    effects and **both** the `mu` and `sigma` fixed effects, the restricted
    likelihood native drmTMB (`REML = TRUE`) maximises for this model, and the
    scale-only and coupled blocks are tested against drmTMB's REML
    log-likelihood, degrees of freedom and estimates. Under REML the reported
    `mu`/`sigma` coefficients are the joint mode at the REML variance estimates.
    As in drmTMB, the coupled block's mean–scale phylogenetic correlation is
    bounded at |cor| ≤ 0.999999. When the data put the two phylogenetic effects
    on one axis, the ML and REML estimates sit on that bound and are reported without a
    Wald covariance. Under REML, `profile_ci = true` on the scale-only and separate
    blocks profiles this restricted likelihood. Earlier versions profiled the ML
    likelihood from the REML estimate, which gave neither an ML nor a REML
    interval. A REML fit whose phylogenetic standard deviation is estimated at
    zero is reported as converged, with no Wald covariance. On the scale-only
    and separate blocks, `profile_ci = true` gives its `[0, upper]` interval.
    The coupled block computes no profile interval, under ML or REML, and
    ignores `profile_ci = true` without a warning. A non-Gaussian scale-axis-only intercept is not part of
    the public formula grammar.

## Coevolution: q=4 phylogenetic bivariate location–scale model (PLSM)

The selling-point model: a shared phylogenetic random effect on all four axes
`(μ1, μ2, log σ1, log σ2)` with a 4×4 between-species covariance `Σ_a`, plus a
residual correlation ρ12. The sparse-Laplace fit, exact O(p) gradient, and
public formula route are **tested**.

| Capability | Status |
|---|---|
| `bf(mu1=…, mu2=…, sigma1=…, sigma2=…, rho12=…)` with phylogeny | **Tested**; recovers fixed effects and `Σ_a` |
| `relmat`, `animal`, and fixed-range `spatial` structured providers | **Tested**; spatial range is fixed (default: mean pairwise distance) |
| `vc(fit)`, `ranef(fit)`, and `coevolution_cor` summaries | **Tested**; `fit.ranef.Sigma_a` is ordered `mu1, mu2, sigma1, sigma2` |
| Fixed-effect covariance and Wald standard errors (`q4_vcov=true`) | **Tested** |
| Bootstrap intervals for coevolution correlations | **Tested for tree-based phylogeny**; non-tree structured providers return point summaries only |

## Structured q=2 bivariate Gaussian (mu1/mu2 only)

This is a complete-response exact-Gaussian ML model with matching
structured random intercepts on `mu1` and `mu2`. It requires the same fixed-effect
design on both mean formulas and intercept-only `sigma1`, `sigma2`, and `rho12`
formulas. Current support covers point estimates and exported summaries only.
It does not cover q2 REML, calibrated intervals, non-Gaussian q2 models, or the
full R bridge.

| Capability | Status |
|---|---|
| `phylo(1\|species)` on `mu1` and `mu2`, with residual `rho12` | **Tested** through `drm()` and direct export |
| `relmat(1\|id)` and `animal(1\|id)` on `mu1` and `mu2`, using known `K` / `A` | **Tested** |
| Fixed-covariance spatial q2 fit | Available only in the documented fixed-covariance example; the range-estimating `spatial(...)` formula route is rejected |

## Bivariate and paired responses (residual correlation)

The Gaussian, lognormal and Student-t routes here fit two responses jointly with a
residual/scatter `rho12`; `associate_pairs` instead couples two *already-fitted*
univariate models in a second stage. Only the lognormal route reaches the
structured (`phylo`/`relmat`/`animal`/`spatial`) engines of the two sections
above, and it does so by delegation rather than by a second engine.

| Capability | Status |
|---|---|
| Bivariate Gaussian with residual `rho12` (`cbind` / `mu1`,`mu2`) | **Tested** |
| `rho12(fit)` accessor | **Tested** |
| Bivariate **lognormal** (`drm(bf(…), LogNormal())`, drmTMB's `biv_lognormal()`) | **Tested.** Both responses must be strictly positive and are modeled as bivariate normal on `log(Y)`: `mu1`/`mu2` are log-scale means and `rho12` is a log-residual correlation, not the raw-scale Pearson correlation. Structured `phylo` and `relmat` routes are tested; `animal` and `spatial` are implemented but untested on this route. `method = :REML` is refused for all bivariate LogNormal models. |
| Bivariate **Student-t** (`drm(bf(…, nu = …), Student())`, drmTMB's `biv_student()`) | **Tested.** `sigma1`/`sigma2` are scale parameters, not marginal SDs; `rho12` is a scatter correlation; and `nu = 2 + exp(η)`, so `nu > 2`. One `nu` is shared by the two responses (it may vary by row via `nu ~ x`); zero `rho12` does not imply independence at finite `nu`. This is a residual-only model: `phylo`, `relmat`, `animal`, `spatial`, and `method = :REML` are deliberately refused. |
| **Staged pair association**: `associate_pairs` / `latent_normal` / `association` / `PairAssociation` / `integration_diagnostics` (drmTMB's `associate_pairs()`) | **Tested.** This is a two-stage, frozen-margin estimator, not a joint model. It supports `gaussian_bernoulli`, `gaussian_nbinom2`, `bernoulli_bernoulli`, `bernoulli_nbinom2`, and `nbinom2_nbinom2`; integration diagnostics are available where numerical integration is used. Its uncertainty ignores margin-estimation error, and it offers no simultaneous association bands or profile intervals. The kernel must be explicit; only `association ~ 1` is supported; `marginal = :AGHQ`, non-converged margins, non-Bernoulli binomial margins, and other pair classes are refused. |
| Cross-family bivariate (different families on `y1` vs `y2`) | **Experimental.** `drm(bf(...), (Gaussian(), Poisson()); data = …)` uses a latent-scale scalar correlation in `fit.rho_latent`. It has narrow documented evidence and no interval-coverage claim. `rho12 ~ x` is refused: this route fits a scalar latent correlation, not an observation-specific residual correlation. See [Cross-family methods](model-guides/cross-family-methods.md). |

## Meta-analysis

| Capability | Status |
|---|---|
| `gaussian()` + `meta_V(v)` with **known diagonal** sampling variances; τ on the σ intercept | **Tested** |
| `meta_V(v)` plus random intercepts on the mean: `(1 \| study)`, `phylo(1 \| sp)`, `relmat(1 \| id)`, `animal(1 \| id)`, and sums of these with distinct grouping columns; `sigma ~ x` allowed | **Tested** (ML). Fits the same model as drmTMB `engine = "tmb"`: on seven comparison fits the log-likelihoods agree within 3e-10 and the estimates within 3e-9 (relative). A phylo SD is on the raw branch-length scale (× √height = drmTMB's). Not available: REML, random slopes, `spatial()`, a `sigma` random effect, `sd(g) ~ …`, two fields on one grouping column, missing responses; bootstrap with more than one field refuses. |
| Bivariate known sampling covariance (`meta_vcov_bivariate`) | **Tested** |
| Deprecated `meta_known_V` parity stub | none | **Not available**; use `meta_V` instead. |

## Inference

| Method | Status |
|---|---|
| Wald SEs + CIs (observed information) | **Tested** |
| Profile-likelihood CIs (`profile_result`, `confint(:profile)`) | **Tested** |
| Parametric bootstrap (`bootstrap_ci`/`_summary`/`_result`, serial + threaded) | **Tested** |
| REML for fixed-effect Gaussian location–scale and Gaussian mean `(1 \| g)` | **Tested** |
| `reml_loglik` / `ml_loglik` / `estimation_method` accessors | **Tested** |
| Epsilon-method bias correction (`bias_correct`) | **Tested** |
| **χ̄² (chi-bar-square) boundary inference** (Self–Liang / Stram–Lee mixture) | **Tested** |
| REML on q=4 Laplace and Location–Scale–Scale models | **Tested** |

!!! warning "REML scope"
    `method=:REML` is opt-in. **ML is the default** (REML likelihoods are not
    comparable across fixed-effect structures). Supported models are the fixed-effect
    Gaussian location–scale model; a single Gaussian mean intercept `(1 | g)`;
    Location–Scale–Scale models (`sd(g) ~ z`,
    `sd(species, phylogenetic) ~ z`, and multi-component LSS); and the
    bivariate q=4 location–scale engine; and the Gaussian `phylo(1 | g)`-on-`sigma`
    location–scale blocks (scale-only, separate, coupled), where both the `mu`
    and `sigma` fixed effects are integrated out with the phylogenetic effects.
    Ordinary σ-RE, random slopes, and non-Gaussian REML stay rejected. This is not AI-REML.

    **Normalisation convention:** every REML route in DRModels.jl reports a
    **normalised** restricted log-likelihood, including the `(n_β/2)·log(2π)`
    constant, so `reml_loglik` is directly comparable to lme4's, glmmTMB's,
    TMB's and drmTMB's `logLik()`. (The bivariate q=2/q=4 Laplace routes once
    omitted that constant; this has been corrected.) Two quantities are in use.
    Most routes report the Patterson–Thompson restricted log-likelihood. The
    Gaussian `phylo(1 | g)`-on-`sigma` location–scale blocks instead report
    TMB's **joint-Laplace** restricted log-likelihood: one Laplace
    approximation over the phylogenetic effects and both sets of fixed effects,
    with flat priors on the fixed effects. That is the quantity drmTMB's
    `REML = TRUE` maximises for this model. It is not the Patterson–Thompson
    quantity, because `beta_sigma` enters the likelihood non-linearly, so the
    fixed effects cannot be integrated out exactly. On the scale-only and
    separate blocks, `profile_ci = true` profiles the same restricted
    likelihood. The other variance parameters are re-optimised, and the fixed
    effects are integrated out rather than profiled. The coupled block
    (`phylo_coupled = true`) computes no profile interval.

## Model comparison & accessors

| Capability | Status |
|---|---|
| `lrtest`, `anova`, `aicc`, `weights`, `update` | **Tested** |
| `aic` / `bic` / `dof` / `nobs` / `deviance` / `dof_residual` | **Tested** |
| `coef` / `vcov` / `confint` / `stderror` / `coeftable` | **Tested** |
| `fixef` / `re_sd` / `vc` / `ranef` / `sigma` / `corpairs` | **Tested** |
| `family` accessor | **Tested** |
| `heritability` / `repeatability` / `icc` with delta + profile CIs | **Tested** |
| Drop-in parity accessors (StatsAPI surface) | **Tested** |

## Prediction, post-fit, residuals, simulation

| Capability | Status |
|---|---|
| `fitted` / `residuals` / response-scale `predict` | **Tested** |
| `predict_parameters` / `marginal_parameters` / `prediction_grid` / delta-method prediction SEs | **Tested** |
| `simulate` / `check_drm` / Dunn–Smyth quantile residuals | **Tested** |
| Visualization data (`profile_curve` / `parameter_surface` / `corpairs_data`) | **Tested** |
| Drawing (`drm_figure` / thin `plot_*`; Confidence Eye on `:profile`) | Optional with Makie and AlgebraOfGraphics; package checks cover the no-Makie fallback, not rendered figures |

## R → Julia bridge (engine = "julia")

The optional R bridge for `drmTMB(..., engine = "julia")` converts formulas and
data into a form that Julia can fit, then converts the result back to R.

| Capability | Status |
|---|---|
| `drm_bridge` (string/dict/named-tuple formula → fit → flattened `Dict`); univariate, bivariate, phylo-mean, and narrow q2 structured Gaussian examples | **Tested** for the listed model configurations |
| q2/q4 direct-export helpers (`q2_point_export`, `q4_point_export`) | **Tested** for point summaries only; broader bridge behaviour and interval calibration have not been established |
| `drm_bridge_inference` (profile + bootstrap), limited to the Gaussian phylo SD block (`param=:resd`) | **Tested** |
| Newick tree string parsing + small LRU cache | **Tested** |
| Full R-side glue / `engine="julia"` round-trip in drmTMB | (R repo) | **Not available here**: the Julia primitive is tested; the R package glue lives in the drmTMB repository |

## Marginal method selection (VA/ELBO)

| Capability | Status |
|---|---|
| `marginal=:LA`, the default integrator: per-family integration for ordinary `(1\|g)` effects (5-node adaptive GHQ for NB2, Poisson, and predictor-dependent Gamma SD regression; GHQ-32 on Gaussian `sigma ~ (1\|g)`), per-group adaptive GHQ (5 nodes per axis, #834) on non-Gaussian `(1 + x\|g)`, Laplace on most other random-effect structures | **Tested** |
| `marginal=:VA` Poisson `(1\|g)` public path | **Experimental**; it uses an ELBO approximation, labels the fit `:VA`, and refuses mixed LA/VA AIC or likelihood-ratio comparisons |
| `marginal=:VA` Binomial / NB2 / Gamma / Beta `(1\|g)` | **Experimental**; scale families require `sigma ~ 1` |
| `marginal=:Laplace` Poisson / Binomial / NB2 / Gamma / Beta `(1\|g)` on the mean | **Tested**; the TMB-convention Laplace approximation (the default `:LA` on this cell is per-group adaptive Gauss–Hermite quadrature, 5 nodes per group). Same log-likelihood as native drmTMB to ≤ 4e-10 on ten test datasets. Scale families require `sigma ~ 1`; ML only. `(1 + x\|g)`, crossed terms, `sigma` covariates or random effects, `zi`/`hu` and REML are refused. `lrtest` against the fixed-effects model works; against a `:LA` random-effect fit it is refused. Prefer `:Laplace` when the family `sigma` is small (about 0.01 or less; failures shown at 0.003 to 0.012), where the default GHQ-32 can miss the optimum |
| `marginal=:Laplace` Gaussian `sigma ~ 1 + (1\|g)` (random intercept on the scale axis, fixed-effect mean) | **Tested**; the Laplace approximation native drmTMB uses (the default `:LA` is GHQ-32 on this cell). Same log-likelihood, estimates and standard errors as drmTMB on the test datasets; ML only. See the scale-axis row above for accuracy and for the bootstrap limitation on the random-effect SD |
| `method=:VA` on non-Gaussian `drm()` | **Rejected**: choose `marginal=:VA`; `method` is ML/REML |

## Absent / out-of-scope (explicit)

To avoid overclaiming, note these boundaries:

- **Missing data:** listwise predictor preprocessing is not FIML. Experimental
  joint missing-predictor routes (`mi()`, `JointDrmFit`, `JointTwoDrmFit`,
  `JointFiniteDrmFit`, `imputed`, and `miss_control`) are exported for evaluation,
  but their API and numerics may change and they are not covered by R-parity
  evidence. Gaussian observed-response masking and missing-response handling for
  Location–Scale–Scale `sd()` models are available. General multiple imputation
  outside the joint-model routes and an `na.action`-style option are absent.
- **VA/ELBO:** experimental random-intercept VA is limited to `(1|g)` for
  Poisson, Binomial, NB2, Gamma, and Beta (`sigma ~ 1` where applicable).
  Phylogenetic, crossed, correlated-slope, and zero-inflated/hurdle variants are
  not available.
- **Experimental prototypes:** experimental optimisation and diagnostic prototypes
  are not public analysis methods. The supported REML and `algorithm = :em`
  routes are listed in the Inference table.

## Current evidence boundaries

- `drm_bridge_inference` is tested only for the Gaussian phylogenetic standard
  deviation block (`param=:resd`); other bridge inference parameters are not yet
  supported claims.
- Coupled q=2 location–scale fitting is public and tested for NB2 and Gamma.
  Beta and beta-binomial cannot currently be requested through `drm()` and
  `bf()` for this model. Poisson and LogNormal versions are implemented but have
  not yet been tested as complete analyses.

---

*“Tested” supports the listed use, not a package-wide performance or
interval-coverage claim. Always assess your fitted model and study design.*
