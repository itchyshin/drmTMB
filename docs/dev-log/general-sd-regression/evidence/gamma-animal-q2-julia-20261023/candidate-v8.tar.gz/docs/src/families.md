# Response families

!!! note "Status: Stable"
    Every family below is fitted by the verified `drm` front end, and every
    worked snippet runs. This page is a reference catalogue with one
    minimal fit per family; for the modelling rationale and side-by-side R
    parity see [Choosing response families](model-guides/distribution-families.md)
    and the per-topic tutorials.

You pick a family from the **shape** of your response, then give each of its
parameters a formula with `bf`. The mean **μ** always comes from the response
formula (`y ~ …`); the family's second parameter lives in the `sigma` slot
(`sigma ~ …`) with a family-specific link, and some families add further
parameters (`nu`, `zoi`, `coi`, ordinal cutpoints).

| Response looks like… | Family | Mean link | `sigma` slot |
|---|---|---|---|
| Real-valued, symmetric | `Gaussian()` | identity | residual SD `σ` (log) |
| Real-valued, heavy tails | `Student()` | identity | scale `σ` (log) + d.o.f. `ν = 2 + exp(η)` (not log `ν`) |
| Strictly positive, multiplicative | `LogNormal()` | identity on `log y` | SD of `log y` (log) |
| Strictly positive, right-skewed | `Gamma()` | log | shape via `α = 1/σ²` |
| Positive **with exact zeros** | `Tweedie()` | log | √dispersion `σ` + power `ν ∈ (1,2)` |
| Counts (variance ≈ mean) | `Poisson()` | log | none |
| Counts, overdispersed | `NegBinomial2()` | log | overdispersion scale `σ` (log); size `θ = 1/σ²` |
| Positive counts (zero-truncated) | `TruncatedNegBinomial2()` | log | overdispersion scale `σ` (log); size `θ = 1/σ²` |
| Positive counts, no overdispersion | `TruncatedPoisson()` | log | none |
| Proportions in `(0,1)` | `Beta()` | logit | precision via `φ = 1/σ²` |
| Successes out of trials | `Binomial()` | logit | none (`cbind(s,f)` or `0/1`) |
| Successes, overdispersed | `BetaBinomial()` | logit | precision via `φ = 1/σ²` |
| Proportions on `[0,1]` incl. 0/1 | `ZeroOneBeta()` | logit | precision `φ` + `zoi` / `coi` |
| Ordered categories `1..K` | `CumulativeLogit()` | logit cutpoints | not used (K−1 cutpoints) |

A handful of families share the name of a `Distributions.jl` distribution
(`Gaussian` excepted: `Poisson`, `Binomial`, `Beta`, `Gamma`, `LogNormal`).
DRModels exports its own *family* object of that name; when a snippet also needs the
distribution to simulate, it qualifies it as `Distributions.Poisson` etc.

## Continuous, real-valued

### Gaussian: `Gaussian()`

Identity link on the mean, log link on the residual SD `σ`. The textbook
location–scale model: both the mean and the spread can depend on covariates.

```@example fam
using DRModels, Random, LinearAlgebra
import Distributions          # qualified, for the simulating distributions
Random.seed!(1)

n = 600
x = randn(n)
y = (1.0 .+ 0.5 .* x) .+ exp.(-0.3 .+ 0.4 .* x) .* randn(n)
fit = drm(bf(@formula(y ~ x), @formula(sigma ~ x)), Gaussian(); data = (; y, x))
(mu = coef(fit, :mu), logsigma = coef(fit, :sigma))   # ≈ (1.0, 0.5) and (-0.3, 0.4)
```

For one ordinary mean random intercept or one independent numeric mean slope,
the SD of the random coefficient can also depend on a predictor that is
constant within each group. Select a slope with `sd(g, coef(x))`; its SD is on
the coefficient scale, so each row's contribution is multiplied by `x`. The
Gaussian route supports ML and REML, and `predict_parameters()` returns the
fitted coefficient SD for each row's group.

```@example fam
Random.seed!(2043)
Ggsd, mgsd = 48, 10
ggsd = repeat(1:Ggsd, inner = mgsd)
zgsd_group = repeat([-1.0, 1.0], inner = Ggsd ÷ 2)
zgsd = zgsd_group[ggsd]
xgsd = randn(Ggsd * mgsd)
bgsd = exp.(-0.65 .+ 0.55 .* zgsd_group) .* randn(Ggsd)
ygsd = 0.25 .+ 0.35 .* xgsd .+ xgsd .* bgsd[ggsd] .+ 0.45 .* randn(length(xgsd))
fit_gsd = drm(bf(@formula(ygsd ~ xgsd + (0 + xgsd | ggsd)),
                 @formula(sigma ~ 1),
                 @formula(sd(ggsd, coef(xgsd)) ~ zgsd)),
              Gaussian(); data = (; ygsd, xgsd, zgsd, ggsd))
(coef(fit_gsd, :sd), predict_parameters(fit_gsd, (; ygsd, xgsd, zgsd, ggsd))[:sd][1:5])
```

This route admits only one independent mean coefficient per fit. Correlated
slope blocks, multiple random-effect components, and structured Gaussian
effects with predictor-dependent SDs use other routes and are not implied by
this example.

### Student-t: `Student()`

The heavy-tailed sibling of Gaussian: identity μ, log `σ`, plus degrees of freedom `ν`
that govern the tail weight, on the link `ν = 2 + exp(η)` (so `ν > 2`). Small `ν`
downweights outliers; `ν → ∞` returns to Gaussian. Recover `ν` with
`2 + exp(coef(fit, :nu))`, never `exp(...)` alone.

```@example fam
Random.seed!(2)
yt = 0.5 .+ 0.8 .* x .+ 2.0 .* rand(Distributions.TDist(4), n)
fitt = drm(bf(@formula(y ~ x), @formula(sigma ~ 1), @formula(nu ~ 1)), Student(); data = (; y = yt, x))
(slope = coef(fitt, :mu)[2], nu = 2 + exp(coef(fitt, :nu)[1]))   # d.o.f., ν = 2 + exp(η)
```

For one ordinary random intercept or one independent numeric random slope on
`mu`, a group-level predictor can model its coefficient SD. Use
`@formula(sd(g) ~ z)` when the target is unique, or select it with
`@formula(sd(g, coef(intercept)) ~ z)` or `@formula(sd(g, coef(x)) ~ z)`.
The SD predictor must be constant within each retained group. For a random
slope `(0 + x | g)`, the SD formula describes the SD of the random coefficient
that multiplies `x`; its observation-level contribution also depends on `x`.
This route uses `marginal = :LA` and requires fixed `sigma ~ 1` and `nu ~ 1`
submodels. Correlated blocks and structured effects with predictor-dependent
SDs are not yet implemented.

```julia
fit_sd_slope = drm(
    bf(@formula(y ~ x + (0 + x | g)), @formula(sigma ~ 1),
       @formula(nu ~ 1), @formula(sd(g, coef(x)) ~ z)),
    Student(); data = dat
)
predict_parameters(fit_sd_slope, dat)[:sd]  # group-specific coefficient SD
```

### LogNormal: `LogNormal()`

For strictly positive, multiplicative data. The μ formula is the mean of
`log y`; `σ` (log link) is the SD of `log y`. The response-scale median is
`exp(μ)`. A random intercept `(1 | g)`, independent numeric slope `(0 + x | g)`,
or correlated slope `(1 + x | g)`, or a
`phylo(1 | group)` (needs `tree = ...`) / `relmat(1 | group)` (needs
`K = ...`) structured marker, may be placed on the mean; the structured
routes delegate to `Gaussian()` on `log y` (exact, with no approximation) and
shift the reported log-likelihood by the parameter-free Jacobian. `animal`/
`spatial` markers are not implemented for `LogNormal()`.

```@example fam
Random.seed!(3)
yln = exp.(0.5 .+ 0.3 .* x .+ 0.4 .* randn(n))
fitln = drm(bf(@formula(y ~ x), @formula(sigma ~ 1)), LogNormal(); data = (; y = yln, x))
(intercept = coef(fitln, :mu)[1], sd_logy = exp(coef(fitln, :sigma)[1]))   # ≈ (0.5, 0.4)
```

For one ordinary mean random intercept, the SD can vary with a predictor that
is constant within group. If `log(s_g) = α₀ + α₁ z_g`, then `sd(g) ~ z` models
the group SD on the log-response scale. This route requires complete outcomes
and fixed `sigma ~ 1`.

```@example fam
Random.seed!(413)
Gln_sd, mln_sd = 60, 20
gln_sd = repeat(1:Gln_sd, inner = mln_sd)
zln_group = repeat([-1.0, 1.0], inner = Gln_sd ÷ 2)
zln_sd = zln_group[gln_sd]
xln_sd = randn(Gln_sd * mln_sd)
bln_sd = exp.(-0.6 .+ 0.5 .* zln_group) .* randn(Gln_sd)
yln_sd = exp.(0.3 .+ 0.25 .* xln_sd .+ bln_sd[gln_sd] .+ 0.6 .* randn(Gln_sd * mln_sd))
datln_sd = (; y = yln_sd, x = xln_sd, z = zln_sd, g = gln_sd)
fitln_sd = drm(bf(@formula(y ~ x + (1 | g)), @formula(sigma ~ 1),
                  @formula(sd(g) ~ z)), LogNormal(); data = datln_sd)
(coef(fitln_sd, :sd), extrema(predict_parameters(fitln_sd, datln_sd)[:sd]))
```

An independent numeric mean slope `(0 + x | g)` can also have a predictor-
dependent coefficient SD. Select the slope explicitly with `coef(x)`. The fitted
SD is for the random coefficient multiplying `x`; its row-level contribution is
`xᵢ b_g`, so it is not the same quantity as `abs(xᵢ)` times the reported SD.
The likelihood is exact because `log(y)` is Gaussian and the slope enters
linearly. Coverage calibration is not established.

```@example fam
Random.seed!(914)
Gln_slope, mln_slope = 48, 18
gln_slope = repeat(1:Gln_slope, inner = mln_slope)
xln_slope = repeat(range(-1.4, 1.4; length = mln_slope), Gln_slope)
zln_group = repeat([-1.0, 1.0], inner = Gln_slope ÷ 2)
zln_slope = zln_group[gln_slope]
bln_slope = exp.(-0.65 .+ 0.55 .* zln_group) .* randn(Gln_slope)
yln_slope = exp.(0.35 .+ 0.2 .* xln_slope .+ bln_slope[gln_slope] .* xln_slope .+ 0.45 .* randn(Gln_slope * mln_slope))
datln_slope = (; y = yln_slope, x = xln_slope, z = zln_slope, g = gln_slope)
fitln_slope = drm(bf(@formula(y ~ x + (0 + x | g)), @formula(sigma ~ 1),
                      @formula(sd(g, coef(x)) ~ z)), LogNormal(); data = datln_slope)
(coef(fitln_slope, :sd), extrema(predict_parameters(fitln_slope, datln_slope)[:sd]))
```

### Gamma: `Gamma()`

Strictly positive, right-skewed (durations, sizes, concentrations). Log link on
the mean; the `sigma` slot maps to the shape `α = 1/σ²`, so the coefficient of
variation is `1/√α`. Recover the shape as `exp(-2·log σ)`.

```@example fam
Random.seed!(4)
αsh = 8.0
μg  = exp.(0.5 .+ 0.4 .* x)
yg  = Float64.([rand(Distributions.Gamma(αsh, μi / αsh)) for μi in μg])
fitg = drm(bf(@formula(y ~ x), @formula(sigma ~ 1)), Gamma(); data = (; y = yg, x))
(mean_ratio = exp(coef(fitg, :mu)[2]), shape = exp(-2 * coef(fitg, :sigma)[1]))   # shape ≈ 8
```

Gamma also supports an ML model with one ordinary random intercept whose
standard deviation has a fixed-predictor formula. Keep the Gamma dispersion
fixed with `sigma ~ 1`; for `sd(g) ~ z`, the fitted model uses
`log(s_g) = alpha_0 + alpha_1 z_g`, with `z` constant within each group. The
rowwise group SDs are available from `predict_parameters(fit, data)[:sd]`.
The same SD formula also supports one independent numeric random slope written
`(0 + x | g)`. For that term, `sd(g) ~ z` describes the SD of the random
coefficient multiplying `x`; the observation-level contribution is `xᵢ b_g`.
Gamma also supports one related-matrix mean intercept, `relmat(1 | g)`, selected
with `sd(g, relmat) ~ z` and a positive-definite `K`. The Julia route
normalizes `K` to a correlation matrix, matching its existing constant-SD
fit. Julia also supports one animal mean intercept, `animal(1 | g)`, selected
with `sd(g, animal) ~ z` and a positive-definite `A`; it applies the same
unit-diagonal normalization. Julia also supports a slope-only animal
coefficient, `animal(0 + x | g)`, with `sd(g, animal) ~ z`. The fitted SD is
for the animal slope coefficient, and the row-level mean contribution is
`xᵢ b_g`. Native TMB candidates support one Gamma animal intercept and one
slope-only coefficient with predictor-dependent SD, but retain the supplied
`A` scale. Thus the reported SD multiplier agrees across engines only when
`diag(A) = 1`; non-unit-diagonal parity has not been established. Julia's
animal-slope route has synthetic recovery, a dense Laplace oracle,
constant-SD equivalence, prediction, marginal simulation, serialization, and
bootstrap-refit checks.
Julia also supports an independent animal intercept and slope together as
`animal(1 + x | g)`, with separate selected SD formulas:

```julia
bf(@formula(y ~ x + animal(1 + x | g)),
   @formula(sigma ~ 1),
   @formula(sd(g, animal, coef(intercept)) ~ z0),
   @formula(sd(g, animal, coef(x)) ~ z1))
```

The two latent fields are independent draws with the same normalized `A`
correlation, and the slope contribution is `xᵢ b₁,g`. The joint Laplace
Hessian includes the data cross-derivative between fields. This route has
synthetic recovery, a dense joint-Laplace oracle, a constant-design objective
comparison, group-SD prediction, seeded marginal simulation, serialization,
and a bootstrap-refit smoke check. The route refuses an all-zero `x`, and it
refuses a constant `x` when the two SD formulas have identical group-level
designs, because the two variance components are then confounded. Other
group-varying designs remain eligible. Additional structured terms are
refused. It does not establish interval coverage or parity for non-unit-diagonal
`A`. Other multi-coefficient
structured combinations remain unestablished.
Julia also supports one phylogenetic mean intercept,
`phylo(1 | species)`, selected with
`sd(species, phylogenetic) ~ z` and `tree = tree`. This route uses the raw
branch-length covariance in its sparse Laplace fit and marginal simulator. On
an ultrametric tree, the marginal tip SD is the fitted multiplier times the
square root of tree height; the multiplier is therefore not directly on the
unit-variance correlation scale. A synthetic recovery check, constant-SD
equivalence check, shuffled-row identity check, sparse-tree covariance check,
and one bootstrap-refit smoke test cover this route. Cross-engine parity and
interval coverage are not established.
Julia also supports one coordinate-spatial mean intercept selected with
`sd(g, spatial) ~ z`, using `spatial(1 | g)` and `coords = coords`. It keeps
DRM.jl's existing exponential-distance covariance, whose range is the mean
off-diagonal site distance and whose diagonal receives `1e-8` jitter. Native
TMB uses the median positive distance and `1e-6` jitter, so this coordinate
route has not been shown to match across engines. The Julia test checks seeded
recovery, SD prediction, and constant-SD likelihood equivalence; simulation,
serialization, profile/bootstrap refits, and interval calibration are not
established for this cell.
All these SD predictors must remain constant within group. These routes require
complete responses and fixed `sigma ~ 1`; interval coverage is not calibrated.
Other Gamma structured provider and coefficient combinations remain unestablished.
The structured routes bound
`log(sigma)` to `[-4, 4]` to keep the
Gamma shape calculation finite; if a fit reaches or approaches that bound, it
withholds Wald standard errors. Very low-variation data can also leave the
random-effect SD weakly identified, so check `fit.converged` and the reported
boundary warning.

```@example fam
Random.seed!(20)
Gg_sd, mg_sd = 40, 12
gg_sd = repeat(1:Gg_sd, inner = mg_sd)
zg_group = repeat([-1.0, 1.0], inner = Gg_sd ÷ 2)
zg_sd = zg_group[gg_sd]
xg_sd = randn(Gg_sd * mg_sd)
bg_sd = exp.(-0.55 .+ 0.35 .* zg_group) .* randn(Gg_sd)
mu_g_sd = exp.(0.25 .+ 0.2 .* xg_sd .+ bg_sd[gg_sd])
sigma_g_sd = 0.35
shape_g_sd = 1 / sigma_g_sd^2
yg_sd = Float64.([rand(Distributions.Gamma(shape_g_sd, m / shape_g_sd)) for m in mu_g_sd])
dat_g_sd = (; y = yg_sd, x = xg_sd, z = zg_sd, g = gg_sd)
fitg_sd = drm(bf(@formula(y ~ x + (1 | g)), @formula(sigma ~ 1),
                 @formula(sd(g) ~ z)), Gamma(); data = dat_g_sd)
(sd_range = extrema(predict_parameters(fitg_sd, dat_g_sd)[:sd]),
 sd_coefficients = coef(fitg_sd, :sd))
```

For a related-matrix intercept, supply the covariance matrix in first-seen
group order. Julia scales the normalized correlation matrix by the fitted
group SDs:

```@example fam
Ggr, mgr = 24, 12
ggr = repeat(1:Ggr, inner = mgr)
zgr_group = repeat([-1.0, 1.0], inner = Ggr ÷ 2)
zgr = zgr_group[ggr]
xgr = randn(Ggr * mgr)
Kgr = [0.65^abs(i - j) for i in 1:Ggr, j in 1:Ggr]
u_gr = cholesky(Symmetric(Kgr)).L * randn(Ggr)
mu_gr = exp.(0.2 .+ 0.2 .* xgr .+ exp.(-0.6 .+ 0.35 .* zgr_group)[ggr] .* u_gr[ggr])
sigma_gr = 0.32
shape_gr = 1 / sigma_gr^2
ygr = Float64.([rand(Distributions.Gamma(shape_gr, m / shape_gr)) for m in mu_gr])
dat_gr = (; y = ygr, x = xgr, z = zgr, g = ggr)
fitg_relmat_sd = drm(bf(@formula(y ~ x + relmat(1 | g)),
                        @formula(sigma ~ 1),
                        @formula(sd(g, relmat) ~ z)), Gamma(); data = dat_gr, K = Kgr)
(coef(fitg_relmat_sd, :sd), extrema(predict_parameters(fitg_relmat_sd, dat_gr)[:sd]))
```

For an independent random slope, the SD is attached to the coefficient of
`x`, not to its observation-specific contribution:

```@example fam
Random.seed!(21)
Ggs, mgs = 80, 25
ggs = repeat(1:Ggs, inner = mgs)
zgs_group = repeat([-1.0, 1.0], inner = Ggs ÷ 2)
zgs = zgs_group[ggs]
xgs = randn(Ggs * mgs)
bgs = exp.(-0.75 .+ 0.5 .* zgs_group) .* randn(Ggs)
mugs = exp.(0.4 .+ 0.3 .* xgs .+ bgs[ggs] .* xgs)
sigmas = 0.3
shapes = 1 / sigmas^2
ygs = Float64.([rand(Distributions.Gamma(shapes, m / shapes)) for m in mugs])
dat_gs = (; y = ygs, x = xgs, z = zgs, g = ggs)
fitg_slope = drm(bf(@formula(y ~ x + (0 + x | g)), @formula(sigma ~ 1),
                    @formula(sd(g) ~ z)), Gamma(); data = dat_gs)
(sd_coefficients = coef(fitg_slope, :sd),
 rowwise_coefficient_sd = extrema(predict_parameters(fitg_slope, dat_gs)[:sd]))
```

### Tweedie: `Tweedie()`

Positive data **with exact zeros** (biomass, rainfall, total loss): a point mass
at 0 plus a positive continuous part. Log link on the mean; `sigma` is the
√dispersion (`φ = σ²`); `nu` is the power `p ∈ (1,2)` on a logit link
(`p = 1 + logistic(coef(:nu))`).

```@example fam
Random.seed!(5)
function rtw(μi, φ, p)                              # compound Poisson–Gamma draw
    λ = μi^(2 - p) / (φ * (2 - p)); γ = φ * (p - 1) * μi^(p - 1)
    N = rand(Distributions.Poisson(λ))
    N == 0 ? 0.0 : rand(Distributions.Gamma(N * (2 - p) / (p - 1), γ))
end
ytw = [rtw(exp(0.5 + 0.3 * xi), 2.0, 1.5) for xi in x]
fittw = drm(bf(@formula(y ~ x), @formula(sigma ~ 1), @formula(nu ~ 1)), Tweedie(); data = (; y = ytw, x))
(zeros = count(==(0.0), ytw), power = 1 + 1 / (1 + exp(-coef(fittw, :nu)[1])))   # power ≈ 1.5
```

An ordinary `(1 | g)` random intercept, and an independent `(0 + x | g)`
random slope, on `mu` are both supported (adaptive Gauss–Hermite marginal,
matching drmTMB's `tweedie() mu ~ x + (1 | g)` / `(0 + x | g)`); the group
SD is `exp(coef(fit, :resd)[1])` either way. The CORRELATED random slope
`(1 + x | g)`, random effects on `sigma`/`nu`, and phylogenetic or animal
markers on `mu` remain unimplemented. A related-matrix intercept is available
only with the predictor-dependent SD route below, using `K` and a Laplace
approximation; this does not imply general structured-effect support.

For one ordinary mean random intercept, the group SD may depend on a
group-level predictor. These predictors must be constant within each group.
The current route uses adaptive Gauss–Hermite integration and exposes fitted
SDs through `predict_parameters()`:

```@example fam
Random.seed!(51)
g_sd = repeat(1:60, inner = 4)
z_group_sd = repeat([-1.0, 1.0], inner = 30)
z_sd = z_group_sd[g_sd]
x_sd = x[1:length(g_sd)]
b_sd = exp.(-0.6 .+ 1.0 .* z_group_sd) .* randn(60)
y_sd = [rtw(exp(0.5 + 0.3 * x_sd[i] + b_sd[g_sd[i]]), 2.0, 1.5) for i in eachindex(g_sd)]
dat_sd = (; y = y_sd, x = x_sd, g = g_sd, z = z_sd)
fit_tw_sd = drm(bf(@formula(y ~ x + (1 | g)), @formula(sigma ~ 1),
                   @formula(nu ~ 1), @formula(sd(g) ~ z)), Tweedie(); data = dat_sd)
coef(fit_tw_sd, :sd)
extrema(predict_parameters(fit_tw_sd, dat_sd)[:sd])
```

This Julia route follows the package's existing missing-response policy:
missing outcomes are dropped with a warning before fitting. It also supports
one independent numeric mean slope, selected by its coefficient name:

```@example fam
fit_tw_slope_sd = drm(bf(@formula(y ~ x + (0 + x | g)),
                        @formula(sigma ~ 1), @formula(nu ~ 1),
                        @formula(sd(g, coef(x)) ~ z)),
                       Tweedie(); data = dat_sd)
coef(fit_tw_slope_sd, :sd)
```

The slope route requires a numeric random-slope predictor and SD predictors
that are constant within groups. Correlated ordinary blocks and structured
providers other than the related-matrix intercept above are not implemented.
Interval coverage calibration is not established.

For a related-matrix mean intercept, select the structured target explicitly
with `sd(g, relmat) ~ z` and supply the group covariance as `K`. This route
uses a Laplace approximation and currently requires `sigma ~ 1` and `nu ~ 1`;
the rows and columns of `K` follow the first-seen order of `g`.
The SD formula is a multiplier of the supplied covariance: if `K` has a
non-unit diagonal, the marginal SD for group `g` is
`exp(alpha_0 + alpha_1 z_g) * sqrt(K[g,g])`. `predict_parameters()` returns
the multiplier SD as `:sd`; the fitted marginal SD for each observation is
stored in `fit.scales[:marginal_sd]`, with group-level values in
`fit.scales[:marginal_sd_group]`. For new data, pass the covariance matrix
with rows and columns in that data's first-seen group order; the result then
includes both `:sd` (the multiplier) and `:marginal_sd` (the kernel-adjusted
marginal SD). With `type = :link`, `:marginal_sd` is returned on the log scale.

```@example fam
Gtw_rel, mtw_rel = 32, 8
rng_tw_rel = MersenneTwister(20261026)
order_tw_rel = randperm(rng_tw_rel, Gtw_rel)
labels_tw_rel = ["group_$(i)" for i in order_tw_rel]
group_index_tw_rel = repeat(1:Gtw_rel; inner = mtw_rel)
gtw_rel = labels_tw_rel[group_index_tw_rel]
ztw_group = [zeros(Gtw_rel ÷ 2); ones(Gtw_rel ÷ 2)][randperm(rng_tw_rel, Gtw_rel)]
ztw_rel = ztw_group[group_index_tw_rel]
xtw_rel = rand(rng_tw_rel, Gtw_rel * mtw_rel) .* 2 .- 1
Rtw_rel = 0.45 .^ abs.(reshape(1:Gtw_rel, :, 1) .- reshape(1:Gtw_rel, 1, :))
ktw_group = ifelse.(ztw_group .== 0, 1.0, 2.0)
Ktw_rel = ktw_group .* Rtw_rel .* ktw_group'
utw_rel = cholesky(Symmetric(Ktw_rel)).L * randn(rng_tw_rel, Gtw_rel)
btw_rel = exp.(-0.6 .+ 0.4 .* ztw_group) .* utw_rel
function rtw_rel(rng, mu, phi, p)
    lambda = mu^(2-p) / (phi * (2-p))
    n = rand(rng, Distributions.Poisson(lambda))
    n == 0 ? 0.0 : rand(rng, Distributions.Gamma(n * (2-p) / (p-1), phi * (p-1) * mu^(p-1)))
end
ytw_rel = [rtw_rel(rng_tw_rel, exp(0.35 + 0.2 * xtw_rel[i] + btw_rel[group_index_tw_rel[i]]), 0.65^2, 1.5)
           for i in eachindex(group_index_tw_rel)]
dat_tw_rel = (; y = ytw_rel, x = xtw_rel, z = ztw_rel, g = gtw_rel)
fit_tw_rel = drm(bf(@formula(y ~ x + relmat(1 | g)), @formula(sigma ~ 1),
                    @formula(nu ~ 1), @formula(sd(g, relmat) ~ z)),
                  Tweedie(); data = dat_tw_rel, K = Ktw_rel)
pred_tw_rel = predict_parameters(fit_tw_rel, dat_tw_rel; K = Ktw_rel)
(sd_multiplier = extrema(pred_tw_rel[:sd]),
 marginal_sd = extrema(pred_tw_rel[:marginal_sd]))
```

## Counts

### Poisson: `Poisson()`

Counts with variance ≈ mean. Log link on the mean; no scale parameter. Slopes
are log rate ratios (`exp(β)` is the multiplicative effect on the expected
count).

```@example fam
Random.seed!(6)
λp = exp.(0.3 .+ 0.5 .* x)
yp = Float64.([rand(Distributions.Poisson(λi)) for λi in λp])
fitp = drm(bf(@formula(y ~ x)), Poisson(); data = (; y = yp, x))
(logmu = coef(fitp, :mu), rate_ratio = exp(coef(fitp, :mu)[2]))   # rate ratio ≈ 1.65
```

Poisson also supports a predictor-dependent SD for one ordinary random
intercept or one independent numeric random slope. For a group-level predictor
z, the model is log(s_g) = alpha_0 + alpha_1 z_g; z must be constant within
each group. For a slope `(0 + x | g)`, `s_g` is the SD of the random
coefficient multiplying `x`, so the observation-level contribution is `x_i b_g`.
Both ordinary routes also accept a fixed exposure offset, for example
`offset(log_exposure)`; the offset enters each conditional log mean once.

```@example fam
Random.seed!(18)
Gsd, msd = 40, 10
gsd = repeat(1:Gsd, inner = msd)
zgroup_sd = repeat([0.0, 1.0], inner = Gsd ÷ 2)
zsd = zgroup_sd[gsd]
xsd = randn(Gsd * msd)
bsd = exp.(-0.45 .+ 0.4 .* zgroup_sd) .* randn(Gsd)
exposure_sd = repeat(range(0.7, 1.4; length = Gsd), inner = msd)
ysd = Float64.([rand(Distributions.Poisson(exp(log(exposure_sd[i]) +
                    0.55 + 0.25*xsd[i] + bsd[gsd[i]])))
                for i in eachindex(xsd)])
dat_sd = (; y = ysd, x = xsd, z = zsd, g = gsd,
          log_exposure = log.(exposure_sd))
fitp_sd = drm(bf(@formula(y ~ x + offset(log_exposure) + (1 | g)),
                 @formula(sd(g) ~ z)),
              Poisson(); data = dat_sd)
sd_by_row = predict_parameters(fitp_sd, dat_sd)[:sd]
length(sd_by_row)  # one fitted group SD per observation
```

The same SD predictor also applies to one independent random slope:

```@example fam
Random.seed!(21)
bslope_sd = exp.(-0.45 .+ 0.4 .* zgroup_sd) .* randn(Gsd)
yslope_sd = Float64.([rand(Distributions.Poisson(exp(
    0.55 + 0.25*xsd[i] + bslope_sd[gsd[i]]*xsd[i])))
    for i in eachindex(xsd)])
dat_slope_sd = (; y = yslope_sd, x = xsd, z = zsd, g = gsd)
fitp_slope_sd = drm(
    bf(@formula(y ~ x + (0 + x | g)), @formula(sd(g) ~ z)),
    Poisson(); data = dat_slope_sd
)
coef(fitp_slope_sd, :sd)
```

The ordinary IID routes use adaptive Gauss–Hermite quadrature. The structured
phylogenetic, related-matrix, and animal SD routes also accept fixed row
offsets. A separate sparse-Laplace route supports one predictor-dependent SD
for a Poisson related-matrix intercept:

For example, include an exposure offset directly in the location formula:
`bf(@formula(y ~ x + offset(log_exposure) + relmat(1 | id)),
@formula(sd(id, relmat) ~ z))`. The same offset syntax works with the supported
phylogenetic and animal SD routes.

```julia
fit_relmat_sd = drm(
    bf(@formula(y ~ x + relmat(1 | id)),
       @formula(sd(id, relmat) ~ z)),
    Poisson(); data, K)
```

The SD predictors must be constant within each group. This Julia route retains
the existing Poisson related-matrix convention: the supplied positive-definite
`K` is converted to a correlation matrix before the coefficient-specific SDs
scale it. Thus a non-unit diagonal in `K` does not multiply the fitted SD; this
matches the existing constant-SD Julia Poisson route. This scaling convention
is engine-specific and should not be assumed to match other structured routes.
The related-matrix structured SD route is limited to one mean intercept; correlated
blocks, zero-inflation/hurdle terms, missing responses, and REML are
not supported with this SD regression. Profile and bootstrap methods are
available, but their interval coverage has not been calibrated.

Poisson also supports one animal-model mean intercept with a predictor-dependent
SD. With covariance input `A`, Julia normalizes the supplied matrix to a
correlation matrix before the fitted group SDs scale it. Alternatively, supply
the positive-definite precision matrix `Ainv = Q`; Julia uses `Q` directly, so
the latent covariance is `D Q⁻¹ D`, where `D` contains the group SDs. For this
direct Julia interface, rows and columns of `Ainv` must follow first-seen animal
order and have one row per observed animal. The SD predictor must be constant
within each animal. This example uses independent synthetic data and a
deliberately non-unit diagonal in `A`:

```@example fam
Random.seed!(25)
Gpa, mpa = 36, 18
idpa = repeat(1:Gpa, inner = mpa)
zpa_group = repeat([-1.0, 1.0], inner = Gpa ÷ 2)
zpa = zpa_group[idpa]
Rpa = 0.45 .^ abs.(reshape(1:Gpa, :, 1) .- reshape(1:Gpa, 1, :))
scale_pa = collect(range(0.7, 1.6; length = Gpa))
Apa = Diagonal(scale_pa) * Rpa * Diagonal(scale_pa)
upa = cholesky(Symmetric(Rpa)).L * randn(Gpa)
bpa = exp.(-0.55 .+ 0.38 .* zpa_group) .* upa
ypa = Float64.([rand(Distributions.Poisson(exp(0.25 + bpa[g]))) for g in idpa])
dat_pa = (; y = ypa, z = zpa, g = idpa)
fitp_animal_sd = drm(
    bf(@formula(y ~ animal(1 | g)), @formula(sd(g, animal) ~ z)),
    Poisson(); data = dat_pa, A = Apa
)
(sd_coefficients = coef(fitp_animal_sd, :sd),
 group_sds = predict_parameters(fitp_animal_sd, dat_pa)[:sd][1:Gpa])

# The precision form uses Q directly. Here Q is the inverse of the correlation
# matrix used by the A route, so the fitted likelihood and SD coefficients agree.
Qpa = inv(Symmetric(Rpa))
fitp_animal_sd_precision = drm(
    bf(@formula(y ~ animal(1 | g)), @formula(sd(g, animal) ~ z)),
    Poisson(); data = dat_pa, Ainv = Qpa
)
coef(fitp_animal_sd_precision, :sd)
```

The direct Julia API is tested for one complete-response animal intercept. Its
tests check recovery, the structured Laplace objective, prediction, marginal
simulation, save/reload, constant-SD equivalence, and one bootstrap refit. The
precision test also checks agreement with the `A` route, group-order handling,
and rejection of invalid precision matrices. Fixed offsets are covered for
animal intercepts and slope-only coefficients with covariance input, plus the
intercept precision route. A same-data comparison of the R
`engine = "julia"` bridge with native TMB checks coefficients, log likelihood,
and named group-SD predictions for `Ainv`. This single fixture does not
establish broad parity. Profile/bootstrap refitting for this precision route
and interval coverage remain unverified.

### Negative-binomial: `NegBinomial2()`

Overdispersed counts. Log link on the mean; the `sigma` slot carries log `σ`
(not log `θ`), with size `θ = 1/σ²`; variance `= μ + μ²/θ`, so `θ → ∞` recovers
Poisson.

```@example fam
Random.seed!(7)
θnb = 2.5
μnb = exp.(0.4 .+ 0.5 .* x)
ynb = Float64.([rand(Distributions.NegativeBinomial(θnb, θnb / (θnb + μi))) for μi in μnb])
fitnb = drm(bf(@formula(y ~ x), @formula(sigma ~ 1)), NegBinomial2(); data = (; y = ynb, x))
exp(-2 * coef(fitnb, :sigma)[1])      # estimated dispersion θ = 1/σ² ≈ 2.5
```

The `sigma` coefficient is on the log-`σ` scale, and the NB2 dispersion is
`θ = 1/σ² = exp(-2·coef(:sigma))` (not `exp(coef(:sigma))`).

NB2 also supports a predictor-dependent SD for one ordinary random intercept
in the mean. This route keeps dispersion fixed with `sigma ~ 1`; the SD
predictors must be fixed and constant within each group. For example,
`sd(g) ~ z` models `log(s_g) = alpha_0 + alpha_1 z_g`:

```@example fam
Random.seed!(19)
Gnb_sd, mnb_sd = 40, 10
gnb_sd = repeat(1:Gnb_sd, inner = mnb_sd)
zgroup_nb = repeat([-1.0, 1.0], inner = Gnb_sd ÷ 2)
znb_sd = zgroup_nb[gnb_sd]
xnb_sd = randn(Gnb_sd * mnb_sd)
b_nb_sd = exp.(-0.5 .+ 0.35 .* zgroup_nb) .* randn(Gnb_sd)
mu_nb_sd = exp.(0.4 .+ 0.25 .* xnb_sd .+ b_nb_sd[gnb_sd])
ynb_sd = Float64.([rand(Distributions.NegativeBinomial(2.5, 2.5 / (2.5 + mu)))
                   for mu in mu_nb_sd])
data_nb_sd = (; y = ynb_sd, x = xnb_sd, z = znb_sd, g = gnb_sd)
fitnb_sd = drm(bf(@formula(y ~ x + (1 | g)), @formula(sigma ~ 1),
                  @formula(sd(g) ~ z)), NegBinomial2(); data = data_nb_sd)
sd_nb_by_row = predict_parameters(fitnb_sd, data_nb_sd)[:sd]
length(sd_nb_by_row)  # one fitted group SD per observation
```

This route uses adaptive Gauss–Hermite quadrature (5 nodes by default); set
`nAGQ` to choose another positive node count. Fit-based bootstrap refits retain
that setting. It supports ML only. The ordinary NB2 SD route refuses
structured effects, offsets, `zi`, missing responses, and REML. The same
direct-SD route also accepts one independent numeric mean slope, written
`@formula(y ~ x + (0 + x | g))` with `@formula(sd(g, coef(x)) ~ z)` and fixed
`sigma ~ 1`. This models the SD of the random coefficient multiplying `x`; its
observation-level contribution is `xᵢ b_g`. The slope has a synthetic recovery
check, an independent slope-loading likelihood oracle, and a same-data
comparison with native TMB, but interval coverage has not been calibrated.
Correlated blocks, offsets, missing responses, `zi`/`hu`, and REML remain
unsupported on the ordinary route.

For one animal mean intercept, use `animal(1 | g)` with
`sd(g, animal) ~ z`, fixed `sigma ~ 1`, and either a covariance matrix
`A = ...` or its precision `Ainv = ...`. The `A` route is normalized to a
unit-diagonal correlation matrix. `Ainv` must be the precision matrix of that
correlation matrix, with rows and columns ordered by the first-seen levels of
`g`. The code checks that `Ainv` is finite, symmetric, and positive definite,
but does not check that its inverse has unit diagonal; supplying the precision
of a covariance matrix with a non-unit diagonal changes the scale represented
by `sd(g, animal)`. A synthetic test compares both inputs on the same reordered data and
checks coefficient, likelihood, and group-SD agreement. This animal route uses
sparse Laplace and requires complete responses and group-constant SD
predictors. A separate pedigree input, refitting from profiles or bootstrap,
and interval coverage are not established.

The Julia engine also supports a narrow hurdle NB2 SD model: one ordinary mean
random intercept or one independently selected numeric mean slope, a
fixed-effects-only hurdle formula such as `hu ~ w`, and fixed `sigma ~ 1`.
For a random slope, use `(0 + x | g)` with `sd(g, coef(x)) ~ z`; the latent
coefficient multiplies `x` in the log-mean, while `z` must be constant within
group. Responses must be complete non-negative integer counts. The hurdle
probability is estimated separately from the positive, zero-truncated NB2
component. Zeros inform the hurdle formula but provide no information about the
mean random-effect SD; a group with no positive counts therefore adds no
information about that SD. The Julia route uses adaptive quadrature, and
bootstrap refits retain `nAGQ`. Intercept and slope routes have synthetic
recovery and independent scalar-integration checks; the slope route also has
selector, constant-SD-design, marginal-simulation, and bootstrap-refit checks.
Interval coverage is not calibrated. Random effects in `hu`, `zi`, structured
or correlated effects, offsets, missing responses, and REML remain unsupported.

```julia
fit_hurdle_sd = drm(
    bf(@formula(y ~ x + (1 | g)), @formula(sigma ~ 1),
       @formula(hu ~ w), @formula(sd(g) ~ z)),
    NegBinomial2(); data
)
predict_parameters(fit_hurdle_sd, data)[:sd]  # mean-intercept SD by group
```

For a random slope, select the coefficient explicitly:

```julia
fit_hurdle_slope_sd = drm(
    bf(@formula(y ~ 0 + x + (0 + x | g)), @formula(sigma ~ 1),
       @formula(hu ~ w), @formula(sd(g, coef(x)) ~ z)),
    NegBinomial2(); data
)
predict_parameters(fit_hurdle_slope_sd, data)[:sd]  # SD of the coefficient multiplying x
```

`TruncatedNegBinomial2()` is the same family conditioned on `y ≥ 1`, for counts
that are positive by construction (litter sizes, group sizes given presence).
`TruncatedPoisson()` is the Poisson conditioned on `y ≥ 1`; adding an `hu ~ ...`
part to either truncated family (or to `Poisson()` / `NegBinomial2()`) fits the
hurdle model.

For one ordinary mean random intercept or one independent numeric mean slope,
`TruncatedPoisson()` also supports predictor-dependent coefficient SDs. Select
the slope explicitly with `coef(x)` in the `sd()` target. SD predictors must be
constant within groups. Correlated and structured effects and an `hu`
combination are not admitted on this route.

For one ordinary mean random intercept or one independent numeric mean slope,
Julia also supports a group-level SD formula on this family. The predictor acts
on the log SD of the latent coefficient; the `sigma` submodel must remain fixed
at `sigma ~ 1`:

```julia
fit = drm(bf(@formula(y ~ x + (1 | site)), @formula(sigma ~ 1),
             @formula(sd(site) ~ habitat)),
          TruncatedNegBinomial2(); data)
predict_parameters(fit, data)[:sd]  # fitted latent SD for each row's site
```

For a slope, select its coefficient explicitly:

```julia
fit_slope = drm(bf(@formula(y ~ x + (0 + x | site)), @formula(sigma ~ 1),
                   @formula(sd(site, coef(x)) ~ habitat)),
                TruncatedNegBinomial2(); data)
predict_parameters(fit_slope, data)[:sd]  # SD of the coefficient multiplying x
```

This Julia route uses adaptive Gauss–Hermite quadrature (5 nodes by default;
choose another positive count with `nAGQ`) and fit-based bootstrap refits retain
that setting. Both intercept and slope routes require complete positive integer
responses. The slope contribution to the mean is `xᵢ b_site`; the returned `sd`
is the SD of `b_site`, not its observation-specific contribution. Structured
effects, offsets, `hu`, and interval coverage calibration are not included.

## Proportions and binary data

### Binomial: `Binomial()`

Successes out of known trials (logistic regression). Logit link on the success
probability; no dispersion parameter. The response is either a `cbind(successes,
failures)` two-column term or a plain `0/1` Bernoulli vector.

```@example fam
Random.seed!(8)
ntrials = fill(20, n)
pb = 1 ./ (1 .+ exp.(-(0.2 .+ 0.7 .* x)))
succ = Float64.([rand(Distributions.Binomial(ntrials[i], pb[i])) for i in 1:n])
fail = ntrials .- succ
fitb = drm(bf(@formula(cbind(succ, fail) ~ x)), Binomial(); data = (; succ, fail, x))
coef(fitb, :mu)      # logit-scale intercept & slope ≈ (0.2, 0.7)
```

For a Bernoulli response, `sd(g) ~ z` can model the group-level SD of either
an ordinary random intercept or one independent numeric random slope. In the
slope case, `sd(g)` is the SD of the random coefficient multiplying `x`; the
observation-level contribution is `xᵢ b_g`. The SD predictor must be constant
within each group. A separate correlated intercept–slope route uses
`(1 + x | g)` with coefficient-specific formulas such as
`sd(g, coef(intercept)) ~ z0` and `sd(g, coef(x)) ~ z1`. The correlation stays
constant in this route. These fits have an independent two-dimensional
integration oracle, but interval coverage has not been calibrated.

Julia also supports two independent ordinary random intercepts on distinct
grouping variables, each with its own SD formula. For example, `sd(g) ~ w` and
`sd(h) ~ v` fit separate log-SD regressions in a model with `(1 | g) + (1 | h)`.
The SD predictors must be constant within their own groups, and each group-level
design must be full rank. This route uses a joint sparse-Laplace fit and supports
marginal bootstrap refits. Its tested scope is two intercepts; it does not
establish nested layouts, more than two grouping variables, or interval
calibration. With multiple SD targets, prediction results have distinct
target-specific names. Inspect `keys(predict_parameters(fit, data; se = false))`;
the legacy `:sd` name is reserved for an unambiguous single target.

```@example fam
rng_cross = MersenneTwister(20261023)
G_cross, H_cross, m_cross = 40, 40, 4
g_cross = repeat(1:G_cross, inner = H_cross * m_cross)
h_cross = repeat(repeat(1:H_cross, inner = m_cross), outer = G_cross)
w_cross_group = repeat([-1.0, 1.0], inner = G_cross ÷ 2)
v_cross_group = repeat([-1.0, 1.0], inner = H_cross ÷ 2)
w_cross, v_cross = w_cross_group[g_cross], v_cross_group[h_cross]
x_cross = randn(rng_cross, length(g_cross))
sd_g_cross = exp.(log(0.45) .+ 0.30 .* w_cross_group)
sd_h_cross = exp.(log(0.50) .- 0.25 .* v_cross_group)
b_g_cross = sd_g_cross .* randn(rng_cross, G_cross)
b_h_cross = sd_h_cross .* randn(rng_cross, H_cross)
eta_cross = -0.20 .+ 0.35 .* x_cross .+ b_g_cross[g_cross] .+ b_h_cross[h_cross]
y_cross = Float64.(rand.(Ref(rng_cross), Distributions.Bernoulli.(1 ./ (1 .+ exp.(-eta_cross)))))
data_cross = (; y_cross, x_cross, g_cross, h_cross, w_cross, v_cross)
fit_cross = drm(bf(
    @formula(y_cross ~ x_cross + (1 | g_cross) + (1 | h_cross)),
    @formula(sd(g_cross) ~ w_cross),
    @formula(sd(h_cross) ~ v_cross)), Binomial(); data = data_cross)
crossed_sd_predictions = predict_parameters(fit_cross, data_cross; se = false)
keys(crossed_sd_predictions)
```

Julia also supports predictor-dependent SD for one Binomial phylogenetic mean
intercept: use `phylo(1 | species)` with
`sd(species, phylogenetic) ~ z` and provide `tree = tree`. One ordinary
intercept on a separate grouping variable can be included with its own
`sd(group) ~ w` formula. The joint fit treats those latent fields as
independent, uses the tree's raw branch-length covariance by default, and
requires complete responses and group-constant SD predictors. Marginal draws
and bootstrap refits include both fields; the current bootstrap result is a
smoke check, not interval-calibration evidence. Native TMB parity for this
phylogenetic combination has not been established.

Binomial also has an animal SD route, including Bernoulli responses. Select the
sole animal coefficient with `sd(g, animal) ~ z` alongside either
`animal(1 | g)` or one slope-only term, `animal(0 + x | g)`, and supply the
relatedness matrix as `A = A`. The matrix must be positive definite and ordered
by the first appearance of `g`; the response must be complete. For an animal
slope, `sd(g, animal)` is the SD of the coefficient multiplying `x`, while the
row-level contribution is `xᵢ b_g`. The SD predictor must be constant within
animal. Multi-coefficient animal blocks, combinations with additional random
effects, other structured SD targets, and interval calibration are not
established.

Julia also supports a Binomial/Bernoulli related-matrix intercept with a
predictor-dependent SD. Use `relmat(1 | id)` in the mean formula,
`sd(id, relmat) ~ z` in the secondary formula, and supply `K = K`. The SD is
the coefficient scale in the covariance `D K D`; `K` is used on its supplied
scale and its rows and columns must follow the first-seen order of `id` in the
data. The route requires a positive-definite matrix and complete responses.
Fitting, rowwise SD prediction, prediction SEs, a dense Laplace oracle,
constant-SD equivalence, seeded marginal simulation, and one bootstrap-refit
smoke check are tested in Julia. Native TMB parity and interval calibration
have not been established.

```@example fam
Random.seed!(20261021)
Grel, nrel = 12, 18
idrel = repeat(["site$(j)" for j in 1:Grel], inner = nrel)
zrel_group = repeat([-1.0, 1.0], inner = Grel ÷ 2)
zrel = repeat(zrel_group; inner = nrel)
xrel = randn(Grel * nrel)
Krel = Matrix(Diagonal(collect(range(0.9, 1.5; length = Grel))) +
              0.08 * ones(Grel, Grel))
urel = cholesky(Symmetric(Krel)).L * randn(Grel)
brel = exp.(-0.7 .+ 0.4 .* zrel_group) .* urel
prel = 1 ./ (1 .+ exp.(-(0.1 .+ 0.25 .* xrel .+ brel[repeat(1:Grel; inner = nrel)])))
yrel = Float64.(rand.(Distributions.Bernoulli.(prel)))
fitrel = drm(bf(@formula(yrel ~ xrel + relmat(1 | idrel)),
                @formula(sd(idrel, relmat) ~ zrel)), DRModels.Binomial();
             data = (; yrel, xrel, zrel, idrel), K = Krel, se = false)
coef(fitrel, :sd)  # log-SD intercept and predictor coefficient
```

```@example fam
Random.seed!(101)
Gsd, msd = 36, 20
gsd = repeat(1:Gsd, inner = msd)
zgroup_sd = repeat([0.0, 1.0], inner = Gsd ÷ 2)
zsd = zgroup_sd[gsd]
xsd = randn(Gsd * msd)
bsd = exp.(-0.8 .+ 0.65 .* zgroup_sd) .* randn(Gsd)
psd = 1 ./ (1 .+ exp.(-(0.2 .+ 0.35 .* xsd .+ bsd[gsd] .* xsd)))
ysd = Float64.(rand.(Distributions.Bernoulli.(psd)))
fitsd = drm(bf(@formula(ysd ~ xsd + (0 + xsd | gsd)),
               @formula(sd(gsd) ~ zsd)), Binomial();
            data = (; ysd, xsd, zsd, gsd))
coef(fitsd, :sd)  # log-SD intercept and zsd coefficient
```

### Beta: `Beta()`

Proportions strictly inside `(0,1)`. Logit link on the mean; the `sigma` slot
carries `σ` with precision `φ = 1/σ²` (recover precision as `exp(-2·log σ)`).

```@example fam
Random.seed!(9)
μbe = 1 ./ (1 .+ exp.(-(0.3 .+ 0.6 .* x))); φbe = 12.0
ybe = Float64.([rand(Distributions.Beta(μi * φbe, (1 - μi) * φbe)) for μi in μbe])
fitbe = drm(bf(@formula(y ~ x), @formula(sigma ~ 1)), Beta(); data = (; y = ybe, x))
(slope = coef(fitbe, :mu)[2], precision = exp(-2 * coef(fitbe, :sigma)[1]))   # φ ≈ 12
```

An ordinary random intercept can have an SD that varies with a group-level
predictor. The predictor must be constant within each group, and this route
requires complete responses and fixed `sigma ~ 1`:

```julia
fit_sd = drm(bf(@formula(y ~ x + (1 | site)), @formula(sigma ~ 1),
                @formula(sd(site) ~ habitat)), Beta();
             data = dat)
predict_parameters(fit_sd, dat)[:sd]  # group-specific random-intercept SD
```

An independent numeric slope can target its coefficient SD explicitly:

```julia
fit_slope_sd = drm(bf(@formula(y ~ x + (0 + x | site)), @formula(sigma ~ 1),
                     @formula(sd(site, coef(x)) ~ habitat)), Beta();
                  data = dat)
```

This Julia route covers one ordinary intercept or one independent numeric
slope. It does not cover SD regression for correlated blocks, structured
effects, or other marginal methods. Recovery and a fixed-parameter quadrature
oracle are tested for the intercept; the slope has synthetic recovery and a
matched-data comparison with native TMB. Interval calibration has not been
established.

### Beta-binomial: `BetaBinomial()`

Successes out of trials **with extra-binomial overdispersion**. Logit mean;
precision `φ = 1/σ²` in the `sigma` slot. Requires a `cbind(successes,
failures)` response.

```@example fam
Random.seed!(10)
ntr = fill(30, n)
μbb = 1 ./ (1 .+ exp.(-(0.1 .+ 0.5 .* x))); φbb = 5.0
sbb = Float64.([rand(Distributions.BetaBinomial(ntr[i], μi * φbb, (1 - μi) * φbb)) for (i, μi) in enumerate(μbb)])
fbb = ntr .- sbb
fitbb = drm(bf(@formula(cbind(s, f) ~ x), @formula(sigma ~ 1)), BetaBinomial(); data = (; s = sbb, f = fbb, x))
(slope = coef(fitbb, :mu)[2], precision = exp(-2 * coef(fitbb, :sigma)[1]))   # φ ≈ 5
```

The Julia engine also supports predictor-dependent SDs for one ordinary mean
random intercept or one independent numeric mean slope. For a slope, the SD
describes the random coefficient; each row's slope predictor multiplies that
coefficient in the mean linear predictor. These routes require fixed
`sigma ~ 1`, complete responses, and SD predictors that are constant within
group. Interval coverage has not been calibrated; correlated and structured
effects are not included in these routes.

### Zero-one-inflated beta: `ZeroOneBeta()`

Proportions on the **closed** interval `[0,1]` (values may be exactly 0 or 1).
Beta mean (logit) and precision `φ` on the interior, plus `zoi` (logit
probability the value is a boundary) and `coi` (logit probability of a 1 given a
boundary).

```@example fam
Random.seed!(11)
function rzob(xi)
    μi = 1 / (1 + exp(-(0.2 + 0.5 * xi))); φ = 10.0; zoi = 0.15; coi = 0.4
    rand() < zoi ? (rand() < coi ? 1.0 : 0.0) : rand(Distributions.Beta(μi * φ, (1 - μi) * φ))
end
yzob = [rzob(xi) for xi in x]
fitzob = drm(bf(@formula(y ~ x), @formula(sigma ~ 1), @formula(zoi ~ 1), @formula(coi ~ 1)), ZeroOneBeta(); data = (; y = yzob, x))
(boundaries = count(yi -> yi == 0 || yi == 1, yzob), zoi = 1 / (1 + exp(-coef(fitzob, :zoi)[1])))
```

The Julia engine also supports an ordinary mean random intercept or one
independent numeric mean slope with a predictor-dependent SD. For a slope,
`sd(g, coef(x)) ~ z` models the SD of the group-specific coefficient; each row's
`x` multiplies that coefficient in the mean linear predictor. The predictors
on the SD formula must be constant within group. These routes require complete
responses and fixed `sigma ~ 1`, `zoi ~ 1`, and `coi ~ 1`; interval coverage has
not been calibrated.

```@example fam
Random.seed!(13)
Gzob, mzob = 24, 12
gzob = repeat(1:Gzob, inner = mzob)
zzob_group = repeat([-1.0, 1.0], inner = Gzob ÷ 2)
zzob = zzob_group[gzob]
xzob = randn(Gzob * mzob)
bzob = exp.(-0.55 .+ 0.35 .* zzob_group) .* randn(Gzob)
μzob = 1 ./ (1 .+ exp.(-(-0.15 .+ 0.25 .* xzob .+ xzob .* bzob[gzob])))
φzob, zoi_zob, coi_zob = 1 / 0.35^2, 0.2, 0.4
yzob = [rand() < zoi_zob ? (rand() < coi_zob ? 1.0 : 0.0) :
    rand(Distributions.Beta(μzob[i] * φzob, (1 - μzob[i]) * φzob))
    for i in eachindex(μzob)]
fitzob_sd = drm(
    bf(@formula(y ~ x + (0 + x | g)), @formula(sigma ~ 1),
       @formula(zoi ~ 1), @formula(coi ~ 1),
       @formula(sd(g, coef(x)) ~ z)),
    ZeroOneBeta(); data = (; y = yzob, x = xzob, g = gzob, z = zzob),
)
coef(fitzob_sd, :sd)
```

## Ordered categories

### Cumulative-logit: `CumulativeLogit()`

Ordered categories coded `1, 2, …, K` (Likert ratings, severity classes):
`Pr(y ≤ k) = logistic(θ_k − η)` with ordered cutpoints. The single linear
predictor comes from the `mu` formula **with its intercept dropped** (the
cutpoints absorb the level), so `coef(fit, :mu)` is the slope.

```@example fam
Random.seed!(12)
θcut = [-1.0, 0.0, 1.2]; K = 4
yo = map(x) do xi
    u = rand(); η = 0.8 * xi; cat = K
    for j in 1:(K-1)
        (u < 1 / (1 + exp(-(θcut[j] - η)))) && (cat = j; break)
    end
    cat
end
fito = drm(bf(@formula(y ~ x)), CumulativeLogit(); data = (; y = Float64.(yo), x))
coef(fito, :mu)[1]      # slope ≈ 0.8
```

An ordinary random intercept `(1 | g)` or an independent random slope
`(0 + x | g)` on `mu` is integrated out by 32-node Gauss–Hermite quadrature
(the same scheme as the Poisson/Gamma/Tweedie GLMM routes); the correlated
form `(1 + x | g)` is not implemented.

```julia
fit_re = drm(bf(y ~ x + (1 | g)), CumulativeLogit(); data = dat)
exp(coef(fit_re, :resd)[1])   # random-intercept SD
```

For one ordinary location random intercept or one independent numeric slope,
the SD can vary with predictors that are constant within each group. Select a
slope with `sd(g, coef(x))`. The scale is modelled on the log-SD
scale, so `sd(g) ~ habitat` means `log(SD_g) = α₀ + α₁ habitat_g`. This
predictor-dependent route requires complete outcomes and currently uses
41-node adaptive Gauss–Hermite quadrature. Its coefficient recovery and
prediction checks are available, but interval coverage has not been calibrated.

```julia
fit_sd = drm(bf(y ~ x + (1 | g), sd(g) ~ habitat),
             CumulativeLogit(); data = dat)
predict_parameters(fit_sd, dat)[:sd]  # fitted link-scale SD for each row's group
```

Correlated blocks and structured SD effects are not admitted on this route.
If `habitat` varies within a group, use a group-level predictor or a
random-regression design instead.

An unlabelled, intercept-only phylogenetic random intercept `phylo(1 | species)`
on `mu` is fit via the sparse augmented-state Laplace GLMM route (the same
engine as the Poisson/Gamma/Binomial/Beta `phylo(1 | g)` cells), matching
drmTMB 0.7.0's `validate_ordinal_phylo_mu_structured_term()`. It cannot be
combined with an ordinary `(1 | g)`/`(0 + x | g)` random effect on `mu`.

```julia
fit_phylo = drm(bf(y ~ x + phylo(1 | species)), CumulativeLogit(); data = dat, tree = tr)
re_sd(fit_phylo)[:species]   # phylogenetic SD, raw branch-length scale
```

## See also

- [Getting started](getting-started.md), install and a first Gaussian fit.
- [Choosing response families](model-guides/distribution-families.md), the
  modelling rationale, with R parity.
- [What can I fit today?](model-guides/model-map.md), the live capability map,
  including the `zi` / `hu` count modifiers and random-effect support per family.
