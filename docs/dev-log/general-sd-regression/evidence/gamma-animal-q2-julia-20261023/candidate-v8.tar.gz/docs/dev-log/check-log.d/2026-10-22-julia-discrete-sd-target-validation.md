# 2026-10-22 Julia discrete-family SD target validation

- **Change:** ordinary Poisson and Binomial SD fitters validate target level,
  distributional parameter and block before fitting; coefficient selectors
  must match the fitted random-effect coefficient.
- **Regression:** Poisson accepted a `dpar = :sigma` target before the fix.
  Binomial accepted `dpar = :sigma`, `level = :spatial`, and labelled-block
  targets. All malformed cases now raise `ArgumentError`.
- **Verification:** Poisson SD tests passed 43 assertions; Binomial SD tests
  passed 165 assertions; `git diff --check` passed.
- **Boundary:** focused Julia route evidence only. No all-family, native TMB,
  prediction/simulation parity, or interval-coverage claim.
- **Report:** `docs/dev-log/after-task/2026-10-22-julia-discrete-sd-target-validation.md`.
