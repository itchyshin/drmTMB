# Truncated NB2 random-slope SD alignment

This slice extends Julia `TruncatedNegBinomial2()` to one independent numeric
location slope with a predictor-dependent coefficient SD. It does not establish
interval coverage or structured-effect support.

| Symbol | Julia formula | Synthetic DGP | Recovery/output check | Truth |
|---|---|---|---|---|
| `b_g ~ Normal(0, tau_g^2)` | `(0 + x | g)` | Draw one standard normal `u_g` per group and set `b_g = exp(alpha0 + alpha1*z_g) * u_g` | `coef(fit, :sd)` | `alpha0 = -0.55`, `alpha1 = 0.55` |
| `tau_g = exp(alpha0 + alpha1*z_g)` | `sd(g, coef(x)) ~ z` | `z_g` is fixed within group and spans `[-1, 1]` | Signed recovery of the `z` coefficient and `predict_parameters(fit, data)[:sd]` | `exp(-0.55 + 0.55*z_g)` |
| `eta_i = beta0 + beta_x*x_i + x_i*b_g` | `y ~ x + (0 + x | g)` | `mu_i = exp(eta_i)` | Independent scalar normal integral uses `tau_g*x_i*u` | `beta0 = 0.25`, `beta_x = 0.4` |
| `Y_i | b_g ~ NB2(mu_i, size=1/sigma^2), Y_i >= 1` | `sigma ~ 1`, `TruncatedNegBinomial2()` | Draw NB2 values conditional on positivity | Likelihood oracle evaluates `log p(y_i)-log p(0)` inside the group integral | `sigma = 0.5`; GHQ likelihood agrees with adaptive scalar integration |

The row-loading matrix passed to adaptive Gauss-Hermite quadrature is the
observation-level slope vector `x`, while the latent standard deviation remains
the group-level `tau_g`. The zero-truncation normalizer is evaluated at the same
conditional linear predictor as the positive-count log probability before
integrating over `b_g`.
