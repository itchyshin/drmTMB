# Binomial SD clamp alignment

This slice aligns the default Bernoulli/Binomial random-effect SD guard with
drmTMB. The guard is a numerical mapping of the scale predictor. It does not
change the coefficient interpretation or the underlying random-effect design.

| Symbol | Fit formula and code | Data generation and recovery | Check |
|---|---|---|---|
| `eta_g` | `eta_g = W_g alpha`; Julia uses `Zgs[j] * theta[sd_ranges[j]]`. | Generate from known `alpha`; recover the matching `coef(fit, :sd)` block. Existing recovery fixtures keep `eta_g` inside the identity band. | Existing Binomial SD recovery tests. |
| `S(eta)` | Identity on `[-12, 12]`; above `12`, `12 + 3*tanh((eta - 12)/3)`; below `-12`, `-12 - 3*tanh((-12 - eta)/3)`. This matches the default native `logsigma_clamp = c(-12, 12)` and margin `3`. | Tail values are not used as ordinary recovery truths. Test the numerical mapping directly against the piecewise expression. | Focused helper test and native formula comparison. |
| `tau_g` | `tau_g = exp(S(eta_g))`; use this same value in the marginal likelihood and fitted SD outputs. | The latent coefficient is `b_g = tau_g * u_g`, with `u_g ~ Normal(0, 1)`. When truth lies inside the identity band, compare the estimated group SD with the DGP scale. | Pure transform test plus the existing in-band fit and output tests. |

This slice covers the default clamp on ordinary and phylogenetic-plus-ordinary
Binomial SD paths. Phylogenetic-only, animal, and related-matrix routes need a
separate clamp audit.
The Julia bridge does not currently forward custom `logsigma_clamp` values from
`drm_control()`. Disabling or widening the clamp through the cross-engine
bridge remains open and must be handled before claiming custom-control parity.
