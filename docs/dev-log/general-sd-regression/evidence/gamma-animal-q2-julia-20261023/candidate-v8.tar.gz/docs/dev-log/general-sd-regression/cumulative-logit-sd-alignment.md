# Cumulative-logit random-effect SD alignment

## Model

For observation `i` in group `g`, let `r_i = 1` for an intercept or let `r_i`
be the numeric covariate for an independent random slope. The cumulative-logit
location predictor is `η_i = x_i'β + r_i b_g`, with
`b_g ~ Normal(0, s_g²)` and `log(s_g) = w_g'α`. The category probabilities
remain `Pr(y_i ≤ k) = logistic(θ_k - η_i)` for ordered cutpoints
`θ_1 < … < θ_(K-1)`. The SD is on the ordinal location-link scale, and the
location intercept remains omitted because the cutpoints absorb it.

## Public formula

`bf(y ~ x + (1 | group), sd(group) ~ habitat)` models the log SD of the
ordinary location intercept. For an independent numeric slope, use
`bf(y ~ x + (0 + x | group), sd(group) ~ habitat)`; the one random coefficient
is uniquely identified. `coef(x)` may be supplied explicitly to name the slope
coefficient. Every SD predictor must be fixed
within group. This slice requires complete responses and one ordinary
independent intercept or slope; correlated and structured effects remain
outside this route.

## Implementation correspondence

| Symbol | Julia object | Fit / public output |
|---|---|---|
| `x_i'β` | `Xμ * β` after dropping `(Intercept)` | `coef(fit, :mu)` and `predict(fit, data)` |
| `r_i` | `ones(n, 1)` for an intercept; `reshape(x, :, 1)` for a slope | The same loading multiplies every group-specific draw |
| `w_g` | `_sd_group_design(...)` | used to compute and store group-level SDs; the design matrix itself is not retained |
| `α` | final parameter block | `coef(fit, :sd)` |
| `s_g` | `exp.(Zg * α)` | `fit.scales[:sd_group]`; row-level `fit.scales[:sd]` and `predict_parameters(fit, data)[:sd]` |
| `b_g` | scalar latent effect per group | integrated by the 41-node adaptive Gauss–Hermite objective |
| `θ_k` | `_cumulative_cuts(δ)` | `fit.scales[:ordinal_cuts]` |
| `y_i` | ordered integer category | unchanged cumulative-logit likelihood and `_rand_cumulative_logit` simulator |

The constant model `sd(group) ~ 1` is checked against the existing
constant-SD fitter for both intercept and independent-slope likelihoods and SD
intercepts. Separate synthetic varying-SD fixtures check recovery direction.
The slope simulator is checked against a seeded draw oracle, and a one-refit
bootstrap smoke test checks refit plumbing. These tests do not establish
interval coverage or broad recovery performance.
