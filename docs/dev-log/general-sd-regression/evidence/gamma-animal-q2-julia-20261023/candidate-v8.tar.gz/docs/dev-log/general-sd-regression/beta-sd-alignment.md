# Julia Beta random-effect SD regression alignment

## Model

For observation `i` in group `g`, the Beta mean is linked by

`logit(mu_i) = x_i' beta + b_g`,

with `b_g ~ Normal(0, tau_g^2)` and `log(tau_g) = z_g' alpha`. The response
likelihood remains `y_i ~ Beta(mu_i * phi, (1 - mu_i) * phi)`, where
`phi = exp(-2 * eta_sigma)` and `eta_sigma` is fixed by `sigma ~ 1` in this
slice. No extra Bernoulli or residual parameter is introduced.

## Public formula and target

`bf(y ~ x + (1 | g), sigma ~ 1, sd(g) ~ z)` means `z` predicts the log SD of
the ordinary Beta location intercept. Each SD predictor must be constant within
group after the retained-row policy. Only one ordinary intercept and one `sd()`
formula are admitted. Random slopes, structured effects, other random-effect
endpoints, incomplete responses, and non-constant `sigma` are excluded.

## Implementation correspondence

| Symbol | Julia data | DGP/test oracle | Fitted block/output |
|---|---|---|---|
| `beta` | `Xmu` from the `mu` formula | fixed logit-mean coefficients | `:mu` block |
| `eta_sigma` | `Xsigma` from `sigma ~ 1` | fixed log dispersion | `:sigma` block |
| `b_g` | one scalar latent coefficient per group | `exp(z_g' alpha) * u_g` | integrated by per-group adaptive GHQ |
| `Z_g` | `_sd_group_design(...)` | group-level fixed predictor matrix | `:sd` coefficient block |
| `alpha` | SD coefficients | log-SD truth | `coef(fit, :sd)` |
| `tau_g` | `exp(Z_g * alpha)` | group latent SD | `fit.scales[:sd_group]`; row output `:sd` |
| `y_i` | strict `(0, 1)` response | Beta density with `phi=1/sigma^2` | unchanged Beta likelihood |

The validation oracle integrates each group likelihood over a standard Normal
latent variable independently with adaptive scalar quadrature. Constant-SD
regression must agree with the existing Beta random-intercept fit using the
same quadrature node count.
