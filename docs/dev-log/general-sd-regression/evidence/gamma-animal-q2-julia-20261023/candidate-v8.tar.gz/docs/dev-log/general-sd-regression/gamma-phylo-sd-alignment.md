# Gamma phylogenetic mean-intercept SD regression

This Julia slice fits one Gamma mean random intercept whose SD varies with
fixed predictors attached to each tree tip. The formula is
`phylo(1 | species)` with `sd(species, phylogenetic) ~ z`, and `sigma ~ 1`.

For tip `t`, let `w_t` be the fixed-effect SD design and `alpha` its
coefficients. The latent tree effect has the existing raw Brownian covariance
`u ~ N(0, K_tree)`, and the fitted effect is
`b_t = exp(w_t' * alpha) * u_t`. Thus
`Cov(b) = D K_tree D`, where `D = diag(exp(W * alpha))`. The Gamma log-mean
predictor is `eta_i = x_i' * beta + b_{t(i)}`. The multiplier
`exp(w_t' * alpha)` equals the marginal tip SD only when `K_tree[t,t] = 1`;
otherwise the marginal tip SD is that multiplier times `sqrt(K_tree[t,t])`.
No tree normalization is introduced, so prior constant-SD fits retain their
existing scale.

The fit uses the sparse root-conditioned augmented-tree precision. The
marginal simulator draws Brownian edge increments from the tree topology in
linear time, then applies the same tip-specific multiplier before drawing the
Gamma response. Separate row-to-tip and row-to-group indices preserve tree
identity when data rows are shuffled. The public `:sd_phylo` coefficient block
and `predict_parameters(... )[:sd_phylo]` retain this target after serialization.

The focused synthetic test checks signed slope recovery, constant-SD
equivalence, shuffled-row identity, missing-tree and missing-tip errors,
public SD prediction, save/reload, the sparse draw covariance against a dense
small-tree oracle, predictor-dependent marginal simulation, and one bootstrap
refit. This establishes implementation and recovery evidence for this Julia
cell. It does not establish R/TMB parity or interval coverage.
