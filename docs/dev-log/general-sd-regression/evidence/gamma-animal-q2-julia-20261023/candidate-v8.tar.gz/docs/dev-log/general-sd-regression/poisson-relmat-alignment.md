# Poisson related-matrix SD alignment

This slice adds a Julia Poisson mean-intercept model with a related-matrix
random effect and a predictor-dependent coefficient SD. The route preserves
the existing Julia Poisson convention for supplied related matrices: it first
converts `K` to a correlation matrix. This engine-specific convention is a
known cross-engine boundary for non-unit-diagonal matrices.

| Symbol | Formula / implementation | Synthetic draw | Recovery / output |
|---|---|---|---|
| Fixed predictor design `X` and coefficients `β` | `y ~ x + relmat(1 | id)`; `Xβ` | `0.35 + 0.2 x` | `coef(fit, :mu)` |
| Supplied matrix `K` | Positive-definite matrix in first-seen group order | `K = S R S`, where `R[g,h] = 0.55^|g-h|` and `S` has unequal positive diagonal values | Fit and dense oracle both use `R = diag(K)^(-1/2) K diag(K)^(-1/2)` |
| Group-level SD design `Z_g` | `sd(id, relmat) ~ z`; `z` is constant within group | Balanced binary `z_g`, independently permuted from matrix order | `coef(fit, :sd)` and `fit.scales[:sd_group] = exp(Z_g α)` |
| Latent related effects `b` | Sparse Laplace route with precision `Q = R^(-1)` | `b = diag(exp(Z_g α)) chol(R) u`, `u ~ N(0,I)` | Dense Laplace objective at fixed parameters; seeded marginal simulator check |
| Response `y` | `y_gi ~ Poisson(exp(x_gi β + b_g))` | Independent Poisson draws at the latent linear predictor | Synthetic SD-slope recovery and fitted/predicted scale checks |

The route refuses response-missingness, an SD predictor that varies within a
group, and absent `K`. The test also compares the unit-column SD formula with
the existing constant-SD Poisson related-matrix fit. Bootstrap is exercised
with one refit only. This is implementation evidence, not interval-coverage
calibration or R/TMB parity evidence.
