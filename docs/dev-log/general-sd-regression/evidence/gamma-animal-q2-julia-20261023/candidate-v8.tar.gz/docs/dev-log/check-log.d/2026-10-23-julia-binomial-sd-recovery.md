# Julia Bernoulli predictor-dependent random-effect SD recovery

- Source pin: `codex/general-sd-regression` at `70dbf564eb670144c63c08f61ea099084d95add2`; this branch is 1 commit ahead and 135 behind local `origin/main` at `611ccb3d435be49070cf146881bd1a33bab5b091`.
- Dirty-source SHA-256: `src/binomial_sd_regression.jl` = `540942a0fd4877a0833247c3067e5fe9e21dd21b27201552c3c2122bd81721bd`; `test/test_binomial_sd_regression.jl` = `ce8af75640a516984fa27db910ae69b2c3948ce79c01ee950db53db69fa3956f`.
- Check: `JULIA_DEPOT_PATH=/tmp/drmTMB-julia-depot:/Users/z3437171/.julia JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 julia --project=. test/test_binomial_sd_regression.jl`.
- Result: exit 0; 169 assertions passed across 11 testsets. Coverage includes correlated and independent intercept/slope SD regressions, an independent 2-D quadrature oracle, constant-SD equivalence, Bernoulli/binomial equivalence, animal intercept/slope routes, prediction, simulation and one-refit bootstrap smoke tests, and explicit refusals.
- Scope limit: this is focused Julia evidence on the exact dirty source hashes above. It does not establish native TMB parity, family-wide capability, interval calibration, or current-main integration. Several fits use private builders; do not present this receipt as a complete public-workflow or calibrated-inference claim.
