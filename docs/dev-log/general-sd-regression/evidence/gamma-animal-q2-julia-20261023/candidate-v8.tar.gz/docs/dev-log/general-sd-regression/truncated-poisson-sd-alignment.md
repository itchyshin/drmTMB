# TruncatedPoisson intercept SD alignment

## Statistical target

For group `g`, the model is

\[
b_g \sim N(0, \tau_g^2), \qquad \log(\tau_g) = W_g\alpha,
\]

and, conditional on the latent intercept,

\[
Y_{ig} \mid b_g, Y_{ig} \ge 1 \sim
\operatorname{Poisson}(\lambda_{ig})\text{ truncated at zero},\qquad
\log(\lambda_{ig}) = X_{ig}\beta + b_g.
\]

The marginal group contribution integrates the product of the row probabilities
against the standard-normal latent variable. Each row log probability is

\[
y_{ig}\eta_{ig} - \exp(\eta_{ig}) - \log(y_{ig}!)
- \log\{1-\exp[-\exp(\eta_{ig})]\}.
\]

The zero-truncation normalizer therefore uses the same latent-effect-adjusted
linear predictor as the positive-count probability and remains inside the group
integral.

## Formula and implementation map

| Layer | Contract |
|---|---|
| Julia formula | `bf(y ~ x + (1 | g), sd(g) ~ z)` |
| SD design | `z` is evaluated using the ordinary formula/design machinery and must be constant within each observed `g` level. |
| Target admission | One ordinary IID mean intercept; the formula target must match the grouping variable. |
| Parameterization | `tau_g = exp(W_g * alpha)`; `alpha` follows the fixed-effect design coding. |
| Likelihood | Adaptive one-dimensional Gaussian quadrature of the zero-truncated Poisson conditional likelihood. |
| Public output | `:sd` coefficient block; `scales[:sd_group]`, rowwise `scales[:sd]`, and `predict_parameters(fit, data)[:sd]`. |
| Simulation | Marginal bootstrap simulator draws one group intercept with the fitted group SD, then samples a positive count. |

## Exclusions for this slice

This admission does not add constant-SD random effects to the ordinary
TruncatedPoisson route. It does not admit random slopes, correlated or
structured effects, `hu`, varying `sigma`, offsets, or missing responses in
the SD-regression route. It does not establish interval coverage or parity with
R/TMB. The source docstring describes the new syntax; the shared family and
capability tables remain subject to the active documentation lane's ownership.
