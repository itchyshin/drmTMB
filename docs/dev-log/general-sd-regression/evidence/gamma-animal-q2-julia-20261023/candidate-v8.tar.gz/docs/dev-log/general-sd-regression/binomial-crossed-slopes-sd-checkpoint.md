# Checkpoint: Julia Bernoulli crossed-slope SD regression

## 1. Goal

Extend the Julia Binomial/Bernoulli predictor-dependent random-effect SD route
to two independent effects on distinct grouping factors, including numeric
slopes, and reject slope designs whose SD regression is not identified by the
observations that carry nonzero loadings.

## 2. Implemented in this slice

The crossed Laplace engine carries observation-level coefficient loadings
through the latent mode, Hessian, selected-inverse quadratic form, and analytic
outer SD gradient. The dispatcher accepts one ordinary intercept or one
numeric slope per factor, with separate group-level SD regressions. Numeric
loadings must be finite and aligned with the retained response. An all-zero
loading now fails early, and the SD-design rank check uses only group levels
with nonzero random-effect loadings.

## 3. Mathematical contract

For observation `i`, the tested model is
`eta_i = X_i beta + x_i tau_g[g_i] u[g_i] + z_i tau_h[h_i] v[h_i]`, with
independent standard-normal latent coefficients and
`log(tau_g) = W_g alpha_g`, `log(tau_h) = W_h alpha_h`, using the existing
smooth log-SD clamp. The independent dense oracle builds the full loading
matrix, solves the fixed-parameter latent mode, and evaluates its Hessian
determinant. This checks the Laplace objective; it does not check interval
coverage.

## 4. Files changed by this slice

- `src/binomial_sd_regression.jl`: crossed observation loadings and informative-level rank guards.
- `test/test_binomial_crossed_slopes_sd_regression.jl`: two-slope synthetic recovery, dense oracle, prediction and bootstrap smoke checks, and rejection tests.
- `docs/dev-log/general-sd-regression/binomial-crossed-slopes-sd-alignment.md`: updated symbolic, formula, and synthetic-DGP alignment.

## 5. Checks run

- Red check: `test/test_binomial_crossed_slopes_sd_regression.jl` failed because all-zero slopes and a one-informative-level SD design were accepted.
- Focused crossed-slope checks: the initial strengthened file passed **17/17** assertions; after adding a known-DGP intercept/slope pairing, it passed **21/21**. With the crossed-intercept regression, exercised pairings now include intercept/intercept, intercept/slope, and slope/slope.
- Crossed-intercept regression: `test/test_binomial_crossed_sd_regression.jl` passed **20/20** assertions.
- Adjacent ordinary Binomial SD file: `test/test_binomial_sd_regression.jl` exited successfully; its reported testsets passed, including correlated blocks, independent slopes, animal effects, and fixed-parameter integration.
- `git diff --check` passed for tracked portions of the implementation and alignment changes.

## 6. Independent review

The independent math review found the slope loadings present in the mode,
Hessian, selected-inverse quadratic, and analytic SD gradient. It agreed that
the dense oracle is an independent likelihood check, but noted it does not
finite-difference the hand-coded outer gradient. It also identified a
pre-existing mismatch in the Binomial derivative helper for extreme absolute
linear predictors above 30; that shared helper was outside this slice and was
not changed here.

## 7. Evidence limits

This checkpoint supports the Julia Binomial two-factor independent-effect
cells under the tested logit model. The tests exercise intercept/intercept,
intercept/slope, and slope/slope pairings. It does not establish
R/TMB parity, structured or correlated slope blocks, more than two factors,
profile or bootstrap uncertainty calibration, interval coverage, save/reload
semantics, or support across other response families.

The shared `docs/src/capabilities.md` row still describes crossed Binomial SDs
as intercept-only. Its path-specific preflight found 14 branch references,
including other active documentation lanes, so this slice did not edit that
shared page. Public capability wording remains a closeout item for the owning
lane.

## 8. Cross-product coverage

The broader predictor-dependent random-effect SD programme remains active.
Coverage validation remains deferred by the user's steering; fit recovery and
smoke checks continue to be required for implementation slices. Native TMB
and Julia consistency, remaining family/effect combinations, public
documentation, and calibrated uncertainty still require separate evidence.
