| Date | Slice | Evidence | Result | Owner |
|---|---|---|---|---|
| 2026-10-18 | Julia Bernoulli SD public integration checks | Focused Julia SD, bridge, bridge-label, and marginal-bootstrap tests | 64 core checks, 42 public checks, 134 bridge checks, 10 bridge-label checks, and 25 marginal-bootstrap checks passed, including two coefficient-specific targets, target-aware simulation, bootstrap refit, explicit-selector bridge serialization, new-data response-dpar filtering, independent scalar-normal likelihood comparison, and Beta SD dispatch; no calibration claim | Codex |
