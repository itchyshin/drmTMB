# LogNormal random-intercept SD alignment

## Model

For observation `i` in group `g`, `log(y_i) = x_i'β + b_g + ε_i`, with
`b_g ~ Normal(0, s_g²)`, `ε_i ~ Normal(0, σ²)`, and
`log(s_g) = z_g'α`. The response density is
`f_Y(y_i) = f_log(Y)(log(y_i)) / y_i`. Thus
`log L_LogNormal = log L_Gaussian(log(y)) - sum(log(y))`.

## Formula

`bf(y ~ x + (1 | g), sigma ~ 1, sd(g) ~ habitat)` models the SD of the
ordinary mean intercept on the log-response scale. `habitat` must be constant
within group, and this slice requires complete responses and fixed `sigma ~ 1`.

## Code correspondence

| Symbol | Julia data or code | Fitted output |
|---|---|---|
| `log(y)` | `log.(y)` | transformed response passed to the Gaussian LSS fitter |
| `x_i'β` | `Xμ * β` | `coef(fit, :mu)`; `predict()` returns the response-scale median |
| `σ` | `Xσ` and the Gaussian LSS `:sigma` block | `sigma(fit)` and `coef(fit, :sigma)` |
| `z_g` | `_sd_group_design(...)` | group-level fixed design |
| `α` | Gaussian LSS `:sd` block | `coef(fit, :sd)` |
| `s_g` | `exp.(Zg * α)` | group scale and rowwise `predict_parameters(fit, data)[:sd]` |
| Jacobian | `sum(log, y)` | subtracted from log likelihood and added to refit objective |

The independent test fits the transformed Gaussian model directly and verifies
the likelihood identity. Constant-SD equivalence is checked against the
existing LogNormal random-intercept route. These checks establish point-fit
correspondence, not interval coverage.
