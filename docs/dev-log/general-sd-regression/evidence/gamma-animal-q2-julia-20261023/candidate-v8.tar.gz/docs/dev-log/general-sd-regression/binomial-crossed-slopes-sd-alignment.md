# Bernoulli crossed intercept and slope SD alignment

## Finite slice

This slice extends the Julia Binomial route to two distinct ordinary grouping
factors with one independent random coefficient per factor. Either coefficient
may be an intercept or one numeric slope. The fixtures cover the
intercept/intercept, intercept/slope, and slope/slope pairings. The slope/slope
recovery fixture uses distinct SD regressions and the dense oracle. Same-group
intercept-slope covariance,
multiple coefficients per factor, more than two factors, structured providers,
R/TMB parity, and interval coverage remain outside this slice.

For observation `i`,

\[
\eta_i = x_i^\top\beta + z_{ig,i}\tau_{g_i}\,u_{g_i}
                         + z_{ih,i}\tau_{h_i}\,v_{h_i},\qquad
y_i\sim\operatorname{Bernoulli}(\operatorname{logit}^{-1}(\eta_i)),
\]

where `z = 1` for an intercept and is the observed numeric covariate for a
slope. The standardized effects are mutually independent,
`u_g, v_h ~ N(0, 1)`. Their SDs satisfy

\[
\log\tau_{g}=W_g\alpha_g,\qquad
\log\tau_{h}=W_h\alpha_h.
\]

The fitted likelihood uses the existing smooth log-SD guard
`exp(softclamp(W alpha, -12, 12, 3))`; coefficients remain on the raw formula
scale. This slice adds no Bernoulli residual scale.

## Alignment table

| Symbol | Formula term / SD target | Synthetic draw | Recovery and output check | Truth |
|---|---|---|---|---|
| `u_g`, `tau_g` | `(0 + x | g)`, `sd(g) ~ w` | `u_g ~ N(0, 1)`, `tau_g = exp(alpha_g0 + alpha_g1 * w_g)`; contributes `x_i * tau_g * u_g` | `coef(fit, sd(g))`; per-row `predict_parameters()` | `alpha_g = (log(0.5), 0.25)` |
| `v_h`, `tau_h` | `(0 + z | h)`, `sd(h) ~ v` | `v_h ~ N(0, 1)`, `tau_h = exp(alpha_h0 + alpha_h1 * v_h)`; contributes `z_i * tau_h * v_h` | `coef(fit, sd(h))`; per-row `predict_parameters()` | `alpha_h = (log(0.4), -0.20)` |
| `eta_i`, `y_i` | `y ~ x + (0 + x | g) + (0 + z | h)` | `y_i ~ Bernoulli(logit^{-1}(eta_i))` | fitted `mu`, one bootstrap refit, dense independent fixed-parameter Laplace oracle | `(beta_0, beta_x) = (-0.2, 0.3)` |

The dense oracle constructs the full observation-by-latent loading matrix,
including both signed observation-level slope values, solves the fixed-parameter
latent mode independently, and evaluates the dense Hessian determinant. The
test also rejects an all-zero random-slope loading and checks SD-design rank
only among group levels with nonzero loadings. These checks support this exact
two-factor cell only; they do not establish interval coverage.
