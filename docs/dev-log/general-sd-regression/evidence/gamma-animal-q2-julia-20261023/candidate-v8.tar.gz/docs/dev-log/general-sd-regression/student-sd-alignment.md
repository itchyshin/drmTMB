# Student-t mean-intercept and independent-slope SD regression alignment

## Model contract

For observation `i` in group `g(i)`,

\[
y_i \mid u_{g(i)} \sim t_{\nu_i}(\mu_i+w_i\tau_{g(i)}u_{g(i)},\sigma_i),\qquad
\tau_g=\exp(W_g\alpha),\quad u_g\sim N(0,1),\quad
\log\tau_g = W_g\alpha.
\]

This Julia slice admits one ordinary intercept or one independent numeric
slope on `mu`, with one unambiguous `sd(group) ~ z` target. Here `w_i=1` for
an intercept and `w_i=x_i` for a slope. The slope SD is the SD of the random
coefficient; its contribution to the observation-level mean is `x_i b_g`.
The route preserves the existing Student links
`\mu_i=X_{\mu i}\beta_\mu`, `\sigma_i=\exp(X_{\sigma i}\beta_\sigma)`, and
`\nu_i=2+\exp(X_{\nu i}\beta_\nu)`. Each group is integrated with the existing
adaptive Gauss-Hermite routine using `L_g=\tau_g`. The public fit uses `:sd` for
the group-level log-SD coefficients, with group and row SD values retained in
`fit.scales`. The admission fixes `sigma ~ 1` and `nu ~ 1`.

## Formula and boundary

Accepted syntax is `sd(group) ~ z` when the coefficient target is unique; use
`sd(group, coef(intercept)) ~ z` or `sd(group, coef(x)) ~ z` to select the
intercept or independent slope. The SD design must be full-rank across groups
and constant within each retained group. The route requires exactly one
ordinary `(1 | group)` or independent numeric `(0 + x | group)` mean effect and
`marginal = :LA`. It also requires fixed `sigma ~ 1` and `nu ~ 1` submodels.
The formula wrapper applies its existing observed-response filtering before
this route. Correlated blocks, structured effects, multiple SD targets, and
`marginal = :Laplace` remain refused.

## Independent validation

`test/test_student_sd_regression.jl` simulates Student-t random-intercept and
independent random-slope models with signed log-SD predictors. Its fixed-
parameter likelihood checks use direct `QuadGK` integration of the Student
density against a standard Normal latent effect, independently of package
AGHQ. The tests check constant-SD equivalence for the intercept, coefficient-
SD prediction for the slope, Hessian-based prediction-SE output, `re_sd()`
refusal for a nonconstant SD, and one-replicate bootstrap refits. These
bootstrap smokes show refit wiring, not interval calibration.
