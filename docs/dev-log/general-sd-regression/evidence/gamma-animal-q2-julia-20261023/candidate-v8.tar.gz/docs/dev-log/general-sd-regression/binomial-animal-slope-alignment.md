# Bernoulli animal-slope SD regression: symbolic alignment

For the one-coefficient animal slope, let `g(i)` map observation `i` to its
animal, `x_i` be the observation-level random-slope covariate, and `z_g` be a
group-level SD design. The fitted model is

\[
u \sim N(0,A),\quad D_{gg}=\exp(z_g^\top\alpha),\quad b=Du,
\]
\[
\eta_i = X_i\beta + x_i b_{g(i)},\quad
Y_i \sim \operatorname{Bernoulli}(\operatorname{logit}^{-1}(\eta_i)).
\]

Thus `Cov(b) = D*A*D`; `sd(g, animal) ~ z` returns `D[g,g]`, the SD of the
random slope coefficient. The rowwise contribution to the linear predictor is
`x_i * b[g(i)]`, so it is not itself a standard deviation. The `A` matrix is
used in its supplied first-seen group order, without normalization.

| Symbol | Formula / route | Synthetic data | Extracted quantity | Truth |
|---|---|---|---|---|
| `X_i beta` | Fixed part of `y ~ x + animal(0 + x | g)` | `-0.1 + 0.3*x_i` | `coef(fit, :mu)` | `[-0.1, 0.3]` |
| `x_i` | Sole animal slope in `animal(0 + x | g)` | Balanced within-group `x` | `animal_slope` row multiplier | `x_i` |
| `u` | Animal latent state with covariance `A` | Cholesky draw `L_A * randn(G)` | Dense oracle latent coefficient | `N(0,A)` |
| `D_gg` | `sd(g, animal) ~ z` | `exp(alpha0 + alpha1*z_g)` | `coef(fit, :sd)`, `fit.scales[:sd_group]` | `alpha = [-0.45, 0.65]` |
| `b_g` | `D*u`, covariance `D*A*D` | `tau_g * u_g` | Fitted latent random slope | `D*u` |
| Bernoulli outcome | `Binomial()` on a `0/1` response | Logistic response from `eta_i` | `coef`/predictions and fixed-parameter NLL | Seed `20261022` |

The test compares the production sparse-Laplace objective at fixed truth to a
dense latent-vector Laplace calculation under `Q = inv(D*A*D)`. This checks the
random-slope loading and covariance scaling independently of the production
structured-state assembly. The seeded recovery fit and a one-replicate
bootstrap check are smoke tests; they do not establish interval coverage.
