# Hurdle NB2 SD-slope test receipt

Date: 2026-10-21 (MDT)  
Repository HEAD: `70dbf564eb670144c63c08f61ea099084d95add2`  
Execution host: Totoro, Julia 1.12.6  
Thread bounds: `OPENBLAS_NUM_THREADS=1`, `JULIA_NUM_THREADS=4`  
Persistent depot: `~/hsq_work/.julia-depot`  
Staged project: `~/hsq_work/general-sd-hurdle-nb2-slope-20261021`

## Exact source files

| File | SHA-256 |
|---|---|
| `src/negbinomial.jl` | `778cad5bf1ab0744b916ba82b43db962a84015fa24ed9f1e3ae85bb6a6f0e285` |
| `src/inference.jl` | `35954b4acded8cf3455638cffb06fbc265a109882fd4f5650b4748fcfd2fa8fe` |
| `test/test_hurdle_negbinomial_sd_regression.jl` | `fd32a58a4eb0aae9b72b51a10b0c5a03794eed76db37a3605e908c4b6710f6d3` |

The staged source files were copied from this checkout. The test harness uses
`include("src/DRModels.jl")` and a copy of the focused test whose package import
was changed from `using DRModels` to `using .DRModels`; model code and assertions
were unchanged.

## Command

```sh
OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=4 \
JULIA_DEPOT_PATH=~/hsq_work/.julia-depot \
~/.juliaup/bin/julia --project=. -e \
  'include("src/DRModels.jl"); include("test/test_hurdle_negbinomial_sd_regression_local.jl")'
```

## Result

```text
Test Summary:                             | Pass  Total   Time
Hurdle NB2 random-intercept SD regression |   17     17  37.0s
Test Summary:                                     | Pass  Total   Time
Hurdle NB2 independent random-slope SD regression |   22     22  18.8s
```

An instrumented rerun placed the single Vcov warning (`rcond =
7.164777844100239e-17`) inside the `bootstrap_result()` call, on its B=1
refit. The refit completed and the test passed, but the boundary standard
errors are not trustworthy. The primary slope fit and its `se=true` prediction
smoke call did not emit that warning. This receipt supports fit/recovery and
plumbing claims only; it does not establish interval calibration.
