# Gates: Julia Bernoulli animal-slope SD regression

OWNS: `src/gaussian_ranef.jl`, `src/gaussian_core.jl`, `src/binomial_sd_regression.jl`, `src/sparse_laplace_glmm.jl`, `src/inference.jl`, `test/test_binomial_sd_regression.jl`, `docs/src/capabilities.md`, `docs/src/families.md`, `docs/src/tutorials/animal-models.md`, `docs/src/developer-notes/formula-grammar.md`, `docs/dev-log/general-sd-regression/binomial-animal-slope-alignment.md`, `docs/dev-log/general-sd-regression/binomial-animal-slope-GATES.md`, `docs/dev-log/after-task/2026-10-21-julia-binomial-animal-slope-sd.md`, `docs/dev-log/check-log.d/2026-10-21-julia-binomial-animal-slope-sd.md`, `news/binomial-sd-regression.md`

Scope: fit one slope-only Bernoulli animal coefficient with a group-level log-SD regression in Julia, and verify recovery smoke, prediction, covariance algebra, simulator/bootstrap behavior, and documentation boundaries.

- [x] G1: Focused Binomial SD regression tests pass, including animal-slope recovery, dense Laplace/simulator oracles, and bootstrap interval plumbing. The profile test records failed nuisance endpoints as failure, not as an interval.
  CHECK: cd ../../.. && JULIA_DEPOT_PATH=/private/tmp/general-sd-julia-depot:$HOME/.julia JULIA_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1 $HOME/.juliaup/bin/julia --project=. test/test_binomial_sd_regression.jl && printf 'BINOMIAL_SD_TESTS_PASS\n'
  EXPECT: BINOMIAL_SD_TESTS_PASS
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/z3437171/Dropbox/Github Local/drmTMB/.worktrees/general-sd-julia/docs/dev-log/general-sd-regression; path=2ea25e4f8a09/10 entries; output=Bernoulli animal random-slope SD regression |   31     31  39.1s | BINOMIAL_SD_TESTS_PASS
  REVERIFICATION: Julia 1.10.0; full `test/test_binomial_sd_regression.jl`; 157/157 assertions passed on 2026-10-21. `src/inference.jl` SHA-256 `f3070a8fe1805d1804c4220456e0c37686e6fb3f61d0b29ed45d6fe5c88d73cb`; test SHA-256 `58af11e899b2776289a225361f04c8b1ae26d0058ac3972ef357ba986f882eac`.

- [x] G2: Patch whitespace and conflict-marker checks are clean.
  CHECK: git diff --check && echo DIFF_CHECK_PASS
  EXPECT: DIFF_CHECK_PASS
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/z3437171/Dropbox/Github Local/drmTMB/.worktrees/general-sd-julia/docs/dev-log/general-sd-regression; path=2ea25e4f8a09/10 entries; output=DIFF_CHECK_PASS

- [x] G3: Independent code review confirms the selected scope, mathematical contract, and no silent support expansion.
  EVIDENCE: independent read-only reviews confirmed sole-coefficient target selection, D*A*D Laplace algebra, coefficient-SD prediction, bootstrap simulation, and the shuffled-order seeded marginal-draw oracle. Reviews found that the DGP, permuted A, first-seen group indices, SD design, and RNG sequence agree; explicit all-zero-design and shuffled-order guards are covered in `test/test_binomial_sd_regression.jl`.
