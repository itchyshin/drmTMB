# Gates: Julia Poisson animal random-slope SD regression

OWNS: `src/poisson.jl`, `src/inference.jl`, `src/gaussian_core.jl`, `test/test_poisson_animal_slope_sd_regression.jl`, `docs/src/tutorials/animal-models.md`, `docs/dev-log/after-task/2026-10-22-julia-poisson-animal-slope-sd-regression.md`, `docs/dev-log/check-log.d/2026-10-22-julia-poisson-animal-slope-sd-regression.md`, `docs/dev-log/general-sd-regression/poisson-animal-slope-GATES.md`, `news/poisson-animal-slope-sd-regression.md`

Scope: support the existing Poisson animal slope-only random effect with constant and predictor-dependent coefficient SDs in Julia. Keep the public SD as the animal coefficient SD, and preserve current intercept and covariance behavior.

- [x] G1: The focused test passes, including recovery, independent dense Laplace oracle, constant-SD baseline equivalence, public outputs, exact seeded marginal simulation, serialization, bootstrap refit, and invalid group-level design rejection.
  CHECK: JULIA_DEPOT_PATH=/private/tmp/drmtmb-julia-depot:/Users/z3437171/.julia JULIA_LOAD_PATH='@:@stdlib:/private/tmp/drmodels-test-pkgdir' JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 julia --compiled-modules=no --project=. test/test_poisson_animal_slope_sd_regression.jl && echo POISSON_ANIMAL_SLOPE_SD_PASS
  EXPECT: POISSON_ANIMAL_SLOPE_SD_PASS
  CWD: /Users/z3437171/Dropbox/Github Local/drmTMB/.worktrees/general-sd-julia
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/z3437171/Dropbox/Github Local/drmTMB/.worktrees/general-sd-julia; path=e3e45f81f421/39 entries; output=Poisson animal random-slope SD regression |   19     19  19.1s | POISSON_ANIMAL_SLOPE_SD_PASS

- [x] G2: Existing Poisson and Gamma animal structured-effect neighbors remain green.
  CHECK: JULIA_DEPOT_PATH=/private/tmp/drmtmb-julia-depot:/Users/z3437171/.julia JULIA_LOAD_PATH='@:@stdlib:/private/tmp/drmodels-test-pkgdir' JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 julia --compiled-modules=no --project=. -e 'include("test/test_poisson_animal_sd_regression.jl"); include("test/test_poisson_relmat_sd_regression.jl"); include("test/test_gamma_animal_slope_sd_regression.jl"); include("test/test_gamma_animal_sd_regression.jl"); println("STRUCTURED_SD_NEIGHBORS_PASS")'
  EXPECT: STRUCTURED_SD_NEIGHBORS_PASS
  CWD: /Users/z3437171/Dropbox/Github Local/drmTMB/.worktrees/general-sd-julia
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/z3437171/Dropbox/Github Local/drmTMB/.worktrees/general-sd-julia; path=e3e45f81f421/39 entries; output=Gamma animal random-effect SD regression |   13     13  7.5s | STRUCTURED_SD_NEIGHBORS_PASS

- [x] G3: The implementation and docs patch has no whitespace errors, the check-log and after-task report exist, and the news fragment describes only the verified Julia capability.
  CHECK: git diff --check && test -s docs/dev-log/after-task/2026-10-22-julia-poisson-animal-slope-sd-regression.md && test -s docs/dev-log/check-log.d/2026-10-22-julia-poisson-animal-slope-sd-regression.md && test -s news/poisson-animal-slope-sd-regression.md && echo PATCH_AND_ARTIFACTS_PASS
  EXPECT: PATCH_AND_ARTIFACTS_PASS
  CWD: /Users/z3437171/Dropbox/Github Local/drmTMB/.worktrees/general-sd-julia
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/z3437171/Dropbox/Github Local/drmTMB/.worktrees/general-sd-julia; path=e3e45f81f421/39 entries; output=PATCH_AND_ARTIFACTS_PASS

- [x] G4: Independent review confirms the Laplace loading, score, curvature, covariance scaling, simulator mapping, and unchanged coefficient-SD public output semantics.
  EVIDENCE: Read-only integration review checked `_poisson_animal_sd_regression`, the shared structured Laplace mode/objective and simulator, plus public prediction parsing. The row loading is `x_i * exp(W_g alpha)`; the mode score adds `loading_i * (mu_i-y_i)` and diagonal Hessian adds `loading_i^2 * mu_i`; the objective and simulator use the same loading and existing normalized covariance. Public `:sd` is `exp(W_g alpha)` repeated by group and excludes `abs(x_i)`. Independent dense-objective, baseline-equivalence, and exact seeded-draw assertions pass. No broad engine parity or interval-coverage inference is made.
