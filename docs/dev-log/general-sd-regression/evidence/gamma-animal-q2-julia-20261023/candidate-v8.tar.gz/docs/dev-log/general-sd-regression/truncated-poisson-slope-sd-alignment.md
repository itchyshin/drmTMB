# TruncatedPoisson random-slope SD alignment

For group `g`, let the independent random slope be

\[
b_g \sim N(0, \tau_g^2), \qquad \log \tau_g = W_g\alpha.
\]

For observation `i` in group `g(i)`, the conditional log mean is

\[
\eta_i = X_i\beta + x_i b_{g(i)}.
\]

The response is zero-truncated Poisson, so its conditional log likelihood is

\[
\ell_i = y_i\eta_i - \exp(\eta_i) - \log(y_i!)
         - \log\{1-\exp[-\exp(\eta_i)]\}.
\]

The marginal likelihood integrates the product of these row contributions over
the one-dimensional normal random coefficient for each group. The truncation
normalizer therefore uses the same slope-adjusted `eta_i` as the Poisson mass.

The formula is `sd(g, coef(x)) ~ z` paired with `(0 + x | g)`. The SD design
matrix `W_g` uses ordinary fixed-effect coding and must be constant within each
group. The coefficient SD is `exp(W_g * alpha)`; the observation-level random
contribution is `x_i * b_g`. The fitter passes the row loading `x_i` to the
adaptive Gauss–Hermite group integrator and stores both group and row-aligned
coefficient SDs.

This slice admits one ordinary, independent mean slope only. It refuses a
missing or mismatched coefficient selector, an absent/non-numeric/non-finite or
all-zero loading, multiple or structured effects, offsets, and hurdle models.
It does not validate interval coverage or establish R/TMB parity.
