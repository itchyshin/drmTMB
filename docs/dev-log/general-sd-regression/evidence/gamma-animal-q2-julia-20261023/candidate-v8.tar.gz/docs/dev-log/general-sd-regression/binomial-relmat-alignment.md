# Binomial related-matrix SD alignment

This slice implements one Julia Binomial/Bernoulli mean intercept whose group-level coefficient SD follows a fixed-effect design. For the first-seen group order, let `D = diag(exp(W alpha))` and let `K` be the supplied related-matrix covariance. The latent covariance is `D K D`; the implementation does not normalize `K`. Therefore, when `K[g,g] != 1`, `exp(W[g,] alpha)` is the coefficient multiplier and the marginal coefficient SD is `exp(W[g,] alpha) * sqrt(K[g,g])`.

The parser selects the target with `sd(id, relmat) ~ z`. The route requires one `relmat(1 | id)` mean term, a positive-definite `K`, one SD formula, and complete responses. Fitting, rowwise SD prediction, prediction SEs, marginal simulation, and bootstrap refitting use the same first-seen index. This slice does not establish native TMB parity, other structured providers, additional random effects, or interval coverage.
