# 2026-10-22 Julia Gamma SD target validation

- **Change:** ordinary Gamma SD fitting validates `level = :iid`, `dpar = :mu`,
  no block, and a matching selected coefficient.
- **Regression:** a target manually marked `dpar = :sigma` was accepted before
  the fix and is rejected afterward.
- **Verification:** `test/test_gamma_sd_regression.jl` passed 33 assertions;
  `git diff --check` passed.
- **Boundary:** focused Julia Gamma target validation only. No all-family,
  native TMB parity, or interval-coverage claim.
- **Report:** `docs/dev-log/after-task/2026-10-22-julia-gamma-sd-target-validation.md`.
