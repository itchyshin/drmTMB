# Hurdle NB2 random-effect SD alignment

This Julia slice adds predictor-dependent SD regression for one ordinary mean
random intercept or one selected independent numeric mean slope in a hurdle NB2 model. The hurdle probability and NB2
dispersion remain fixed-effect submodels. This is a narrow fitted capability,
not a claim that every NB2 random-effect type or distributional endpoint is
supported.

For group `g(i)`, the model is

\[
b_g \sim N(0, \tau_g^2), \qquad \log \tau_g = Z_g\alpha,
\]

\[
\operatorname{logit}(\pi_i)=W_i\gamma, \qquad
\log \mu_i(b_g)=X_i\beta+x_i b_g, \qquad
r=\exp(-2\eta_{\sigma}),
\]

with `sigma ~ 1`. Its response distribution is

\[
P(Y_i=0\mid b_g)=\pi_i,\qquad
P(Y_i=y>0\mid b_g)=(1-\pi_i)
\frac{p_{NB2}(y;\mu_i(b_g),r)}{1-p_{NB2}(0;\mu_i(b_g),r)}.
\]

The group likelihood integrates the product of these observation probabilities
over the same `b_g`. Zero rows inform `gamma` but carry no information about
`alpha`; an all-zero group therefore contributes no mean-SD information.

| Symbol | Julia formula | Synthetic generator | Recovery or oracle | Truth |
|---|---|---|---|---|
| `b_g ~ N(0, tau_g^2)` | `(1 | g)` or `(0 + x | g)` | One standard normal per group, multiplied by `exp(Z_g * alpha)` | Group-integrated likelihood and recovered `sd` block | intercept and slope `alpha = [-0.65, 0.38]` |
| `log(tau_g) = Z_g * alpha` | `sd(g) ~ z` | `z_g` is constant within group | Signed coefficient recovery and rowwise `predict_parameters(fit, data)[:sd]` | `tau_g = exp(-0.65 + 0.38*z_g)` |
| `log(mu_i) = X_i * beta + x_i * b_g` | `mu ~ x + (1 | g)` or `mu ~ 0 + x + (0 + x | g)` | Positive-count mean varies with fixed predictors and the loaded random coefficient | Independent QuadGK integral and fit recovery with the observation-specific slope loading | `beta = [0.45, 0.25]` |
| `logit(pi_i) = W_i * gamma` | `hu ~ w` | Bernoulli hurdle draw; zeros stop, positive NB2 draws continue | `hu` extraction and marginal simulation | `gamma = [-1.25, 0.22]` |
| `r = exp(-2*eta_sigma)` | `sigma ~ 1` | NB2 count draw conditional on positivity | Oracle and zero-SD limit against fixed-effect hurdle NB2 | `sigma = 0.45` |

The synthetic tests include an all-zero group and check the independent
scalar-integral likelihood, signed recovery, target selection, public
prediction, the zero-SD limit, marginal simulation, and a bootstrap refit for
the intercept and slope routes. They do not establish
interval coverage.
