# Poisson independent-slope SD regression (Julia)

The focused Julia Poisson SD suite passed 35 assertions: 8 slope, 22 intercept, 4 refusal, and 1 independent intercept integral assertion. The slope test also checks an independent QuadGK likelihood oracle. Test-first red was the prior intercept-only rejection.

The live R bridge test `devtools::test(filter = "julia-poisson-sd")` passed 22 assertions across two live Julia fits and a same-data native TMB slope comparison with 0.25 coefficient tolerance. One non-fatal JuliaCall dependency-install warning was printed (`LogExpFunctionsInverseFunctionsExt`, undefined `loglogistic`).

The updated Poisson slope example in `docs/src/families.md` executed and recovered log-SD coefficients `(-0.4378, 0.3959)` from generating values `(-0.45, 0.4)`; rowwise `predict_parameters()` output had the expected observation count.

The route is limited to one ordinary intercept or one independent numeric slope with group-constant fixed SD predictors, ML, and adaptive Gauss-Hermite quadrature. No calibration or broad cross-engine parity claim follows.
