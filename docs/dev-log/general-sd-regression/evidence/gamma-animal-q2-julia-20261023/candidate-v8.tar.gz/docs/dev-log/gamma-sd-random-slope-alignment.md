# Julia Gamma random-slope SD alignment

The model for this slice is

\[
b_g \sim N(0,s_g^2), \qquad \log s_g = z_g^\top\alpha,
\]
\[
y_{ig}\mid b_g \sim \operatorname{Gamma}\!\left(\kappa,
\frac{\mu_{ig}}{\kappa}\right), \qquad
\log\mu_{ig} = x_{ig}^\top\beta + b_g w_{ig}, \qquad
\kappa=\exp(-2\eta_\sigma), \quad \eta_\sigma=\log\sigma.
\]

Here `z` is constant within group and `w` is the numeric random-slope predictor. The first delivery keeps `sigma ~ 1`, one independent slope `(0 + w | g)`, complete responses, and the existing one-dimensional adaptive Gauss-Hermite integration.

| Symbol in prose | Formula or covariance term | DGP draw | Recovery or oracle | Truth |
|---|---|---|---|---|
| `beta` | `mu ~ x + (0 + x | g)` | Fixed `beta = (0.4, 0.3)` | `coef(fit, :mu)` | `(0.4, 0.3)` |
| `eta_sigma` | `sigma ~ 1` | Fixed log scale `log(0.3)` | `coef(fit, :sigma)` | `log(0.3)` |
| `log(s_g)` | `sd(g) ~ z` | `s_g = exp(alpha_0 + alpha_1 z_g)` | `coef(fit, :sd)` | `(-0.75, 0.5)` |
| `b_g` | Independent random slope on `x` | `b_g = s_g u_g`, `u_g ~ N(0,1)` | Marginal likelihood, integrating `u_g` independently by group | One coefficient per group; no conditional estimate is claimed |
| `y_ig` | Gamma mean/shape map | `Gamma(kappa, mu_ig / kappa)` with `kappa = 1/sigma^2` | `fit.nll(theta)` against a QuadGK integral | Same likelihood and parameter order as the formula |

The seeded recovery test uses many independent groups, balanced SD-predictor levels, and within-group variation in `x`. The fixed-parameter oracle integrates each group over a standard-normal `u_g`; it checks that the random slope multiplies `x` inside the Gamma mean before the group integral.
