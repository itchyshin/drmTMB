# BetaBinomial mean random-slope SD alignment

This slice adds one independent numeric mean slope in the Julia BetaBinomial
route. The SD formula describes variation in the random coefficient. The
observation-level random-slope predictor multiplies that coefficient in the
linear predictor.

| Symbol | Julia model term | Synthetic data term | Recovery or oracle check | Truth |
|---|---|---|---|---|
| `b_g` | `(0 + x | g)` | `b_g = exp(w_g' * alpha) * epsilon_g` | The likelihood integrates one scalar `b_g` per group | `epsilon_g ~ Normal(0, 1)` |
| `tau_g` | `sd(g) ~ z` | `log(tau_g) = alpha[1] + alpha[2] * z_g` | Fit block `:sd` and `predict_parameters(fit, data)[:sd]` | `alpha = [-1.35, 0.6]` |
| `x_i * b_g` | Rowwise loading in `(0 + x | g)` | `eta_i = 0.2 + 0.35*x_i + x_i*b_g` | Independent `QuadGK` integral uses `eta_i + x_i*tau_g*u`, `u ~ Normal(0, 1)` | fixed slope `0.35`; loading `x_i` |
| `mu_i` | `logit(mu_i) = eta_i` | `mu_i = logistic(eta_i)` | BetaBinomial log likelihood and public mean fit | logit link |
| `phi` | fixed `sigma ~ 1` | `phi = 1 / 0.36^2` | Independent likelihood oracle uses fitted `exp(-2 * coef(fit, :sigma))` | common overdispersion |

The existing adaptive-quadrature kernel evaluates `eta0 + Zre * b` and the
normal density with covariance `L * L'`. This route passes rowwise `x` as
`Zre` and the group-specific `tau_g` as `L`; its fitted objective agrees with
the independent standard-normal integral in the synthetic test. This is
implementation and recovery evidence, not interval-coverage calibration.
