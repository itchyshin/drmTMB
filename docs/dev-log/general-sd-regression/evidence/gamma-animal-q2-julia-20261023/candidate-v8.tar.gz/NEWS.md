# DRModels.jl — NEWS

All notable changes are recorded here. The live work ledger is
[GitHub Issues](https://github.com/itchyshin/DRModels.jl/issues); this file is the
human-readable changelog.

## Development

- **NB2 animal-intercept SD regression accepts covariance `A` or precision `Ainv`.** `Ainv` is the precision of a unit-diagonal animal correlation matrix, ordered by the first-seen group levels. A same-data synthetic test checks coefficient, likelihood, and group-SD agreement against the covariance route after observation rows are shuffled. The fit still requires fixed `sigma ~ 1` and complete responses; a separate pedigree input and interval coverage are not established.
- Gaussian location-scale fits now accept an SD regression for one ordinary mean intercept or one independent numeric mean slope. Select a slope with `sd(g, coef(x)) ~ z`; `z` must be constant within each group, and the fitted SD is on the random-coefficient scale. The route supports ML and REML, rowwise SD prediction, marginal simulation, and bootstrap refitting. Synthetic recovery, independent dense ML/REML likelihood oracles, constant-SD equivalence, and refit workflow checks pass. Correlated or multiple slopes, structured effects, and interval coverage calibration are not established.
- Julia Gamma structured SD regression also supports independent animal intercept and slope fields, `animal(1 + x | g)`, with separate `sd(g, animal, coef(intercept)) ~ z0` and `sd(g, animal, coef(x)) ~ z1` designs. Fixed `sigma ~ 1`, complete responses, and group-constant SD predictors are required; Julia normalizes supplied `A` to a correlation matrix. A joint Laplace Hessian includes the cross-field data terms. Tests cover recovery, an independent dense Laplace oracle, bridge coefficient identity, selected prediction, seeded marginal simulation, serialization, and one bootstrap refit. An all-zero slope predictor is refused, as is the confounded case of constant `x` and identical SD designs; additional structured terms are refused. Non-unit-diagonal cross-engine scale parity and interval coverage remain unestablished.
- Julia Gamma phylogenetic SD regression now supports one `phylo(1 | species)` mean intercept with `sd(species, phylogenetic) ~ z`. The sparse Laplace fit and marginal simulator use the supplied tree's raw branch-length covariance; tests cover signed recovery, constant-SD equivalence, tree-tip ordering, public predictions, serialization, marginal simulation, and a bootstrap refit. Cross-engine parity and interval coverage are not established.
- Julia SkewNormal SD regression now accepts one independent numeric mean slope: fit `(0 + x | g)` with `sd(g, coef(x)) ~ z`. The SD describes the group-specific coefficient; each row's `x` multiplies it in the mean. The route requires fixed `sigma ~ 1` and `nu ~ 1`, complete responses, and group-constant SD predictors. Signed recovery and an independent scalar likelihood oracle pass, as do prediction, marginal simulation, and bootstrap-refit smoke checks. Correlated and structured effects are not established, and interval coverage is not calibrated.
- **ZeroOneBeta random-effect SD regression is available for ordinary mean intercepts and independent numeric slopes.** Use `sd(g) ~ z` for an unambiguous intercept target or `sd(g, coef(x)) ~ z` for `(0 + x | g)`. Other distributional predictors must remain fixed at intercepts, responses must be complete, and the SD predictors must be constant within group. A synthetic recovery test and independent normal-integral oracle cover the slope route; interval coverage is not calibrated, and correlated or structured effects remain unsupported here.
- **LogNormal random-intercept SD regression is available in Julia.** `LogNormal()` now accepts one ordinary mean intercept with `sd(group) ~ predictors`, fixed `sigma ~ 1`, complete outcomes, and group-constant SD predictors. The exact Gaussian-on-log-response marginal is reused with the LogNormal Jacobian; tests cover signed recovery, prediction, marginal simulation, constant-SD equivalence, and a transformed-likelihood oracle. Coverage calibration and slopes or structured effects remain open.
- **Cumulative-logit random-intercept SD regression is available in Julia.** `CumulativeLogit()` now accepts one ordinary location intercept with `sd(group) ~ predictors` when those predictors are constant within group. The route includes signed synthetic recovery, prediction, marginal simulation, and constant-SD equivalence checks. It requires complete outcomes; random slopes, structured effects, and interval-coverage calibration remain open.
- **Student-t random-effect SD regression now admits one independent mean slope.** In addition to one ordinary mean intercept, `Student()` accepts `(0 + x | g)` with `sd(g, coef(x)) ~ z`, fixed `sigma ~ 1` and `nu ~ 1`, and group-constant SD predictors. The SD output is the random coefficient's SD; the likelihood applies the row-level `x` loading. A fixed-parameter quadrature oracle, synthetic recovery, prediction, and bootstrap-refit smoke tests pass. Correlated blocks, structured effects, and interval calibration remain open.

## v0.7.2 — 2026-10-04

- **Location-scale fits no longer stall at a variance boundary.** Two loops in the location-scale fit counted an exactly tied objective as progress and had no stall stop, so a fit whose variance component slid to its zero boundary could spin for tens of minutes (a 4-species Gamma bootstrap test took 12 to 74 minutes on CI, depending on the runner's BLAS kernel). The inner mode solve now stops a run of 40 exactly tied steps only when the gradient is far above its bound and cannot reach it in the remaining iterations, and the certified refinement ladder stops a run only after 100 iterations with a bit-identical position, value and gradient. Converging fits are unchanged: across 30 test files every location-scale fit is bit-identical to before, and the fixture's standard errors and `check_drm` verdict are unchanged.
- **Docs: the README install section now shows `Pkg.add(url = "https://github.com/itchyshin/DRModels.jl")`**, matching the getting-started page. The local-clone `Pkg.develop` route is kept as a one-line alternative for contributors.

- **README first example now tells the same story as drmTMB's first model.** The worked example simulates growth of 120 individuals in forest and grassland with drmTMB's true values (mean `1 + 0.6·grassland + 0.4·temperature`, log residual SD `-0.5 + 0.45·grassland`) and fits `growth ~ habitat + temperature`, `sigma ~ habitat`. It links the twin drmTMB article and says plainly that the estimates differ from R's because the two languages generate different random numbers. The homepage and getting-started snippets are left for a follow-up.

- **Docs: the Student-t `nu` link is now stated as `ν = 2 + exp(η)` (#675).** The family table and Student-t prose called it a log link, which invites reading `exp(coef(fit, :nu))` as `ν`; it is `ν − 2`. Recover `ν` with `2 + exp(coef(fit, :nu))`.

- **Docs: the NegBinomial2 `sigma` slot is now described as log `σ` with size `θ = 1/σ²` (#676).** The family tables and the NB2 prose said "dispersion `θ` (log)", which contradicted the code and the worked example: `coef(fit, :sigma)` is log `σ`, and `θ = exp(-2·coef(:sigma))`. The same wording is fixed for `TruncatedNegBinomial2()`.

- **Docs: the large-data guide now names the parallel backend (#677).** `threads = true` uses Julia threads in one process; there is no Distributed.jl (`addprocs` / `@everywhere` / `pmap`) interface. The guide says how to avoid BLAS oversubscription and how to spread a simulation grid over independent Julia processes.

- **Docs: the profile-likelihood page links a drmTMB article that exists (#680).** Its status note pointed at a drmTMB `profile-likelihood` article that returns 404. It now links the drmTMB "First-week intervals: fit, profile, and boundary" article and the `profile.drmTMB` reference page.

- **Docs: one family count across the reference pages (#679, #683).** The model-specification page said "All 13 drmTMB families" and the API-stability page said "fourteen"; both now say fifteen response-family constructors, matching the README, the capability page and the stable-API test list (the fourteen under Response families plus `SkewNormal`).

- **Retired the orphan changelog stub page (#685).** `docs/src/changelog.md` was no longer in the documentation navigation, so it is removed (and no longer regenerated by `docs/make_stubs.jl`). The API stability page now points readers to `NEWS.md` on GitHub for release notes.

- **Correction: the v0.7.0 "threaded bootstrap, demonstrated" figure was not a threading gain (#689).** The 10× over native TMB at R=199 came from a Julia session with one thread (`julia.threads` = 1), so `threads = TRUE` ran the refits serially; the figure compares warm serial Julia with TMB. `threads = TRUE` parallelises the refits only when `JULIA_NUM_THREADS` > 1 is set before Julia starts. The evidence note carries the same correction.

- **Docs: the random-dispersion tutorial now says when the default integrator and Laplace differ (#692).** For `sigma ~ (1 | g)` the default `marginal = :LA` is non-adaptive 32-node Gauss–Hermite quadrature, close to exact for small groups and less accurate for groups of hundreds of rows; `marginal = :Laplace` matches drmTMB and suits large groups. The tutorial also says the `sigma` intercept is E[log σ], not log E[σ]; they differ by τ²/2.

- **Docs: the README no longer says the documentation site mirrors drmTMB's navbar (#699).** The menus are organised for readers, and many pages link their drmTMB twin article; the README now says that instead.

- **Retired the orphan `/get-started` transition page (#700).** `docs/src/get-started.md` was no longer built, and its text described a preserved URL that no longer exists. It is removed (and no longer regenerated by `docs/make_stubs.jl`); the first-model tutorial remains at `getting-started.md`.

- **Coming from R lists the drmTMB articles with no DRModels.jl page (#702).** A short section links the five drmTMB "Start here" articles that have no Julia counterpart: capability-and-limits, first-week-intervals, function-map-cheatsheet, missing-data and comparing-with-other-packages.

- **Docs: the location–scale–scale R snippet now says that `threads = TRUE` needs `JULIA_NUM_THREADS` > 1 (#703).** Without it the bootstrap refits run serially and `julia.threaded` reports `FALSE`; set the variable before the first Julia call in the R session.

- **Correction: Julia General registration did not happen at v0.7.1 (#704).** The v0.7.0 entry said registration was planned at v0.7.1. DRModels.jl stays out of Julia General until it and drmTMB are both ready (see the README Status section); until then, install it from GitHub with `Pkg.add(url = "https://github.com/itchyshin/DRModels.jl")`.

- **Large-data guide states that a single fit is single-threaded by design (#711).** As in drmTMB, `drm()` has no `threads` option; the parallel speed-ups are `bootstrap_ci(...; threads = true)` and `confint(...; method = :profile, threads = true)` with `JULIA_NUM_THREADS` set.

- **Binomial/Bernoulli fixed-effect fits are now screened for (quasi-)complete separation: detect and warn (#731, #728).** A fixed-effects-only `Binomial()` fit runs the Albert–Anderson / Konis (2007) separation check on the signed design (`X̃ d ≥ 0` for some `d ≠ 0`; a non-negative least-squares solve, no new dependency — see the #910-review fragment). When the maximum-likelihood estimate does not exist the fit is still returned, a warning names the coefficients that can diverge (`flagged_coefficients`), and their standard errors are `Inf` (their vcov rows/columns are NaN). Near separation is flagged the same way, on the scale-free rule described in the #910-review fragment. No refusal and no Firth/MSPL by default. drmTMB (#1268) runs the same check with the same constants, so the twins flag the same coefficients; coefficient values under separation are arbitrary stopping points and are not expected to agree. Random-intercept binomial routes are not screened. Non-separated fits are unchanged.

- **Large-data guide cites Latte.jl and GaussianMarkovRandomFields.jl (#776).** A short "Related software" section names them as the comparison and independent cross-check for the engine, with the one measured agreement (four location-scale estimates within 0.024 standard errors on a 50-group test model) and its limits.

- **q=4 REML engine: whitened prior, no Λ inverse (#857 site q4-REML).**
  `reml_ll_and_mode`, `_reml_exact_state` and the exact-gradient helper
  `reml_nll_and_exact_grad` built the REML prior precision
  `P = kron(Q_cond, inv(Λ))` from a formed `Λ` at six sites, plus a bare
  `logdet(Symmetric(Λ))` for its gradient term. Near a singular Λ (correlation
  → ±1, log-Cholesky diagonal around −18 to −30) this poisoned the
  Newton-certified joint mode badly enough that the Schur complement came back
  non-PD and `reml_nll_exact` returned the `Inf` barrier outright — on a
  well-identified p=6-leaf/n=24 fixture, l22 = −18/−20/−30 all failed this way
  while a 256-bit reference gives a finite value (≤ 1e-8 relative once fixed).
  Now built in whitened coordinates (`v = (I ⊗ L⁻¹)u`), matching the sister
  fix to the ML engine (#857 site q4) and the coevolution/q2 prior (#857 site
  K). Normal-regime values are unchanged: a frozen copy of the pre-fix
  algorithm agrees with the live one to ≤ 1e-10 over 10 random well-conditioned
  points.

- **Whitened q=4 engine: acceptance bar and test changes.** Owner-approved bar
  (2026-09-30): (i) identity with the unwhitened engine at a *polished* inner mode
  (`test_q4_prior_whitening.jl` compares `marginal_nll` with main's `P = Q ⊗ Λ⁻¹`
  construction solved to ‖∇J‖ < 1e-11; `test_reml_q4_chol.jl` compares the REML
  objective with a frozen pre-whitening copy), plus (ii) accuracy against a 256-bit
  reference (ML: l22 from −2 to −30; REML: −2, −12, −18, −20, −30). The inner mode
  gets a Newton polish after the LM λ-break so finite-difference vcov checks are not
  noise-dominated. `marginal_nll`'s 4th return is a `WhitenedPrior` (see below);
  `test_coverage_engine.jl` and `test_optimizer_robustness.jl` follow that contract
  (an extreme θ now gives a non-finite objective/gradient, which the fit rejects,
  instead of an `ArgumentError`). The factorisation floor in
  `test_q4_perf_identities.jl` drops from ≥ 100 to ≥ 90 because the fit converges in
  fewer iterations, and the `test_gaussian_bivariate_q4_structured.jl` positive
  control uses `q4_iterations = 300` (the whitened objective needs > 120 there).

- **q=4 ML PLSM engine: whitened prior, no Λ inverse (#857 site q4).** The
  Newton mode-finder, `laplace_ll`, `marginal_nll`, the exact O(p) gradient and
  `q4_marginal_diagnostic` now work in `v = (I ⊗ L⁻¹)u` (`Λ = LLᵀ` built from θ
  by `lc_to_chol`), so `H̃ = Q⊗I + blockdiag(LᵀD L)` and the `Σ log Lᵢᵢ` terms
  cancel analytically; the 1e-10 prior ridge is kept exactly. On the
  `test_q4_objective_diagnostic` fixture the marginal was 6.5e-7 relatively wrong
  at l22 = −12 and 2.4 nats off at l22 ≤ −20; it is now ≤ 4e-11 of a 256-bit
  reference from −2 to −30. `marginal_nll`'s 4th return value is now the
  `WhitenedPrior` and its `ch_H` the factor of `H̃`. The q=4 REML is separate.

- **`Binomial()` random intercept `(1 | g)`: the default integrator is now 5-node adaptive Gauss-Hermite (was 3) (#908).** This matches the other families. Fits can change slightly, always towards the true marginal likelihood. On `MASS::bacteria` (sparse binary, `y ~ week + (1 | ID)`), the 3-node default put `sd_mu` at 1.2866 (5.1% below the 61-node reference 1.3562, 0.22 nat of log-likelihood short); 5 nodes gives 1.3475 (0.64% below, 0.014 nat short). On the other binomial cells checked (binary and `cbind`), the change is below 1e-3 relative on `sd_mu` and 1e-3 nat on logLik. Binomial `(1 | g)` fits take roughly 1.6 times as many quadrature evaluations per group; wall time on the binomial test files is reported in the PR. Only the ordinary `(1 | g)` route changes: crossed, phylo, `(1 + x | g)` (already 5 nodes), `marginal = :Laplace` and `marginal = :VA` are untouched. Evidence: `docs/dev-log/evidence/binomial-5node/`.

- **Separation check: scale-free near rule, consistent intervals, bounded solver (fixes the #910 review).** The near-separation rule no longer flags healthy fits: the old "fitted probability within 1e-8 of 0/1 AND a Wald SE above 1e4" test was unit-dependent (it flagged a well-identified slope, z = 4.6, once its covariate was divided by 1e5) and read a failed SE as evidence. It is now scale-free: a fitted probability within 1e-8 of 0/1, a coefficient whose own contribution `|βⱼ|·range(xⱼ)` spans that whole probability range (> 36.84 on the logit scale), and Wald `|z| < 0.05`; a non-finite SE is never read as near separation. The exact check is now a Lawson–Hanson non-negative least-squares (Farkas) solve in place of the Bland-rule simplex, with the same flagged coefficients on every case tested; it is bounded by an iteration budget, and an exhausted budget warns that the check was inconclusive instead of silently reporting no separation. Flagged coefficients now carry an `Inf` vcov diagonal (rows/columns NaN), so `stderror`, `coeftable` and Wald `confint` agree on `Inf` / `(-Inf, Inf)`. Bootstrap replicate refits no longer repeat the warning. Flag semantics: a coefficient is flagged when any separating direction moves it, which can list more coefficients than R's `detectseparation`. drmTMB (#1268, PR #1442) carries the identical change. Healthy fits are unchanged.
- **Separation check, second review (#914): near rule gated, no absolute scale floor, outlier-robust scaling.** A single far `x` outlier with a null slope (z = 0.003) made the near rule warn on a finite-MLE fit (7 of 388 non-separated designs in a 400-design high-leverage scan); the near rule is now consulted only when the exact check is inconclusive — when the check proves there is no separation, the MLE is finite and its Wald SE stands (0 of 388 flagged). Columns are scaled by their median non-zero `|x|` (no `eps()` floor), so a completely separated `1e-200`-scaled column is detected and a far outlier no longer drives entries into the tolerances; the solver's KKT tolerance is relative to the residual. Checked against R's `detectseparation` on 1,500 random designs (466 with a far outlier, some with `1e-150`-scaled columns): identical separated verdicts, and its infinite-estimate coefficients are always among ours. Coefficients are flagged on the basis-free null-space projector diagonal, and an aliased column riding on a flagged one (e.g. `x2 = 2x`) is named too.

- **AR1 and OU `temporal()` fits: standardised residuals are now conditional on the fitted modes, as in drmTMB.** `residuals(fit; type = :quantile)` used to divide `y − Xβ̂` by σ̂ alone. That ignored the temporal and `(1 | id)` covariance, so it was not the residual of either package's model. It now returns `(y − Xβ̂ − b̂ − ŝ)/σ̂`, where `ŝ` is the temporal mode and `b̂` is the `(1 | id)` mode (or the phylogenetic stable mode of a paired `phylo()` + OU fit). This is drmTMB's Pearson and quantile residual for these routes (drmTMB `07d1612ea`; for the paired route, `012258e9f`): its `fitted()` adds every mode.
  - **Meaning.** The residual is the estimated noise `E[ε | y]/σ̂`, so its variance is below 1 even when the model is true. It is not whitened against the marginal covariance. Homogeneous Toeplitz fits keep their whitened residual, because they have no modes.
  - **Caveats.** At a residual-SD boundary (`sigma_ratio` in `check_drm(fit).temporal_boundary`) the temporal path absorbs the data: as σ̂ goes to 0 these residuals collapse toward 0 and cannot reveal outliers, so check the boundary first. The temporal routes do not clamp the far tail; the PIT routes of every other fit cap `|r|` at 8.126.
  - **Unchanged.** `residuals(fit)` (`type = :response`) stays `y − Xβ̂`, matching `fitted`. drmTMB's response residual subtracts its conditional `fitted()`. The bridge payload's `fitted` / `residuals` stay population level too; its comment no longer claims they equal drmTMB's for random-effect, phylogenetic or temporal fits.
  - **Checks.** A dense test checks the residual against `σ̂ V⁻¹(y − Xβ̂)` for AR1 and OU, with and without `(1 | id)`, and for the paired fit. The parity test also checks it against the same dense formula at drmTMB's stored estimates, to 1e-8 (measured at most 2.1e-9).
  - **Parity.** Every temporal parity cell now stores drmTMB's Pearson residuals. The eight AR1 / OU cells were regenerated at drmTMB `07d1612ea`, the head of open drmTMB PR #1447 as of 2026-10-02. The two paired `phylo()` + OU cells gained the block from drmTMB `012258e9f`, the head of open draft PR #1448 as of 2026-10-02; every other number in them is unchanged. DRModels.jl matches the residuals to 6.9e-7 (vignette-ou), 2.9e-7 (vignette-ar1-ri) and at most 2.1e-9 on the other eleven cells (Julia 1.10.12 and 1.13). The two larger gaps are drmTMB's: it builds its modes from TMB's `last.par.best`, which for those two fits are not the modes at its reported optimum, so its stored residual misses the exact `σ̂ V⁻¹(y − Xβ̂)` at its own estimates by exactly those amounts, while DRModels.jl's residual is exact. The OU cells are bit-identical to the earlier `dc81bb368` numbers. The AR1 cells moved by at most 4.4e-13 relative on the estimates, and both vignette-ar1-ri treatment profile endpoints moved by at most 3.5e-10 absolute (5.5e-10 relative).
  - **Docs.** The `residuals` docstring now says what each route returns and what a correct model implies: approximately standard normal with no random effect, marginal over σ̂_b for one `(1 | g)` on the mean, conditional on the modes for AR1 / OU, and whitened for homogeneous Toeplitz (where drmTMB's own `type = "quantile"` is not whitened, so compare with its Pearson residuals). It also lists TruncatedPoisson and names SkewNormal, with Tweedie, as unsupported. The post-fit page no longer says quantile residuals cover only Gaussian and Poisson, or that a well-specified model always gives ≈ N(0, 1).

- **Homogeneous Toeplitz `temporal()` fits: the bootstrap and the profile plots now keep the mean-coefficient scope.** drmTMB defers interval inference for σ and the lag correlations of `structure = "homtoep"`, and it has no bootstrap for temporal models (`confint(..., method = "bootstrap")` is refused for every temporal structure).
  - `bootstrap_ci`, `bootstrap_summary` and `bootstrap_result` now return rows for the mean coefficients only, with a one-time `@info`, instead of percentile intervals for σ and the partial autocorrelations. This matches the default of `confint(fit; method = :profile)`. The mean-coefficient intervals remain an extension, without a calibration claim.
  - `profile_curve` and `parameter_surface` refuse a σ or partial-autocorrelation coordinate, with the same scope as `confint` and `profile_result`. drmTMB's `profile()` refuses the same targets; `parameter_surface` has no drmTMB counterpart.
  - **Fix: the bootstrap of a fit that dropped missing-response rows.** Every replicate used to fail, because the simulated response had one value per fitted row while the covariates kept every data row. `simulate` now returns one value per data row, `NaN` at the dropped rows, so each replicate refit drops the same rows. The missing-response warning is not repeated for every replicate. For any univariate model, a bootstrap draw whose length does not match `data` is now an error rather than a silent mismatch.
  - AR1, OU and the paired `phylo()` + OU fits are unchanged.

- **Quantile residuals of zero-inflated and hurdle count fits now use the full mixture CDF (#922).** `residuals(fit; type = :quantile)` for a Poisson or NB2 fit with a `zi ~ …` or `hu ~ …` part used to build the randomized PIT from the count component alone, so under a correctly specified model the residuals were not N(0, 1). On simulated data (n = 2000, true model fitted) the scaled Kolmogorov–Smirnov statistic √n·D was 13.0 (ZI Poisson), 12.0 (ZI NB2), 9.3 (hurdle Poisson) and 6.2 (hurdle NB2), with residual means between −0.64 and −0.26; it is now 0.48–0.88, with means within 0.005 of 0.
  - Zero-inflated: `F(y) = π + (1 − π)·F_count(y)` for `y ≥ 0`. Hurdle: `F(0) = p0` and `F(y) = p0 + (1 − p0)·F_trunc(y)` for `y ≥ 1`, where `F_trunc` is the zero-truncated count CDF. Each observation is randomized within `[F(y − 1), F(y)]`, as for the other discrete families.
  - The hurdle part reuses the log-space zero-truncated Poisson and NB2 CDFs of `TruncatedPoisson()` and `TruncatedNegBinomial2()`, so a hurdle NB2 fit at extreme dispersion cannot return `NaN`. Those two families' residuals are unchanged.
  - Known limitation, inherited and shared with plain `NegBinomial2()`: the zero-inflated NB2 count CDF still comes from `Distributions.cdf`, which rounds to 1 at extreme dispersion (log σ below about −19). There the zero-inflated NB2 PIT degenerates, as the plain NB2 PIT already does; the hurdle NB2 PIT does not.
  - drmTMB's `residuals(fit, type = "quantile")` already uses the mixture CDF for `zi_poisson`, `zi_nbinom2` and `hurdle_nbinom2` (drmTMB has no hurdle Poisson). On one shared dataset (n = 2000, drmTMB origin/main 0eb046785) the PIT interval bounds `[F(y − 1), F(y)]` agree to 1.7e-15 when DRModels.jl evaluates them at drmTMB's fitted parameters, and to 3.6e-12 at each package's own fit; with drmTMB's uniforms the residuals agree to 2.1e-11.

- **Fix: quantile residuals of a Gaussian `sigma ~ 1 + (1 | g)` fit no longer treat the scale random intercept as a mean intercept (#923).** `residuals(fit; type = :quantile)` sent every fit with exactly one random-intercept SD to the σ_b-marginal route (#760), whatever axis the intercept was on. A scale-only fit therefore integrated the MEAN over N(0, τ̂²), with τ̂ the log-σ random-effect SD, which is a different model: on the new test's simulated fit (τ = 0.6, 30 groups of 20) the residual SD was 0.85 instead of about 1, and residuals sat up to 1.22 from the correct reference.
  - A lone log-σ intercept is now integrated out of the scale, σ_i e^b with b ~ N(0, τ̂²), on the same 32 Gauss–Hermite nodes. On that fit the residuals match an adaptive-quadrature reference to 1.4e-6 and their SD is 1.01.
  - The routing keys on the `<g>_logsigma` name of the random-effect SD, and that name counts only when the sigma formula has a random term on group `g` (the same check `repeatability()` uses, #925), so a mean grouping column that happens to be named `*_logsigma` keeps the mean route. A lone mean intercept (`(1 | g)`, `phylo(1 | g)`, `relmat(1 | g)`) keeps the σ_b-marginal route, and a mean plus sigma `(1 | g)` pair keeps both random effects at 0. (`drm()` fits a sigma random intercept for Gaussian only; a non-Gaussian one is refused before residuals are reached.)
  - drmTMB's quantile residuals for these fits condition on the fitted modes instead: its `predict()` adds them, and its residuals equal `(y − μ̂)/σ̂` with the log-σ mode included to 4e-15. DRModels.jl marginalises the random effect instead, the population-level reference it already uses for the mean intercept, so per-row values differ from drmTMB's by design, and how closely they track drmTMB's varies from one simulated replicate to the next.
  - What to expect: residuals of shapes judged with the random effects at 0 (crossed, correlated slopes, a mean and a sigma intercept together) are over-dispersed under a correct model, so a bent QQ plot is not by itself misfit. Gaussian `sigma ~ 1 + (1 | g)` residuals can be under-dispersed when the log-σ SD is moderate or large, because the default `marginal = :LA` fit integrates that intercept on a fixed prior-scale grid; refit with `marginal = :AGHQ` to check.

- **Fix: `Binomial()` (and `BetaBinomial()`) fits no longer stop on a flat clamp plateau and report a garbage "converged" answer.** The objective clamped the logit linear predictor to ±15 (±30 for the BetaBinomial fixed-effect route) *inside* the log-likelihood, which makes it exactly flat wherever any |η| exceeds the clamp. An L-BFGS step that overshot there (common with a wide covariate, e.g. `sd(x) ≳ 5`) stalled on the plateau with zero gradient and the fit reported `converged = true` with a slope in the tens or hundreds and a log-likelihood near −15 (e.g. 22 non-separated Bernoulli rows: slope 50.8, loglik −15.0 versus the true MLE slope 0.70, loglik −5.56). The Binomial log-likelihood is now the unclamped, numerically stable `k·η − n·log1pexp(η) + log C(n,k)`; the BetaBinomial uses an unclamped logit-parameterised log-pmf (overflow guard at |η| = 700 only). Fits that never leave the old ±15 band are unchanged (coefficients and log-likelihood agree with the previous release to ~1e-12 on the existing fixtures). Two supporting changes make the unclamped fit robust: the `(1 | g)` / `(1 + x | g)` quadrature routes map a non-finite objective probe to the repo's `1e18` failed-fit sentinel so the line search backtracks instead of throwing, and a non-finite AD Hessian at a runaway optimum there is reported as the NaN-covariance convention (standard errors `Inf`, with a warning) instead of throwing a LAPACK error. Completely separated data still terminates and returns a fit (the slope drifts to a large value; the separation guard in #910 still applies).

- **New (opt-in): `drm(...; marginal = :Laplace)` for `Student()` with one ordinary `(1 | g)` on the mean (#714).** Fits the TMB-convention Laplace objective drmTMB uses, so Student random-intercept fits can be compared with drmTMB on the same integrator; on regenerated issue cells the two engines agree to <= 2e-10 relative on logLik, coefficients, `sigma`, `nu` and the random-effect SD. The default integrator (`:LA`, per-group adaptive quadrature) is unchanged and byte-identical to before. `Student()` also gains an `se` keyword (default `true`). Class-1 twin-parity evidence for Poisson, Binomial, NegBinomial2, Gamma and Beta (which already had `:Laplace`) and the integrator-gap table: `docs/dev-log/evidence/class1-laplace-parity/receipt.md`.

- **New: a variance-component boundary warning for Gaussian fits with a grouped / structured random effect and `sigma ~ 1` (#724, #697).** When the structured term absorbs essentially all the variance (residual SD below `1e-3` of the SD of the random-effect BLUPs, i.e. a residual variance share below about `1e-6`) or the structured SD collapses to 0 relative to the residual, `drm` now warns and names the cause, and `check_drm(fit).variance_boundary` carries the flags (`residual_at_boundary`, `structured_at_boundary`, ratios, `one_obs_per_group`; `nothing` where the diagnostic is not defined). The residual `σ̂` of such a fit is an optimiser-stopping artefact, not an estimate (the likelihood is increasing in `σ²` from 0, so the log-scale gradient vanishes like `σ²`), so it is not twin-stable between engines (geiger::carnivores, n = 16: drmTMB 4.3e-5, DRModels.jl 3.1e-4, with `μ`, log-likelihood and the structured SD equal to 1e-8); compare `μ`, log-likelihood and the structured SD, not `σ`. Bootstrap refits stay quiet. The trigger is calibrated on 48 simulated phylogenetic fits and the full test suite (boundary fits `≤ 4.4e-5`, interior fits `≥ 2.2e-2`). Healthy fits are unchanged apart from `check_drm` gaining the `variance_boundary` field. With one observation per group, `σ_a` and `σ_e` are separated only by the off-diagonal structure of `A` (singular exactly for a star tree); the warning says so when that design collapses (see the location-scale-scale tutorial).
- **New: covariate-conditional repeatability / phylogenetic share for location-scale-scale fits (#694).** With `sd(id) ~ z` and `sigma ~ z`, repeatability is a function of the covariates, `R(z) = σ_b(z)² / (σ_b(z)² + σ_e(z)²) = logistic(2(α'z − γ'z))`, not a number. `repeatability(fit, newdata)`, `icc(fit, newdata)` (iid `sd`) and `heritability(fit, newdata)` (`sd(g, phylogenetic)`: `h²(z) = σ_a(z)² / (σ_a(z)² + σ_e(z)²)`) now return `R(z)` per row with a Wald-on-logit interval (the logit is linear in the coefficients; the joint `vcov` of the `sd` and `sigma` blocks is used). The single-argument forms still refuse these fits, and the refusal now states the estimand and points to the two-argument form. No behaviour change for fits without `sd()` submodels.

- **Behaviour change: a degenerate finite-difference Hessian now gives a NaN vcov, not
  fabricated SEs.** `_finite_hessian` (the outer-objective Wald Hessian behind the
  sparse-Laplace GLMM, crossed, phylo/relmat, cumulative, ordinary-Laplace,
  bivariate q=2 structured and sparse-phylo variance-block routes) used to react to a
  non-finite Hessian by warning and adding `1e12` to the diagonal, so the reported SEs
  came from a ridged matrix (near zero, looking precise), and it never treated the
  `1e18` failed-fit objective sentinel as a failure. It now returns an all-NaN
  matrix of the same shape, with a warning, when the objective at the fitted point --
  or any stencil probe -- is non-finite or a `>= 1e16` sentinel, and
  the callers' new `_vcov_from_fd_hessian` passes it through as an all-NaN vcov (the
  NaN-vcov convention of the other guarded Hessian helpers; `stderror` reports `Inf`
  for it, as for `se = false`). The `1e12` ridge is removed. Healthy fits are
  bit-identical (vcov compared to main on Julia 1.10). Only degenerate fits change.

- **Location-scale profile CI endpoints no longer come back as spurious `±Inf` from NaN / stalled inner solves.** Three root causes, none a model bug. (1) Objective-resolution stall: the backtracking (Armijo-only) L-BFGS profile nuisance solve stopped ~1e-5 from stationarity because trial objectives differ by less than the ~1e-12 noise floor at nll ~ 600, then reported `not_converged`/`not_stationary`; the exact gradient was correct (matches central differences). Such a stall is now retried once from the stall point with a Hager-Zhang line search under the same strict 1e-7 postcheck; accepted solves are untouched. (2) Stiff prior: at log L22 ~ -11.8 the prior precision has ~1e10 entries, one ulp of the latent mode moves the inner gradient by ~2e-9 > the strict `1e-9 (1+‖a‖)` certificate, the inner Newton cycled, and the objective/gradient became the 1e18/NaN sentinels. Profile solves (only) now accept the mode under `tol (1+‖a‖) + 4 eps ‖|P||a|‖` after the strict test has stalled (`relaxed=true`; the ordinary fit and Wald path is unchanged). (3) Range overflow: on a flat variance arm the geometric bracket expansion walked to |log L| ~ 700-1000 where `exp` overflows, so a flat unbounded profile was reported as a failed endpoint; log-Cholesky-diagonal arms are now capped at |log L| <= 300 and report `:no_crossing`. Together with owner decision 15 (a) (boundary log-Cholesky coordinates exempt from the stationarity gate), the slow `test_locscale_profile.jl` passes 9/9 and 45/45 on Julia 1.10 and 1.13 (main: 7 of 9 fail); new fast tests in `test_locscale_profile_nan.jl`.

- **Cross-family latent-rho profile CI no longer drops an arm to `NaN` when a penalised inner solve stalls a hair short of `g_tol`.** The first inner solve of the profile (far start, penalty 1e4, deviance far above the chi-square cutoff) can stop at `g_residual` ~ 1e-9 to 1e-7 without meeting `g_tol = 1e-9`, because trial objectives differ by less than the ~1e-12 noise floor at nll ~ 600. Whether it stalls depends on last-ulp differences (start point, CPU, BLAS kernel), so the same fit returned `(NaN, hi)` on some runners and not others (seen as a flaky CI failure on Julia 1.10). A stalled solve is now retried once from the stall point with a Hager-Zhang line search and accepted if stationary to 1e-6; solves that already converged, and sentinel (>= 1e9) solves, are unchanged.

- **Fix: `repeatability`, `icc` and `heritability` no longer treat a random intercept on log σ as a variance component.** A `sigma ~ (1 | g)` random intercept (SD `re_sd(fit)[:g_logsigma]`) lives on the log σ scale. Before this fix it was counted as a response-scale variance: a fit with only `sigma ~ (1 | g)` returned a meaningless ratio, and a fit with `y ~ x + (1 | g)` and `sigma ~ (1 | g)` could not pick its mean component without `component =` and could even pick the log-σ SD. The ratios now use the mean components only, and a scale random intercept turns the residual entry into the marginal residual variance `E[σ²] = exp(2 b₀ + 2 Σ ω²)`, as drmTMB does. On the mean-plus-scale fixture DRModels.jl matches drmTMB's `repeatability()` estimate and SE to 1e-6 (0.2032 and 0.0471, drmTMB `0eb0467`); the interval differs slightly because DRModels.jl centres it on the bias-corrected estimate. A fit whose only random effect is on `sigma` is refused, as in drmTMB. The fit-time variance-boundary check made the same mistake (it added the log-σ modes to the response-scale structured total) and is fixed the same way.

- **Temporal AR1 and OU random effects on the Gaussian mean: `temporal(1 | id, time, ar1)` and `temporal(1 | id, time, ou)` (D-310; twin of drmTMB's `temporal(1 | id, time = occ, structure = "ar1" | "ou")`, drmTMB#1302).** Each series `id` carries a stationary unit-variance chain at its observed times, scaled by a process SD and added to the mean; AR1 uses integer occasions with real gaps (`φ^gap`, `φ = tanh θ`, may be negative), OU uses numeric elapsed time (`exp(−λ Δt)`, `λ = exp θ`). The exact Gaussian marginal is evaluated per series with tridiagonal algebra in O(n) and is checked against a dense `MvNormal` oracle to 1e-10. An ordinary `(1 | id)` on the same id may be added, as in drmTMB. `temporal_parameters(fit)` reports the process SD, `phi` or `decay`, the residual SD and the stable-intercept SD. `fitted()` is population-level (drmTMB's is conditional; the conditional temporal effects are in `ranef(fit)`); `simulate()` draws a fresh temporal chain per series, as drmTMB's `simulate()`; `bootstrap_ci` uses the same draws (an extension: drmTMB refuses the temporal bootstrap). `@formula` cannot parse keyword arguments, so the Julia spelling is positional; `drm_bridge` accepts drmTMB's keyword spelling. Wave 1 is Gaussian, `sigma ~ 1`, ML only: other families, a temporal term on `sigma`, slopes, labelled bars, REML, bivariate models, a second temporal or another structured term, missing responses and duplicate `(id, time)` rows are refused by name. drmTMB parity cells and a twin of drmTMB's temporal article follow in the entry below.

- **Homogeneous Toeplitz temporal covariance on the Gaussian mean: `temporal(1 | id, occ, homtoep)` (D-311; twin of drmTMB's `temporal(1 | id, time = occ, structure = "homtoep")`, drmTMB draft #1449).** On a complete panel, each series' responses have covariance σ²R, where R is a free positive-definite Toeplitz correlation matrix. A complete panel means every `id` is observed at the same 3–12 equally spaced integer occasions, with at least as many ids as occasions.
  - **Parameters.** There is one correlation per lag (`temporal_parameters(fit).cor`, drmTMB's `cor_lag1…`), estimated through the partial autocorrelations (`coef(fit, :temporal_pac)`, atanh scale), so every fitted R is positive definite. As in drmTMB, `sigma` is the TOTAL within-series SD. There is no separate process SD, residual SD or `(1 | id)`, which are not identified when every lag is free, and there are no latent states.
  - **Engine.** The exact likelihood uses the Durbin–Levinson innovations factorisation, O(K²) per series.
  - **Checks** (Julia 1.10.12):
    - BigFloat dense oracle: ≤ 4e-15 relative, with partial autocorrelations up to ±0.995.
    - drmTMB's stability points (atanh PACs up to ±40): a 2048-bit Yule–Walker prediction-error reference to ≤ 3e-14.
    - The parameterisation is checked against dense Schur complements.
  - **Inference scope.** As in drmTMB, mean-coefficient profile intervals are given, and `vcov`, `stderror`, Wald `confint`, `predict(se = true)` and profiles of σ or the lag correlations are refused; `coeftable` prints `NaN` standard errors. As an extension (drmTMB refuses the temporal bootstrap), the parametric bootstrap gives mean-coefficient percentile intervals, without a calibration claim.
  - **Residuals.** `residuals(fit; type = :quantile)` returns the whitened L⁻¹(y − Xβ̂), which is drmTMB's Pearson residual. `simulate` and `bootstrap_ci` draw each series from σ²R.
  - **Missing responses, as drmTMB.** The rows are dropped first and the panel rules then apply to the retained rows. drmTMB's panel rules are refused by name.
  - **Parity.** Three drmTMB cells (drmTMB `90c740791`, including drmTMB's 80-site article data), on Julia 1.10.12: logLik ≤ 9.6e-12, lag correlations ≤ 4.9e-10, Pearson residuals ≤ 1e-6, profile endpoints ≤ 6.6e-6. The tutorial (now *Temporal AR1, OU and Toeplitz effects*) gains a Toeplitz section.

- **Temporal AR1 / OU: drmTMB parity cells and a twin article (D-310).** Eight cells in `test/parity/temporal/` (AR1 and OU, each with and without `(1 | id)`, on the two `test/fixtures/temporal/` datasets and on the two datasets of drmTMB's *Temporal AR1 and OU random effects* article) record drmTMB's ML numbers (drmTMB `dc81bb3`, 0.7.1, R 4.6.1). In the measured run (Julia 1.12.6, Linux, Totoro) DRModels.jl reproduced logLik to ≤ 1e-11 and β, process SD, φ / decay, `(1 | id)` SD and σ to ≤ 1e-8 relative; `test/test_parity_temporal.jl` enforces 1e-8 absolute (logLik) and 1e-6 relative on every run, and the gated `test/parity/runparity_temporal.jl` (`DRM_PARITY_TESTS=1`) also fits drmTMB's keyword spelling through `drm_bridge`. New tutorial *Temporal AR1 and OU random effects* fits drmTMB's article data, prints the same estimates, all 288 conditional fitted values and the AR1 Wald and AR1 / OU profile intervals side by side against drmTMB numbers read from the parity cells (prose adapted from the drmTMB article with attribution), and reports drmTMB's interval scope (AR1 mean-coefficient Wald; mean-coefficient profiles for AR1 and OU) and states that DRModels.jl's further Wald, profile and bootstrap intervals for the variance components and φ / decay are an uncalibrated extension (drmTMB refuses them).

- **Phylogenetic stable intercept + OU temporal deviations on the Gaussian mean: `phylo(1 | species) + temporal(1 | species, elapsed, ou)` with `drm(...; tree)` (D-311; twin of drmTMB's paired provider `phylo(1 | species, tree = tree) + temporal(1 | species, time = elapsed, structure = "ou")`, drmTMB draft #1448).** Closely related species share a stable baseline (`a ~ N(0, σ_a² C)`, `C` the tree's tip correlation matrix, as drmTMB), while each species makes its own OU departures through time. The two are additive; this is not a separable phylogeny-by-time field.
  - **Engine.** The exact marginal costs O(n). Wave 1's per-series Kalman filter reduces each species to a Gaussian factor in its stable effect, and an exact pruning (upward-message) pass integrates the tree. That pass is the zero-fill sparse Cholesky of the joint precision, and ForwardDiff runs through it.
  - **Trees, as drmTMB.** The tree must be ultrametric (drmTMB's relative `sqrt(eps)` tolerance). Zero-length branches are accepted: the route reads the Newick without the sparse-precision assembly, and the shared parser is unchanged.
  - **Checks** (Julia 1.10.12):
    - Dense `MvNormal` oracle: |Δnll| ≤ 9.2e-13 at random parameters, decay → 0 / ∞ and σ_a → 0 / large.
    - Pruning pass on non-ultrametric trees (internal identities, not a user route): exact to 1e-10.
    - Zero-length internal and tip branches: dense oracle to 1e-10.
  - **Accessors.** `temporal_parameters(fit).sd_phylo` is drmTMB's `sd_phylo_stable`. `ranef(fit)[:species_phylo]` holds the stable modes and `ranef(fit)[:species]` the OU modes. `simulate` and `bootstrap_ci` draw a fresh phylogenetic vector, fresh OU paths and fresh noise.
  - **Refusals.** drmTMB's pairing rules are refused by name: OU only; an unlabelled intercept on the same grouping; no ordinary `(1 | species)`; ≥ 3 species, each with ≥ 2 times; ≥ 3 distinct lags; tree tips exactly the observed species, with unobserved tips named.
  - **Parity.** Two drmTMB cells (drmTMB `012258e9f`): a 24-species fixture and drmTMB's 60-species article data. On Julia 1.10.12: logLik ≤ 5.5e-12, every estimate ≤ 2.1e-11 relative, conditional fitted values ≤ 2.3e-12.
  - **No interval claim.** Only profile `confint` warns that the paired fit's intervals are uncalibrated, as in drmTMB. drmTMB refuses Wald and bootstrap intervals for this fit; DRModels.jl returns them as an extension, without a calibration claim, and does not warn that they are uncalibrated.
- **Temporal boundary diagnostic (twin of drmTMB's `temporal_boundary` and random-effect-SD checks, drmTMB #1447 / #1448).** Every `temporal()` fit (AR1, OU, paired phylo + OU) is checked against drmTMB's rules:
  - residual σ̂ below 1e-3 · sd(y);
  - OU decay × longest series span below 1e-4, or × shortest gap above 30;
  - AR1 |φ̂| above 0.999;
  - the smallest random-effect SD (process, phylogenetic or `(1 | id)`) below 1e-4.

  A fit that meets any rule warns at fit time (quietly inside bootstrap and profile refits) and reports `check_drm(fit).temporal_boundary = (at_boundary = true, findings = […])`. drmTMB calls this `convergence_status() == "boundary"`.
  - On drmTMB's own boundary panel, DRModels.jl reaches decay ≈ 1.4e-18 with drmTMB's β, σ and process SD. Its logLik, −45.5124249, equals a 256-bit dense evaluation; drmTMB prints −45.5124225 there, a precision loss at the boundary, not in DRModels.jl.
  - On a panel whose true stable SD is 0 (12 species × 5 times), the fitted phylogenetic SD (3.9e-10) is flagged.
  - **Caveat.** As in drmTMB, the σ rule uses the marginal sd(y), so it can fire when a covariate dominates the response.

- **New: `TruncatedPoisson()` family (#726, owner decision 16a).** Zero-truncated Poisson for strictly-positive counts, mirroring `TruncatedNegBinomial2()` and drmTMB's `truncated_poisson()`. `TruncatedPoisson()` + `hu ~ ...` is the shared twin spelling of the hurdle Poisson: it delegates to the existing `Poisson()` + `hu` route and gives bit-identical fits (the fit reports `Poisson` as its family). `Poisson()` + `hu` keeps working. Without `hu` it fits the plain zero-truncated Poisson (fixed effects only); `zi`, `sigma`, random effects and zeros in the response are refused. Bridge name `truncated_poisson`.

- **Heritability/ICC `:profile` CI no longer returns a failed-fit cliff as a bound.**
  `nll_at_ratio` now evaluates the objective at the minimizer (not the stale
  `Optim.minimum`) and flags a sentinel (>= 1e16), non-finite, or non-converged inner
  solve as failed; `_profile_side` treats a failed evaluation as unresolved instead of
  "above target" and returns `NaN` (with a warning) for that arm. Ordinary CIs are
  unchanged to 1e-8.
- **Cross-family (`fit_mixed_family`) no longer reads the 1e10 objective sentinel
  as data.** The profile CI on rho treats a non-converged, non-finite or sentinel
  inner solve (or one stopped short of rho0 with deviance below the cutoff) as
  unresolved and reports that arm as `NaN`, instead of "crossed" (which pinned the
  endpoint to the cliff edge). The parametric bootstrap skips refits that are
  non-converged or on the sentinel (`loglik <= -1e9`) and reports the number kept
  in `n_boot_kept`. `mf_aic` / `mf_bic` return `NaN` with a warning for such fits
  instead of an AIC near 2e10. Ordinary fits and CIs are unchanged.
- **Sentinel-loglik fits are refused at the fit level.** A fit stranded on the
  1e18 failed-objective sentinel (loglik = -1e18: finite, and possibly
  "converged" on a zero-gradient plateau) used to pass `_nondegenerate_fit` and
  feed `lrtest`/`anova`, `lrt_boundary`, `aic`/`bic`/`aicc` (LR statistic ~2e18,
  AIC ~2e18). `is_converged` now rejects loglik <= -1e15 (the loglik-scale
  counterpart of the Laplace `nll < 1e17` bar); `lrtest`, `anova` and
  `lrt_boundary` throw `ArgumentError` naming the degenerate fit; `aic`, `bic`
  and `aicc` return `NaN` with a warning. Healthy fits are unchanged.

- **σ-phylo profile CIs no longer fabricate an endpoint from a failed solve.**
  `_glsp_profile_ci` read the ML route's 1e18 failure sentinel as a threshold
  crossing (the endpoint landed on the edge of the failed region) and the REML
  route's Inf / a throwing sub-fit as "not crossed" (a false boundary, SD 0 or
  Inf). A failed evaluation is now a third outcome: it backs off toward the last
  good point and, if the crossing cannot be bracketed, that arm of
  `profile_ci_sd_sigma` / `profile_ci_sd_mu` is `NaN` (unresolved). Genuine
  boundaries (`[0, Inf]`) and ordinary CIs are unchanged (fixtures agree to 1e-8).
- **Generic profile CI no longer reads a 1e18 sentinel as a crossing.** A
  profiled objective at or above 1e16 while the reference NLL is ordinary is
  now a failed arm with `nuisance_reason = :sentinel_objective` (previously the
  bisection collapsed onto the sentinel cliff), and `profile_curve` /
  `parameter_surface` deviance is `NaN` there instead of about 2e18.
- **Fix 8-15x slowdown in Gaussian location-scale phylo REML.** The outer β Newton in `_glsp_joint_reml_nll` now exits when the predicted decrease is at rounding level and the gradient test passes, instead of letting the accept-on-equal line search halve ~26 times to a near-null step and repeat near the optimum (H2 fixture 59 s -> ~7 s or better); answers unchanged (reml_nll to ~1e-12).

- **Tweedie crossed random effects (#737, drmTMB twin parity).**
  `Tweedie()` now fits crossed/multiple random intercepts on the log-mean,
  `(1 | g) + (1 | h)`, matching drmTMB's `tweedie()`. `sigma ~ 1` and
  `nu ~ 1` are now REQUIRED on this route. Integrator: the sparse
  augmented-state Laplace GLMM engine already shared by Gamma/NB2/Beta's
  crossed routes (`_fit_crossed_mean_laplace_nuisance`) — no new integrator
  for the random effects. That shared engine's single scalar "nuisance" slot
  takes the dispersion; the power `p` (a second nuisance parameter the shared
  engine has no room for) is found by an outer 1-D Brent profile search over
  `p`, refitting the full (β, dispersion, σ_g, σ_h) inner model at each
  candidate `p` — exact profile-likelihood optimisation, not an approximation.
  Per-observation value/derivatives for the Dunn–Smyth compound Poisson–Gamma
  density (which has no convenient closed-form derivative) are obtained by
  nested `ForwardDiff.derivative` rather than hand-derived analytically.
- **Gaussian `(1 | g)` REML no longer throws or returns -Inf on an extreme
  line-search probe.** The REML term's `Xμ'V⁻¹Xμ` in `_fit_ranef_gaussian` and
  the `sd(g) ~ z` route `_fit_ranef_gaussian_lss` was built by Woodbury
  subtraction. At an LBFGS probe with log sigma_i ≈ -105 that gave an exactly
  singular 8e110 matrix where the true value is about 1e-7. The ForwardDiff
  Cholesky accepted the zero pivot, so the objective became -Inf, and fitting
  the #835 tutorial-style model (`sd(id) ~ sex`) threw
  `AssertionError: isfinite(phi_c) && isfinite(dphi_c)` on Julia 1.10.
  `_re_xtvinvx_stable` now forms the matrix as a penalised sum of squares, so
  it is positive semi-definite by construction. A non-finite logdet now also
  triggers the REML barrier. The Julia 1.10 vs 1.13 "different optima" reported
  on #835's test (ll -412.301 vs -408.179) were not false convergence: each
  version drew different data from `MersenneTwister(20260715)`. Each answer is
  a verified stationary point of its own data, and the two versions agree to
  1e-11 on the same literal data (`test/test_lss_reml_falseconv.jl`).
- **Simultaneous mean + `sigma` random intercepts on Gaussian (#745, twin
  drmTMB #1287).** `bf(y ~ x + (1 | g), sigma ~ (1 | g))` used to refuse with
  "a random effect on `sigma` must be the only random structure", even though
  drmTMB admits it (TMB's nested Laplace integrates the full stacked
  `(u_mu, u_sigma)` vector). A new route, `_fit_musigma_ranef_gaussian`
  (`src/gaussian_ranef.jl`), is admitted for exactly this cell: BOTH random
  effects a single intercept `(1 | g)`, sharing the SAME grouping factor. The
  two REs' joint Hessian is then block-diagonal in 2×2 blocks (one per
  group), so each group's `(b_mu, delta_sigma)` pair is found and
  Laplace-integrated together, and summing those independent per-group 2-D
  Laplace terms is the whole-model nested Laplace approximation — the mean
  RE is NOT profiled out in closed form first (unlike `_fit_ranef_gaussian`'s
  exact Woodbury marginal for `sigma ~ x` fixed effects), because the sigma
  random effect makes each row's variance itself latent. `marginal` is
  always `:Laplace` on this route (no closed-form or quadrature alternative
  is implemented). On a G=60/n_g=10 simulated fixture it matches native
  drmTMB 0.7.1 (TMB Laplace) to <1e-10 in logLik and every estimate — far
  inside the twin ledger's ~1e-4 bar (`test/test_twin_gap_745.jl`,
  `test/fixtures/musigma_ranef_745/`). Refused, not silently dropped: a
  random SLOPE on either axis, more than one random-effect term per axis, the
  two REs on DIFFERENT grouping factors, a structured (phylo/relmat/animal/
  spatial) mean marker or `meta_V(...)` alongside this cell, and
  `method = :REML`.
- **Data-driven starts/restart for Gaussian `(1 | g)` + `sigma ~ x`, follow-up
  to #746/#747.** The two optimiser misses left open by #746/#747 (seed 4:
  LBFGS stopped at a boundary sd_g -> 0 local optimum 123 nats short of
  drmTMB's interior optimum; seed 10: non-converged, 95 nats short) were a
  bad start, not the objective. `_fit_ranef_gaussian` now starts the `sigma ~
  …` coefficients from an OLS regression of log(guarded residual²) on the
  scale design (a real slope instead of always 0), and the random-intercept
  log-SD from a one-way ANOVA method-of-moments estimate, then restarts once
  from the historical always-interior start if the result does not
  gradient-converge or lands at a boundary — keeping whichever objective is
  lower (deterministic, no random multi-start; mirrors the boundary-restart
  already used by the correlated `(1 + x | g)` route). Seed 4 now matches
  drmTMB to 1.5e-11, seed 10 to 2e-8 (both well inside 1e-6). Zero regressions
  on the RUNAWAY panel: the other 17 seeds are unaffected (one, seed 1, now
  reaches its unchanged boundary optimum through a tie-break instead of
  throwing at a more extreme representative of the same tie — see
  `_re_lbfgs_with_restart`'s docstring). See
  `test/test_twin_gap_747_starts.jl`. Not touched: the objective itself, the
  correlated `(1 + x | g)` route, or the simultaneous mean+sigma RE route.

- **Cancellation-free Woodbury quadratic for Gaussian `(1 | g)` + `sigma ~ x`
  (#746, #747).** `_fit_ranef_gaussian` and the `sd(g) ~ z` route
  `_fit_ranef_gaussian_lss` formed `r'V⁻¹r` as `q1 - q2` (both terms `~1/D_min`),
  so once one residual sigma_i got small the rounding error swamped the true
  value and LBFGS chased the resulting cancellation hole (logLik up to +1e133
  on origin/main). `_re_quad_stable` now evaluates the same quantity as the
  penalised RSS at the conditional mode instead. StableRNG sweep, 60 fits:
  origin/main 12/60 absurd, fixed 0/60, logLik matches drmTMB 0.7.1 to <=
  3.6e-13. Of the 3 seeds that still throw on the #609 runaway panel, only one
  (seed 3) is the boundary-Hessian-overflow case; seeds 4 and 10 are optimiser
  misses (LBFGS lands on a worse or non-converged point than drmTMB's), filed
  as a follow-up rather than fixed here — see `test/test_ranef_varying_scale_convergence.jl`.
- **`cov_to_lc` no longer throws a bare `PosDefException` on a boundary-fitted
  q=2 covariance (#787).** CI intermittently hit `PosDefException` inside
  `cov_to_lc` when packing a fitted `Λ` for the front-end theta vector: a
  fitted variance-component covariance can land marginally non-PD in floating
  point at a variance boundary, and LAPACK's cholesky detects that
  indefiniteness on some architectures/BLAS builds and not others (the CI
  x86 runner vs local aarch64), so the same seed could pass or fail depending
  on the machine. `cov_to_lc` now regularises a boundary-scale miss (floors
  the smallest eigenvalue back onto the PD cone) instead of throwing, and
  still raises a diagnosable `ArgumentError` naming the offending eigenvalue
  for a genuinely, substantively indefinite matrix.
- **Adaptive quadrature for `CumulativeLogit()` `(1 | g)` / `(0 + x | g)`.**
  Both ordinal random-effect routes now integrate `b_g` by per-group adaptive
  Gauss–Hermite quadrature (the shared helper from #834/#719, `q = 1`) instead
  of a fixed 32-node PRIOR-scale grid. With a large random-effect SD that grid
  was badly under-resolved: on the seed-24 likelihood-fuzzer dataset
  (`y ~ x + (1 | id)`, n = 48, G = 6) the old fit stopped at nll 21.30 with a
  gradient of 5.6 (main), or, once the NaN fix below removed that stall,
  reached a spurious 18.95 whose true marginal is 20.31. The fit now reaches
  the exact maximum, nll 19.83614 (β = 7.997, cutpoints −4.152 / 12.306,
  σ_b = 7.646), matching an exact per-group QuadGK integral and
  `ordinal::clmm` with nAGQ ≥ 30. The ordinal group posterior is far from
  Gaussian at large σ_b, so these routes use `K = 41` nodes (worst error
  2.9e-9 nat against the exact integral on that dataset, versus 1.4e-2 at the
  `K = 5` used by the other families). The two drmTMB-parity fixtures
  (σ_b ≈ 0.69 and 0.34) move by −3.6e-8 and +1e-10 nat in logLik. Public API
  unchanged; the `phylo(1 | species)` and fixed-effects-only routes are
  untouched.
- **Adaptive quadrature for `Tweedie()`'s two `mu` random-effect routes,
  `(1 | g)` and `(0 + x | g)`.** `_fit_tweedie_ranef` and
  `_fit_tweedie_slope_ranef` were the last two `_fit_*_ranef` routes still on
  the pre-#719 fixed 32-node PRIOR-scale grid (`b = √2 σ_b z`); both now use
  the shared per-group adaptive Gauss–Hermite helper (`src/adaptive_ghq.jl`,
  #719/#834), `q = 1`, with the same `K = _RANEF1D_AGHQ_K = 5` default as the
  other 1-D `(1 | g)` families. On a single informative group (`σ_b = 6`,
  20 obs/group, `η0 = 0.5`, `φ = 1.3`, `p = 1.5`) the old grid missed the
  QuadGK-exact per-group marginal by 12.87 nat (intercept route) / 23.40 nat
  (slope route); the new default AGHQ is within 3e-8 / 6e-8 nat of the same
  reference. Public API and defaults are unchanged; both routes gain an
  internal `K` keyword (default `_RANEF1D_AGHQ_K`), matching the `(1 | g)`
  pattern on the other families. `test/test_tweedie_aghq.jl`.
- **`marginal = :AGHQ` for the Gaussian random intercept on `sigma`
  (`sigma ~ 1 + (1 | g)`).** New opt-in integrator, alongside the existing
  default (`:LA`, unchanged, D-273) and `:Laplace`: per-group adaptive
  Gauss-Hermite quadrature at `K = 5` nodes (the shared `q = 1` helper from
  #834/#719), reusing the same `_aghq_marginal_loglik` every other `(1 | g)`
  family was moved onto. The default `:LA` route integrates on a fixed
  32-node PRIOR-scale grid, independent of where the group posterior actually
  sits; for a large group SD (`sigma_b` = 3-6) that grid misses the exact
  per-group marginal (verified against an independent QuadGK integral) by
  tens of nats, while `:AGHQ` at `K = 5` is within 0.01 nat and the
  underlying method is exact to 1e-6 nat at higher `K`. On the small-`sigma_b`
  fixture already covered by `test/test_sigma_re.jl` (where the default grid
  is already accurate), `:AGHQ` moves every working-scale coefficient by
  less than 0.02 and the total logLik by less than 0.05 nat. `marginal = :LA`
  stays the default; nothing changes unless `marginal = :AGHQ` is requested.
- **`fit_mixed_family(...; aghq = true)`: adaptive quadrature for the
  cross-family shared-latent route (#719).** The bivariate joint-random-effect
  fitter (`src/mixed_family.jl`, two families sharing one per-observation
  latent `u_i ~ N(0,1)`) integrated `u_i` by a fixed K=32 prior-scale
  Gauss-Hermite grid, the one remaining `(1 | g)`-shaped route #846 left on
  the non-adaptive integrator. New opt-in `aghq = true` (default `false`,
  signature-stable) reuses the #834/#719 `_aghq_marginal_loglik` helper,
  treating each observation as its own AGHQ "group" of two virtual members
  (one per family) sharing the fixed prior; the loadings `λ1`/`λ2` (not a
  group SD) carry the scale. At large loadings (`λ ~ 3-6`, the role a group SD
  plays elsewhere) the prior-scale grid misses the exact per-observation
  marginal (verified against an independent QuadGK integral) by up to ~28 nat;
  `aghq = true` at `K = 5` (matching `_RANEF1D_AGHQ_K`) is within 5e-5 nat at
  the same inputs, and the underlying method is exact to 1e-6 nat at higher
  `K`. On a full recovery fit (`λ1_true = 2.5`, `λ2_true = 2.0`, `n = 600`)
  `aghq = true` recovers both loadings within 0.4 and lands ~392 nat higher in
  logLik than the unchanged default. `aghq = false` (the default) is
  byte-for-byte unchanged.
- **Adaptive quadrature for 1-D random intercepts `(1 | g)` (#719).** Every
  default-route (`:LA`) `_fit_*_ranef` fitter for Poisson, NegBinomial2, Gamma,
  Beta, BetaBinomial, Student, and LogNormal now integrates the group random
  intercept `b_g` by per-group adaptive Gauss–Hermite quadrature (the shared
  `q`-dimensional helper from #834, here with `q = 1`, centred and scaled on
  each group's own posterior mode), instead of a fixed 32-node grid on the
  PRIOR scale (`b = √2 σ_b z`). On an informative group the prior-scale grid
  misses where the posterior mode actually sits: on `HSAUR3::epilepsy`
  (Poisson `(1 | subject)`, `sd(subject) ≈ 0.52`) the pre-#719 fit landed
  5.2 nat below the true maximum, with a fixed effect 18% off and the random-
  effect SD 25% off, while native drmTMB's Laplace approximation is exact to
  ~1e-6 nat. `K = 5` nodes (matching `_CORR_RANEF_AGHQ_K` for the `(1 + x | g)`
  routes) keeps every family within 0.01 nat of an AGHQ-40+ reference on an
  informative-group DGP (worst case Poisson, −0.0034 nat); `K = 1` is exactly
  drmTMB's Laplace approximation (verified on the epilepsy fit to 1e-6 nat).
  LogNormal's `(1 | g)` marginal is linear-Gaussian in `b_g`, so `K = 1` is
  exact there for any `K` and is used directly. Public API and defaults are
  unchanged; TruncatedNegBinomial2 and ZeroOneBeta have no `(1 | g)` route yet
  and Binomial is out of scope for this change (tracked separately).
- **`CumulativeLogit()` `(1 | g)` / `(0 + x | g)` no longer returns a NaN nll
  at extreme θ (likelihood-sanity fuzzer finding, draft PR #866).** Two
  compounding causes in `src/cumulative.jl`: (1) the interior-category
  probability `logistic(cuts[k]-η) - logistic(cuts[k-1]-η)` was computed as a
  raw difference of two independently-rounded probabilities, so near/at a
  collapsed cutpoint gap or a saturating η it could go to exact 0 (fine,
  `-Inf`) but sometimes rounded to a tiny NEGATIVE float instead, whose
  `log()` is NaN; (2) the 32-node Gauss-Hermite quadrature accumulator's
  `mx = maximum(terms); terms .- mx` produced `-Inf - (-Inf) == NaN` whenever
  EVERY node's log-likelihood for a group was exactly `-Inf` (a deterministic,
  node-independent "impossible category" that no finite random-effect draw
  can undo, e.g. from an extreme fixed effect or cutpoint). The interior
  probability is now computed directly in log-space from the two already-
  stable `_log_logistic` values via a `log1mexp`-style identity (never
  subtracts raw probabilities), and the quadrature accumulator short-circuits
  to `-Inf` when its running max is `-Inf` instead of computing `Inf - Inf`.
  The fixed-effects-only and `phylo(1 | g)` routes were already clean and are
  unchanged. Evaluating the nll at an ordinary θ is unchanged to 1e-10; a
  fresh fit on affected data now correctly continues past what had been a
  spurious NaN "cliff" blocking LBFGS, converging further to a lower (more
  correct) nll instead of stopping short. See `test/test_cumlogit_nan.jl`.
- **`Binomial()` correlated random slope `(1 + x | g)` (#753), on the #834
  adaptive-quadrature engine.** Binomial now fits a logistic GLMM with a
  correlated random intercept + slope on the mean, via the shared per-group
  ADAPTIVE Gauss–Hermite quadrature helper (`_aghq_marginal_loglik`, #834) —
  the same scheme `BetaBinomial()` already uses, minus the precision
  parameter Binomial doesn't have. Brings Binomial in line with the other
  seven families and with drmTMB's `binomial()`. Its logLik matches an
  independent AGHQ-40 reference within 0.05 nat and, at `nq = 1`, matches
  drmTMB's own Laplace integrator to ~1e-9 on the same simulated data
  (`test/test_binomial_slope_re.jl`). A non-adaptive 12×12 prior-scale grid
  was used briefly in review (draft #831) but was never released — it was
  ~15 nat off on this file's own DGP; see #834. Guarded: a slope predictor
  that is constant within any group leaves the slope SD and the group-level
  correlation unidentified and is refused with an informative error (mirrors
  drmTMB's `drm_validate_q2_slope_variation`, reimplemented rather than
  vendored). Still refused: an independent random slope `(0 + x | g)` and
  `marginal = :VA` on the correlated slope. Unlike drmTMB, DRModels.jl does
  not run a `detectseparation`-style separation screen before fitting.

- **`Binomial()` random intercept `(1 | g)`: adaptive quadrature for grouped
  trials (#712, #713).** The 1-D route also now goes through the #834
  adaptive-quadrature helper (`nq = 3` by default), replacing a fixed 32-node
  PRIOR-SCALE grid. For grouped trials (`cbind(successes, failures)` with
  more than one trial per row) and an informative group SD, the old grid's
  posterior coverage was too coarse: measured error up to −9.73 nat on a
  DGP with `G = 100` groups, 30 obs/group, 20 trials/row, RE SD 0.5–0.8 (a
  4.6–20 nat error across that SD range when evaluated at an AGHQ-accurate
  θ̂). Bernoulli 0/1 responses were unaffected. `nq = 1` is exactly Laplace
  (drmTMB's own integrator); `nq = 3` is the smallest node count within 0.01
  nat of an independent AGHQ-40 reference on the same DGP (`nq = 2` misses at
  ≈0.03 nat) — see `test/test_binomial_aghq.jl`.
- **`ZeroOneBeta()` phylo/relmat structured random intercept on the mean (#739,
  drmTMB twin gap #1281).** `ZeroOneBeta()` now admits a structured random
  intercept on the mean — `phylo(1 | species)` (needs `tree = ...`), and
  `relmat(1 | id)` / `animal(1 | id)` / `spatial(1 | id)` (need `K = ...` /
  `A = ...` / `coords = ...`) — via the same verified `:beta_fixed`-derived
  sparse-Laplace spine `Beta()` uses, restricted to a constant `sigma ~ 1` and
  intercept-only `zoi ~ 1` / `coi ~ 1`. The atom/coi mixture (`P(y=0)`,
  `P(y=1)`) is completely separable from the mean/dispersion/phylo likelihood,
  so `zoi`/`coi` are estimated by their closed-form Bernoulli MLEs and travel
  as fixed `aux` fields into a new additive `Val(:zeroonebeta_fixed)` Laplace
  kernel (atom rows contribute zero η-derivatives; interior rows are exactly
  `:beta_fixed`). Verified against drmTMB's `zero_one_beta()` phylo route on
  matched data (identical tree, ML): logLik agrees to 5e-5, all four
  parameter blocks (`mu`, `sigma`, `zoi`, `coi`) agree to ≤ 1e-7.

- **`ZeroOneBeta()` random intercept `(1 | g)` on the mean (#723, drmTMB twin gap).**
  `ZeroOneBeta()` no longer hard-blocks every random effect: an ordinary
  random intercept on the mean, `y ~ x + (1 | g)`, is now admitted exactly as
  `Beta()` admits it — `b_g ~ N(0, σ_b²)` integrated out per group by 32-node
  Gauss–Hermite quadrature (default `:LA`-style marginal). `sigma`, `zoi`, and
  `coi` must stay fixed-effects-only (their formulas still refuse any random
  effect). Mirrors drmTMB's admitted `zero_one_beta()` + ordinary RI (e.g.
  `faraway::leafblotch`). Structured (`tree=`/`K=`) random intercepts on
  `ZeroOneBeta()`'s mean are now implemented too — see #739 above.
  `ZeroOneBeta()`'s mean remain unimplemented (#739).
- **Fix: `animal(1|id)` / `relmat(1|id)` Gaussian could diverge with one record
  per structured level (#764).** `_fit_structured_gaussian`'s homoscedastic
  (`sigma ~ 1`) Woodbury quadratic `q1 - dot(C, Mfac \ C)` is a difference of
  two O(1/σ_e²) terms that cancel to an O(1) residual as σ_e → 0; with one
  observation per animal-model level that residual IS the whole quadratic
  form, so it was lost to rounding — measured, `logLik = +4.4e253` with
  `converged = true` on a fit whose true value (confirmed by an independent
  dense reassembly and by the same likelihood's 1-D profile) is a bounded,
  interior optimum. This is the #548/#835/#837/#838 cancellation class, not
  genuine unboundedness. Fixed by computing the quadratic form via a
  within/between-group sum-of-squares decomposition (Welford-style deviations
  from the group mean) instead of subtracting two near-equal large terms; the
  fit is now bounded down to σ_e as small as machine precision allows. See
  `test/test_twin_gap_764.jl`.
- **`show(io, fit)` (2-arg) now names the fitted family (#758).** The compact
  form — used by `println(fit)`, string interpolation and `repr` — printed
  "Gaussian location–scale" for every family (Poisson, BetaBinomial, …) while
  the `MIME"text/plain"` method already printed the correct one. Both now
  agree.
- **`offset(...)` on the Poisson mean (#727, drmTMB twin gap).** The formula
  grammar had no `offset()` term at all. `drm(bf(y ~ x + offset(log_exposure)),
  Poisson(); data)` now fits `log λ = Xβ + offset`, with the offset's own
  coefficient fixed at 1 (never estimated) — matching drmTMB's
  `offset()` contract, gated to the Poisson mean (log link). The offset term
  accepts a plain column (`offset(log_exposure)`) or an inline numeric
  transform (`offset(log(exposure))`) via the same schema/modelcols machinery
  ordinary terms use, with no implicit intercept inserted. Currently supported
  only on the fixed-effects-only Poisson mean (no random effect, structured
  marker, `zi`, or `hu` yet); those combinations raise a clear error rather
  than silently dropping the offset. Verified against drmTMB's `poisson()` +
  `offset()` on matched simulated data: logLik and both fixed-effect
  coefficients agree to ≤ 1e-6.
- **`loglikelihood(fit)` (StatsAPI/StatsBase generic) added for `DrmFit`
  (#668).** `DRM.loglik(fit)` already worked, but the StatsAPI-facing
  `loglikelihood` was undefined, so anything dispatching on the generic
  `StatsAPI.StatisticalModel` interface errored on a `DrmFit`. It is now
  exported and delegates to `loglik(fit)` (same value, same REML caveat).
- **CumulativeLogit crossed random effects (#738, drmTMB twin parity).**
  `CumulativeLogit()` now fits crossed/multiple random intercepts on the
  latent linear predictor, `(1 | g) + (1 | h)`, matching drmTMB's
  `cumulative_logit()`. Integrator: the PLAIN (no-nuisance) sparse
  augmented-state Laplace GLMM engine already shared by Poisson/Binomial's
  crossed routes (`_fit_crossed_mean_laplace`) — no new integrator for the
  random effects. The `K - 1` ordered cutpoints (a second block of structure
  that shared engine's `[βμ; logσ_g; logσ_h]` layout has no room for) are
  found by an outer Nelder–Mead profile search, refitting the full crossed
  model at each candidate cutpoint vector — exact profile-likelihood
  optimisation, not an approximation. Correlated slopes `(1 + x | g)` and
  `relmat`/`animal`/`spatial` structured markers combined with crossed
  intercepts remain refused.
- **LogNormal crossed random effects (#736, drmTMB twin parity).**
  `LogNormal()` now fits crossed/multiple random intercepts on the log-mean,
  `(1 | g) + (1 | h)`, matching drmTMB's `lognormal()`. `log(y)` is exactly
  Gaussian, so the fit delegates WHOLESALE to
  `drm(f, Gaussian(); data = data-with-logged-response)`
  (`_fit_multi_ranef_gaussian`, the closed-form exact crossed marginal
  likelihood — no Laplace approximation, so no new integrator), the same
  identity already used for `phylo`/`relmat` structured markers on the mean,
  with the reported log-likelihood shifted by the parameter-free Jacobian
  `-sum(log y)`.
- **`ranef(fit)` no longer silently returns an empty `Dict` for a non-Gaussian
  GLMM (#759).** A `Binomial`/`Poisson`/etc. fit with a random-effect block,
  fitted by the Gauss–Hermite/Laplace marginal route (which integrates the
  random effect out without ever computing a posterior mode), now throws an
  informative `ArgumentError` from `ranef` instead of returning an empty
  `Dict` that silently looked like "no random effects". A fit with genuinely
  no random-effect block still returns an empty `Dict`. The docstring's
  pointer to the closed #73 is removed.
- **`residuals(fit; type = :quantile)` on a mixed fit now uses the marginal
  reference distribution, not `fitted(fit)` at the random intercept fixed at
  0 (#760).** A single ordinary random intercept `(1 | g)` on the mean used to
  be judged against the fixed-effect-only mean, inflating the residuals' SD
  even on a correctly specified GLMM (reported on a Binomial `(1|BroodNo)`
  chick-survival fit: engine SD 1.0538 vs a hand-computed marginal SD 1.0144).
  `ranef()` conditional modes are not yet available for a non-Gaussian GLMM,
  so the fix integrates the random intercept out with its fitted σ_b by the
  same 32-node Gauss–Hermite quadrature the `_fit_*_ranef` routes use to fit
  it (`_ranef_marginal_mix`, `src/quantile_residuals.jl`) — covers Poisson,
  NegBinomial2, TruncatedNegBinomial2, Gamma, Binomial, Beta, BetaBinomial,
  Gaussian, Student, LogNormal, and `ZeroOneBeta()`'s new `(1 | g)` route
  (#723). Crossed `(1|g)+(1|h)`, correlated `(1+x|g)`, and structured
  (`phylo`/`relmat`) random intercepts whose per-tip variance is not σ_b²
  keep the previous (fixed-effect-only) reference rather than risk a wrong
  marginalisation. A future conditional-mode variant is tracked once #759
  wires non-Gaussian `ranef()`.
- **Bivariate `Student()` (`biv_student()` twin): `confint(fit; method =
  :bootstrap)`-equivalent entry points (`bootstrap_result`, `bootstrap_ci`) no
  longer abort on the first replicate (#766).** `simulate(fit)`'s generic
  fallback assumed univariate keys (`fit.means[:mu]`, `fit.scales[:sigma]`);
  a bivariate Student-t fit stores `:mu1`/`:mu2` and `:sigma1`/`:sigma2`
  instead (the same shape as bivariate `Gaussian()`), so every bootstrap
  replicate threw `KeyError: key :mu not found` before any refit was
  attempted — a ~0 s abort regardless of `parm`. A new `_simulate_once`
  method dispatches on the bivariate shape and draws `Y = mu + diag(sigma) *
  Z * sqrt(nu / chisq_nu)`, `Z ~ N(0, R)`, mirroring bivariate Gaussian's own
  branch. `confint(fit; method = :profile)` was unaffected by this bug (it
  does not call `simulate`) and was already fixed by the large-ν bivariate-t
  density correction below.

- **Bivariate `Student()` (`biv_student()` twin) no longer diverges at large ν
  (follow-up to #721).** The joint (p = 2) and marginal (p = 1) log-density
  terms computed `loggamma((ν+2)/2) - loggamma(ν/2)` and
  `loggamma((ν+1)/2) - loggamma(ν/2)` by hand — the same catastrophic
  loggamma-difference cancellation #721 found in the univariate `Student()`.
  The joint term is now the exact Gamma-recursion identity
  `loggamma((ν+2)/2) - loggamma(ν/2) = log(ν/2)` (valid for every ν > 0, not
  an approximation), which collapses the whole normalising constant to
  `log(2π)`; the marginal term now reuses `_student_logpdf_std` from
  `student.jl`. Both are exact/stable to < 1e-9 against a 256-bit reference
  across ν ∈ [2.5, 1e16]. Recovery of genuinely heavy-tailed data (ν ≈ 5) is
  unaffected.
- **`Student()` fits crossed random intercepts on the mean (#725; drmTMB twin
  #1266).** `y ~ x + (1 | g) + (1 | h)` was refused ("single random-effect
  term"); drmTMB `student()` fits it. It now uses the Laplace approximation, as
  drmTMB/TMB does, with the observed Hessian of the random effects, exact
  ForwardDiff outer derivatives, and `sigma`/`nu` formulas allowed. On a
  simulated fixture (n = 600, 30 × 25 levels) it matches drmTMB 0.7.1 to
  |ΔlogLik| < 1e-9 and every estimate to < 1e-8, with and without `sigma ~ x`;
  fixed-effect SEs agree to 1e-6. Random slopes with a second term are still
  refused. The random-effect Hessian is dense, so very many levels are slow.

- **`Student()` crossed intercepts: three robustness fixes from adversarial
  review (#827).** (1) An extreme σ/ν line-search probe could produce a
  non-finite expected-information fallback matrix; the fallback Cholesky now
  fails closed (`check = false`) instead of throwing `PosDefException` out of
  `drm`. (2) The `|log σ| > 12` guard on a crossed variance rejected genuine
  boundary MLEs (drmTMB puts a zero crossed variance at log σ ≈ −12.57); the
  guard is now a `|log σ| > 30` overflow check, and the inner Newton's
  convergence floor is loosened 100× so it stops registering a converged
  boundary fit as a failure. (3) A non-converged outer LBFGS run is now
  restarted from its own minimizer (bounded to 8 attempts, comparing freshly
  re-evaluated objective values rather than `Optim.minimum`, which can read a
  rejected line-search trial instead of the true minimizer) — on a fresh
  simulated dataset this now reaches drmTMB's optimum to 1e-10 where the
  first run previously stopped short. New regression tests
  (`test/test_student_725.jl`) reproduce all three failures on the reviewer's
  simulated fixtures and pin drmTMB reference log-likelihoods.
- **`residuals(fit; type = :quantile)` on a `TruncatedNegBinomial2` fit no
  longer returns NaN at extreme dispersion or extreme small μ.** The
  zero-truncated randomized-quantile-residual driver (`_quantile_residuals`,
  `src/quantile_residuals.jl`) built the truncated CDF as `F_t(k) =
  (Distributions.cdf(NB, k) − F0) / (1 − F0)`. At `log σ ≲ -20` the NB2 size
  `r = 1/σ²` grows so large that `r + μ` rounds to exactly `r` in Float64 —
  `p = r/(r+μ)` rounds to exactly `1.0`, so `Distributions.cdf` returns exactly
  `1.0` for every `k`, and both the numerator and the denominator evaluate to
  `0.0`: `0/0 = NaN`. The same underflow occurs at extreme small μ (μ/r
  rounds to exactly `0.0`) at ordinary dispersion. This is the same
  cancellation #866/#874 fixed in the truncated/hurdle NB2 *likelihood*; this
  fix carries the `_nb2_logpmf` / `_log1mexp` log-space technique into the
  quantile-residual driver: `log(1 − F0)` via `_log1mexp(_nb2_logpmf(r, μ,
  0))`, and `log P(1 ≤ Y ≤ k)` via a running `_logaddexp` sum of
  `_nb2_logpmf(r, μ, j)` terms, neither of which ever forms the degenerate `p`.
  A swept-and-confirmed-clean regression guard covers the other discrete
  quantile-residual drivers (plain `NegBinomial2`, `NegBinomial2`/`Poisson`
  hurdle-tagged fits, `BetaBinomial`) at the same extreme parameters — none of
  them divide by a near-zero quantity, so they saturate to a large-but-finite
  residual rather than NaN. Ordinary parameter values are bit-for-bit
  unaffected (matches the old `Distributions.cdf`-ratio path to 1e-10).

- **Hurdle NB2 (`NegBinomial2() + hu ~ ...`, and `TruncatedNegBinomial2() + hu
  ~ ...`, which delegates to it) no longer returns NaN at extreme dispersion
  (#866).** At `log σ ≈ -20..-50` the NB2 size `r = exp(-2·ησ) ~ 1e17-1e43` is
  so much larger than `μ` that `r + μ` rounds to exactly `r` in Float64 and
  `p = r/(r+μ)` rounds to exactly `1.0`. Distributions' `NegativeBinomial(r,
  p).logpdf` then returns a finite value at `k = 0` but `-Inf` at any `k > 0`
  (it needs a `log(1 - p) = log(0)` term there), so the hurdle's zero-truncation
  divisor, `log(1 - P(0))`, computed as `-Inf - (-Inf)`, was `NaN`. Found by
  the likelihood sanity fuzzer (#866). Fixed by a log1p-space NB2 log-pmf
  (`_nb2_logpmf`, `src/negbinomial.jl`) that never forms `r + μ` — the same
  cancellation class #846 fixed on the `(1 | g)` AGHQ path. Ordinary parameter
  values are bit-for-bit unaffected (matches the old `Distributions.logpdf`
  path to 1e-10).

- **Plain zero-truncated NB2 (`TruncatedNegBinomial2()`, no `hu` part) no
  longer returns NaN at extreme dispersion.** `_fit_truncated_negbin2`
  (`src/negbinomial.jl`) had the identical `logpdf(d, y) - log(1 - P(0))`
  cancellation as the hurdle NB2 fix above (#866): at `log σ ≈ -20..-50`
  the zero-truncation divisor was `-Inf - (-Inf) = NaN`. A repo-wide sweep of
  every other NB2/truncated-NB2 log-likelihood site (zero-inflated, `(1|g)`
  and `(1+x|g)` random-effect, phylo, relmat/animal/spatial, crossed, and
  variational NB2 paths) found no other affected site — each of those either
  has no zero-truncation divisor or hard-clamps the dispersion linear
  predictor well inside the safe range. Fixed the same way, with `_nb2_logpmf`.
  (A related NaN in `_conditional_dist`'s cdf-based zero-truncation divisor
  for quantile residuals, `src/quantile_residuals.jl`, was also found but is
  out of scope here — it is a diagnostic/residual path, not a fitting
  log-likelihood.)
- **The `relmat`/`animal` PD guard now covers every dense Gaussian entry
  point, not just `_dense_comp`.** Two more user-matrix sites lacked it:
  `_fit_structured_gaussian` (the single, non-crossed relmat/animal route)
  called `cholesky(Symmetric(K))` with the default `check = true` — a bare
  `PosDefException` on a non-PD `K`, and `Symmetric(K)` silently reading only
  one triangle of a non-symmetric `K` with no error at all; and
  `_fit_two_structured_gaussian` checked only the assembled marginal `V`
  inside the optimiser (with a large finite penalty on failure, so it never
  threw), never `C1`/`C2` themselves at setup. All three sites now share one
  `_checked_relmat_chol(C, grp)` helper: symmetry at a sqrt(eps) relative
  tolerance, then a `check = false` Cholesky, raising `ArgumentError` naming
  the grouping factor on either failure. PD input is unaffected (fits agree
  with the pre-guard path to 1e-10). This does **not** add a condition-number
  threshold — a floating-point "semidefinite" matrix with a tiny positive
  pivot still factors successfully, as it does in R; whether to refuse
  ill-conditioned input is an open owner decision.

- **`relmat(1 | g)` / `animal(1 | g)` (dense Gaussian path) now refuses a
  non-PD relatedness/correlation matrix with a clear error, instead of
  silently propagating garbage.** `_dense_comp` used to call
  `inv(Symmetric(Matrix(C)))` / `logdet(Symmetric(Matrix(C)))` directly, with
  no positive-definiteness check. On a semidefinite `C` (e.g. a GRM with
  duplicate individuals, or a singular pedigree A-matrix) this silently
  returned a finite but WRONG `logdet` about half the time in a random sweep —
  no error at all — and a confusing low-level `DomainError` from `log` of a
  negative number the other half, never naming the offending matrix. It now
  factors via `cholesky(Symmetric(C); check = false)` and throws an
  `ArgumentError` naming the grouping factor when the factorization fails.
  On well-conditioned and ill-conditioned (cond up to 1e12) PD input the
  Cholesky-based precision/logdet match the old inv/logdet path and a 256-bit
  BigFloat reference to the tolerances measured (accuracy was already
  comparable between the two paths on PD input — the fix is about the
  non-PD case, not accuracy on well-posed input).
- **Location–scale group covariance Λ⁻¹ no longer loses ~14 digits near a
  singular log-Cholesky factor.** `_ls_inv2x2` (`locscale_inner.jl`) inverted
  Λ = L Lᵀ via the naive `a*d - b*c` determinant on the already-formed matrix;
  forming Λ from its log-Cholesky factor computes `d = L21² + L22²` as a
  Float64 sum, which silently discards L22 whenever `|L21| ≫ L22`, so neither
  that determinant nor a fresh `cholesky` re-factorisation of the formed Λ can
  recover it (relative error vs a 256-bit reference: exact at l22-diagonal
  −12, then ~1e-1 to total failure by −18/−25). The coupled (L21 ≠ 0) call
  sites in `locscale_grad.jl`, `locscale_fit.jl`, `locscale_profile.jl` and
  `gaussian_locscale_phylo.jl` now invert directly from the log-Cholesky
  vector (`_ls_lc_inv2x2`/`_ls_lc_logdetΛ`), never forming Λ as an
  intermediate matrix; accurate to ≤1e-10 relative at l22-diagonal −12, −18,
  −25 against a BigFloat reference, and agrees with the old matrix-formed
  path to ≤1e-12 in the well-conditioned regime. The diagonal-only callers
  (`locscale_sigma.jl`, `locscale_corr.jl`, the separate/asymmetric σ-phylo
  blocks) are unaffected — their off-diagonal is exactly zero, so the naive
  determinant never cancels.
- **`cond_newton_beta` (q=4 REML) and `mstep_beta` no longer evaluate the
  objective at a wild trial point on an ill-conditioned fixed-effect design.**
  Both take a Newton step on the profiled fixed effects from an exact
  ForwardDiff Hessian (ridge ladder for indefiniteness, up to 25 halvings
  accepted only on decrease), but the raw step had no cap on its size. On a
  near-collinear mean design (x2 = x1 + 1e-8·noise, cond(H) up to 5.6e16) the
  raw step reached ‖step‖∞ ≈ 3.25e5, a step of about 1.4e5 was accepted, and β
  for the collinear pair diverged to ±602. The whole raw step is now scaled so
  ‖step‖∞ ≤ 5.0 (matching `_estep_robust`'s existing trust radius) BEFORE
  backtracking, in both functions. A no-op on well-conditioned designs (the
  fitted β and REML logLik are unchanged to 1e-8 on the existing q4 REML
  fixtures); the collinear pair itself stays unidentified regardless of the
  cap — the cap only prevents evaluating wild points, matching the pattern
  drmTMB adopted for the same failure mode (draft PR #1441).

- **`lrtest`/`anova` refuse REML-vs-ML pairs; `_fixed_effect_structure` (was
  `_mean_structure`) covers bivariate fits (#639).** `_reml_compare_guard`
  previously refused a REML-vs-REML pair only when their `:mu` blocks
  differed, and never checked whether the OTHER fit was ML at all — so
  `lrtest(ml_fit, reml_fit)` silently compared two different likelihoods
  whenever the (univariate-only) mean-structure check happened to match.
  It now (1) refuses any pair with different `estim_method`s outright (REML
  is never comparable to ML or MAP), and (2) for a REML-vs-REML pair, checks
  fixed-effect structure in **every** mean/scale block, not just `:mu` — so a
  bivariate fit's `:mu1`/`:mu2`/`:sigma1`/`:sigma2`/`:rho12` blocks are seen
  correctly (the old `_mean_structure` matched only `:mu` and silently
  returned `String[]` for every bivariate fit, passing any bivariate REML
  pair regardless of structure). The variance-component boundary label
  (`_boundary_vc_warn`, #304) already keyed off block symbols shared across
  univariate and bivariate fits (`:phylocov`/`:recov`/…), so it was already
  bivariate-safe; now pinned end-to-end by a bivariate q=4 phylogenetic test.
- **`drm_bridge` exports route-aware convergence diagnostics (#569).** A new
  `bridge_diagnostics(fit)` (`src/introspection.jl`), the Julia twin of
  `check_drm`, reports which route fitted the model, its integrator
  (`fit.marginal`), the optimiser (`"Optim.LBFGS"` where `niterations`
  records an achieved count), `converged`, `iterations`, `max_abs_grad` +
  `grad_source`, `vcov_complete`/`vcov_posdef`/`min_eigval`/`cond`,
  `penalized_map`, and `boundary` (indices whose stored variance is
  non-finite or negative). `drm_bridge`'s payload now carries this under a
  `"diagnostics"` key, plus a top-level `"grad_source"` echo for
  `R/julia-diagnostics.R`'s `drm_julia_gradient_source()` (drmTMB) to read.
  Nothing is fabricated: a quantity a route does not record (e.g. the crossed
  sparse-Laplace engine's iteration count, or `vcov_posdef`/`min_eigval`/`cond`
  when the covariance is only partially finite) is `missing`, never a
  placeholder zero.
- **Coupled σ-phylo ML reaches drmTMB's optimum on its correlation bound
  (#818).** With `phylo(1 | g)` on `mu` and `sigma` and `phylo_coupled = true`,
  `method = :ML` used to stop at a worse optimum than native drmTMB whenever
  native's optimum sits on its bound |cor| ≤ 0.999999, and it still reported
  convergence: logLik 1.016 lower on fixture G1 and 0.685 lower on G2, with the
  mean-axis SD collapsed to about zero. Near the bound the latent precision
  reaches about 1e10, the inner mode's fixed 1e-9 stationarity test fell below
  the gradient's rounding noise, and the marginal likelihood could not be
  evaluated there at all. The inner test now sits at the noise floor, and the
  bound is fitted as its own candidate in whitened coordinates, as the coupled
  REML fit already did. G1, G2 and F1 now match or beat native's ML logLik
  (within 1e-6), the fits take about 20 s instead of 30-90 s, and a fit on the
  bound reports no Wald covariance, as native does. Coupled REML, which starts
  from this fit, keeps its logLik; on F1 its estimates move by at most 1.5e-7,
  towards native's.

- **Gaussian σ-phylo REML now fits drmTMB's restricted likelihood.** For the
  Gaussian location–scale model with `phylo(1 | g)` on `sigma` (the scale-only,
  separate and coupled blocks), `method = :REML` now maximises TMB's
  joint-Laplace restricted log-likelihood. This is one Laplace approximation over
  the phylogenetic effects, `beta_mu` and `beta_sigma`, with flat priors on the
  fixed effects, and it is the quantity drmTMB's `REML = TRUE` maximises. It
  replaces the Patterson–Thompson composite from #337, so **REML estimates and
  `reml_loglik` change on all three blocks**. The reported fixed effects are the
  joint mode at the REML variance estimates. The scale-only and coupled blocks
  reproduce native drmTMB's df, logLik (≤ 1e-6) and estimates (≤ 1e-5 relative)
  on two fixtures, and the coupled block's df and logLik on two more whose
  mean–scale correlation sits on drmTMB's bound. That bound, |cor| ≤ 0.999999,
  now applies to the coupled REML fit too: when the data put both phylogenetic
  effects on one axis, the fit lands on the bound and reports no Wald covariance,
  where it used to stop at a worse local optimum. The receipt is in
  `docs/dev-log/evidence/arc2-gaussian-sigma-phylo-reml/`. The separate block
  has no native twin, because drmTMB always estimates the mean–scale
  correlation. **The coupled block (`phylo_coupled = true`) now accepts REML**;
  it used to throw. Under REML, `profile_ci = true` on the scale-only and
  separate blocks now profiles this restricted likelihood; it used to profile
  the ML likelihood from the REML estimate. When a phylogenetic SD is estimated
  at zero, a REML fit now reports convergence and sits on the likelihood
  plateau. Its Wald covariance is NaN, and on the scale-only and separate blocks
  `profile_ci = true` gives a `[0, upper]` interval. The coupled block computes
  no profile interval, under ML or REML; it ignores `profile_ci = true`.
- **`re_sd(fit)` now returns SDs for a correlated random-effect block
  (`(1 + x | g)`) (#708, #763).** It previously returned an empty `Dict`,
  leaving `vc(fit)` as the only route to the intercept/slope SDs. `re_sd`
  now keys the two SDs `<group>_intercept` and `<group>_slope`, decoded from
  the same Cholesky factor `vc(fit)` uses (`sqrt.(diag(vc(fit)[:g]))`); the
  correlation itself is still only in `vc(fit)`.
- **Every parity fixture and TSV summary table now stamps its drmTMB
  comparator (#473).** "drmTMB 0.7.0" identifies at least 16 different
  builds, so a version string alone cannot say which one measured a given
  number. `tools/drmtmb_provenance.R` already computed a real
  `drmtmb_code_hash` fingerprint, and #512 wired it into four harnesses, but
  18 `test/parity/fixtures/*/expected.meta.toml` files and 5
  `docs/dev-log/evidence/parity-*.tsv` tables still carried no stamp. Those
  18 fixtures and 5 tables now record `drmtmb_code_hash` — three
  `parity-fixtures.tsv` rows recovered a real hash already noted in their own
  `note` text, and the rest, whose generating build cannot be recovered
  honestly, are stamped `"unknown (pre-#473)"` rather than guessed.
  `test/test_fixture_provenance.jl` fails on any future `expected.meta.toml`
  that omits the stamp. `xfam-external-gllvm` is excluded (its comparator is
  gllvm, not drmTMB). No fixture's numeric values changed — only metadata.
- **Coevolution / q=2 structured marginal stays accurate near a singular Λ
  (#857 site K).** `coevo_marginal_cov` formed `Λ = L L'` in Float64 and
  inverted it, so as the among-trait correlation approached ±1 (log-Cholesky
  diagonal l22 → −14 … −18) the marginal lost every digit: on a known-K q2
  fixture the error was 7.6e-7 (relative) at l22 = −14, a spurious +0.03 nats at
  −17, and a −Inf wall from −18. It now works in whitened coordinates
  (`v = (I ⊗ L⁻¹)u`; `Λ⁻¹` is never formed) and accepts `Λ` factored as a
  `Cholesky` (new `DRModels.lc_to_chol`), which `fit_coevolution` and
  `fit_coevolution_q2_residual` now pass. Error vs a 256-bit reference is
  ≤ 1e-12 from l22 = −2 to −30. Identical in exact arithmetic, including the
  historical 1e-10 prior ridge: normal-regime objective values match the old
  form to 4.3e-13; fitted estimates move only within the optimiser's own
  tolerance floor. The third return value is now the factor of the whitened
  Hessian. The q=4 PLSM engine builds its prior the same way and is also
  affected (measured, pinned as `@test_broken`); it is not changed here.

- **Follow-up to the above: two more `coevo_marginal_cov` callers now build Λ's
  factor straight from θ (#857 site K, draft #862).** The bivariate Gaussian
  ML route (`gaussian_bivariate.jl`, `_fit_bivariate_q2_structured`'s `nll`)
  and the q=2 structured REML route (`reml_q2.jl`, `_q2_reml_ll` and
  `fit_coevolution_q2_reml`'s final `ml_ll`) still passed a Λ ALREADY FORMED
  as a matrix (`lc_to_cov`), so `coevo_marginal_cov`'s `cholesky(Symmetric(Λ))`
  re-factored an already-lossy matrix — accurate to l22 ≈ −18, then `-Inf`
  from l22 = −20. Both now pass `lc_to_chol(lc, 2)` directly, matching a
  256-bit reference to machine precision through l22 = −30 where the old path
  returned `-Inf`; normal-regime objective values are identical to the old
  path to ≤ 1e-12.

- **Last `inv(Λ)` site in the q=2 REML route removed (#857 site K, #862/#865
  follow-up).** `_q2_profile_and_schur` (`reml_q2.jl`) was the one caller left
  forming `Λ` densely and calling `inv(Λ)` to build the bordered (u, β)
  Hessian used for the profile/Schur step. Measured against a 256-bit dense
  GLS reference (S = X'V⁻¹X, β̂ the GLS estimator) at log-Cholesky diagonal
  l22 = −18/−20/−30: before, l22 = −18 returned a finite but silently wrong
  S/β̂, and l22 = −20/−30 rejected the step outright (`ok = false`); after, all
  three match the reference to relative error ≤ 6e-16 (β̂: ≤ 2e-15). It now
  takes `chΛ::Cholesky` (via `lc_to_chol`) and whitens `u` (`v = (I ⊗ L)⁻¹u`,
  same construction as `coevo_marginal_cov`); the Schur complement of the
  profiled β block is basis-invariant under this substitution, so normal-
  regime `S`/`β̂` are unchanged (checked against the pre-fix formula over 10
  random draws: agree to ≤ 2e-16 relative). A convenience method still accepts
  a formed `Λ::AbstractMatrix` for existing callers/tests, factoring it once.
- **`drm_bridge` sweep: six more formula constructs that reached a confusing
  low-level error instead of a clear refusal now refuse sharply and by name
  (#467 follow-up).** Following the `%in%`/nested-`/` fix below, a sweep of
  twenty formula constructs against base R's own `stats::model.matrix()`
  found no additional SILENTLY-WRONG case, but six LATE-ERROR cases where the
  bridge reached a `ParseError`, an `UndefVarError`, or a scalar-label
  renderer crash deep inside translation, none of which named the actual
  unsupported construct: `y ~ .` ("every other column"), package-qualified
  calls like `y ~ splines::ns(x, 3)` (Julia parses `pkg::fn(...)` as a type
  assertion, not a call — a `pkg::fn(...)` from any package is unsupported),
  `y ~ cut(x, 3)`, `y ~ interaction(f, g)`, `y ~ offset(o) + x`, and
  `y ~ C(g, contr.sum)`. All six now raise an `ArgumentError` naming the
  construct. Eight other constructs from the same sweep (`x - 1`, `0 + x`,
  `x + z - z`, `log(x)`, `x^2` on a bare symbol, `(x + z)^2 - x:z`, bare
  `x:f`, `f - 1`) were already FAITHFUL and are now locked in by a regression
  fixture comparing both column names and fitted values against
  `model.matrix()` (`test/test_bridge_silent_sweep.jl`); three more
  (`x * z - x:z`, `poly(x, 2, raw = TRUE)`, `as.numeric(f)`) already refused
  sharply and needed no change.

- **`drm_bridge` translates R's `%in%` and nested `/` formula operators, or
  refuses them sharply (#467).** Neither was handled before: `%in%` is not
  valid Julia infix syntax the way R means it, so `Meta.parse` silently read
  `b %in% a` as nested modulo, `(b % in) % a`, surfacing only later as a
  confusing "no variable called 'in'" error from deep inside `@formula`; `/`
  parsed as plain Julia division, so `y ~ x / z` on two numeric columns did
  not error at all — it silently fit a single materialised `x / z`
  arithmetic-division covariate instead of R's nesting expansion `x + x:z`
  (SILENTLY WRONG, not merely a late error). Both are now rewritten to the
  bridge's existing `&` (R's `:`) interaction primitive — `b %in% a` → `b&a`;
  `a/b` → `a + a&b` — confirmed against base R's own
  `stats::terms()`/`model.matrix()` to reproduce identical column names and
  values. A compound or chained nesting left-hand side (`(a+c)/b`, `a/b/c`)
  is refused with an `ArgumentError` naming the construct and its explicit
  expansion, rather than guessed, since R's contrast algebra there is not a
  simple AST rewrite.

- **Fixed: reported/compared logLik could read a rejected line-search trial's
  value, not the value at the reported optimum.** After a failed line search
  (`Status: failure (line search failed)`), Optim.jl v1.13.3 can leave
  `Optim.minimum(res)` holding the objective from an earlier, REJECTED trial
  point while `Optim.minimizer(res)` has already moved past it — confirmed by
  a minimal reproduction (`test/test_optim_minimum_contract.jl`) that gets a
  barrier-sentinel `Optim.minimum(res) == 1e18` alongside a finite
  `f(Optim.minimizer(res))`. Every site in `src/` that REPORTED
  `-Optim.minimum(res)` as a fit's logLik, or COMPARED `Optim.minimum` across
  candidates/restarts, has been changed to re-evaluate the objective fresh at
  `Optim.minimizer(res)` (`src/optim_minimum_guard.jl`,
  `_objective_at_minimizer`/`_objective_at_minimizer_fg`). Converged fits are
  numerically unaffected — the two values coincide there.
- **`re_sd(fit; scale = :drmtmb, tree = ...)` reports a `phylo(1 | g)` SD on
  drmTMB's scale (#732, twin drmTMB#1272).** `re_sd`'s default (unchanged) is
  the raw branch-length scale (tip variance = the tree's height `h`) for every
  route where `fit.phylo_scale === :covariance` (the sparse Gaussian-mean
  phylo route and all non-Gaussian Laplace/GLMM phylo routes); drmTMB reports
  the same random effect on the tip-CORRELATION scale (`ape::vcv(tree, corr =
  TRUE)`, tip variance 1). FE and logLik already agreed between the two
  engines — only the reported SD differed, by the exact factor `sqrt(h)`. The
  new `scale = :drmtmb` option (needs the same `tree` passed to `drm(...)`)
  returns drmTMB's number directly; it is a no-op (and needs no `tree`) on a
  route whose `phylo_scale === :correlation` (e.g. `phylo(1|sp) + (1|h)`),
  since that route's raw `re_sd` already matches drmTMB.
- **New permanent test: likelihood sanity fuzzer across all discrete routes
  (`test/test_ll_sanity_fuzzer.jl`).** For a discrete response every
  probability mass is ≤ 1, so a random-effects model's marginal logLik must be
  ≤ 0 too; the objective must also never return NaN or -Inf-as-nll at any θ.
  Sweeps every discrete-family route (fixed effects, `(1|g)`, `(1+x|g)`,
  crossed, `phylo`/`relmat`, `zi`/`hu`, ordinal) across extreme fixed effects,
  variance-component log-SDs, and nuisance log-parameters. Encodes today's
  known-open violations as `@test_broken` (NegBinomial2/TruncatedNegBinomial2
  `+ hu` and `CumulativeLogit (1|id)` at extreme dispersion/cutpoint/fixed-
  effect values) so CI flips them green the moment each is fixed; the
  NegBinomial2 `(1|g)` cell is already fixed on #846 and is marked
  accordingly pending merge.

- **`Student()` no longer reports a garbage log-likelihood near the Gaussian
  limit (#721; drmTMB twin #1265).** When the data are close to Normal the
  likelihood is flat in the ν predictor, and the optimiser can walk ν = 2 +
  exp(η) to ~1e16. There `Distributions.TDist`'s log density loses all
  precision (a cancelling difference of loggamma terms), so a fit on
  `datasets::trees` returned loglik ≈ +1924 with a converged status; drmTMB
  reports −87.82. The Student density is now evaluated by an exact
  large-ν asymptotic form for ν > ~1100 (error < 1e-13 against a 256-bit
  reference; it tends exactly to the Normal density as η → ∞), in the
  fixed-effect, `(1 | g)` and `(1 + x | g)` fitters. The trees fit now reports
  loglik −87.82; the ν coefficient itself is not identified on that ridge.
  Fits with moderate ν are unchanged.
- **Fix: a Binomial fit with two crossed random-intercept groupings
  (`(1 | g) + (1 | h)`) silently reported `[Inf, Inf, Inf, Inf]` standard
  errors with no warning (#761).** `_fit_binomial_crossed_laplace`'s own
  keyword default was `se = false` (unlike its Poisson/NB2 siblings, which
  default `se = true`), and `drm()`'s Binomial dispatcher never forwards the
  user's `se` argument down to it — so the Hessian/vcov step was skipped
  entirely regardless of what the caller asked for, `V` came back all-`NaN`,
  and `stderror` reported all-`Inf` per its existing non-finite-variance
  convention, with the guard that would have warned (`_vcov_from_hessian`,
  `src/vcov_guard.jl`) never invoked. Fixed by flipping the default to
  `se = true`; a genuinely non-identifiable random-intercept grouping (e.g.
  a grouping fully aliased with another, as when no cluster of one grouping
  spans more than one level of the other) now surfaces the existing
  "Hessian is numerically singular" / "not positive definite" warnings
  instead of a silent `Inf`.
- **Bivariate LogNormal structured markers (#471, LogNormal half): `animal`/
  `spatial` test coverage added, alongside the existing `phylo`/`relmat`
  identity tests.** `src/bivariate_lognormal.jl`'s `drm` method already
  forwarded `tree`/`K`/`A`/`coords`/`spatial_range` unconditionally to the
  bivariate Gaussian dispatcher on `log(y)` — there was no marker-specific
  gate to lift, so `animal(1 | group)` and `spatial(1 | group)` already fit
  and converge for `LogNormal()` exactly like `phylo`/`relmat` do. The gap was
  test coverage only: `test/test_twin_gap_471_bivln.jl` adds q=2 and q=4
  identity checks against `Gaussian()` on `log(y)` for `animal`/`spatial`, plus
  a small known-DGP recovery check on a 40-tip simulated tree. No `src/`
  change was needed. drmTMB's own `biv_lognormal()` (0.7.1) refuses all
  random/structured effects, the same blanket refusal as `biv_student()`; no
  R-parity fixture is claimed for this cell, but the Julia route rests on a
  closed-form identity (log(Y) bivariate Gaussian) rather than a bespoke
  unverified engine, matching owner decision D-180 that this is sound to ship
  ahead of drmTMB.

- **`simulate()`/the parametric bootstrap no longer throw for `biv_lognormal()`
  (same class as #766).** The generic `_simulate_once` fallback special-cases
  bivariate Gaussian fits (`fam isa Gaussian && haskey(fit.scales, :sigma1)`)
  before falling through to `fit.means[:mu]` for every other family. A
  bivariate lognormal fit has `fit.family isa LogNormal`, never `Gaussian`,
  even though it is built entirely by delegating to the bivariate Gaussian
  route on `log(y)` and so carries the SAME `:mu1`/`:mu2`/`:sigma1`/`:sigma2`/
  `:rho12` keys — so `simulate(fit)` and every parametric-bootstrap replicate
  (`bootstrap_result`/`bootstrap_ci`, which draw via `simulate` before any
  refit) threw `KeyError: key :mu not found` immediately. `src/bivariate_lognormal.jl`
  now adds a `_simulate_once(fit::DrmFit{LogNormal}, rng; ...)` method, dispatched
  ahead of the generic one, that draws log(Y) exactly as bivariate Gaussian does
  and exponentiates, leaving the univariate lognormal draw unchanged.
- **`predict`/`predict_parameters` on `newdata` with a factor predictor now use
  the TRAINING levels and contrasts (issue #609 item 1).** Previously the
  design matrix for `newdata` was built from a schema derived from `newdata`
  itself, so a `newdata` that omitted a training factor level crashed with an
  opaque `DimensionMismatch`, and one with an unseen level either errored
  obscurely or (with only that level present) refused with a misleading
  "need at least two levels" message. `DrmFormula` now caches the schema
  built from the training data at fit time; `predict`/`predict_parameters`
  reuse it, so `newdata` may present a subset of levels, the levels in a
  different row order, or all of them — and an unseen level now raises a
  clear `ArgumentError` naming the parameter. Numeric-only predictors are
  unaffected. See `test/test_twin_gap_609.jl`.
- **`marginal = :AGHQ` for crossed random intercepts `(1 | g) + (1 | h)` (#761;
  supersedes the rejected #850).** The default crossed route is the Laplace
  approximation that drmTMB and lme4 use, and it still matches them. **Laplace is
  biased low for Bernoulli / Binomial data with a large random-intercept SD and few
  observations per group**: on a G = 300, H = 4, n = 1600 Bernoulli design with
  σ_g = 2.5 (about 5 observations per g-level) its log-likelihood sits about 9.4 nat
  below the true value, and it shrinks σ_g. The new opt-in `marginal = :AGHQ`
  integrates the same model accurately when one grouping has few levels (at most
  8): each g-level's intercept by 15-node adaptive Gauss–Hermite quadrature
  conditional on the h-effects, and the h-effects by a tensor adaptive rule
  (3 nodes per level for H ≤ 4, 2 for 5–8) centred at the joint mode. At one node
  each it reproduces the crossed Laplace fit exactly. `fit.loglik` and `fit.nll`
  are the same objective, and the fit is tagged `marginal = :AGHQ`, so `lrtest` /
  `anova` refuse to compare it with a Laplace or GHQ fit. Wired for Binomial and
  Poisson (mean-only); also wired for NegBinomial2, Gamma, Beta and BetaBinomial,
  whose nuisance parameter (NB2 size, Gamma shape, Beta/BetaBinomial precision)
  is estimated jointly with β and the two variance components
  (`_fit_crossed_mean_aghq_nuisance`, the nuisance-aware twin of the mean-only
  route). Default fits are unchanged.

- **Fix: the same silent-`Inf`-SE class as #761, for Gamma, Beta and
  BetaBinomial crossed random intercepts.** `_fit_gamma_crossed_laplace`,
  `_fit_beta_crossed_laplace` and `_fit_betabinomial_crossed_laplace`
  (`src/sparse_laplace_glmm.jl`) also defaulted `se = false`, and their family
  dispatchers (`src/gamma.jl`, `src/beta.jl`, `src/betabinomial.jl`) never
  forwarded the caller's `se` down to them — so a crossed `(1 | g) + (1 | h)`
  fit for these three families always skipped the Hessian/vcov step
  regardless of what was asked for. Fixed by flipping each fitter's default
  to `se = true` (matching Poisson/NB2) and forwarding `se = se` at each
  dispatcher's crossed-dispatch call site.

- **`marginal = :Laplace` on an ordinary `(1 | g)` (Arc 2, drmTMB parity).**
  Poisson, Binomial, NegBinomial2, Gamma and Beta with one ordinary random
  intercept on the mean (`sigma ~ 1` for the scale families) can now be fitted
  with the Laplace approximation exactly as drmTMB/TMB does, instead of the
  default `:LA` route's 32-node Gauss–Hermite quadrature. It reuses the
  structured routes' sparse-Laplace kernels with an identity precision and
  unclamped scales (`raw_scales = true`); the fit is tagged
  `marginal = :Laplace`, and `drm_bridge` now accepts a `marginal` option and
  reports the integrator it used. On ten fixtures (five families × two seeds)
  it matches native drmTMB to |ΔlogLik| ≤ 3.8e-10 and ≤ 6.1e-8 relative on
  every estimate (`docs/dev-log/evidence/arc2-ordinary-laplace/`). The default
  `:LA` answers are unchanged. Not covered and refused: `(1 + x | g)`,
  `(0 + x | g)`, crossed terms, `sigma ~ covariates`, a random effect on
  `sigma`, `zi`/`hu`, and REML. When the family `sigma` is small (about
  0.01) the raw gradient stays large at the optimum because the curvature is
  large; the route then judges convergence by the scale-free Newton
  decrement, after up to three Newton steps on the outer gradient (with the
  inner mode solved to 1e-13), so such a fit reports `converged = true` only
  once it sits on drmTMB's optimum (Gamma `sigma` = 0.003: 5.6e-12 relative).
  NegBinomial2 on this route uses its own NB2 kernel that stays accurate when
  the size 1/σ² is huge (near-Poisson data); the structured NB2 kernel lost
  all precision there and reported logLik −0.0014 against drmTMB's −559.55.
  If a scale-family fit ends with log σ below −8, where the objective is
  flat (for NB2, the Poisson limit), the route re-fits from log σ = −1 and
  keeps the lower objective; on one NB2 review cell the first fit had
  stopped on that plateau, reporting `converged = true`, 0.81 below
  drmTMB's logLik. `lrtest`/`anova` now accept a random-effect-free fit
  against any non-VA fit, including `marginal = :AGHQ` (refused before),
  because a fixed-effects log-likelihood is exact; they still refuse `:LA`
  vs `:Laplace` random-effect pairs and any VA fit.

- **`meta_V(v)` with a random effect on the mean fits drmTMB's model.** `meta_V(v) + (1 | study)`
  used to return the `meta_V`-only fit (the random effect silently dropped: df 3 against drmTMB's 4),
  and `meta_V(v) + phylo(1 | sp)` / `+ relmat(1 | id)` the structured fit with the known variances
  silently dropped. A new route, `_fit_meta_gaussian_re` (`src/gaussian_meta.jl`), fits the marginal
  `y ~ N(Xβ, diag(v + σ²) + Σ s_k² Z_k C_k Z_kᵀ)` that drmTMB's Laplace integrates exactly, for any
  mix of `(1 | g)`, `phylo`, `relmat` and `animal` intercepts on distinct grouping columns, with
  `sigma ~ x` allowed. Measured against drmTMB `engine = "tmb"` in seven fits on six fixtures: logLik within
  3e-10, every estimate within 3e-9 relative (`docs/dev-log/evidence/arc2-metav-random-effect/`).
  Random slopes, `spatial()`, REML, a `sigma` random effect and `sd(g) ~ …` still refuse; the marginal
  bootstrap refuses a `meta_V` fit with more than one random field rather than drop one.
  The same refusal now covers the two-structured Gaussian route (`phylo(1 | sp) + relmat(1 | id)`),
  whose bootstrap used to draw the phylo field alone. Fits whose random fields are all ordinary
  bars keep their existing bootstrap path.
- **Bootstrap draws a phylo field on the right tree tips.** The marginal bootstrap simulator placed
  `phylo(1 | sp)` rows on tips by the order species first appear in the data, not by name, so a data
  set not sorted in tree-tip order drew the wrong phylogenetic covariance (sister tips: -0.005 drawn
  against 0.294 in the model), and a tree with tips absent from the data fell back to the conditional
  draw. It now places rows on tips by name, as every phylo fit does (next item). On the dense Gaussian
  phylo routes it also draws on the tip correlation those fits use, not the raw covariance, which
  over-dispersed the field by the tree height. Tip-ordered data give the same draws as before, except
  on those dense routes with a tree whose height is not 1.
- **The dense Gaussian phylo routes map rows to tree tips by name.** The single-field fallback taken
  for `phylo(1 | sp)` with `sigma ~ x` or `algorithm = :gls` / `:lbfgs`, and the two-structured route
  (`phylo(1 | sp) + relmat(1 | id)`), placed rows on tips in the order species first appear in the
  data. When the data were not in tree-tip order they fitted a different model from drmTMB's and from
  the default route: on one 12-tip fixture, `sigma ~ x` gave logLik -52.141 against drmTMB's -46.142,
  and `algorithm = :lbfgs` gave -55.018 against -49.119 from the default route on the same data. Rows
  now go to tips by name (or integer tip index), so row order no longer changes the fit, those logLiks
  now equal drmTMB's and the default route's, and a tree with tips absent from the data fits instead
  of failing the size check. The SD stays on the tip-correlation scale on these routes. Tip-ordered
  data give identical fits.

- **A structured marker plus an ordinary random effect no longer drops the ordinary
  term.** `drm(bf(y ~ x + phylo(1 | sp) + (1 | h), sigma ~ 1), Gaussian(); …)` (and
  the same shape with `relmat`/`animal`, or with `(0 + x | h)` or several bars) used
  to reach the single-structured fitter, which fitted the marker alone and silently
  discarded every `(1 | h)` term. It now fits drmTMB's model: independent blocks,
  `V = D + Σ_k σ_k² Z_k K_k Z_kᵀ`, ML, reported in one `:resd` block (ordinary bars
  first, the marker last; an ordinary intercept that shares the marker's grouping is
  keyed `<g>_iid`). Nine fixtures match drmTMB `engine = "tmb"` to |ΔlogLik| ≤ 1.4e-10
  (`docs/dev-log/evidence/arc2-structured-ordinary-bar/`). REML, `(1 + x | h)`,
  range-estimated `spatial()`, `penalty` and sparse algorithms with this shape now
  raise an `ArgumentError` instead of dropping a term; with `meta_V(v)` added, the
  `meta_V` + random-intercept route above fits it.
- **Package renamed to DRModels.jl.** The Julia package and module are now
  `DRModels`, while the modelling API remains `drm()`, `bf()`, and the existing
  fit/post-fit surface. `DRModels.DRM` is a soft-deprecated qualified alias for
  migration only; `using DRM` cannot survive a Julia package rename. The
  canonical `using DRModels` import is intentionally quiet; this changelog and
  the migration documentation carry the deprecation notice instead of a
  package-startup warning. The UUID and package version remain unchanged.
  The GitHub repository rename is complete; the stable Pages deployment awaits
  this unmerged PR landing. Historical
  `docs/dev-log/` records intentionally retain their original spelling.

- **`marginal = :Laplace` for a Gaussian random intercept on `sigma`.**
  `drm(bf(y ~ x, sigma ~ 1 + (1 | g)), Gaussian(); marginal = :Laplace)` fits
  each group's log-scale effect by the Laplace approximation, which is what
  native drmTMB (TMB) computes for this model. The default (`marginal = :LA`)
  still uses non-adaptive 32-node Gauss–Hermite quadrature and its answers are
  byte-identical to before. The inner mode is a bracketed 1-D Newton solve
  (the per-group log-density is strictly concave in the effect), followed by
  two Newton steps in the optimiser's number type, so ForwardDiff gradients and
  Hessians carry the implicit derivative of the mode. On seven data sets
  (five equal-size designs with 10 to 400 rows per group, one with `sigma ~ 1 +
  x + (1 | g)`, one with 3 to 120 rows per group) the route matches native
  drmTMB to |ΔlogLik| ≤ 3e-10, ≤ 3e-10 relative on every estimate and ≤ 2e-6
  relative on every standard error, where the default route differed from
  drmTMB by 0.002 to 3.3 log-likelihood units
  (`docs/dev-log/evidence/arc2-sigma-re-laplace/`). The same receipt shows why:
  against the exact marginal at drmTMB's estimates, GHQ-32 is exact for 10 rows
  per group but 0.49 and 4.8 units low at 150 and 400 rows per group, where
  Laplace is within 0.008. At the default fit's own optimum the error can go
  the other way: the reported default log-likelihood can lie above drmTMB's
  (by about 4 units on 5 groups of 300 rows), with a random-effect SD about
  twice drmTMB's (`own_optimum.tsv` in the same folder). The random-effect SD is still reported as
  `re_sd(fit)[:<g>_logsigma]`. `drm_bridge` now accepts a `marginal` option,
  `"LA"` or `"Laplace"` only (`"VA"`, `"AGHQ"` and other values are refused by
  name, as is any value for a `drm` method that has no `marginal` keyword), and
  reports the integrator it used as `"marginal"`. Refused, with an
  `ArgumentError`: `:Laplace` on any other Gaussian model (mean random effects,
  structured terms, `sd()` submodels, random slopes on `sigma`, REML,
  non-default `algorithm`), and `marginal = :VA` / `:AGHQ` on Gaussian models.
  `bootstrap_result`, `bootstrap_ci` and `bootstrap_summary` refit every
  replicate of a `:Laplace` fit with `:Laplace`. Parametric bootstrap intervals
  for the sigma random-effect SD are not valid on this route yet, under either
  integrator: the replicates are simulated without redrawing the random effect on
  `sigma`, so the refitted SD collapses towards zero. Use profile or Wald intervals
  for that SD. The names follow one rule:
  `:LA` is the route's default integrator (not always Laplace; here it is
  Gauss–Hermite quadrature), and `:Laplace` always forces the Laplace
  approximation drmTMB uses. `lrtest` and `anova` no longer refuse a fit with
  no random effect against a non-VA fit with a different `marginal` tag, so the
  fixed-effect `sigma ~ 1` model can be tested against a `:Laplace` fit (the
  `comparison.jl` change is shared verbatim with the ordinary `(1 | g)`
  `:Laplace` work). The error for `:Laplace` on a family that does not
  implement it now says so, instead of pointing to `:LA` as Laplace.

## v0.7.1 — 2026-09-05

- **Bootstrap replicates keep a masked fit's response mask (drmTMB #1188).** `_bootstrap_data`
  merged each simulated draw into the original table wholesale, so on the missing-response routes
  every replicate refitted on the FULL design regardless of how many rows the seed fit observed.
  (The draw itself must span the full design -- `means`/`scales` are rebuilt over all rows by #646 --
  so the mask has to be re-imposed one step later, when the replicate table is built.) A bootstrap
  whose replicates are richer than the original understates uncertainty, and the shortfall grows with
  the missing fraction. `_bootstrap_data` now restores the seed fit's response mask, reading it with
  `_is_response_missing` so `missing` and `NaN` are treated exactly as the fit itself treated them; a
  `cbind(successes, failures)` response is masked where EITHER cell is absent, and the failure column
  inherits the mask through NaN arithmetic. MEASURED end to end through the drmTMB bridge
  (`engine = "julia"`, `y = 0.3 + 0.5x + N(0,1) exp(0.1x)`, `n = 60`, `bf(y ~ x, sigma ~ x)`,
  Gaussian, 30 of 60 responses masked, `B = 99`, 99/99 replicates converged in both arms): the
  bootstrap interval on `fixef:mu:x` was 0.4748 wide against a Wald width of 0.8153 before the fix
  (ratio 0.58) and 0.8754 after (ratio 1.07). MEASURED on the R side of the same defect, which is
  where coverage is affordable (`S = 200` datasets, `B = 99` replicates each, nominal 95% percentile
  interval, truth 0.5, same datasets and seeds in both arms): coverage 0.895 / 0.820 / 0.720 before
  at 10% / 30% / 50% masked and 0.910 / 0.895 / 0.910 after, against a Wald reference of
  0.920 / 0.925 / 0.915; Monte Carlo standard errors 0.020-0.032, and the paired improvement is
  significant at 30% (p = 2.75e-04) and 50% (p = 7.28e-12) but NOT at 10% (p = 0.375). Receipt:
  drmTMB `docs/dev-log/evidence/julia-r-parity/p2-g3/1188-bootstrap-mask-receipt.md`.
  KNOWN CONSEQUENCE: replicates now legitimately drop rows, so `drm`'s #258 "never silent" warning
  fires once per replicate. It was left in place deliberately -- the same channel carries the
  saturated-fit (`residual dof 0`) warning, which is exactly what a user needs when replicates on a
  heavily masked fit degenerate. `test/test_bridge_response_mask_inference.jl`.
- **The `zi`/`hu` count mixtures now have a test at the `drm_bridge` MARSHALLING
  boundary, and a family spelled `zi_poisson` gets an actionable refusal.**
  `test_zi.jl` and `test_hurdle.jl` covered these mixtures through native `drm`
  only; nothing covered the `drm_bridge` route, which is the boundary drmTMB's
  `engine = "julia"` actually crosses and the one its banked `zi_poisson` parity
  receipt rests on. New `test/test_bridge_zi.jl` (45 assertions) pins
  bridge-vs-native agreement for ZIP (`family = "poisson"` + a keyed `zi` entry)
  and ZINB (`family = "nbinom2"` + `sigma` + `zi`): coefficients agree to
  `< 1e-8` and log-likelihoods to `1e-8` on both, with a plain-Poisson contrast
  proving the `zi` entry is not silently dropped in marshalling. Separately,
  `_bridge_family("zi_poisson")` (or `zi_nbinom2`, `zero_inflated_poisson`,
  `hurdle_nbinom2`) previously threw a bare ``unsupported family `zi_poisson` ``;
  it now names the spelling that works -- `family = "poisson"` plus a `zi` entry
  in `formula`. It is deliberately NOT an alias: mapping `zi_poisson` to
  `Poisson()` would fit a PLAIN Poisson, silently and without error, whenever
  the caller omitted the `zi ~` part. A mixture prefix on a non-count family
  (`zi_gaussian`, `hurdle_beta`) and any other unknown tag still get the plain
  message, with no suggestion.
- **The #574 resolvable-scale guard had zero margin, so the #461 runaway degenerate optimum was
  still reachable (`src/location_only.jl`).** #574 refused the sparse phylogenetic location-only
  Woodbury objective where the residual variance is "below machine precision relative to the
  phylogenetic variance", coded as `sigma^2 / sigma_phy^2 >= eps`. The relative error of that
  Woodbury subtraction grows as `eps * (sigma_phy^2 / sigma^2)`, so `eps` is exactly the point at
  which NO digits survive: the bar sat *on* the cliff rather than back from it, and the objective
  was still wrong just above it. Measured 2026-09-05 against a dense `V = sigma^2 I + sigma_phy^2 C`
  oracle on the #461 fixture (G = 100, one row per species) at `log(sigma_phy) = -26.9176`: the
  Woodbury log-likelihood tracks the oracle to 1.37e-05 relative at `log(sigma) = -40.0`, then
  FLIPS SIGN at `log(sigma) = -44.0` (`+4.37745e+25` against the oracle's `-3.15149e+25`). That
  break is at `log(sigma) - log(sigma_phy) = -17.086`, INSIDE #574's bar of `-18.022`, and it is
  the whole #461 runaway: `Optim` reports convergence there, `sigma = 7.75e-20`,
  `sd_phylo = 2.04e-12`, `loglik = +4.38e+25`. Whether the optimiser walks into that sliver is
  decided by rounding, so `test/test_bootstrap_marginal.jl`'s `#461` testset passed on x86_64
  Linux CI and failed on aarch64 macOS at the same commit with the same seeds and B = 60
  (`res.failed == 0` evaluated `1 == 0`; `res.used == 60` evaluated `59 == 60` -- replicate 38).
  The bar is now the standard rule for a cancellation-limited difference: keep at least HALF the
  mantissa, `sigma^2 / sigma_phy^2 >= sqrt(eps)`, i.e. `log(sigma) - log(sigma_phy) >=
  0.25 * log(eps)` = `-9.011`. It refuses `sigma / sigma_phy < 1.2e-04`; on the #461 fixture the
  60 bootstrap refits span `[-1.033, +1.439]`, about eight nats clear of it. This is a
  floating-point representation limit, not a statistical lower bound; `algorithm = :gls` remains
  available for a genuine boundary estimate. New path-independent pin in
  `test/test_lss_phylo.jl`: every `(log sigma, log sigma_phy)` pair the guard ADMITS must agree
  with the dense oracle to 1e-06 relative -- the property, not the constant, so re-loosening the
  bar fails it (17 assertions and 1 error under #574's value).

- **REML for the Gaussian mean-only phylogenetic cell (#624 item (c)).** `drm(bf(y ~ x +
  phylo(1 | species), sigma ~ 1), Gaussian(); tree, method = :REML)` now FITS. It used to reach
  the generic univariate REML gate and throw, even though the sparse location-only spine already
  carried a validated restricted objective. The objective is the same Patterson–Thompson
  restriction the `sd()` / Woodbury routes use, `nll_REML = nll_ML + 0.5·logdet(Xμ′V⁻¹Xμ) −
  0.5·pμ·log(2π)`, evaluated by `_loconly_reml_components`; because β_μ is profiled out exactly
  by GLS at every variance point, the restriction is exact rather than approximate. The
  integrated-out set is {u_phylo, β_μ} with the same additive `+0.5·pμ·log(2π)` that drmTMB gets
  from TMB's Laplace fold of `beta_mu` into `random=`, so the two engines' REML log-likelihoods
  are on ONE convention with no offset to remove. `fit.estim_method` is `:REML`, `reml_loglik` /
  `ml_loglik` are both populated, and the variance-component SEs use the restricted curvature.
  Measured against native drmTMB REML on the drmTMB fixture (n = 90, 30 tips): logLik
  −76.000977125105 vs −76.000977125761 (6.56e-10), coefficients to 3.71e-08, phylogenetic SD
  0.480176374690 vs 0.480176234530. ML is untouched (same fixture logLik before and after:
  −61.46784165162242). The widening is scoped to exactly the shape the sparse route serves:
  `sigma ~ x`, `relmat` / `animal` / `spatial`, `algorithm = :em` and a phylo random slope all
  still refuse (`test/test_reml_reml_phylo_mean.jl`). A REML fit also carries the
  RESTRICTED objective in `fit.nll` and no `fit.nllgrad`: the route's analytic
  score belongs to the ML marginal, and at the REML optimum it is (1.01, 0.99) on
  the two variance parameters — reporting it would have read as "not converged"
  for a converged fit, through drmTMB's `fit$bridge$gradient`. The ML path keeps
  its analytic score unchanged.
- **Profile and bootstrap intervals on a fixed-effect target of the RESIDUAL-ONLY bivariate
  Gaussian fit (drmTMB A8b).** `bf(mu1 = y1 ~ x, mu2 = y2 ~ x, sigma1 = ~ 1, sigma2 = ~ 1,
  rho12 = ~ 1)` with no structured term had no bootstrap route at all: `_bootstrap_fit_formula`
  refused every `BivariateDrmFormula`. That gate now admits the residual-only case, and the
  three blockers behind it are fixed — the `bootstrap_result(::DrmFit{<:Gaussian})` refit
  closure no longer forwards `algorithm` (which `drm(::BivariateDrmFormula, ::Gaussian; ...)`
  does not declare), `_bootstrap_result` accepts a `BivariateDrmFormula`, and `_bootstrap_data`
  gained a bivariate method for the `Dict(:mu1, :mu2)` draw `_simulate_once` returns. That
  method PRESERVES THE OBSERVATION PATTERN: a cell unobserved in the data stays unobserved in
  every replicate, so the refits fit the model the seed fit fitted. `profile_result` needed no
  change (it already reached the generic ForwardDiff path) and is now covered by assertions on
  the #631 endpoint-failure flags. Measured on an n = 200 fixture: 40/40 replicates, 0 failed,
  finite bounds on all five blocks; `drm_bridge_inference(parm = "fixef:mu1:x" |
  "fixef:rho12:(Intercept)")` returns finite rows for both methods
  (`test/test_bridge_biv_inference.jl`, 71 assertions). BOUNDARY: the STRUCTURED (q = 4
  phylogenetic) bivariate route is untouched — its `Sigma_a` guard fires first and it still
  routes to `bootstrap_sigma_a`; a `DrmFit` with no `.formula` is still refused; and this is a
  capability claim, NOT an interval-coverage claim (one fixture, one seed).
- **`converged` on the varying-scale Gaussian random-intercept route is now the GRADIENT
  criterion (#609 item 2).** `bf(y ~ x + (1 | g), sigma ~ x)` fits through
  `_fit_ranef_gaussian`, which reported `Optim.converged(res)` -- the OR of Optim's x, f and g
  criteria. Because `Optim.Options(g_tol = ...)` leaves `f_reltol`/`f_abstol`/`x_reltol`/
  `x_abstol` at their `0.0` defaults, `f_converged` fires on two byte-identical successive
  objective values, which a VARYING-scale surface reaches while running away up the unbounded
  sigma_i -> 0 ridge, nowhere near a stationary point. Measured over a 6,400-cell grid (n
  30..400, G 3..20, sigma slope 0.15..8.0): 1,042 fits returned `converged = true` with the
  gradient criterion false; the true gradient inf-norm there exceeded 1e-3 in 95 of them and 1.0
  in 45, worst 3.7e137 alongside a POSITIVE Gaussian logLik of +980. The reported flag now also
  requires `Optim.g_converged(res)`, so `fit.converged` implies the gradient met `g_tol`.
  NOTHING ELSE MOVES: theta-hat, the ML and REML objectives, logLik, vcov and the BLUPs are
  byte-identical (five fixtures across four routes, logLik equal to 17 significant figures
  before and after). This is the DRModels.jl half of #609 item 2; the ~1e-5 conditional-prediction
  parity gap the issue diagnosed is drmTMB's `nlminb` stopping rule and is tracked as
  drmTMB #1130. Guard: `test/test_ranef_varying_scale_convergence.jl`.
- **`coef_labels` count mismatch now names the construct behind it (#467, #609).** When the R side
  supplies more names for a dpar than the fit has columns, the commonest cause is a factor level
  with no rows in the data: base-R `model.matrix()` gives every DECLARED level a column (an
  all-zero one for a level nothing uses), while DRModels.jl codes only the levels it OBSERVES. The
  message previously said only "the R side must send exactly one name per column", naming neither
  the column nor the fix. It now names the coded columns DRModels.jl actually built and points at
  `droplevels()`. Measured through drmTMB on 2026-09-05 against this repository: `y ~ gempty` with
  `levels = c("a", "b", "c", "zz")` produced exactly this mismatch (R supplied 4 names, DRModels.jl built
  `["(Intercept)", "gempty: b", "gempty: c"]`). The hint is emitted only when the block has coded
  (`"<column>: <level>"`) columns and the supply is too LONG; a short supply, and a block of purely
  continuous columns, keep the bare count message unchanged. Behaviour is otherwise identical: this
  is refusal WORDING, not a new refusal, and every existing count/echo/fidelity test is unchanged
  (`test_bridge_formula_constructs.jl` 188 assertions, `test_bridge_coef_labels_echo.jl` 42,
  `test_bridge_formula_labels.jl` 819, `test_bridge_base_r_names.jl` 20, all green).
- **`check_drm()` CRASHED on four shipping routes instead of reporting on them, and a NaN gradient
  could not be told apart from a verified one.** `_check_max_abs_grad` (`src/inference.jl`) ended in
  an unguarded `maximum(abs, ForwardDiff.gradient(fit.nll, fit.theta))`. Four routes store a bare
  objective (no gradient callback) that is exact on `Float64` but NOT dual-number safe, so that line
  threw and the health check died on the very fits it exists to report on -- against the comment
  written two functions below it, "A diagnostic must REPORT trouble, not crash on it". Measured
  2026-09-05 at origin/main 109b6421c, in two distinct exception types: the bivariate q=2 structured
  route (`gaussian_bivariate.jl:626`, whose objective factorises a sparse `H_uu` through CHOLMOD
  inside `coevo_marginal_cov`) and the sparse two-structured Gaussian mean route
  (`gaussian_structured.jl:652`, same factorisation) both raised `TypeError: in Sparse, in Tv,
  expected Tv<:Union{Float64, ComplexF64}, got Type{ForwardDiff.Dual{...}}`; sparse LSS under REML,
  single-component (`gaussian_sparse_lss.jl:285`) and multi-component (`:1018`), raised the
  different `MethodError: no method matching Float64(::ForwardDiff.Dual{...})` from a Float64 work
  array. Only the REML arm of those last two ever reaches the line: both store
  `reml ? nothing : nllgrad!`, and the ML arm's stored callback is consulted first (its
  `max_abs_grad` is unchanged). The probe now falls back to a CENTRAL FINITE DIFFERENCE of the same
  objective -- the pattern `_profile_autodiff_mode` (`:805-821`) already uses for exactly this
  situation -- rather than returning `NaN`. Returning `NaN` would have been the quiet version of the
  same defect: `ok = converged && (penalized || isnan(mag) || mag <= grad_tol) && pd` treats a NaN
  magnitude as a PASS, a disjunct written for a fit that stores no objective at all, so an untested
  route would have reported `ok = true` and looked identical to a verified one. `check_drm` gains a
  `grad_source` field naming the producer -- `:locscale`, `:stored`, `:forward`, `:finite`, `:none`,
  `:unavailable`, reusing `profile_result`'s `autodiff` vocabulary -- warns when the magnitude is a
  finite difference (good to about 1e-6 relative, not to machine precision), and warns again on
  `:unavailable`, the NaN that is NOT `:none` and whose `ok` was never scored against a gradient.
  Measured after the fix, all four now RETURN with `grad_source = :finite`: q=2 structured
  2.7504093225161337e-3, two-structured sparse 2.7248279090903387e-8, sparse LSS REML
  1.7936919476824185, multi-component sparse LSS REML 1.0092392038529852. The last two are an
  accuracy check on the fallback rather than just a smoke test: the dense engine fits the same two
  models with a dual-safe objective, and its exact ForwardDiff magnitudes on the identical fixtures
  are 1.7936919467546497 and 1.0092392105794588 -- the finite difference agrees to 5.2e-10 and
  6.7e-9 relative. Eleven dual-safe fixtures spanning `:forward`, `:stored` and `:locscale` are
  unchanged to the last digit (e.g. plain Gaussian 2.580158309228864e-13, canonical location-scale
  1.651913078548617e-9), with every `check_drm` verdict field identical. Guarded by
  `test/test_check_drm.jl` (77 assertions, one testset per AD-hostile route plus `:none` vs
  `:unavailable` and a non-finite stored callback); removing the guard errors 5 of its testsets with
  the exceptions quoted above.

- **Bivariate q=2 `spatial(1 | group)` is admitted at the formula front end.** The q=2 marker
  allow-list took only `phylo`, `relmat` and `animal`, so a `spatial(...)` marker on `mu1`/`mu2`
  was refused outright -- a cell drmTMB fits natively AND through the bridge, which reaches it
  only by rewriting `spatial(...)` into `relmat(...) + K` on the R side (`R/julia-bridge.R`).
  `spatial` now supplies a covariance exactly as `relmat(K = ...)` and `animal(A = ...)` do:
  the exponential kernel `exp(-d / rho)` over the group levels at a FIXED range `rho` (keyword
  `spatial_range`, else the mean off-diagonal pairwise distance), which is the identical rule
  the q=4 structured route already used -- that construction is now one shared helper, so the
  two cells cannot drift apart. Same solver call as the other providers, so `method = :REML`
  comes on the same path, and `fit.ranef.structured_type` carries `:spatial` through to the
  bridge export target `gaussian_q2_mu1_mu2_spatial_residual_correlation` with no change to
  `src/bridge.jl`. Measured: `spatial(coords)` and `relmat(K = the same matrix)` on one fixture
  agree BIT-FOR-BIT -- max abs difference 0.0 on logLik and on all ten coefficients, under both
  ML and REML (`test/test_reml_q2_structured.jl`). The range in force is readable off the fit as
  `fit.ranef.spatial_range`, the same field the q=4 route already records, because the default is
  data-dependent and would otherwise be invisible; `relmat`/`animal` fits report `nothing`.
  BOUNDARY: `rho` is FIXED, not estimated. This is not the univariate `spatial` route, which
  carries `log rho` as a free parameter -- the two are different models and must not be compared
  as one. Note also that DRModels.jl's default range is the MEAN off-diagonal distance with a 1e-8
  ridge, while drmTMB's native R-side rule is the MEDIAN positive distance with a 1e-6 jitter,
  so the two engines build different matrices from the same coordinates unless `spatial_range`
  is pinned; a coords-to-coords cross-engine comparison is therefore not a parity check.
  REPAIR shipped with it: the q=2 route had a second, broader guard that refused ANY q=2
  structured fit merely for carrying a `coords =` keyword, so an ordinary `relmat`/`animal` q=2
  fit with a stray `coords =` errored. That guard is gone; each provider branch refuses when its
  own input is missing.
- **`drm_bridge` admits `skew_normal`** — `_bridge_family` now maps drmTMB's
  `skew_normal()` (tags `skew_normal` / `skewnormal`) to the native `SkewNormal()`
  family. The family was already implemented (`src/skewnormal.jl`) but the R
  bridge had no case for it, so drmTMB's `engine = "julia"` could not admit it.
  Both packages use the same public moment parameterisation (`mu` = mean,
  `sigma` = SD, `nu` = Azzalini slant), so the bridged coefficients are the
  native ones. Fixed effects only, ML only — exactly what `SkewNormal()` fits.
- **REML on the residual-only bivariate Gaussian route (#624; drmTMB #1142).** `drm(bf(mu1 = y1 ~ x, mu2 = y2 ~ x, sigma1 = ~1, sigma2 = ~1, rho12 = ~1), Gaussian(); method = :REML)` fits instead of refusing. The old message ("`method = :REML` needs random effects to restrict") mistook "no random effects" for "nothing to restrict": REML here integrates the MEAN fixed effects `beta_mu1`/`beta_mu2` out of the Gaussian likelihood under the row-wise 2x2 residual covariance — the classical Patterson–Thompson/SUR case, and the same set native drmTMB hands to TMB's Laplace approximation for this cell (whose Laplace step is EXACT, the integrand being quadratic). Closed form: profile `beta` by GLS, add `-0.5*logdet(sum_i Z_i' S_i^-1 Z_i)` and the `+(p_beta/2)*log(2*pi)` normalising constant, and optimise over `(beta_sigma1, beta_sigma2, beta_rho)` alone. Same-target against drmTMB `engine = "tmb"` with `REML = TRUE` on the committed fixture: logLik `-97.021205818372` on both engines (difference 0.0 at 12 decimal places), coefficients to 4.33e-7, standard errors to 6.54e-7 relative. `vcov` reports the joint mean block `H^-1 + G Var(phi) G'` that TMB's `sdreport()` reports. The ML route is unchanged (same fixture, `-90.202703298791` on both engines, difference 4.8e-13). `meta_V` plus `:REML` keeps its permanent refusal — that route marginalises nothing. `test/test_reml_reml_biv_residual.jl`.
- **Profile CIs on the canonical (non-sparse) location-scale route returned a signed infinite
  bound because ONE unevaluable trial abandoned the whole endpoint arm (#651).** #631/#633 closed
  this class for the SPARSE phylogenetic LSS engine and made `confint(...; method = :profile)` fail
  closed; the canonical whitened route kept the defect, and it has been failing unrelated pull
  requests at random on `Julia 1.10 - shard 1/4` (`test/test_locscale_profile_threads.jl:55` and
  `:91`, the two `isfinite` assertions). The endpoint search
  (`_ls_profile_root_result`, `src/locscale_profile.jl`) treated a single trial whose nuisance
  solve did not converge as terminal, in both the bracket-expansion and guarded-Newton phases, and
  reported that premature give-up as `Inf`/`-Inf`. It is not a data race and not run-to-run
  non-determinism: 600 repeats of the fixture at 1, 2 and 4 Julia threads produced zero failures
  and exactly four distinct `gradient_maxabs` values, bit-identical across thread counts. The
  fixture's accepted arms simply sit against the acceptance bar -- worst measured 7.96e-08 against
  a hard 1e-07 -- so a last-bit difference between macOS aarch64 and Linux x86-64 decides whether
  an arm is accepted, which is why it reproduced in CI and not locally. Both phases now CONTRACT
  toward a point already known to be feasible, on the bounded budget `maxcontract` (default 8):
  expansion halves `thi` toward the feasible `tlo`, and refinement halves the TRIAL toward `tlo`,
  leaving the maintained bracket -- and its proof that a crossing exists -- untouched. Measured with
  a +/-2-ULP perturbation of the response, the honest local surrogate for that platform difference:
  17 of 200 draws returned a non-finite bound before, 0 of 200 after, with all 800 endpoint arms
  accepted and 37 contractions across exactly the 17 draws that used to fail. The search is still
  bounded -- at most `(maxexpand + maxnewton + 1) * (1 + maxcontract)` evaluations -- so it cannot
  hang, and it is inert where nothing fails: the unperturbed fixture's intervals and residuals are
  bit-identical before and after. Contraction only POSTPONES failure; an arm that cannot be
  evaluated anywhere down to `xtol` is still a failed, signed-infinity endpoint, so
  `profile_result` remains the auditable surface #631 made it and `confint` still refuses it. One
  behaviour change beyond that: an expansion that had to contract can no longer certify
  UNBOUNDEDNESS, because part of the range was never evaluated -- it reports the new
  `:infeasible_region` failed endpoint instead of `:no_crossing`. Guarded by
  `test/test_locscale_profile_threads.jl` (29 assertions, 0.3 s, deterministic and
  platform-independent: it pins the search logic, which is what changed).

- **Inference on a missing-response ("response mask") Gaussian fit: `is_converged` read false on a
  converged fit, and every bootstrap replicate failed (#646).** Both defects sat downstream of the
  fit itself -- the point estimates were already right, matching drmTMB's `engine = "tmb"` to ~7e-06
  on the qualification fixture -- which is why nothing caught them until bridge-side inference was
  measured. (1) `_nondegenerate_fit` (`src/summary.jl`) took its scale-free degeneracy bar as
  `std(fit.obs[:mu])`, but the missing-response routes keep the full-design response there with NaN
  in the masked positions, so `yscale` was NaN and `smax > 1e-6 * max(NaN, eps)` was false for every
  `smax` under IEEE-754. `is_converged` therefore returned false on EVERY masked Gaussian fit,
  independent of the optimiser: measured on the fixture, `Optim.converged` true, `|grad|inf`
  6.41e-12 against `g_tol` 1e-8, and `theta` bit-identical to the complete-case fit (max abs diff
  0.0), yet `is_converged` false. The bar is now taken over the observed (finite) responses only;
  a genuinely degenerate sigma is still rejected. (2) `_simulate_once` (`src/gaussian_core.jl`)
  drew `randn(rng, fit.nobs)` -- the count that entered the likelihood, 54 on the fixture -- and
  broadcast it against the length-60 `means`/`scales` that `_with_full_fixed_gaussian_rows` rebuilds
  over the full design, throwing `DimensionMismatch` deterministically on every replicate, so
  `bootstrap_result` raised `"all B bootstrap replicates failed"`. Draws are now taken per row of
  the design, which is also the length `_bootstrap_data` needs to merge back into the caller's
  table. (3) Found while fixing those: `_with_full_fixed_gaussian_rows` and `_with_full_response_rows`
  used the 19-argument compatibility constructor, silently resetting `iterations` to -1
  ("not recorded") -- the identical complete-case fit reported 7 -- and dropping the MAP penalty
  slots; both now pass all 22 fields. Guarded by `test/test_bridge_response_mask_inference.jl`
  (21 assertions: converged status, a 5-replicate bootstrap on a masked response, the iteration
  count, and a degenerate-sigma control proving the widened bar still rejects).
- **Standard errors on the bivariate q=2 structured route (relmat / animal / phylo, ML and
  REML).** `vcov` on this route was an all-NaN placeholder for every provider and both
  estimators, which `stderror` then mapped to `Inf` and `confint` to `(-Inf, Inf)` -- the
  package's signal for "at a variance boundary", so a converged fit was indistinguishable from
  an unidentified one. The route now second-differences the marginal ML negative log-likelihood
  it already builds, through the shared `_finite_hessian` helper, and passes the result to the
  same `_vcov_from_hessian` guard the dense ML bivariate route uses; that guard eigen-tests the
  matrix, pseudo-inverts a singular one and warns, naming this route. ForwardDiff is not an
  option here because `coevo_marginal_cov` factorises a sparse H_uu through CHOLMOD, which
  rejects dual numbers -- the same reason the sparse-LSS routes finite-difference. RECEIPT: the
  beta block of the finite-difference Hessian is compared against the EXACT Schur complement
  `S = X' V^-1 X` that `_q2_profile_and_schur` assembles by an entirely different route; max
  relative difference 3.96e-9 (ML) and 9.75e-9 (REML) on the committed fixture, asserted at
  1e-6 in `test/test_q2_structured_vcov.jl`. That oracle is exact but covers only the four
  beta coordinates, so the variance/correlation axes are corroborated separately by profile
  likelihood, which never touches the Hessian: profile/Wald half-width ratio 1.0082 for
  `rho12` and 1.0050 for `sigma1`. `confint(fit, method = :profile)` works on this route
  through the existing `:finite` autodiff fallback -- and note that it did NOT before: the
  profile endpoint search seeds its bracket from the Wald standard error, so an infinite SE
  made it refuse with `not_converged`. The all-NaN covariance had therefore also disabled the
  documented fallback that the boundary warning tells users to reach for. Cost is 0.012 s at the usual ten parameters and
  scales as O(p^2): 2.6 s at 46 parameters (a 20-covariate mean design), against a 6.1 s fit,
  so there is no opt-out keyword -- unlike the q=4 route's `q4_vcov`.
  ESTIMATOR NOTE: under `method = :REML` the reported covariance is the ML curvature evaluated
  at the REML point, with the restricted-penalty curvature omitted -- the policy already
  documented for the q=4 sibling. REML Wald intervals on this route are therefore mildly
  anti-conservative; prefer `confint(fit, method = :profile)` when that matters.
  KNOWN WART: when the finite-difference Hessian is poor, the warning that says so is emitted
  under a hardcoded "sparse-Laplace vcov:" label, because the shared helper carries it. The
  route-naming text reaches the user through the guard's own singularity warning.

- **Gaussian two-SD phylogenetic random slope `phylo(1 + x | species)` on the mean (#620).** The
  #621 refusal is replaced by the fit on the Gaussian mean route: two INDEPENDENT phylogenetic
  fields, `a ~ N(0, σₐ² C)` for the intercept and `b ~ N(0, σ_b² C)` for the slope on the same
  tree correlation `C`, no intercept–slope correlation. That is drmTMB's Gaussian model
  term for term (`src/drmTMB.cpp`, `model_type == 1`, `has_phylo_mu` with `q_phylo == 2`: both
  fields sit on `mu`, so `has_cross_dpar_phylo` is false and the else-branch adds one
  `exp(-2·log_sd_phylo(k))·uₖᵀQuₖ` term per field with no cross term). Fitted here as the
  closed-form dense marginal `V = D + σₐ² Z C Zᵀ + σ_b² Zₓ C Zₓᵀ`, which is that Laplace
  objective evaluated exactly. Reported as a two-row `:resd` block (`species`, `species:x`;
  `re_sd`/`vc`/`ranef` all carry both fields), five free parameters — the same five drmTMB
  optimizes. Measured same-target against drmTMB 67703f541 on the committed fixture: logLik,
  both SDs, β and log σ all agree to ≤ 6.7e-13 (`test/test_phylo_slope_two_sd.jl`).
  BOUNDARY (corrected 2026-09-05 after measurement): drmTMB fits `phylo(1 + x | g)` on Poisson
  and NegBinomial2 as well, and it fits the SAME independent two-SD model there — measured on
  drmTMB main, `corpars` is empty for the untagged `phylo(1 + x | g)` on Poisson (two SD rows,
  `phylo(1 | site)` and `phylo(0 + x | site)`), while the estimated intercept–slope correlation
  (`has_phylo_mu_q2_covariance`, reported in `corpars` as `cor(mu:(Intercept),mu:x | p | site)`)
  appears only for the DIFFERENT tagged formula `phylo(1 + x | p | g)`. drmTMB refuses the
  formula on Gamma ("intercept-only in this q=1 route"). DRModels.jl still refuses every non-Gaussian
  family here, for the accurate reason: this route is the EXACT closed-form Gaussian marginal
  and does not extend to a non-Gaussian likelihood, so the count families need a two-field
  Laplace route that does not exist yet. The earlier claim that drmTMB fits "a DIFFERENT model"
  for Poisson/NegBinomial2 on this formula was wrong; the refusal it justified is unchanged. `phylo(0 + x | g)`, multi-slope
  forms, a second structured component, ordinary and `sigma`-side random effects, a structured
  (`phylo`) `sigma`, the `sd(...)`/`sd_phylo(...)` location-scale-scale submodels, REML, missing
  responses, the sparse algorithms and the parametric-bootstrap simulator all stay refused with
  a named error. Those refusals are raised next to `_split_ranef`, ABOVE every route that can
  return, so no engine written for the intercept-only cell can receive this formula and quietly
  fit `phylo(1 | g)` instead.

## v0.7.0 — 2026-08-28

**The twin-parity release.** Versioning now twin-tracks drmTMB (D-181, like GLLVM.jl↔gllvmTMB):
v0.7.0 means "at parity with drmTMB 0.7.0", pinned at drmTMB commit `a6de6bb71`; drmTMB's
fast-moving mi() missing-data axis is a named, fenced delta (D-180 #1) and the designated
post-0.7 headline. Registration in Julia General is planned at v0.7.1, mirroring the twin.

- **The API freeze** — every one of the 159 exports classified into Stable / Experimental /
  Engine tiers, machine-checked by `test/test_api_stability.jl` (total classification: a new
  export cannot appear untiered, a stable name cannot vanish silently). The promise and its
  honest Julia-0.x framing: `docs/src/api-stability.md`.
- **The comprehensive engine speed grid** (`report/engine-speed-grid.md`) — Julia wins 14 of 15
  comparable warm-fit cells (2.3×–42×); the one loss (q4 phylo REML, 0.46×) was diagnosed (the
  inner alternation burned 15 iterations per objective evaluation against a never-firing exit)
  and fixed to ~parity (0.94×, 2.1× faster).
- **The user-journey sweep** (`tools/user_journey_sweep.R`) — 29 models typed the way users type
  them, both engines: 25 matches at 1e-6..1e-11, refusal quality graded, and one real bug found
  and fixed (drmTMB#1099: `predict(newdata)` on factors/interactions failed on
  Julia-vs-R coefficient-name conventions).
- **The threaded bootstrap, demonstrated** — `confint(fit, parm, method = "bootstrap",
  threads = TRUE)` from R: 10× native TMB at R=199 on the same model and data
  (`docs/dev-log/evidence/2026-08-28-engine-julia-usability-demo.md`).
- Wave Q quality debt to zero: drmTMB#1090 (univariate `nu` tripping the bivariate bridge
  branch) fixed; #526 (q4 REML flag folds in the inner alternation, measured criterion);
  #527 hardening both repos; #482 and #8 closed.

## v0.2.0 — 2026-08-28

### The completion arc (2026-08-24 → 2026-08-27, D-179)

- **The R↔Julia capability ledger is COMPLETE** (drmTMB PRs #1085, #1087, and
  the Phase 2 promotions): every one of the 11 rows in drmTMB's generated
  `julia-capabilities.tsv` is now `covered` (9), an owner-signed permanent
  boundary (`cross_family_latent`, drmTMB #1089 — with a retraction: the route
  IS reachable from R), or unsupported by design (`engine_control_surface`).
  Every promotion is backed by SE-grade parity on a stamped comparator build.
  `covered` remains a capability claim, never interval coverage — the
  `coverage_claimed` fences are permanent documented boundaries by owner
  decision (D-179 #4).
- **`converged` answers a fixed question (#491, #517)** — the sparse-Laplace
  flag now tests the mean per-observation gradient against 1e-6 and no longer
  short-circuits on `Optim.converged`; a deliberately sloppy `g_tol` can no
  longer buy a green flag ("converged is not for sale" gate).
- **The large-p SE gap is fixed at source (#517)** — the outer vcov
  finite-difference step now grows with n (`clamp(2.5e-7·n, 1e-4, 1e-2)`);
  measured SE parity vs native TMB at p=1000 went 1.2e-03 → 4.0e-06 and at
  p=3000 9.0e-04 → 4.5e-06. Below n=400 nothing changes.
- **`response = "include"` fits the Gaussian phylo-mean cell (#517)** —
  measured byte-identical to `drop` on drmTMB's own route, so it is
  implemented as observed-rows + full tree (the σ-phylo convention); the
  wrapper deliberately does not extend to positional-matching routes.
- **q4 `converged` is gated on Λ admissibility (#509, #518)** — success is no
  longer claimed at a numerically singular Λ (the saturated-fixture regime);
  the smoke fixture is de-saturated and the saturated one kept as the
  negative control.
- **`mstep_Lambda`'s descent is a wired characterisation (#472, #519)** — the
  measured negative result now runs in the default suite as a tripwire, and
  `src/experimental/` carries per-file verdicts (#520).
- **Per-family speed table (#9, #521)** — `report/speed-per-family.md`
  consolidates every engine-vs-engine timing with its caveats; README swept to
  match the promoted ledger (its REML sentence was three routes stale).
- Earlier in the same arc: bivariate q=2 structured REML (#470,
  `reml_q2.jl`), per-coefficient `parm` for `confint` (#495, #514), comparator
  provenance stamping in all four parity harnesses (#473, #512), and the inner
  `newton_tol` tightening whose SE effect was measured, not assumed (#513).


- **VA Rung 2+3 (#136)** — scaffold anchors a/b/c in `test/test_variational.jl`
  are live (RE→0 ELBO = GLM loglik; ELBO ≤ adaptive GHQ; NB2 `r→∞` ≈ Poisson-VA).
  `aicc` on a VA fit errors even when `n − k − 1 ≤ 0` (no `Inf` short-circuit).
  Docs status is **Experimental** for Poisson + Binomial + NB2 + Gamma + Beta
  `(1 | g)`, not Planned-only. **Does not close #136.**

- **Public variational marginal Rung 1 (#136)** — Experimental
  `drm(...; marginal = :VA)` now covers Poisson **and** Binomial / NegBinomial2 /
  Gamma / Beta random intercept `(1 | g)` (scale families need `sigma ~ 1`),
  routing to the existing ELBO kernels. Default remains Laplace. `loglik` on a
  VA fit is an ELBO; mixed LA/VA AIC/LRT errors. Unsupported VA
  (phylo/crossed/corr/zi/hu/FE/`sigma ~ x`) rejects. `method = :VA` points at
  `marginal`. **Does not close #136.**

- **Non-Gaussian phylogenetic location–scale (#202)** — public `drm()` path for
  `NegBinomial2()` / `Gamma()` with a shared structured RE on **μ and log σ**
  via grammar B `(1 | p | phylo(species))` on both axes (`tree=` forwarded into
  the locscale frontend). `vc(fit)[:species]` reports the 2×2 group-level
  covariance (never residual `rho12`). Dual issue-text `phylo(1|sp)` on both
  axes stays rejected. Evidence: `test/test_public_phylo_locscale.jl` (NB2
  recovery + Gamma smoke). R `nbinom2-locscale` fixture deferred until drmTMB
  supports coupled `(1|p|species)` (D-94; R q=1 structured-σ covers scale-axis
  existence).

## v0.1.2 (2026-08-01)

**Version catch-up on the post–v0.1.1 `main` tip (registry candidate — not yet
in Julia General).** `Project.toml` / `CITATION.cff` advance `0.1.0` → `0.1.2`
so a first General registration does not collide with the existing git tags
`v0.1.0` / `v0.1.1` (May 2026; tip is hundreds of commits past those tags).
Prep + gates: [`docs/dev-log/plans/registrator-prep-2026-08-01.md`](docs/dev-log/plans/registrator-prep-2026-08-01.md).
**Registrator submit and tagging wait explicit Shinichi OK** (ultra-plan S4).
This note does **not** claim General membership, Phase 1.5 / #5 bridge closeout,
or a full public wire of remaining `src/experimental/`.

Post–v0.1.1 tip highlights already on `main` (Rose-honest; measured claims stay
in `HANDOVER.md` / `report/`):

- **Registry hygiene (S2/S3)** — ayumi↔main integrate (#340), load-banner silence
  (#341), docs honesty on Next / bridge / version drift (#342), post-merge
  checkpoint (#343).
- **σ-phylo REML correctness** — REML restricts both β_μ and β_ψ (#337).
- **Opt-in Gaussian REML**, conjugate-EM phylo-mean solver, heritability /
  repeatability / ICC accessors, DHARMa-style randomised quantile residuals, and
  the coevolution q=4 phylo front end (see HANDOVER TL;DR).
- **Julia-side bridge surface** (`drm_bridge` / `drm_bridge_inference`) remains
  in-tree; R-side `engine = "julia"` finish is still open (#5).
- **Bivariate q=4 coevolution bootstrap uncertainty** — `bootstrap_sigma_a` gives
  parametric-bootstrap intervals for the q=4 phylogenetic among-axis SDs
  (`sqrt(diag(Σ_a))`) and the six among-axis coevolution correlations, reachable
  from R via JuliaCall; `bootstrap_result(fit)` and the R bridge route a bivariate
  q4 fit here. Boundary-honest: a collapsing scale axis returns a small interval
  near the floor and its correlations come back unidentified (`~[−1, 1]`). A
  coverage study (`report/finish-audit/bootstrap-coverage-findings.md`) confirms
  the mean-axis SD CIs are well-calibrated and the detection/correlation reads are
  robust; the scale-axis *precise* CIs are anti-conservative (a known
  boundary-bootstrap effect) — read them as detection/indication, with a calibrated
  interval (BCa / bias-correction) tracked as a follow-up.
- **Per-parameter prediction** — `predict_parameters` (fitted distributional
  parameters on new data), `marginal_parameters` (population-averaged), and
  `prediction_grid` (build a swept `newdata` grid from a reference table).
- **Auditable profile-likelihood CIs** — `profile_result` exposes the full
  profile object behind `confint(fit; method = :profile)`.
- **Post-fit accessors** — `summary`, `family`, `is_converged`, `deviance`,
  `dof_residual`, and `rho12` (bivariate residual correlation).
- **Non-Gaussian phylogenetic random effects** — `phylo(1 | species, tree)` on
  the mean for Poisson, NegBinomial2, Gamma, Beta, and Binomial families
  (constant `σ`), via a sparse Laplace approximation, plus crossed intercepts
  `(1 | g) + (1 | h)` for those families.

## v0.1.1 (2026-05-31)

**drmTMB family parity complete** — the four remaining families, each
recovery-tested and shipped one-PR-per-family with green CI. DRModels.jl now fits
every distribution family drmTMB offers.

- **Beta-binomial** `BetaBinomial()` — successes out of known trials with
  extra-binomial overdispersion. Two-column `cbind(successes, failures) ~ …`
  response (drmTMB-exact, via a `cbind` formula marker + a second-response field
  on `DrmFormula`), logit mean + `φ = 1/σ²`. (drmTMB has no standalone
  `binomial`; ordinary binomial is the `φ → ∞` limit of beta-binomial.)
- **Zero-one-inflated beta** `ZeroOneBeta()` — proportions on the closed `[0,1]`;
  mixture `P(0)=zoi(1-coi)`, `P(1)=zoi·coi`, `(1-zoi)·Beta(μ,φ)`. Params
  `mu`/`sigma`/`zoi`/`coi`.
- **Tweedie** `Tweedie()` — semicontinuous (compound Poisson–Gamma, `1<p<2`):
  exact-zero mass + positive continuous part. Mean `μ` (log), `sigma` =
  √dispersion, `nu` = the estimated power `p` (logit-`(1,2)`). Density via the
  Dunn–Smyth series (adds the `SpecialFunctions` dependency).
- **Cumulative-logit** `CumulativeLogit()` — ordinal: `Pr(y≤k)=logistic(θ_k−η)`
  with `K-1` ordered cutpoints; intercept dropped.

Full set (12 univariate + bivariate Gaussian): Gaussian, Student-t, LogNormal,
Gamma, Tweedie, Beta, zero-one-inflated beta, beta-binomial, Poisson,
NegBinomial2, truncated-NB2, cumulative-logit. Families are validated by
simulation parameter recovery; the numerical drmTMB-parity gate is #17.

## v0.1.0 (2026-05-31)

First tagged release: the `drm()` / `bf()` distributional-regression front end
with **8 response families**, the count `zi` / `hu` modifiers, the complete
Gaussian random-effect / structured / inference surface, and a published
DocumenterVitepress site. Formula syntax mirrors drmTMB exactly; families are
validated by simulation parameter recovery (numerical drmTMB-parity gate: #17).

### Phase 0 — Team & workflows (2026-05-30)

- Stood up the 12-persona team (`AGENTS.md`), extended the project `CLAUDE.md`,
  and added `ROADMAP.md` (phases → v1.0).
- Added 10 scripted workflows in `.claude/workflows/` (W0/Q/A/B/D/F/G/H/S/R)
  and 12 Codex agent configs in `.codex/agents/`.
- Established the **GitHub work ledger**: labels, milestones (Phase 0 → v1.0),
  and the initial near-term issues; issue + PR templates.
- Added the `docs/dev-log/` discipline (check-log, coordination-board,
  after-task, decisions, recovery-checkpoints, scout) and
  `tools/drm-checkpoint.jl`.
- Scaffolded the **Documenter** site mirroring drmTMB's pkgdown navbar — 36
  status-tagged stub pages, reference index in 6 workflow-ordered categories.
- Project meta: `bench/Project.toml`, `test/Project.toml`, `CITATION.cff`,
  `.JuliaFormatter.toml`, and `Documenter.yml` / `TagBot.yml` CI.
- **Engine unchanged.** The verified q=4 PLSM engine (2.18× over drmTMB on the
  single fit, O(p) to p=10,000, valid CIs where drmTMB's Hessian is singular)
  is exactly as handed over. See `HANDOVER.md`.

### Gaussian surface — first tranche (2026-05-30)

The public `drm()` / `bf()` front end (StatsModels `@formula`, mirroring drmTMB)
and the Gaussian family, built test-first with recovery tests and merged via
PRs #21–#27 (green CI each):

- **Univariate location–scale** — `drm(bf(y ~ x, sigma ~ x), Gaussian())`, ML.
- **Bivariate location–scale + residual correlation** —
  `bf(mu1=…, mu2=…, sigma1=…, sigma2=…, rho12=…)` (tanh link on ρ12).
- **Ordinary random intercept** `(1 | g)` on the mean — closed-form Gaussian
  marginal (matrix-determinant lemma + Woodbury); `re_sd`.
- **Meta-analysis** — `meta_V(v)` known sampling variances + estimated
  heterogeneity τ.
- **Inference & post-fit** — `coef` / `vcov` / `stderror` / `confint` (Wald) /
  `fitted` / `residuals` / `loglik` / `nobs` / `fixef`.
- **Docs** — landing page rewritten as a real stats-package page; Get started,
  location-scale, bivariate-coscale, which-scale, meta-analysis, model-workflow,
  and the "What can I fit today?" capability map filled with **executed**
  examples.
- Fixed R's implicit intercept (`y ~ x` ⇒ `y ~ 1 + x`). Verified `src/` engine
  unchanged.

### Gaussian surface — completed (2026-05-31)

Completing the Gaussian distributional-regression surface, all recovery-tested,
each shipped as one PR with green CI:

- **Random effects on the mean** — independent slopes `(0 + x | g)`, correlated
  intercept+slope `(1 + x | g)` (`vc`), and multiple crossed / nested terms
  `(1 | g) + (1 | h)` (whitened-Woodbury capacitance).
- **Random effects on the scale** — `sigma ~ … + (1 | g)`, integrated out by
  per-group Gauss–Hermite quadrature (#40).
- **Structured effects on the mean** — `relmat(1|id, K)`, `animal(1|id, A)`,
  `phylo(1|species, tree)`, `spatial(1|site, coords)` — closed-form GLS.
- **Parametric bootstrap** (`bootstrap_ci`) and **profile-likelihood** intervals
  (`confint(fit; method = :profile)`, #38), alongside Wald.
- **Post-fit** — `predict` (new data) and `simulate`.

### Phase 2 — response families (2026-05-31)

Eight families behind the same `bf()` grammar, each with its own per-parameter
formulas and a simulation recovery test:

- **Student-t** `Student()` — robust location–scale–shape (μ, σ, ν).
- **Poisson** `Poisson()` — counts (log-link mean).
- **NegBinomial2** `NegBinomial2()` — overdispersed counts (dispersion θ).
- **TruncatedNegBinomial2** `TruncatedNegBinomial2()` — positive counts (≥ 1).
- **Beta** `Beta()` — proportions in (0,1) (logit mean; precision φ = 1/σ²).
- **Gamma** `Gamma()` — positive continuous (shape α = 1/σ²).
- **LogNormal** `LogNormal()` — positive, multiplicative.
- **Count modifiers** — `zi` (zero-inflation: ZIP / ZINB) and `hu` (hurdle).

### Documentation — the makie-style site (2026-05-31)

- Adopted the **DocumenterVitepress** backend (the docs.makie.org look); Node is
  supplied by `NodeJS_jll`, so there is no system install and no extra CI step.
- **CairoMakie** figure gallery rendered from live fits, including the
  **Confidence Eye** (pale compatibility lens + outline + hollow estimate).
- Landing page, capability matrix, family guide, and tutorials filled with
  executed examples and honest status tags.

Planned next: the R↔Julia bridge (`engine = "julia"`), beta-binomial (needs a
trials column — drmTMB has no standalone binomial), the bespoke families
(Tweedie / cumulative_logit / zero-one-inflated beta), wiring `src/experimental/`,
and the RCall numerical drmTMB-parity gate (#17).

[parity anchor: drmTMB v0.1.3 (2026-05-20)]
