# Binomial/Bernoulli SD regression for ordinary group effects. Each independent
# coefficient can have its own group-level log-SD regression; one ordinary
# intercept-slope block can also use predictor-dependent marginal SDs and a
# shared constant correlation. Bernoulli responses have no residual scale.

# Stable sech(eta): unlike sqrt(1 - tanh(eta)^2), this remains positive for
# large finite eta after tanh(eta) rounds to +/-1.
function _binomial_stable_sech(eta)
    a = abs(eta)
    return exp(log(2) - a - log1p(exp(-2a)))
end

# Match drmTMB's default smooth guard on latent log-SD predictors. The fitted
# coefficients remain on the raw linear-predictor scale.
_binomial_sd_scale(eta) = exp.(_softclamp.(eta, -12.0, 12.0, 3.0))

function _binomial_sd_scale_derivative(eta)
    upper_slope = 1 .- tanh.((eta .- 12.0) ./ 3.0).^2
    lower_slope = 1 .- tanh.((-12.0 .- eta) ./ 3.0).^2
    log_slope = ifelse.(eta .> 12.0, upper_slope,
        ifelse.(eta .< -12.0, lower_slope, 1.0))
    return _binomial_sd_scale(eta) .* log_slope
end

# Two independent ordinary effects on distinct grouping factors, each with a
# separate group-level SD regression. A factor may contribute an intercept or
# one numeric slope. The standardized latent coefficients have prior N(0, I);
# each observation loading is its coefficient design value times the
# group-specific SD. The outer score differentiates the Laplace determinant
# analytically, including the latent-mode response; ForwardDiff is used only
# for the final observed Hessian, never through the latent mode.
function _fit_binomial_crossed_sd_laplace(fam::Binomial, s, ntr, Xmu, Zg, nmsg,
                                          gidx, G, hidx, Hh, loading_g, loading_h,
                                          nmmu, groups, g_tol; se::Bool = true,
                                          target_blocks = [:sd_g, :sd_h])
    n = length(s)
    pμ = size(Xmu, 2)
    pgs, phs = size(Zg[1], 2), size(Zg[2], 2)
    length(s) == length(ntr) == length(gidx) == length(hidx) == n ||
        throw(ArgumentError("crossed Binomial SD dimensions do not match the response"))
    length(loading_g) == length(loading_h) == n || throw(ArgumentError(
        "crossed Binomial coefficient loadings must match the response length"))
    size(Zg[1], 1) == G && size(Zg[2], 1) == Hh ||
        throw(ArgumentError("crossed Binomial SD designs must have one row per level"))
    length(target_blocks) == 2 || throw(ArgumentError("crossed Binomial SD fitting needs two target blocks"))
    sint, nint = round.(Int, s), round.(Int, ntr)
    lc = [_logchoose(nint[i], sint[i]) for i in 1:n]
    q = G + Hh
    last_u = zeros(q)
    group_ranges = (pμ + 1:pμ + pgs, pμ + pgs + 1:pμ + pgs + phs)

    function scales_at(theta)
        eta_g = Zg[1] * @view(theta[group_ranges[1]])
        eta_h = Zg[2] * @view(theta[group_ranges[2]])
        logtau_g = _softclamp.(eta_g, -12.0, 12.0, 3.0)
        logtau_h = _softclamp.(eta_h, -12.0, 12.0, 3.0)
        return exp.(logtau_g), exp.(logtau_h), logtau_g, logtau_h
    end

    function mode(theta; start = last_u)
        tau_g, tau_h, _, _ = scales_at(theta)
        eta0 = Xmu * @view(theta[1:pμ])
        u = copy(start)
        function joint(uu)
            val = 0.5 * dot(uu, uu)
            @inbounds for i in 1:n
                ag = tau_g[gidx[i]] * loading_g[i]
                ah = tau_h[hidx[i]] * loading_h[i]
                eta = eta0[i] + ag * uu[gidx[i]] + ah * uu[G + hidx[i]]
                val -= _binomial_logit_ll(nint[i], sint[i], eta, lc[i])
            end
            return val
        end
        ch = nothing
        for _ in 1:60
            grad = copy(u)
            diagH = ones(Float64, q)
            crossw = Vector{Float64}(undef, n)
            all_w_nonneg = true
            @inbounds for i in 1:n
                gi, hi = gidx[i], G + hidx[i]
                ag = tau_g[gidx[i]] * loading_g[i]
                ah = tau_h[hidx[i]] * loading_h[i]
                eta = eta0[i] + ag * u[gi] + ah * u[hi]
                _, r, w, _ = _laplace_v123(Val(:binomial),
                    (; s = sint, ntr = nint, logchoose = lc), i, eta)
                grad[gi] += ag * r
                grad[hi] += ah * r
                diagH[gi] += ag^2 * w
                diagH[hi] += ah^2 * w
                crossw[i] = ag * ah * w
                w < 0 && (all_w_nonneg = false)
            end
            Hmat = _crossed_hessian(diagH, crossw, gidx, G, hidx, Hh)
            ch = cholesky(Symmetric(Hmat); check = false)
            issuccess(ch) || return u, ch, false
            step = ch \ grad
            sn = norm(step)
            sn <= 1e-9 * (1 + norm(u)) && return u, ch, true
            if all_w_nonneg && sn <= 1e-3 * (1 + norm(u))
                u .-= step
            else
                old = joint(u)
                rate = 1.0
                accepted = false
                while rate >= 1e-5
                    trial = u .- rate .* step
                    if joint(trial) <= old
                        u .= trial
                        accepted = true
                        break
                    end
                    rate *= 0.5
                end
                accepted || return u, ch, false
            end
        end
        return u, ch, false
    end

    function eval_laplace(theta; gradient::Bool = false)
        tau_g, tau_h, logtau_g, logtau_h = scales_at(theta)
        u, ch, ok = mode(theta)
        if !ok
            u, ch, ok = mode(theta; start = zeros(q))
        end
        ok || return gradient ? (1e18, zeros(length(theta))) : 1e18
        last_u .= u
        eta0 = Xmu * @view(theta[1:pμ])
        vstore, rstore, wstore, tstore = (Vector{Float64}(undef, n) for _ in 1:4)
        eta = Vector{Float64}(undef, n)
        value = 0.5 * dot(u, u)
        @inbounds for i in 1:n
            gi, hi = gidx[i], hidx[i]
            ag = tau_g[gi] * loading_g[i]
            ah = tau_h[hi] * loading_h[i]
            eta[i] = eta0[i] + ag * u[gi] + ah * u[G + hi]
            v, r, w, t = _laplace_v123(Val(:binomial),
                (; s = sint, ntr = nint, logchoose = lc), i, eta[i])
            value += v
            vstore[i], rstore[i], wstore[i], tstore[i] = v, r, w, t
        end
        value += 0.5 * logdet(ch)
        gradient || return value

        hd, crossinv = _crossed_selected_inverse_entries(ch, gidx, G, hidx, Hh)
        qform = Vector{Float64}(undef, n)
        @inbounds for i in 1:n
            gi, hi = gidx[i], hidx[i]
            ag, ah = tau_g[gi] * loading_g[i], tau_h[hi] * loading_h[i]
            qform[i] = ag^2 * hd[gi] + ah^2 * hd[G + hi] +
                       2 * ag * ah * crossinv[i]
        end

        grad = zeros(Float64, length(theta))
        # Fixed-effect derivative: the mode response cancels from the joint
        # term. It remains in dH through the third derivative of the likelihood.
        for k in 1:pμ
            direct = @view Xmu[:, k]
            dmode_score = zeros(Float64, q)
            @inbounds for i in 1:n
                ag = tau_g[gidx[i]] * loading_g[i]
                ah = tau_h[hidx[i]] * loading_h[i]
                dmode_score[gidx[i]] += ag * wstore[i] * direct[i]
                dmode_score[G + hidx[i]] += ah * wstore[i] * direct[i]
            end
            du = -(ch \ dmode_score)
            score = 0.0
            @inbounds for i in 1:n
                ag = tau_g[gidx[i]] * loading_g[i]
                ah = tau_h[hidx[i]] * loading_h[i]
                total_eta = direct[i] + ag * du[gidx[i]] + ah * du[G + hidx[i]]
                score += rstore[i] * direct[i] + 0.5 * tstore[i] * total_eta * qform[i]
            end
            grad[k] = score
        end

        # A group SD coefficient changes both its observation loading and its
        # latent mode. Differentiate the mode equation, then the selected
        # inverse entries in log|H| without differentiating through the solve.
        for (axis, (idx, nlev, Z, logtau, tau, range)) in enumerate(
                ((gidx, G, Zg[1], logtau_g, tau_g, group_ranges[1]),
                 (hidx, Hh, Zg[2], logtau_h, tau_h, group_ranges[2])))
            raw_sd_predictor = Z * @view(theta[range])
            dclamp = [ForwardDiff.derivative(x -> _softclamp(x, -12.0, 12.0, 3.0),
                                              raw_sd_predictor[j]) for j in 1:nlev]
            for k in 1:size(Z, 2)
                direct_loading = Vector{Float64}(undef, n)
                direct_eta = Vector{Float64}(undef, n)
                dmode_score = zeros(Float64, q)
                @inbounds for i in 1:n
                    gi, hi = gidx[i], hidx[i]
                    level = idx[i]
                    loading = axis == 1 ? loading_g[i] : loading_h[i]
                    direct_loading[i] = loading * tau[level] * dclamp[level] * Z[level, k]
                    direct_eta[i] = direct_loading[i] * u[axis == 1 ? gi : G + hi]
                    dmode_score[gi] += (axis == 1 ? direct_loading[i] * rstore[i] : 0.0)
                    dmode_score[G + hi] += (axis == 2 ? direct_loading[i] * rstore[i] : 0.0)
                    dmode_score[gi] += tau_g[gi] * loading_g[i] * wstore[i] * direct_eta[i]
                    dmode_score[G + hi] += tau_h[hi] * loading_h[i] * wstore[i] * direct_eta[i]
                end
                du = -(ch \ dmode_score)
                score = 0.0
                @inbounds for i in 1:n
                    gi, hi = gidx[i], hidx[i]
                    ag, ah = tau_g[gi] * loading_g[i], tau_h[hi] * loading_h[i]
                    total_eta = direct_eta[i] + ag * du[gi] + ah * du[G + hi]
                    if axis == 1
                        score += rstore[i] * direct_eta[i] +
                            wstore[i] * direct_loading[i] * (ag * hd[gi] + ah * crossinv[i])
                    else
                        score += rstore[i] * direct_eta[i] +
                            wstore[i] * direct_loading[i] * (ah * hd[G + hi] + ag * crossinv[i])
                    end
                    score += 0.5 * tstore[i] * total_eta * qform[i]
                end
                grad[first(range) + k - 1] = score
            end
        end
        return value, grad
    end

    nll(theta) = eval_laplace(theta; gradient = false)
    function grad!(out, theta)
        _, g = eval_laplace(theta; gradient = true)
        out .= g
        return out
    end
    theta0 = zeros(pμ + pgs + phs)
    pbar = clamp(sum(s) / max(sum(ntr), 1), 1e-3, 1 - 1e-3)
    theta0[1] = log(pbar / (1 - pbar))
    theta0[group_ranges[1]] .= Zg[1] \ fill(log(0.45), G)
    theta0[group_ranges[2]] .= Zg[2] \ fill(log(0.45), Hh)
    od = Optim.OnceDifferentiable(nll, grad!, theta0)
    res = Optim.optimize(od, theta0, Optim.LBFGS(linesearch = Optim.LineSearches.BackTracking()),
                         Optim.Options(g_tol = g_tol, iterations = 350))
    theta_hat = Optim.minimizer(res)
    final_grad = zeros(length(theta_hat))
    grad!(final_grad, theta_hat)
    value = nll(theta_hat)
    converged = _laplace_outer_converged(res, value, final_grad, theta_hat, n, g_tol)
    V = if se
        hstep = _fd_hessian_step(n)
        Htheta = _finite_hessian(nll, theta_hat; h = hstep)
        _vcov_from_fd_hessian(Htheta; context = "crossed Binomial SD regression")
    else
        fill(NaN, length(theta_hat), length(theta_hat))
    end
    blocks = Pair{Symbol,UnitRange{Int}}[:mu => (1:pμ),
        target_blocks[1] => group_ranges[1], target_blocks[2] => group_ranges[2]]
    names = Pair{Symbol,Vector{String}}[:mu => nmmu,
        target_blocks[1] => nmsg[1], target_blocks[2] => nmsg[2]]
    mu_eta = Xmu * theta_hat[1:pμ]
    means = Dict(:mu => _logistic.(mu_eta))
    obs = Dict(:mu => s ./ ntr)
    tau_g, tau_h, _, _ = scales_at(theta_hat)
    sd_g = _binomial_sd_scale(Zg[1] * theta_hat[group_ranges[1]])
    sd_h = _binomial_sd_scale(Zg[2] * theta_hat[group_ranges[2]])
    scales = Dict{Symbol,Vector{Float64}}(
        :trials => Float64.(nint),
        Symbol("sd_group_index_", groups[1]) => Float64.(gidx),
        Symbol("sd_group_index_", groups[2]) => Float64.(hidx),
        target_blocks[1] => sd_g[gidx],
        target_blocks[2] => sd_h[hidx],
    )
    fit = DrmFit(fam, blocks, names, theta_hat, Matrix(V), -value, n,
        converged, means, obs, scales)
    for (label, eta_sd) in ((groups[1], Zg[1] * theta_hat[group_ranges[1]]),
                            (groups[2], Zg[2] * theta_hat[group_ranges[2]]))
        _warn_at_clamp("Binomial SD regression",
            ["$label random-effect log SD" => (collect(Float64, eta_sd), -12.0, 12.0)])
    end
    return _withiterations(_withnll(fit, nll, grad!), Optim.iterations(res))
end

function _drm_binomial_phylo_sd_regression(f::DrmFormula, fam::Binomial; data,
                                          tree, g_tol::Real = 1e-8,
                                          se::Bool = true)
    sdpp = _sdphylo_parts(f)
    length(sdpp) == 1 || throw(ArgumentError(
        "Binomial phylogenetic SD regression requires exactly one `sd(group, phylogenetic) ~ …` formula."))
    isempty(_sd_parts(f)) || throw(ArgumentError(
        "Binomial phylogenetic SD regression cannot be combined with an ordinary `sd(group)` formula yet."))
    sgrp, srhs = only(sdpp)
    rhs = Dict(f.forms)
    fixed_mu, re, mv, st = _split_ranef(rhs[:mu])
    mv === nothing || throw(ArgumentError("Binomial phylogenetic SD regression cannot use meta_V()."))
    st !== nothing && first(st) === :phylo || throw(ArgumentError(
        "Binomial `sd($sgrp, phylogenetic)` requires `phylo(1 | $sgrp)` in the location formula."))
    tree === nothing && throw(ArgumentError("phylo(1 | $sgrp) needs `tree = …`"))
    isempty(re) || throw(ArgumentError(
        "Binomial `sd($sgrp, phylogenetic)` currently requires a phylogenetic random intercept without additional random effects."))
    last(st) === sgrp || throw(ArgumentError(
        "Binomial `sd($sgrp, phylogenetic)` must name the group in `phylo(1 | $(last(st)))`."))
    for (pname, _) in f.forms
        (pname === :mu || pname === Symbol("sdphy_", sgrp)) && continue
        pname === :sigma && Dict(f.forms)[pname] == ConstantTerm(1) && continue
        throw(ArgumentError("Binomial phylogenetic SD regression supports only `mu` and one phylogenetic SD formula."))
    end
    all(_formula_response_observed_mask(f, data)) || throw(ArgumentError(
        "Binomial phylogenetic SD regression requires observed responses; remove incomplete rows before fitting."))

    s, ntr = _binomial_response(f, data)
    _, Xmu, nmmu = _design(f.response, fixed_mu, data)
    labels = getproperty(data, sgrp)
    _, tip_index, G = _lss_phylo_group_index(tree, labels, sgrp)
    group_index, Gdata = _group_index(labels)
    Gdata == G || error("phylogenetic group indexing changed unexpectedly")
    Zg, nmsd = _sd_group_design(f.response, srhs, data, group_index, Gdata, sgrp;
                                schema_cache = f.schema_cache, schema_key = :sd_phylo)
    tip_group = zeros(Int, G)
    @inbounds for i in eachindex(tip_index)
        ti, gi = tip_index[i], group_index[i]
        tip_group[ti] == 0 || tip_group[ti] == gi || throw(ArgumentError(
            "Binomial phylogenetic SD predictors must be constant within each tree tip."))
        tip_group[ti] = gi
    end
    all(!iszero, tip_group) || throw(ArgumentError(
        "Binomial phylogenetic SD regression requires SD predictors for every tree tip."))
    Ztip = Matrix{Float64}(Zg[tip_group, :])
    Zobs = Ztip[tip_index, :]
    return _withformula(_fit_binomial_phylo_sd_laplace(
        fam, s, ntr, Xmu, Zobs, labels, tree, nmmu, nmsd, sgrp, g_tol; se,
    ), f)
end

function _drm_binomial_related_sd_regression(f::DrmFormula, fam::Binomial;
                                             data, covariance, level::Symbol,
                                             tree, K, A, coords,
                                             g_tol::Real, se::Bool)
    targets = _sd_target_parts(f)
    length(targets) == 1 || throw(ArgumentError(
        "Binomial $level SD regression currently requires exactly one `sd(group, $level) ~ …` formula."))
    target = only(targets)
    descriptor = target.target
    (descriptor.level === level && descriptor.dpar === :mu &&
     descriptor.member === nothing && descriptor.block === nothing) ||
        throw(ArgumentError("Binomial $level SD regression targets the sole structured mean coefficient."))
    if level === :animal
        tree === nothing && K === nothing && coords === nothing ||
            throw(ArgumentError("Binomial animal SD regression uses `A = …` only; do not also supply `tree`, `K`, or `coords`."))
        covariance === nothing && throw(ArgumentError(
            "animal(1 | $(descriptor.group)) needs the relatedness matrix `A = …`"))
    else
        tree === nothing && A === nothing && coords === nothing ||
            throw(ArgumentError("Binomial relmat SD regression uses `K = …` only; do not also supply `tree`, `A`, or `coords`."))
        covariance === nothing && throw(ArgumentError(
            "relmat(1 | $(descriptor.group)) needs the covariance matrix `K = …`"))
    end

    rhs = Dict(f.forms)
    fixed_mu, re, mv, st, _, _, animal_slope =
        _split_ranef(rhs[:mu]; allow_animal_slope = level === :animal)
    mv === nothing || throw(ArgumentError("Binomial $level SD regression cannot use meta_V()."))
    st !== nothing && first(st) === level || throw(ArgumentError(
        "Binomial `sd($(descriptor.group), $level)` requires one `$level(1 | $(descriptor.group))` term in the location formula."))
    structured = _collect_structured(rhs[:mu])
    length(structured) == 1 && only(structured) == (level, descriptor.group) ||
        throw(ArgumentError("Binomial $level SD regression currently requires exactly one structured term and no other structured effects."))
    isempty(re) || throw(ArgumentError(
        "Binomial $level SD regression currently requires one structured coefficient without additional random effects."))
    last(st) === descriptor.group || throw(ArgumentError(
        "The $level SD formula must name the group in the structured term `$level(… | $(last(st)))`."))
    for (pname, form) in f.forms
        (pname === :mu || pname === target.key) && continue
        pname === :sigma && form === ConstantTerm(1) && continue
        throw(ArgumentError("Binomial $level SD regression supports only `mu`, fixed `sigma ~ 1`, and one structured SD formula."))
    end
    all(_formula_response_observed_mask(f, data)) || throw(ArgumentError(
        "Binomial $level SD regression requires observed responses; remove incomplete rows before fitting."))

    s, ntr = _binomial_response(f, data)
    _, Xmu, nmmu = _design(f.response, fixed_mu, data)
    labels = getproperty(data, descriptor.group)
    gidx, G = _group_index(labels)
    C = Matrix{Float64}(covariance)
    size(C) == (G, G) || throw(ArgumentError(
        "$level covariance matrix must be $(G)×$(G) (the number of `$(descriptor.group)` levels, in first-seen order)"))
    Zg, nmsd = _sd_group_design(f.response, target.rhs, data, gidx, G,
                                descriptor.group; schema_cache = f.schema_cache,
                                schema_key = target.key)
    size(Zg, 2) <= G && rank(Zg) == size(Zg, 2) || throw(ArgumentError(
        "Binomial $level SD target has a rank-deficient group-level design."))
    Zobs = Zg[gidx, :]
    re_design = if animal_slope === nothing
        ones(Float64, length(gidx))
    else
        hasproperty(data, animal_slope) || throw(ArgumentError(
            "Binomial animal slope term is missing predictor `$animal_slope` from data."))
        raw = getproperty(data, animal_slope)
        raw isa AbstractVector{<:Real} && length(raw) == length(gidx) && all(isfinite, raw) ||
            throw(ArgumentError("Binomial animal slope predictor `$animal_slope` must be numeric, finite, and have one value per response."))
        any(!iszero, raw) || throw(ArgumentError(
            "Binomial animal slope predictor `$animal_slope` is zero for every observation, so its SD is not identifiable."))
        Float64.(raw)
    end
    fit = _fit_binomial_related_sd_laplace(
        fam, s, ntr, Xmu, Zobs, Zg, labels, C, gidx, nmmu, nmsd,
        descriptor.group, level, g_tol; se, re_design,
    )
    return _withformula(fit, f)
end

_drm_binomial_animal_sd_regression(f::DrmFormula, fam::Binomial; data, A,
                                   tree, K, coords, g_tol::Real, se::Bool) =
    _drm_binomial_related_sd_regression(f, fam; data, covariance = A,
        level = :animal, tree, K, A, coords, g_tol, se)

_drm_binomial_relmat_sd_regression(f::DrmFormula, fam::Binomial; data, K,
                                   tree, A, coords, g_tol::Real, se::Bool) =
    _drm_binomial_related_sd_regression(f, fam; data, covariance = K,
        level = :relmat, tree, K, A, coords, g_tol, se)

function _binomial_phylo_ordinary_mode(aux, eta0, A, Q, b0;
                                      maxiter::Int = 60, tol::Real = 1e-10)
    b = copy(b0)
    function joint(bb)
        eta = eta0 + A * bb
        value = 0.5 * dot(bb, Q * bb)
        @inbounds for i in eachindex(eta)
            value += _laplace_value(Val(:binomial), aux, i, eta[i])
        end
        value
    end
    for _ in 1:maxiter
        eta = eta0 + A * b
        grad = Q * b
        weights = zeros(Float64, length(eta))
        all_w_nonneg = true
        @inbounds for i in eachindex(eta)
            _, r, w, _ = _laplace_v123(Val(:binomial), aux, i, eta[i])
            grad .+= vec(Array(A[i, :])) .* r
            weights[i] = w
            w < 0 && (all_w_nonneg = false)
        end
        H = Q + A' * spdiagm(0 => weights) * A
        ch = cholesky(Symmetric(H); check = false)
        issuccess(ch) || return b, ch, false
        step = ch \ grad
        norm(step) <= tol * (1 + norm(b)) && return b, ch, true
        if all_w_nonneg && norm(step) <= 1e-3 * (1 + norm(b))
            b .-= step
            continue
        end
        f0 = joint(b)
        a = 1.0
        accepted = false
        while a >= 1e-5
            trial = b .- a .* step
            if joint(trial) <= f0
                b = trial
                accepted = true
                break
            end
            a *= 0.5
        end
        accepted || return b, ch, false
    end
    return b, nothing, false
end

function _drm_binomial_phylo_ordinary_sd_regression(f::DrmFormula, fam::Binomial;
                                                    data, tree, g_tol::Real,
                                                    se::Bool)
    phy_targets = _sdphylo_parts(f)
    ordinary_targets = _sd_target_parts(f)
    length(phy_targets) == 1 || throw(ArgumentError(
        "Binomial mixed phylogenetic SD regression requires exactly one phylogenetic SD formula."))
    length(ordinary_targets) == 1 || throw(ArgumentError(
        "Binomial mixed phylogenetic SD regression currently requires exactly one ordinary SD formula."))
    species, phy_rhs = only(phy_targets)
    ordinary = only(ordinary_targets)
    target = ordinary.target
    (target.level === :iid && target.dpar === :mu && target.block === nothing) ||
        throw(ArgumentError("The ordinary SD formula must target one IID mean coefficient."))
    rhs = Dict(f.forms)
    fixed_mu, re, mv, st = _split_ranef(rhs[:mu])
    mv === nothing || throw(ArgumentError("Binomial mixed phylogenetic SD regression cannot use meta_V()."))
    st !== nothing && first(st) === :phylo || throw(ArgumentError(
        "Binomial `sd($species, phylogenetic)` requires `phylo(1 | $species)` in the location formula."))
    tree === nothing && throw(ArgumentError("phylo(1 | $species) needs `tree = …`"))
    last(st) === species || throw(ArgumentError(
        "The phylogenetic SD formula must name the group in `phylo(1 | $(last(st)))`."))
    length(re) == 1 || throw(ArgumentError(
        "Binomial mixed phylogenetic SD regression currently requires one ordinary random intercept."))
    term, group = only(re)
    first(_re_kind(term)) === :intercept || throw(ArgumentError(
        "This Binomial mixed phylogenetic route currently requires an ordinary random intercept."))
    target.group === group || throw(ArgumentError(
        "The ordinary SD formula must name the ordinary effect group `$group`."))
    for (pname, form) in f.forms
        (pname === :mu || pname === ordinary.key || pname === Symbol("sdphy_", species)) && continue
        pname === :sigma && form == ConstantTerm(1) && continue
        throw(ArgumentError(
            "Binomial mixed phylogenetic SD regression supports `mu`, one ordinary SD formula, and one phylogenetic SD formula."))
    end
    all(_formula_response_observed_mask(f, data)) || throw(ArgumentError(
        "Binomial mixed phylogenetic SD regression requires observed responses; remove incomplete rows before fitting."))

    s, ntr = _binomial_response(f, data)
    _, Xmu, nmmu = _design(f.response, fixed_mu, data)
    labels = getproperty(data, species)
    _, tip_index, Gtip = _lss_phylo_group_index(tree, labels, species)
    group_index, Ggroup = _group_index(getproperty(data, group))
    Wgroup, nmgroup = _sd_group_design(f.response, ordinary.rhs, data,
        group_index, Ggroup, group; schema_cache = f.schema_cache,
        schema_key = ordinary.key)
    size(Wgroup, 2) <= Ggroup && rank(Wgroup) == size(Wgroup, 2) ||
        throw(ArgumentError("Binomial ordinary SD design is rank deficient across groups."))
    species_group, Gspecies = _group_index(labels)
    Gspecies == Gtip || error("phylogenetic group indexing changed unexpectedly")
    Wspecies, nmphy = _sd_group_design(f.response, phy_rhs, data, species_group,
        Gspecies, species; schema_cache = f.schema_cache, schema_key = :sd_phylo)
    tip_group = zeros(Int, Gtip)
    for i in eachindex(tip_index)
        ti, gi = tip_index[i], species_group[i]
        tip_group[ti] == 0 || tip_group[ti] == gi || throw(ArgumentError(
            "Phylogenetic SD predictors must be constant within each tree tip."))
        tip_group[ti] = gi
    end
    all(!iszero, tip_group) || throw(ArgumentError(
        "Every tree tip needs a phylogenetic SD predictor."))
    Wtip = Matrix{Float64}(Wspecies[tip_group, :])
    Zphy = Wtip[tip_index, :]
    nint, sint = round.(Int, ntr), round.(Int, s)
    logchoose = [_logfactorial(nint[i]) - _logfactorial(sint[i]) -
                 _logfactorial(nint[i] - sint[i]) for i in eachindex(sint)]
    aux = (s = sint, ntr = nint, logchoose = logchoose)
    Qphy, leaf_node, _ = _poisson_phylo_setup(tree, labels)
    qphy, pμ, pord, pphy = size(Qphy, 1), size(Xmu, 2),
                            size(Wgroup, 2), size(Wtip, 2)
    cholphy = cholesky(Symmetric(Qphy); check = false)
    issuccess(cholphy) || error("phylo(1 | $species) tree precision is not positive definite after root conditioning")
    logdetQphy = logdet(cholphy)
    last_b = zeros(qphy + Ggroup)
    function nll(theta)
        beta = @view theta[1:pμ]
        alpha_ord = @view theta[(pμ + 1):(pμ + pord)]
        alpha_phy = @view theta[(pμ + pord + 1):(pμ + pord + pphy)]
        tau_ord = _binomial_sd_scale(Wgroup * alpha_ord)
        tau_phy = _binomial_sd_scale(Wtip * alpha_phy)
        all(isfinite, tau_ord) && all(isfinite, tau_phy) || return 1e18
        n = length(s)
        A = sparse(vcat(collect(1:n), collect(1:n)),
                   vcat(leaf_node, qphy .+ group_index),
                   vcat(tau_phy[tip_index], tau_ord[group_index]), n, qphy + Ggroup)
        Qord = spdiagm(0 => ones(Ggroup))
        Q = [Qphy spzeros(qphy, Ggroup); spzeros(Ggroup, qphy) Qord]
        logdetQ = logdetQphy
        eta0 = Xmu * beta
        b, ch, ok = _binomial_phylo_ordinary_mode(aux, eta0, A, Q, last_b)
        if !ok
            b, ch, ok = _binomial_phylo_ordinary_mode(aux, eta0, A, Q,
                                                       zeros(length(last_b)))
        end
        ok || return 1e18
        last_b .= b
        eta = eta0 + A * b
        joint = 0.5 * dot(b, Q * b)
        @inbounds for i in eachindex(eta)
            joint += _laplace_value(Val(:binomial), aux, i, eta[i])
        end
        return joint - 0.5 * logdetQ + 0.5 * logdet(ch)
    end
    grad! = function (gradient, theta)
        for j in eachindex(theta)
            h = 2e-4 * (1 + abs(theta[j]))
            offset = zeros(length(theta)); offset[j] = h
            gradient[j] = (nll(theta .+ offset) - nll(theta .- offset)) / (2h)
        end
        gradient
    end
    pbar = clamp(sum(s) / max(sum(ntr), 1), 1e-4, 1 - 1e-4)
    theta0 = zeros(pμ + pord + pphy)
    theta0[1] = log(pbar / (1 - pbar))
    theta0[(pμ + 1):(pμ + pord)] .= Wgroup \ fill(log(0.4), Ggroup)
    theta0[pμ + pord + 1] = log(0.4)
    od = Optim.OnceDifferentiable(nll, grad!, theta0)
    res = Optim.optimize(od, theta0,
        Optim.LBFGS(linesearch = Optim.LineSearches.BackTracking()),
        Optim.Options(g_tol = g_tol, iterations = 250))
    theta_hat = Optim.minimizer(res)
    value = nll(theta_hat)
    gfinal = zeros(length(theta_hat)); grad!(gfinal, theta_hat)
    converged = _laplace_outer_converged(res, value, gfinal, theta_hat, length(s), g_tol)
    V = se ? _vcov_from_fd_hessian(
        _finite_hessian(nll, theta_hat; h = _fd_hessian_step(length(s)));
        context = "joint sparse-Laplace Binomial ordinary and phylogenetic SD regression") :
        fill(NaN, length(theta_hat), length(theta_hat))
    ord_block = _sd_target_block(target)
    ord_range, phy_range = (pμ + 1):(pμ + pord), (pμ + pord + 1):(pμ + pord + pphy)
    blocks = Pair{Symbol,UnitRange{Int}}[:mu => (1:pμ), ord_block => ord_range,
                                         :sd_phylo => phy_range]
    names = Pair{Symbol,Vector{String}}[:mu => nmmu, ord_block => nmgroup,
                                        :sd_phylo => nmphy]
    means = Dict(:mu => _laplace_logistic.(Xmu * theta_hat[1:pμ]))
    obs = Dict(:mu => s ./ ntr)
    tau_ord = _binomial_sd_scale(Wgroup * theta_hat[ord_range])
    tau_phy = _binomial_sd_scale(Wtip * theta_hat[phy_range])
    tau_ord_obs, tau_phy_obs = tau_ord[group_index], tau_phy[tip_index]
    scales = Dict(:trials => Float64.(nint), :sd_group_index => Float64.(group_index),
                  :sd_group => tau_ord, :sd => tau_ord_obs, ord_block => tau_ord_obs,
                  :sd_phylo => tau_phy_obs, :tree_tip_index => Float64.(tip_index))
    fit = DrmFit(fam, blocks, names, theta_hat, Matrix(V), -value, length(s),
                 converged, means, obs, scales)
    return _withformula(_withiterations(_withnll(fit, nll), Optim.iterations(res)), f)
end

function _drm_binomial_sd_regression(f::DrmFormula, fam::Binomial; data,
                                     tree = nothing, K = nothing, A = nothing,
                                     coords = nothing, g_tol::Real = 1e-8,
                                     se::Bool = true, marginal::Symbol = :LA,
                                     method = nothing, nq::Int = _BINOMIAL_RANEF_AGHQ_K)
    _reject_method_as_marginal(fam, method)
    marginal === :LA || throw(ArgumentError(
        "Binomial `sd(group) ~ …` currently supports `marginal = :LA` " *
            "only: one ordinary grouping variable uses adaptive Gauss-Hermite quadrature, " *
            "while crossed independent intercepts or numeric slopes use a Laplace approximation."))
    if !isempty(_sdphylo_parts(f))
        isempty(_sd_parts(f)) && return _drm_binomial_phylo_sd_regression(
            f, fam; data, tree, g_tol, se)
        return _drm_binomial_phylo_ordinary_sd_regression(
            f, fam; data, tree, g_tol, se)
    end
    targets = _sd_target_parts(f)
    if any(item -> item.target.level === :relmat, targets)
        return _drm_binomial_relmat_sd_regression(
            f, fam; data, K, tree, A, coords, g_tol, se,
        )
    end
    if any(item -> item.target.level === :animal, targets)
        return _drm_binomial_animal_sd_regression(
            f, fam; data, A, tree, K, coords, g_tol, se,
        )
    end
    (tree === nothing && K === nothing && A === nothing && coords === nothing) ||
        throw(ArgumentError("Binomial SD regression currently supports ordinary " *
            "random intercepts, numeric slopes, and correlated intercept-slope blocks only; " *
            "structured covariance inputs are not used."))
    isempty(_sdphylo_parts(f)) || throw(ArgumentError(
        "Binomial `sd(group, phylogenetic) ~ …` is not implemented by the ordinary random-effect route."))
    isempty(targets) && throw(ArgumentError("Binomial SD regression needs at least one ordinary SD formula."))
    all(item -> item.target.level === :iid && item.target.dpar === :mu &&
                item.target.block === nothing, targets) || throw(ArgumentError(
        "Binomial ordinary SD regression targets IID mean random-effect coefficients only."))
    rhs = Dict(f.forms)
    fixed_mu, re, mv, st = _split_ranef(rhs[:mu])
    mv === nothing || throw(ArgumentError("Binomial SD regression cannot use meta_V()."))
    st === nothing || throw(ArgumentError("Binomial SD regression does not yet support structured random-effect terms."))
    correlated = length(re) == 1 && first(_re_kind(re[1][1])) === :corr
    if correlated
        1 <= length(targets) <= 2 || throw(ArgumentError(
            "Binomial correlated-block SD regression needs an intercept or slope SD formula, or both."))
    else
        length(re) == length(targets) || throw(ArgumentError(
            "Binomial SD regression requires one SD formula for each independent random-effect coefficient."))
    end
    all(_formula_response_observed_mask(f, data)) || throw(ArgumentError(
        "Binomial random-effect SD regression does not yet support missing responses; " *
        "drop incomplete rows before fitting so the fitted group SD design and bootstrap rows remain aligned."))

    # Resolve each scale formula to one coefficient. The explicit
    # `coef(term)` selector is required for a correlated block.
    re_meta = if correlated
        term, group = only(re)
        kind, slope = _re_kind(term)
        ((; term, group, member = :intercept, kind = :intercept, slope = nothing),
         (; term, group, member = slope, kind = :slope, slope))
    else
        map(re) do (term, group)
            kind, slope = _re_kind(term)
            kind in (:intercept, :slope) || throw(ArgumentError(
                "Binomial SD regression supports independent `(1 | group)`, `(0 + x | group)` terms, or one correlated `(1 + x | group)` block."))
            member = kind === :intercept ? :intercept : slope
            (; term, group, member, kind, slope)
        end
    end
    group_names = unique(x.group for x in re_meta)
    used = Set{Symbol}()
    ordered_targets = Vector{Union{Nothing,eltype(targets)}}(undef, length(re_meta))
    for (j, effect) in enumerate(re_meta)
        matches = filter(targets) do item
            t = item.target
            t.group === effect.group && (t.member === nothing || t.member === effect.member)
        end
        length(matches) <= 1 || throw(ArgumentError(
            "Binomial SD target is ambiguous for correlated coefficients; select `coef(intercept)` or `coef($(effect.member))`."))
        if isempty(matches)
            correlated || throw(ArgumentError(
                "Binomial SD formulas must identify each independent random-effect coefficient exactly once."))
            ordered_targets[j] = nothing
            continue
        end
        target = only(matches)
        target.key in used && throw(ArgumentError("Binomial SD formulas target one random-effect coefficient more than once."))
        push!(used, target.key)
        ordered_targets[j] = target
    end
    length(used) == length(targets) || throw(ArgumentError(
        "Every Binomial SD formula must match a random-effect coefficient in the mean formula."))

    for (pname, _) in f.forms
        (pname === :mu || haskey(f.sd_targets, pname)) && continue
        pname === :sigma && Dict(f.forms)[pname] === ConstantTerm(1) && continue
        throw(ArgumentError("Binomial SD regression is a mean-only model with no residual sigma formula."))
    end

    if length(group_names) > 1
        (!correlated && length(re_meta) == 2 && length(group_names) == 2) ||
            throw(ArgumentError("Binomial SD regression supports two distinct groups only as independent intercept or numeric-slope terms."))
        all(effect -> effect.kind in (:intercept, :slope), re_meta) || throw(ArgumentError(
            "Binomial crossed SD regression supports ordinary intercepts or independent numeric slopes only."))
        s, ntr = _binomial_response(f, data)
        _, Xmu, nmmu = _design(f.response, fixed_mu, data)
        group_indices = [_group_index(getproperty(data, effect.group)) for effect in re_meta]
        loadings = map(re_meta) do effect
            if effect.kind === :intercept
                ones(Float64, length(s))
            else
                hasproperty(data, effect.slope) || throw(ArgumentError(
                    "Binomial random-slope predictor `$(effect.slope)` is absent from data."))
                values = getproperty(data, effect.slope)
                values isa AbstractVector{<:Real} || throw(ArgumentError(
                    "Binomial random-slope predictor `$(effect.slope)` must be numeric."))
                length(values) == length(s) && all(isfinite, values) || throw(ArgumentError(
                    "Binomial random-slope predictor `$(effect.slope)` must contain one finite value per retained response."))
                Float64.(values)
            end
        end
        for (j, effect) in enumerate(re_meta)
            gidx_j, G_j = group_indices[j]
            informative = falses(G_j)
            @inbounds for i in eachindex(loadings[j])
                !iszero(loadings[j][i]) && (informative[gidx_j[i]] = true)
            end
            any(informative) || throw(ArgumentError(
                "Binomial random-slope predictor for `$(effect.group)` must have at least one nonzero retained value."))
        end
        Zgs, nmsds = Matrix{Float64}[], Vector{String}[]
        group_labels = String[]
        for (j, effect) in enumerate(re_meta)
            gidx_j, G_j = group_indices[j]
            target = ordered_targets[j]
            Zg, nmsd = _sd_group_design(f.response, target.rhs, data, gidx_j,
                                        G_j, effect.group;
                                        schema_cache = f.schema_cache,
                                        schema_key = target.key)
            informative = falses(G_j)
            @inbounds for i in eachindex(loadings[j])
                !iszero(loadings[j][i]) && (informative[gidx_j[i]] = true)
            end
            active_design = Zg[findall(informative), :]
            size(Zg, 2) <= size(active_design, 1) &&
                rank(active_design) == size(Zg, 2) || throw(ArgumentError(
                "Binomial SD target for `$(effect.group)` has a rank-deficient design over group levels contributing nonzero random-effect loadings."))
            push!(Zgs, Matrix{Float64}(Zg))
            push!(nmsds, nmsd)
            push!(group_labels, String(effect.group))
        end
        fit = _fit_binomial_crossed_sd_laplace(
            fam, s, ntr, Xmu, Zgs, nmsds,
            group_indices[1][1], group_indices[1][2],
            group_indices[2][1], group_indices[2][2],
            loadings[1], loadings[2],
            nmmu, group_labels, g_tol; se,
            target_blocks = Symbol[_sd_target_block(
                item.target; disambiguate = count(item -> item !== nothing, ordered_targets) > 1,
            ) for item in ordered_targets],
        )
        return _withformula(fit, f)
    end

    s, ntr = _binomial_response(f, data)
    _, Xmu, nmmu = _design(f.response, fixed_mu, data)
    group = first(re_meta).group
    grpcol = getproperty(data, group)
    gidx, G = _group_index(grpcol)
    n = length(s)
    Zre = Matrix{Float64}(undef, n, length(re_meta))
    Zgs = Matrix{Float64}[]
    nmsds = Vector{String}[]
    sd_ranges = UnitRange{Int}[]
    target_blocks = Symbol[]
    for (j, effect) in enumerate(re_meta)
        raw = if effect.kind === :intercept
            ones(n)
        else
            hasproperty(data, effect.slope) || throw(ArgumentError(
                "Binomial random-slope predictor `$(effect.slope)` is absent from data."))
            values = getproperty(data, effect.slope)
            values isa AbstractVector{<:Real} || throw(ArgumentError(
                "Binomial random-slope predictor `$(effect.slope)` must be numeric."))
            all(isfinite, values) || throw(ArgumentError(
                "Binomial random-slope predictor `$(effect.slope)` must contain finite values."))
            Float64.(values)
        end
        Zre[:, j] = raw
        target = ordered_targets[j]
        if target === nothing
            Zg = ones(G, 1)
            nmsd = ["$(group):log_sd_$(effect.member)"]
            push!(target_blocks, Symbol("sdconst_", effect.member))
        else
            Zg, nmsd = _sd_group_design(f.response, target.rhs, data, gidx, G, group;
                                        schema_cache = f.schema_cache,
                                        schema_key = target.key)
            push!(target_blocks, _sd_target_block(
                target.target; disambiguate = length(targets) > 1,
            ))
        end
        size(Zg, 2) <= G && rank(Zg) == size(Zg, 2) || throw(ArgumentError(
            "Binomial SD target for `$(effect.member)` has a rank-deficient group-level design."))
        push!(Zgs, Zg)
        push!(nmsds, nmsd)
    end
    if correlated
        _binomial_check_slope_identifiable(Float64.(Zre[:, 2]), gidx, G, group)
    end
    return _withformula(_fit_binomial_sd_regression(
        fam, s, ntr, Xmu, Zgs, nmsds, gidx, G, nmmu, group, g_tol,
        target_blocks; nq = nq, Zre = Zre, correlated = correlated,
    ), f)
end

function _fit_binomial_sd_regression(fam::Binomial, s, ntr, Xmu, Zgs, nmsds,
                                      gidx, G, nmmu, group, g_tol, target_blocks;
                                      nq::Int = _BINOMIAL_RANEF_AGHQ_K,
                                      Zre = ones(length(s), 1), correlated::Bool = false)
    n = length(s)
    pmu = size(Xmu, 2)
    q = length(Zgs)
    length(Zre) == n * q || throw(ArgumentError("random-effect design dimensions do not match the response"))
    sint, nint = round.(Int, s), round.(Int, ntr)
    members = [Int[] for _ in 1:G]
    for i in 1:n
        push!(members[gidx[i]], i)
    end
    lc = [_logchoose(nint[i], sint[i]) for i in 1:n]
    rule = _AGHQRule(q, nq)
    psd = size.(Zgs, 2)
    is_constant = startswith.(String.(target_blocks), "sdconst_")
    offset = pmu
    sd_ranges = Vector{UnitRange{Int}}(undef, q)
    for j in 1:q
        if !is_constant[j]
            sd_ranges[j] = offset + 1:offset + psd[j]
            offset += psd[j]
        end
    end
    constant_ranges = UnitRange{Int}[]
    constant_names = String[]
    for j in 1:q
        if is_constant[j]
            sd_ranges[j] = offset + 1:offset + psd[j]
            offset += psd[j]
            push!(constant_ranges, sd_ranges[j])
            push!(constant_names, only(nmsds[j]))
        end
    end
    corr_range = correlated ? (offset + 1:offset + 1) : (offset + 1:offset)
    correlated && (offset += 1)
    function nll(theta)
        betamu = @view theta[1:pmu]
        eta0 = Xmu * betamu
        sdgroup = hcat((_binomial_sd_scale(Zgs[j] * @view(theta[sd_ranges[j]])) for j in 1:q)...)
        ll = (i, eta) -> _binomial_logit_ll(nint[i], sint[i], eta, lc[i])
        bcache = zeros(eltype(theta), q, G)
        total = zero(eltype(theta))
        rho = correlated ? tanh(only(@view theta[corr_range])) : zero(eltype(theta))
        for gi in 1:G
            Lg = if correlated
                slope_sd = sdgroup[gi, 2]
                [sdgroup[gi, 1] zero(eltype(theta));
                 rho * slope_sd slope_sd * _binomial_stable_sech(only(@view theta[corr_range]))]
            else
                Matrix(Diagonal(@view(sdgroup[gi, :])))
            end
            value, bhat = _aghq_group_logint(ll, members[gi], eta0, Zre, Lg,
                                               rule, @view(bcache[:, gi]))
            bcache[:, gi] .= ifelse.(isfinite.(bhat), bhat, zero(eltype(theta)))
            total += value
        end
        return -total
    end
    theta0 = zeros(offset)
    pbar = clamp(sum(s) / max(sum(ntr), 1), 1e-3, 1 - 1e-3)
    theta0[1] = log(pbar / (1 - pbar))
    for j in 1:q
        if is_constant[j]
            theta0[sd_ranges[j]] .= log(0.5)
        else
            theta0[sd_ranges[j]] .= Zgs[j] \ fill(log(0.5), G)
        end
    end
    correlated && (theta0[corr_range] .= 0.0)
    res = _optimize_with_fallback(nll, theta0, g_tol)
    thetahat = Optim.minimizer(res)
    V = _vcov_or_nan(ForwardDiff.hessian(nll, thetahat))
    blocks = Pair{Symbol,UnitRange{Int}}[:mu => 1:pmu]
    names = Pair{Symbol,Vector{String}}[:mu => nmmu]
    for j in 1:q
        is_constant[j] && continue
        push!(blocks, target_blocks[j] => sd_ranges[j])
        push!(names, target_blocks[j] => nmsds[j])
    end
    if correlated
        recov_start = isempty(constant_ranges) ? first(corr_range) : first(first(constant_ranges))
        push!(blocks, :recov => (recov_start:last(corr_range)))
        push!(names, :recov => [constant_names; "$(group):atanh_rho"])
    end
    means = Dict(:mu => _logistic.(Xmu * thetahat[1:pmu]))
    obs = Dict(:mu => s ./ ntr)
    sdgroups = [_binomial_sd_scale(Zgs[j] * thetahat[sd_ranges[j]]) for j in 1:q]
    sdobs = [sdgroups[j][gidx] for j in 1:q]
    scales = Dict(:trials => Float64.(nint),
                  :sd_group_index => Float64.(gidx),
                  :aghq_nodes => [Float64(nq)])
    # Preserve historical aliases for a single target. With multiple targets,
    # generic concatenated vectors would have no single-target meaning.
    if q == 1
        scales[:sd_group] = sdgroups[1]
        scales[:sd] = sdobs[1]
    end
    # `marginal_parameters()` follows fitted parameter blocks, so each SD block
    # needs its own row-level values under that exact fitted block name.
    for j in 1:q
        is_constant[j] || (scales[target_blocks[j]] = sdobs[j])
    end
    fit = DrmFit(fam, blocks, names, thetahat, V, -nll(thetahat), n,
        drm_optim_converged(res), means, obs, scales)
    return _withiterations(_withnll(fit, nll), Optim.iterations(res))
end
