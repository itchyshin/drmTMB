# betabinomial.jl — Beta-binomial family: successes out of known trials, with
# extra-binomial overdispersion. Two-column response `cbind(successes, failures)`
# (trials = successes + failures), exactly as drmTMB. Logit link on the mean
# success probability μ; the `sigma` slot is σ with precision φ = 1/σ² (same
# mapping as Beta) — likelihood BetaBinomial(n, μφ, (1-μ)φ). `Distributions.
# BetaBinomial` is used qualified — DRModels exports its own `BetaBinomial` family.

import Distributions

"""
    cbind(successes, failures)

Formula marker for a two-column count response, e.g.
`bf(cbind(successes, failures) ~ x, sigma ~ z)` with [`BetaBinomial`](@ref).
Trials are `successes + failures`. Mirrors drmTMB's `cbind(...)` response.
Only inspected structurally on a formula left-hand side.
"""
cbind(a, b) = hcat(a, b)

# `_LOGIT_GUARD` is an overflow guard, not a model bound: at |η| = 700 a parameter
# is e^-700 ≈ 1e-304 and the likelihood of any observation on the wrong side is
# ≈ -700 nats, so no sane start is ever beaten by the (flat) region beyond it; it only
# keeps `loggamma(0)` / NaN gradients out of the line search.
const _LOGIT_GUARD = 700.0

# BetaBinomial(n, μφ, (1-μ)φ) log-pmf with μ = logistic(η), parameterised directly
# on the logit η and UNCLAMPED: α = φ·σ(η), β = φ·σ(−η) never saturate to 0 until
# |η| ≈ 745, so no clamp is needed to keep the pmf proper. A clamp of η inside the
# objective makes it flat beyond the clamp and lets L-BFGS park on the plateau
# (see `_binomial_logit_ll`). Equal to `Distributions.logpdf(BetaBinomial(...))`
# off the plateau up to rounding.
@inline function _betabinomial_logit_ll(n, k, η, φ)
    η = clamp(η, -_LOGIT_GUARD, _LOGIT_GUARD)
    α = φ * _logistic(η); β = φ * _logistic(-η)
    return _logchoose(n, k) + (loggamma(k + α) + loggamma(n - k + β) - loggamma(n + α + β)) -
           (loggamma(α) + loggamma(β) - loggamma(α + β))
end

"""
    BetaBinomial()

Beta-binomial response family — successes out of known trials with
extra-binomial overdispersion. Logit link on the mean success probability `μ`;
the `sigma` slot carries `σ` with precision `φ = 1/σ²` (so `coef(fit, :sigma)`
is `log σ`). Likelihood `BetaBinomial(n, μφ, (1-μ)φ)`. Requires a two-column
response via [`cbind`](@ref). Mirrors `drmTMB`'s `beta_binomial`.
Crossed random intercepts on the mean, such as `(1 | g) + (1 | h)`, use the
sparse-Laplace engine when `sigma ~ 1`. A phylogenetic random intercept on the
mean, `phylo(1 | species)`, also uses the sparse-Laplace engine; both
routes require constant σ (overdispersion). One ordinary mean random intercept
or one independent numeric mean slope also supports a predictor-dependent SD
with `sd(g) ~ predictors`, provided `sigma ~ 1`; the SD predictors must be
constant within groups. For a random slope, the SD is the coefficient SD and
the observation-level slope predictor multiplies that coefficient in the mean
linear predictor. These routes use adaptive Gauss–Hermite quadrature and do
not add a free Bernoulli-style residual scale.

```julia
fit = drm(bf(cbind(successes, failures) ~ x, sigma ~ 1), BetaBinomial(); data = dat)
fit = drm(bf(cbind(successes, failures) ~ x + (1 | g) + (1 | h), sigma ~ 1), BetaBinomial(); data = dat)
fit_phy = drm(bf(@formula(cbind(successes, failures) ~ x + phylo(1 | species)), @formula(sigma ~ 1)),
              BetaBinomial(); data = dat, tree = tr, se = false)
fit_sd = drm(bf(@formula(cbind(successes, failures) ~ x + (1 | g)),
                @formula(sigma ~ 1), @formula(sd(g) ~ treatment)),
              BetaBinomial(); data = dat)
```
"""
struct BetaBinomial end

function drm(f::DrmFormula, fam::BetaBinomial; data, tree = nothing, g_tol::Real = 1e-8,
             se::Bool = true, marginal::Symbol = :LA)
    !isempty(_sd_parts(f)) &&
        return _drm_betabinomial_sd_regression(f, fam; data, g_tol, se, marginal)
    missing_fit = _fit_observed_response_rows(f, data) do data_observed
        drm(f, fam; data = data_observed, tree = tree, g_tol = g_tol, se = se, marginal = marginal)
    end
    missing_fit !== nothing && return missing_fit

    f.response2 === nothing &&
        error("BetaBinomial() needs a two-column response: bf(cbind(successes, failures) ~ …)")
    marg = _marginal_method(marginal)                     # :LA (default) or :AGHQ (#761)
    isaghq = marg isa AGHQ
    _lss_only_gaussian_guard(f, fam)   # #544: refuse, never silently drop, sd() parts
    rhs = Dict(f.forms)
    fixed_mu, re, mv, st = _split_ranef(rhs[:mu])
    isaghq && !(length(re) > 1 && st === nothing) &&
        _aghq_reject(fam, "this model (BetaBinomial `marginal = :AGHQ` covers crossed random " *
                          "intercepts `(1 | g) + (1 | h)` only, #761)")
    mv === nothing ||
        error("BetaBinomial() does not support meta_V markers")
    for (pname, r) in f.forms          # only the mean may carry a random effect
        pname === :mu && continue
        _, re2, mv2, st2 = _split_ranef(r)
        (isempty(re2) && mv2 === nothing && st2 === nothing) ||
            error("BetaBinomial(): only the mean formula may carry a random effect")
    end
    s = Float64.(getproperty(data, f.response))          # successes
    fl = Float64.(getproperty(data, f.response2))        # failures
    (all(si -> si ≥ 0 && isinteger(si), s) && all(fi -> fi ≥ 0 && isinteger(fi), fl)) ||
        error("BetaBinomial() requires non-negative integer successes and failures")
    ntr = s .+ fl                                        # trials
    _, Xμ, nmμ = _design(f.response, fixed_mu, data)     # successes column is a dummy LHS
    _, Xσ, nmσ = _design(f.response, get(rhs, :sigma, ConstantTerm(1)), data)
    if st !== nothing
        isempty(re) ||
            error("BetaBinomial() phylo structured effects cannot be combined with ordinary random effects yet")
        kind, grp = st
        kind === :phylo ||
            error("BetaBinomial() currently supports only phylo(1 | group) among structured markers")
        tree === nothing && error("phylo(1 | $grp) needs `tree = ...`")
        (size(Xσ, 2) == 1 && all(x -> x == 1.0, @view Xσ[:, 1])) ||
            error("BetaBinomial() phylo(1 | group) currently supports only a constant sigma formula")
        labels = getproperty(data, grp)
        return _withformula(_fit_betabinomial_phylo_laplace(fam, s, ntr, Xμ, labels, tree, nmμ, nmσ, grp, g_tol; se = se), f)
    end
    if !isempty(re)                    # random effect on the logit mean → GHQ/Laplace
        if length(re) > 1
            all(_re_kind(r[1])[1] === :intercept for r in re) ||
                error("BetaBinomial() supports multiple random effects only as crossed/nested intercepts, e.g. `(1 | g) + (1 | h)`")
            (size(Xσ, 2) == 1 && all(x -> x == 1.0, @view Xσ[:, 1])) ||
                error("BetaBinomial() crossed random intercepts currently support only a constant sigma formula")
            comps = map(re) do r
                grp = r[2]; gidx, G = _group_index(getproperty(data, grp))
                (ones(length(s)), gidx, G, String(grp))
            end
            isaghq && return _withformula(_fit_betabinomial_crossed_aghq(fam, s, ntr, Xμ, comps, nmμ, nmσ, g_tol; se = se), f)   # #761
            return _withformula(_fit_betabinomial_crossed_laplace(fam, s, ntr, Xμ, comps, nmμ, nmσ, g_tol; se = se), f)
        end
        (rk, var) = _re_kind(re[1][1]); grp = re[1][2]; gidx, G = _group_index(getproperty(data, grp))
        if rk === :intercept                              # (1 | g) → 1-D GHQ
            return _withformula(_fit_betabinomial_ranef(fam, s, ntr, Xμ, Xσ, gidx, G, nmμ, nmσ, grp, g_tol), f)
        elseif rk === :corr                               # (1 + x | g) → 2-D GHQ
            xs = Float64.(getproperty(data, var))
            return _withformula(_fit_betabinomial_corr_ranef(fam, s, ntr, Xμ, Xσ, xs, gidx, G, nmμ, nmσ, grp, g_tol), f)
        else
            error("BetaBinomial() supports `(1 | g)` or `(1 + x | g)` random effects on the mean")
        end
    end
    return _withformula(_fit_betabinomial(fam, s, ntr, Xμ, Xσ, nmμ, nmσ, g_tol), f)
end

# Predictor-dependent SD for one ordinary IID mean intercept or independent
# numeric slope on the logit scale. BetaBinomial overdispersion remains fixed.
function _drm_betabinomial_sd_regression(f::DrmFormula, fam::BetaBinomial; data,
                                         g_tol::Real = 1e-8, se::Bool = true,
                                         marginal::Symbol = :LA,
                                         nAGQ::Int = _RANEF1D_AGHQ_K)
    marginal === :LA || throw(ArgumentError(
        "BetaBinomial `sd(group) ~ …` currently supports `marginal = :LA` only."))
    nAGQ >= 1 || throw(ArgumentError("nAGQ must be ≥ 1; got $nAGQ"))
    f.response2 === nothing && throw(ArgumentError(
        "BetaBinomial() needs a two-column response: bf(cbind(successes, failures) ~ …)"))
    targets = _sd_target_parts(f)
    length(targets) == 1 || throw(ArgumentError(
        "BetaBinomial random-effect SD regression requires exactly one `sd(group) ~ …` formula."))
    target = only(targets)
    descriptor = target.target
    (descriptor.level === :iid && descriptor.dpar === :mu &&
     descriptor.block === nothing) || throw(ArgumentError(
        "BetaBinomial SD regression targets only one ordinary mean intercept or independent numeric slope."))
    grp, sd_rhs = descriptor.group, target.rhs
    rhs = Dict(f.forms)
    fixed_mu, re, mv, st = _split_ranef(rhs[:mu])
    mv === nothing || throw(ArgumentError("BetaBinomial `sd($grp)` cannot use meta_V()."))
    st === nothing || throw(ArgumentError(
        "BetaBinomial `sd($grp)` currently requires one ordinary `(1 | $grp)` effect."))
    length(re) == 1 || throw(ArgumentError(
        "BetaBinomial `sd($grp)` currently requires exactly one ordinary random-effect coefficient."))
    kind, slope = _re_kind(re[1][1])
    member = kind === :intercept ? :intercept : kind === :slope ? slope : nothing
    kind in (:intercept, :slope) || throw(ArgumentError(
        "BetaBinomial `sd($grp)` supports `(1 | $grp)` or one independent numeric `(0 + x | $grp)` term; correlated blocks are not implemented."))
    descriptor.member in (nothing, member) || throw(ArgumentError(
        "BetaBinomial SD target `coef($(descriptor.member))` does not match the fitted random-effect coefficient `$(member)`."))
    regrp = re[1][2]
    regrp === grp || throw(ArgumentError(
        "BetaBinomial `sd($grp)` must name the random-effect grouping variable `$regrp`."))
    sigma_rhs = get(rhs, :sigma, nothing)
    sigma_rhs isa ConstantTerm && sigma_rhs == ConstantTerm(1) || throw(ArgumentError(
        "BetaBinomial `sd($grp)` requires a fixed `sigma ~ 1` overdispersion submodel."))
    for (pname, _) in f.forms
        (pname in (:mu, :sigma, Symbol("sd_", grp)) ||
         haskey(f.sd_targets, pname)) && continue
        throw(ArgumentError(
            "BetaBinomial `sd($grp)` supports only `mu`, fixed `sigma ~ 1`, and one `sd($grp)` formula."))
    end
    all(_formula_response_observed_mask(f, data)) || throw(ArgumentError(
        "BetaBinomial random-effect SD regression requires observed responses; remove incomplete rows before fitting."))

    successes = Float64.(getproperty(data, f.response))
    failures = Float64.(getproperty(data, f.response2))
    (all(isfinite, successes) && all(isfinite, failures) &&
     all(x -> x >= 0 && isinteger(x), successes) &&
     all(x -> x >= 0 && isinteger(x), failures)) || throw(ArgumentError(
        "BetaBinomial() requires finite non-negative integer successes and failures"))
    trials = successes .+ failures
    all(>(0), trials) || throw(ArgumentError(
        "BetaBinomial random-effect SD regression requires positive trial counts"))
    _, Xmu, nmmu = _design(f.response, fixed_mu, data)
    _, Xsigma, nmsigma = _design(f.response, sigma_rhs, data)
    gidx, G = _group_index(getproperty(data, grp))
    Wsd, nmsd = _sd_group_design(f.response, sd_rhs, data, gidx, G, grp;
                                 schema_cache = f.schema_cache,
                                 schema_key = target.key)
    size(Wsd, 2) <= G && rank(Wsd) == size(Wsd, 2) || throw(ArgumentError(
        "BetaBinomial `sd($grp)` group-level design is rank deficient; use predictors that vary independently across groups."))
    Zre = if kind === :intercept
        ones(length(successes), 1)
    else
        hasproperty(data, slope) || throw(ArgumentError(
            "BetaBinomial random-slope predictor `$slope` is absent from data."))
        values = getproperty(data, slope)
        values isa AbstractVector{<:Real} || throw(ArgumentError(
            "BetaBinomial random-slope predictor `$slope` must be numeric."))
        length(values) == length(successes) && all(isfinite, values) || throw(ArgumentError(
            "BetaBinomial random-slope predictor `$slope` must contain one finite value per response."))
        reshape(Float64.(values), :, 1)
    end
    return _withformula(_fit_betabinomial_sd_regression(fam, successes, trials,
        Xmu, Xsigma, Zre, Wsd, gidx, G, nmmu, nmsigma, nmsd, grp, g_tol;
        nAGQ, se), f)
end

function _fit_betabinomial_sd_regression(fam::BetaBinomial, successes, trials,
                                         Xmu, Xsigma, Zre, Wsd, gidx, G,
                                         nmmu, nmsigma, nmsd, grp, g_tol;
                                         nAGQ::Int = _RANEF1D_AGHQ_K,
                                         se::Bool = true)
    n = length(successes)
    pmu, psigma, psd = size(Xmu, 2), size(Xsigma, 2), size(Wsd, 2)
    sint, nint = round.(Int, successes), round.(Int, trials)
    members = [Int[] for _ in 1:G]
    for i in 1:n
        push!(members[gidx[i]], i)
    end
    rule = _AGHQRule(1, nAGQ)
    bcache = zeros(1, G)
    function nll(theta)
        beta_mu = @view theta[1:pmu]
        beta_sigma = @view theta[(pmu+1):(pmu+psigma)]
        alpha = @view theta[(pmu+psigma+1):(pmu+psigma+psd)]
        eta_mu = Xmu * beta_mu
        eta_sigma = clamp.(Xsigma * beta_sigma, -15.0, 15.0)
        sd_group = exp.(Wsd * alpha)
        ll = (i, eta) -> _betabinomial_logit_ll(
            nint[i], sint[i], eta, exp(-2 * eta_sigma[i]))
        total = zero(eltype(theta))
        for gi in 1:G
            Lg = reshape([sd_group[gi]], 1, 1)
            value, bhat = _aghq_group_logint(ll, members[gi], eta_mu,
                Zre, Lg, rule, @view(bcache[:, gi]))
            bcache[1, gi] = isfinite(bhat[1]) ? bhat[1] : 0.0
            total += value
        end
        return -total
    end
    pbar = clamp(sum(successes) / max(sum(trials), 1), 1e-3, 1 - 1e-3)
    theta0 = zeros(pmu + psigma + psd)
    theta0[1] = log(pbar / (1 - pbar))
    theta0[pmu+1] = -0.5 * log(10.0)
    theta0[(pmu+psigma+1):end] .= Wsd \ fill(log(0.5), G)
    result = Optim.optimize(nll, theta0, Optim.LBFGS(),
        Optim.Options(g_tol = g_tol); autodiff = :forward)
    theta_hat = Optim.minimizer(result)
    V = se ? _vcov_from_hessian(ForwardDiff.hessian(nll, theta_hat)) :
             fill(NaN, length(theta_hat), length(theta_hat))
    blocks = [:mu => 1:pmu, :sigma => (pmu+1):(pmu+psigma),
              :sd => (pmu+psigma+1):(pmu+psigma+psd)]
    names = [:mu => nmmu, :sigma => nmsigma, :sd => nmsd]
    sd_group = exp.(Wsd * theta_hat[(pmu+psigma+1):end])
    means = Dict(:mu => _logistic.(Xmu * theta_hat[1:pmu]))
    observed = Dict(:mu => successes ./ trials)
    scales = Dict(:sigma => exp.(Xsigma * theta_hat[(pmu+1):(pmu+psigma)]),
                  :sd_group => sd_group, :sd => sd_group[gidx],
                  :sd_group_index => Float64.(gidx), :trials => Float64.(nint),
                  :aghq_nodes => [Float64(nAGQ)])
    return _withiterations(_withnll(DrmFit(fam, blocks, names, theta_hat, V,
        -nll(theta_hat), n, Optim.converged(result), means, observed, scales), nll),
        Optim.iterations(result))
end

# Beta-binomial GLMM with a random intercept (1|g) on the logit mean. b_g ~ N(0,σ_b²)
# integrated out per group by 32-node Gauss–Hermite quadrature (b = √2 σ_b z); the
# precision φ = 1/σ² stays a fixed effect. Same scheme as the Gamma/count GLMMs.
function _fit_betabinomial_ranef(fam::BetaBinomial, s, ntr, Xμ, Xσ, gidx, G, nmμ, nmσ, grp, g_tol; K::Int = _RANEF1D_AGHQ_K)
    n = length(s); pμ, pσ = size(Xμ, 2), size(Xσ, 2)
    sint = round.(Int, s); nint = round.(Int, ntr)
    members = [Int[] for _ in 1:G]
    for i in 1:n
        push!(members[gidx[i]], i)
    end
    rule = _AGHQRule(1, K); Zre = ones(n, 1); bcache = zeros(1, G)   # #719: per-group AGHQ
    function nll(θ)
        βμ = θ[1:pμ]; βσ = θ[pμ+1:pμ+pσ]; σb = exp(θ[pμ+pσ+1])
        η0 = Xμ * βμ; ησ = clamp.(Xσ * βσ, -15.0, 15.0)
        ll = (i, η) -> _betabinomial_logit_ll(nint[i], sint[i], η, exp(-2 * ησ[i]))
        L = reshape([σb], 1, 1)
        return -_aghq_marginal_loglik(ll, members, η0, Zre, L, rule, bcache)
    end
    p̄ = clamp(sum(s) / max(sum(ntr), 1), 1e-3, 1 - 1e-3)
    θ0 = zeros(pμ + pσ + 1)
    θ0[1] = log(p̄ / (1 - p̄))                                # logit p̄
    θ0[pμ+1] = -0.5 * log(10.0)                             # moderate precision init (φ ≈ 10)
    θ0[pμ+pσ+1] = log(0.5)
    res = _optimize_with_fallback(nll, θ0, g_tol)
    θ̂ = Optim.minimizer(res); V = _vcov_or_nan(ForwardDiff.hessian(nll, θ̂))
    blocks = [:mu => 1:pμ, :sigma => (pμ+1):(pμ+pσ), :resd => (pμ+pσ+1):(pμ+pσ+1)]
    names = [:mu => nmμ, :sigma => nmσ, :resd => [String(grp)]]
    means = Dict(:mu => _logistic.(Xμ * θ̂[1:pμ])); obs = Dict(:mu => s ./ ntr)   # population μ (b=0)
    scales = Dict(:sigma => exp.(Xσ * θ̂[(pμ+1):(pμ+pσ)]), :trials => Float64.(nint))
    return _withiterations(
        _withnll(DrmFit(fam, blocks, names, θ̂, V, -nll(θ̂), n, drm_optim_converged(res), means, obs, scales), nll),
        Optim.iterations(res))
end

# Beta-binomial GLMM with a correlated random intercept+slope (1 + x | g) on the
# logit mean. Per group (b0,b1) ~ N(0, Σ); logit μ_i = Xμ_iᵀβ + b0_g + b1_g·x_i.
# Because groups are disjoint the per-group 2-D integral factorises; it is done by
# per-group ADAPTIVE Gauss–Hermite quadrature
# (`_aghq_marginal_loglik`, #834: nodes b̂_g + √2 C z at each group's mode), `nq` nodes per axis. Σ is the log-Cholesky
# parameterisation L = [exp(a) 0; cc exp(b)] (the `vc` convention), so vc(fit)
# reconstructs Σ = L Lᵀ. The precision φ = 1/σ² stays a fixed effect.
function _fit_betabinomial_corr_ranef(fam::BetaBinomial, s, ntr, Xμ, Xσ, xs, gidx, G, nmμ, nmσ, grp, g_tol; nq::Int = _CORR_RANEF_AGHQ_K)
    n = length(s); pμ, pσ = size(Xμ, 2), size(Xσ, 2)
    sint = round.(Int, s); nint = round.(Int, ntr)
    members = [Int[] for _ in 1:G]
    for i in 1:n
        push!(members[gidx[i]], i)
    end
    rule = _AGHQRule(2, nq); Zre = hcat(ones(n), Float64.(xs)); bcache = zeros(2, G)   # #834: per-group AGHQ
    function nll(θ)
        βμ = θ[1:pμ]; βσ = θ[pμ+1:pμ+pσ]
        L = _corr_ranef_L(θ[pμ+pσ+1], θ[pμ+pσ+2], θ[pμ+pσ+3])
        η0 = Xμ * βμ; ησ = clamp.(Xσ * βσ, -15.0, 15.0)
        ll = (i, η) -> _betabinomial_logit_ll(nint[i], sint[i], η, exp(-2 * ησ[i]))
        return -_aghq_marginal_loglik(ll, members, η0, Zre, L, rule, bcache)
    end
    p̄ = clamp(sum(s) / max(sum(ntr), 1), 1e-3, 1 - 1e-3)
    θ0 = zeros(pμ + pσ + 3)
    θ0[1] = log(p̄ / (1 - p̄))                                # logit p̄
    θ0[pμ+1] = -0.5 * log(10.0)                             # moderate precision init (φ ≈ 10)
    θ0[pμ+pσ+1] = log(0.4); θ0[pμ+pσ+2] = log(0.4); θ0[pμ+pσ+3] = 0.0
    res = _optimize_with_fallback(nll, θ0, g_tol)
    θ̂ = Optim.minimizer(res); V = _vcov_or_nan(ForwardDiff.hessian(nll, θ̂))
    blocks = [:mu => 1:pμ, :sigma => (pμ+1):(pμ+pσ), :recov => (pμ+pσ+1):(pμ+pσ+3)]
    names = [:mu => nmμ, :sigma => nmσ, :recov => ["$(grp):L11", "$(grp):L22", "$(grp):L21"]]
    means = Dict(:mu => _logistic.(Xμ * θ̂[1:pμ])); obs = Dict(:mu => s ./ ntr)
    scales = Dict(:sigma => exp.(Xσ * θ̂[(pμ+1):(pμ+pσ)]), :trials => Float64.(nint))
    return _withiterations(
        _withnll(DrmFit(fam, blocks, names, θ̂, V, -nll(θ̂), n, drm_optim_converged(res), means, obs, scales), nll),
        Optim.iterations(res))
end

function _fit_betabinomial(fam::BetaBinomial, s, ntr, Xμ, Xσ, nmμ, nmσ, g_tol)
    n = length(s); pμ, pσ = size(Xμ, 2), size(Xσ, 2)
    sint = round.(Int, s); nint = round.(Int, ntr)
    function nll(θ)
        βμ = θ[1:pμ]; βσ = θ[pμ+1:pμ+pσ]
        ημ = Xμ * βμ                             # unclamped: see `_betabinomial_logit_ll`
        ησ = clamp.(Xσ * βσ, -15.0, 15.0)        # φ = exp(-2ησ) > 0 finite
        v = zero(eltype(θ))
        @inbounds for i in 1:n
            v -= _betabinomial_logit_ll(nint[i], sint[i], ημ[i], exp(-2 * ησ[i]))
        end
        return v
    end
    p̄ = clamp(sum(s) / max(sum(ntr), 1), 1e-3, 1 - 1e-3)   # overall success rate
    θ0 = zeros(pμ + pσ)
    θ0[1] = log(p̄ / (1 - p̄))                                # logit p̄
    θ0[pμ+1] = -0.5 * log(10.0)                             # moderate precision init (φ ≈ 10)
    res = Optim.optimize(nll, θ0, Optim.LBFGS(), Optim.Options(g_tol = g_tol); autodiff = :forward)
    θ̂ = Optim.minimizer(res); V = _vcov_from_hessian(ForwardDiff.hessian(nll, θ̂))
    blocks = [:mu => 1:pμ, :sigma => (pμ+1):(pμ+pσ)]
    names = [:mu => nmμ, :sigma => nmσ]
    means = Dict(:mu => _logistic.(Xμ * θ̂[1:pμ]))           # fitted mean success probability
    obs = Dict(:mu => s ./ ntr)                             # observed proportion (for residuals)
    scales = Dict(:sigma => exp.(Xσ * θ̂[(pμ+1):(pμ+pσ)]), :trials => Float64.(nint))
    return _withiterations(
        _withnll(DrmFit(fam, blocks, names, θ̂, V, -nll(θ̂), n, drm_optim_converged(res), means, obs, scales), nll),
        Optim.iterations(res))
end
