# poisson.jl — Poisson family for count responses. Log link on the mean
# (λ = exp(Xμβ)); no residual dispersion parameter (see the negative-binomial
# family for overdispersed counts). Fixed and random effects, maximum likelihood.
# Mirrors drmTMB's
# `poisson`. The log-pmf is written out explicitly (y·log λ − λ − log y!) so the
# fit needs no `Distributions.Poisson` — that name is left to Distributions.

"""
    Poisson()

Poisson response family for counts: log link on the mean `μ` (so `μ` coefficients
act on `log λ`). No residual scale parameter. Mirrors `drmTMB`'s `poisson` family.

!!! note
    `DRModels.Poisson` shadows `Distributions.Poisson`; if you need the distribution
    too (e.g. to simulate), qualify it as `Distributions.Poisson`.

```julia
fit = drm(bf(y ~ x), Poisson(); data = dat)
fitted(fit)        # fitted counts λ = exp(Xβ̂), on the response scale

# Regress the SD of an ordinary Poisson random intercept on a group-level
# predictor. Each value of z must be constant within its group g.
fit_sd = drm(bf(@formula(y ~ x + (1 | g)), @formula(sd(g) ~ z)),
             Poisson(); data = dat)
length(predict_parameters(fit_sd, dat)[:sd])  # one value per observation

# A known-exposure offset (#727, drmTMB twin gap): `offset(log_exposure)`'s
# coefficient is fixed at 1, so λ = exposure · exp(Xβ̂). Fixed-effects-only mean.
fit_off = drm(bf(y ~ x + offset(log_exposure)), Poisson(); data = dat)

fit_phy = drm(bf(@formula(y ~ x + phylo(1 | species))), Poisson();
              data = dat, tree = tr, se = false)

# A predictor-dependent SD for one animal slope-only mean coefficient.
# `sd(animal, animal) ~ habitat` models the coefficient SD by animal;
# the row-level random contribution is `x * b_animal`.
fit_animal_sd = drm(
    bf(@formula(y ~ x + animal(0 + x | animal)),
       @formula(sd(animal, animal) ~ habitat)),
    Poisson(); data = dat, A = A)

# Experimental: Poisson random-intercept variational (ELBO) marginal.
# Default remains `marginal = :LA` (GHQ-32 on an ordinary `(1 | g)`). `loglik` on a VA fit is an ELBO.
fit_va = drm(bf(@formula(y ~ x + (1 | g))), Poisson(); data = dat, marginal = :VA)

# TMB-convention Laplace on an ordinary `(1 | g)`, as native drmTMB fits it (ML only).
fit_lap = drm(bf(@formula(y ~ x + (1 | g))), Poisson(); data = dat, marginal = :Laplace)

# Opt-in Cox–Reid restricted estimation. ML is the default.
fit_reml = drm(bf(@formula(y ~ x + (1 | g))), Poisson(); data = dat, method = :REML)
estimation_method(fit_reml)   # :REML

# Opt-in 1-D Liu–Pierce AGHQ for `(1 | g)` only. Default `:LA` stays
# non-adaptive GHQ-32. k=1 ≡ 1-point Laplace; this identity does not establish
# parameter recovery. `:REML` is not available with `:AGHQ`.
fit_aghq = drm(bf(@formula(y ~ x + (1 | g))), Poisson();
               data = dat, marginal = :AGHQ, nAGQ = 5)
fit_aghq.marginal   # :AGHQ

fit_phy_reml = drm(bf(@formula(y ~ x + phylo(1 | species))), Poisson();
                   data = dat, tree = tr, se = false, method = :REML)
```

For an ordinary random-intercept route, the group SD follows
log(s_g) = Z_g α and uses adaptive Gauss–Hermite quadrature. One independent
numeric random slope is also supported. Sparse-Laplace routes support a
predictor-dependent SD for one phylogenetic or related-matrix mean intercept,
and an animal mean intercept or slope-only coefficient. For an animal slope,
`sd(animal, animal) ~ z` models the SD of the coefficient multiplying `x`;
each row contributes `xᵢ b_g` to the log mean. The SD predictors must be
constant within animal. Supplied `A` is normalized to a unit-diagonal
correlation before the animal SD scales the coefficient, matching the Julia
Poisson constant-SD convention. Ordinary IID intercept and slope SD routes,
and structured phylogenetic, related-matrix, and animal SD routes, accept a
fixed `offset(...)` in the mean formula. For an animal intercept, callers may instead
supply a positive-definite precision matrix with `Ainv`; Julia uses it directly
as `Q` in the latent covariance `D Q⁻¹ D`. Its rows and columns must follow the
first-seen animal order. The non-SD Poisson animal-slope route uses the same
covariance scaling. Correlated blocks, zero-inflation/hurdle terms, and REML
for animal slopes are not supported with these routes. Profile and
bootstrap methods are available as fit-level plumbing; their interval coverage
has not been calibrated.

# Restricted (Cox–Reid) estimation

`method = :REML` is **opt-in — ML remains the default**. It maximises the Cox–Reid
adjusted profile likelihood `ℓ_ML − ½·log|I_ββ|` on two Poisson routes:

- a scalar random intercept `(1 | g)` integrated by GHQ-32
- phylogenetic / `relmat` / `animal` / precomputed-spatial Laplace
  (`_fit_poisson_general_laplace`)

On the Gaussian route this correction is exactly Patterson–Thompson REML, so the
mechanism is anchored rather than ad hoc.

!!! warning "Limited evidence for phylogenetic models"
    A 16-tip / 12-seed Poisson phylo cell over-corrected under Cox–Reid
    (ML +8.18%, CR +17.41%). Do not read those percentages as a bias-sign
    headline or a reason to prefer `:REML` on trees. Recovery on larger trees
    has not been established. This is a small exploratory result, not a general
    performance claim.

!!! warning "It over-corrects when clusters are plentiful"
    On a Poisson `(1 | g)` cell with true `σ_b = 0.6` and 6 observations per cluster,
    ML was **−12.4%** at `G = 10` where Cox–Reid was **−1.8%** — but by `G = 40` ML was
    **+1.4%** and Cox–Reid **+4.4%**. Reach for it when clusters are few, not by habit.
    That asymmetry is why ML is the default.

Crossed intercepts, correlated slopes `(1 + x | g)`, coordinate-spatial with
estimated range `ρ`, fixed-effects-only, `zi`/`hu`, `marginal = :VA`, and
`marginal = :AGHQ` still error on `method = :REML` rather than silently
returning an ML fit. REML
log-likelihoods are not comparable across different fixed-effect structures, so
do not use them for model selection over `μ`.
"""
struct Poisson end

_logfactorial(k::Integer) = sum(log, 2:k; init = 0.0)   # log k!  (0 for k = 0, 1)

# ---- offset() on the Poisson mean (#727, drmTMB twin gap) ------------------
# `offset(x)` is a marker function, exactly like `phylo`/`relmat`/`meta_V`: the
# `@formula` macro captures `offset(log_exposure)` as a `FunctionTerm` and
# `_extract_offset` (below) intercepts it before the mean design matrix is
# built, so it never becomes an ordinary estimated covariate. Its coefficient
# is fixed at 1 (an offset, not a regressor): `η = Xμβ + offset`.
offset(x) = x

# Split an `offset(...)` marker off a (already `_split_ranef`-stripped) rhs,
# returning `(rhs_without_offset, offset_term_or_nothing)`. At most one
# `offset(...)` term is admitted, matching drmTMB (`y ~ x + offset(log_exposure)`).
function _extract_offset(rhs)
    terms = rhs isa Tuple ? collect(rhs) : Any[rhs]
    fixed = Any[]
    offset_term = nothing
    for t in terms
        if t isa FunctionTerm && t.f === offset
            offset_term === nothing ||
                error("Poisson(): only one `offset(...)` term is supported")
            length(t.args) == 1 ||
                error("Poisson(): `offset(...)` takes exactly one term, e.g. `offset(log_exposure)`")
            offset_term = t.args[1]
        else
            push!(fixed, t)
        end
    end
    fixed_rhs = isempty(fixed) ? ConstantTerm(1) :
                length(fixed) == 1 ? fixed[1] : Tuple(fixed)
    return fixed_rhs, offset_term
end

# Evaluate an `offset(...)` term (a plain column reference or an arbitrary
# numeric transform, e.g. `offset(log(exposure))`) to a `Float64` vector, reusing
# the same schema/modelcols machinery `_design` uses for ordinary terms — but with
# NO `StatisticalModel` context, so no implicit intercept column is inserted.
function _offset_vector(offset_term, data)
    sch = schema(offset_term, data)
    t = apply_schema(offset_term, sch)
    v = modelcols(t, data)
    v isa AbstractMatrix && size(v, 2) == 1 && (v = vec(v))
    v isa AbstractVector ||
        error("Poisson(): `offset(...)` must resolve to a single numeric column")
    return Float64.(v)
end

function drm(f::DrmFormula, fam::Poisson; data, tree = nothing, K = nothing,
             A = nothing, Ainv = nothing, coords = nothing,
             g_tol::Real = 1e-8, se::Bool = true,
             marginal::Symbol = :LA, method = nothing, nAGQ::Int = 5)
    # `method` is the ML/REML selector. LA/VA/AGHQ is `marginal` (Q1 / #136 / #448).
    # `:REML` is the opt-in Cox–Reid restricted objective, admitted on Poisson
    # `(1 | g)` GHQ under `:LA` (#443) and on `_fit_poisson_general_laplace`
    # callers (phylo / relmat / animal / precomputed spatial; #450). `:REML` ×
    # `:AGHQ` is not wired. Every other route calls `_reject_reml_route` rather
    # than ignoring the request.
    meth = _reject_method_as_marginal(fam, method; allow_reml = true)
    reml = meth === :REML
    if !isempty(_sd_parts(f)) || !isempty(_sdphylo_parts(f))
        return _drm_poisson_sd_regression(f, fam; data, tree, K, A, Ainv, coords,
            g_tol, se, marginal, reml, nAGQ)
    end
    Ainv === nothing || throw(ArgumentError(
        "Poisson `Ainv` is currently supported for predictor-dependent animal SD regression only."))
    _scalar_laplace_requested(marginal) &&     # Arc 2: TMB-convention Laplace, ordinary (1 | g)
        return _drm_ordinary_laplace(f, fam; data = data, tree = tree, K = K, A = A,
                                     coords = coords, g_tol = g_tol, se = se, method = method)

    missing_fit = _fit_observed_response_rows(f, data) do data_observed
        drm(f, fam; data = data_observed, tree = tree, K = K, A = A,
            coords = coords, g_tol = g_tol, se = se, marginal = marginal,
            method = method, nAGQ = nAGQ)
    end
    missing_fit !== nothing && return missing_fit

    marg = _marginal_method(marginal)                     # :LA (default), :VA (#136), :AGHQ (#448)
    isva = marg isa Variational
    isaghq = marg isa AGHQ
    _lss_only_gaussian_guard(f, fam)   # #544: refuse, never silently drop, sd() parts
    rhs = Dict(f.forms)
    fixed_mu, re, mv, st, _, _, animal_slope =
        _split_ranef(rhs[:mu]; allow_animal_slope = true)
    mv === nothing ||
        error("Poisson() does not support meta_V markers")
    fixed_mu, offset_term = _extract_offset(fixed_mu)     # #727: offset(log_exposure), coefficient fixed at 1
    y, Xμ, nmμ = _design(f.response, fixed_mu, data)
    off = offset_term === nothing ? zeros(length(y)) : _offset_vector(offset_term, data)
    length(off) == length(y) ||
        error("Poisson(): `offset(...)` must have one value per observation")
    all(yi -> yi ≥ 0 && isinteger(yi), y) ||
        error("Poisson() requires non-negative integer counts as the response")
    if offset_term !== nothing && (st !== nothing || !isempty(re) || haskey(rhs, :zi) || haskey(rhs, :hu))
        error("Poisson(): `offset(...)` is currently only supported on the fixed-effects-only " *
              "mean (no random effect, structured marker, `zi`, or `hu`)")
    end
    if st !== nothing
        isva && _va_reject(fam, "a phylogenetic/structured random effect")
        isaghq && _aghq_reject(fam, "a phylogenetic/structured random effect")
        # Phylo / relmat / animal / precomputed spatial share `_fit_poisson_general_laplace`
        # and admit opt-in Cox–Reid (#450). Probe Cell D is not a recovery headline —
        # the docstring warning is the honesty ledger. Coordinate-spatial with
        # jointly estimated ρ is a different fitter and stays rejected. AGHQ stays
        # rejected here (#448): 1-D Liu–Pierce is Poisson `(1 | g)` only.
        isempty(re) ||
            error("Poisson() structured effects cannot be combined with ordinary random effects yet")
        (haskey(rhs, :zi) || haskey(rhs, :hu)) &&
            error("Poisson() structured effects cannot be combined with `zi`/`hu` yet")
        kind, grp = st
        labels = getproperty(data, grp)
        if animal_slope !== nothing
            kind === :animal || throw(ArgumentError(
                "Poisson() supports a structured random slope only for `animal(0 + x | group)`."))
            isempty(re) || throw(ArgumentError(
                "Poisson() animal random slopes cannot yet be combined with ordinary random effects."))
            (haskey(rhs, :zi) || haskey(rhs, :hu)) && throw(ArgumentError(
                "Poisson() animal random slopes cannot yet be combined with `zi` or `hu`."))
            fixed_mu, slope_offset = _extract_offset(fixed_mu)
            slope_offset === nothing || throw(ArgumentError(
                "Poisson() animal random slopes do not yet support `offset(...)`."))
            _, Xslope_mu, nmslope_mu = _design(f.response, fixed_mu, data)
            slope_loading = _poisson_animal_slope_loading(data, animal_slope, length(y))
            C = _poisson_structured_cov(kind, grp, K, A, coords)
            fit = _fit_poisson_animal_slope_laplace(
                fam, y, Xslope_mu, slope_loading, C, labels, nmslope_mu,
                grp, g_tol; se, reml)
            return _withformula(fit, f)
        end
        if kind === :phylo
            tree === nothing && error("phylo(1 | $grp) needs `tree = …`")
            return _withformula(_fit_poisson_phylo_laplace(fam, y, Xμ, labels, tree, nmμ, grp, g_tol;
                                                          se = se, reml = reml), f)
        elseif kind === :spatial && K === nothing && coords !== nothing
            # Coordinate-based exponential-kernel spatial covariance with the range
            # ρ ESTIMATED JOINTLY (#270): C(ρ) = exp(-d/ρ) from the site distances,
            # ρ enters the outer parameter vector, and its gradient flows through
            # C(ρ) → Q(ρ) → the Laplace marginal. The coordinate-spatial twin of the
            # Gaussian `_fit_spatial_gaussian` path, on the Poisson Laplace spine.
            reml && _reject_reml_route(fam, "coordinate-based spatial with jointly estimated range ρ")
            return _withformula(_fit_poisson_spatial_coord(fam, y, Xμ, labels, coords, nmμ, grp, g_tol; se = se), f)
        elseif kind === :relmat || kind === :animal || kind === :spatial
            # General user-supplied PD covariance C on the mean intercept
            # (relatedness / animal model / PRECOMPUTED spatial). Reuses the phylo
            # sparse-Laplace spine with the tree precision swapped for C⁻¹ (#167).
            C = _poisson_structured_cov(kind, grp, K, A, coords)
            return _withformula(_fit_poisson_relmat_laplace(fam, y, Xμ, C, labels, nmμ, grp, g_tol;
                                                           se = se, reml = reml), f)
        else
            error("Poisson() supports phylo/relmat/animal/spatial(1 | group) among structured markers")
        end
    end
    if !isempty(re)                                       # random intercept (1|g) → GHQ marginal
        isva && (haskey(rhs, :zi) || haskey(rhs, :hu)) &&
            _va_reject(fam, "`zi`/`hu` combined with a random effect")
        (haskey(rhs, :zi) || haskey(rhs, :hu)) &&
            error("Poisson() random effects cannot be combined with `zi`/`hu` yet")
        if length(re) > 1                                 # (1|g)+(1|h)+… crossed/multiple intercepts → sparse Laplace
            isva && _va_reject(fam, "crossed/multiple random intercepts")
            reml && _reject_reml_route(fam, "crossed/multiple random intercepts")
            all(_re_kind(r[1])[1] === :intercept for r in re) ||
                error("Poisson() supports multiple random effects only as crossed/nested intercepts, e.g. `(1 | g) + (1 | h)`")
            comps = map(re) do r
                grp = r[2]; gidx, G = _group_index(getproperty(data, grp))
                (ones(length(y)), gidx, G, String(grp))
            end
            isaghq && return _withformula(_fit_poisson_crossed_aghq(fam, y, Xμ, comps, nmμ, g_tol; se = se), f)   # #761
            return _withformula(_fit_poisson_crossed_laplace(fam, y, Xμ, comps, nmμ, g_tol; se = se), f)
        end
        (rk, var) = _re_kind(re[1][1]); grp = re[1][2]; gidx, G = _group_index(getproperty(data, grp))
        if rk === :intercept                              # (1 | g) → GHQ-32 :LA, VA (#136), or 1-D AGHQ (#448)
            # The one route where `method = :REML` punches through (#443). VA is an ELBO,
            # not a likelihood, so a restricted correction of it is not defined.
            # `:REML` × `:AGHQ` is not wired this slice (Cox–Reid on the AGHQ
            # marginal is deferred B).
            reml && isva && _reject_reml_route(fam, "`marginal = :VA` (the ELBO is not a likelihood)")
            reml && isaghq && throw(ArgumentError(
                "drm (Poisson): `method = :REML` is not available with `marginal = :AGHQ`. " *
                "The restricted (Cox–Reid) correction is not wired to the AGHQ marginal this slice. " *
                "Use `method = :ML` (the default) with `marginal = :AGHQ`, or `method = :REML` with `marginal = :LA`."))
            isva && return _withformula(_withmarginal(
                _fit_poisson_ranef_va(fam, y, Xμ, gidx, G, nmμ, grp, g_tol), :VA), f)
            isaghq && return _withformula(_withmarginal(
                _fit_poisson_ranef_aghq(fam, y, Xμ, gidx, G, nmμ, grp, g_tol; nAGQ = nAGQ), :AGHQ), f)
            return _withformula(
                _fit_poisson_ranef(fam, y, Xμ, gidx, G, nmμ, grp, g_tol; reml = reml), f)
        elseif rk === :corr                               # (1 + x | g) → 2-D GHQ (NOT AGHQ)
            isva && _va_reject(fam, "a correlated random slope `(1 + x | g)`")
            isaghq && _aghq_reject(fam, "a correlated random slope `(1 + x | g)` (12² tensor GHQ is not AGHQ)")
            # A 2-D per-cluster effect is not scalar-per-cluster: out of the certified cell.
            reml && _reject_reml_route(fam, "a correlated random slope `(1 + x | g)`")
            xs = Float64.(getproperty(data, var))
            return _withformula(_fit_poisson_corr_ranef(fam, y, Xμ, xs, gidx, G, nmμ, grp, g_tol), f)
        else
            error("Poisson() supports `(1 | g)` or `(1 + x | g)` random effects on the mean")
        end
    end
    isva && _va_reject(fam, "no random intercept (fixed-effects-only / zi / hu)")
    isaghq && _aghq_reject(fam, "no random intercept (fixed-effects-only / zi / hu)")
    # No variance component ⇒ nothing for a restricted objective to correct.
    reml && _reject_reml_route(fam, "no random effect (fixed-effects-only / `zi` / `hu`)")
    haskey(rhs, :zi) && haskey(rhs, :hu) &&
        error("`zi` and `hu` cannot both be specified (zero-inflation vs hurdle)")
    if haskey(rhs, :zi)                                   # zero-inflated Poisson
        _, Xzi, nmzi = _design(f.response, rhs[:zi], data)
        return _withformula(_fit_poisson_zi(fam, y, Xμ, Xzi, nmμ, nmzi, g_tol), f)
    end
    if haskey(rhs, :hu)                                   # hurdle Poisson
        _, Xhu, nmhu = _design(f.response, rhs[:hu], data)
        return _withformula(_fit_poisson_hu(fam, y, Xμ, Xhu, nmμ, nmhu, g_tol), f)
    end
    return _withformula(_fit_poisson(fam, y, Xμ, nmμ, g_tol; offset = off), f)
end

# Poisson random-effect SD regression. For group g,
#   log(λ_i) = X_i β + w_i b_g,  b_g ~ Normal(0, exp(2 Z_g α)),
# where w_i is 1 for an intercept or the numeric slope predictor.
# The fixed-effect SD design is evaluated once per group, as in the Binomial
# route. This Poisson slice admits one ordinary iid intercept or independent slope;
# structured and correlated-block routes must not fall through to this fitter.
function _drm_poisson_sd_regression(f::DrmFormula, fam::Poisson; data,
                                    tree = nothing, K = nothing, A = nothing,
                                    Ainv = nothing, coords = nothing,
                                    g_tol::Real = 1e-8,
                                    se::Bool = true, marginal::Symbol = :LA,
                                    reml::Bool = false, nAGQ::Int = 5)
    reml && throw(ArgumentError(
        "Poisson `sd(group) ~ …` currently supports maximum likelihood only; " *
        "the Cox–Reid correction is not implemented for SD-regression coefficients."))
    marginal === :LA || throw(ArgumentError(
        "Poisson `sd(group) ~ …` currently supports `marginal = :LA` only."))
    nAGQ >= 1 || throw(ArgumentError("nAGQ must be ≥ 1; got $nAGQ"))
    targets = _sd_target_parts(f)
    if any(item -> item.target.level === :relmat, targets)
        Ainv === nothing || throw(ArgumentError(
            "Poisson related-matrix SD regression uses `K = …`, not animal precision `Ainv = …`."))
        return _drm_poisson_relmat_sd_regression(
            f, fam; data, tree, K, A, coords, g_tol, se)
    end
    if any(item -> item.target.level === :animal, targets)
        return _drm_poisson_animal_sd_regression(
            f, fam; data, tree, K, A, Ainv, coords, g_tol, se)
    end
    Ainv === nothing || throw(ArgumentError(
        "Poisson `Ainv` is currently supported for predictor-dependent animal SD regression only."))
    !isempty(_sdphylo_parts(f)) && return _drm_poisson_phylo_sd_regression(
        f, fam; data, tree, K, A, coords, g_tol, se)
    length(targets) == 1 || throw(ArgumentError(
        "Poisson random-effect SD regression requires exactly one SD target."))
    target = only(targets)
    (target.target.level === :iid && target.target.dpar === :mu &&
     target.target.block === nothing) || throw(ArgumentError(
        "Poisson SD regression currently targets one ordinary mean random-effect coefficient."))
    (tree === nothing && K === nothing && A === nothing && Ainv === nothing && coords === nothing) ||
        throw(ArgumentError("Poisson `sd(group) ~ …` currently supports one ordinary " *
            "independent random intercept or numeric slope; structured covariance inputs are not used."))
    isempty(_sdphylo_parts(f)) || throw(ArgumentError(
        "Poisson `sd(group, phylogenetic) ~ …` is not implemented by the ordinary random-intercept route."))
    sgrp, srhs = target.target.group, target.rhs
    rhs = Dict(f.forms)
    fixed_mu, re, mv, st = _split_ranef(rhs[:mu])
    mv === nothing || throw(ArgumentError("Poisson `sd($sgrp)` cannot use meta_V()."))
    st === nothing || throw(ArgumentError(
        "Poisson `sd($sgrp)` currently requires one ordinary `(1 | $sgrp)` or `(0 + x | $sgrp)` effect."))
    length(re) == 1 || throw(ArgumentError(
        "Poisson `sd($sgrp)` currently requires exactly one ordinary independent random effect."))
    kind, slope = _re_kind(re[1][1])
    kind in (:intercept, :slope) || throw(ArgumentError(
        "Poisson `sd($sgrp)` supports `(1 | $sgrp)` or one independent numeric slope `(0 + x | $sgrp)`; correlated blocks are not implemented on this route."))
    member = kind === :intercept ? :intercept : slope
    target.target.member in (nothing, member) || throw(ArgumentError(
        "Poisson SD target `coef($(target.target.member))` does not match fitted coefficient `$(member)`."))
    grp = re[1][2]
    grp === sgrp || throw(ArgumentError(
        "Poisson `sd($sgrp)` must name the random-effect grouping variable `$grp`."))
    (haskey(rhs, :zi) || haskey(rhs, :hu)) && throw(ArgumentError(
        "Poisson random-effect SD regression cannot yet be combined with `zi` or `hu`."))
    fixed_mu, offset_term = _extract_offset(fixed_mu)
    for (pname, r) in f.forms
        (pname in (:mu, Symbol("sd_", sgrp)) || haskey(f.sd_targets, pname)) && continue
        pname === :sigma && r === ConstantTerm(1) && continue
        throw(ArgumentError("Poisson `sd($sgrp)` is a mean-only model with no residual sigma formula."))
    end
    all(_formula_response_observed_mask(f, data)) || throw(ArgumentError(
        "Poisson random-effect SD regression does not yet support missing responses; " *
        "drop incomplete rows before fitting so the group SD design remains aligned."))

    y, Xmu, nmmu = _design(f.response, fixed_mu, data)
    off = offset_term === nothing ? zeros(Float64, length(y)) :
          _offset_vector(offset_term, data)
    length(off) == length(y) || throw(ArgumentError(
        "Poisson `offset(...)` must have one value per observation."))
    all(yi -> yi >= 0 && isinteger(yi), y) || throw(ArgumentError(
        "Poisson() requires non-negative integer counts as the response"))
    gidx, G = _group_index(getproperty(data, grp))
    Zg, nmsd = _sd_group_design(f.response, srhs, data, gidx, G, grp;
                                schema_cache = f.schema_cache, schema_key = :sd)
    size(Zg, 2) <= G && rank(Zg) == size(Zg, 2) || throw(ArgumentError(
        "Poisson `sd($grp)` group-level design is rank deficient; use predictors that vary independently across groups."))
    w = if kind === :intercept
        ones(length(y))
    else
        hasproperty(data, slope) || throw(ArgumentError(
            "Poisson random-slope predictor `$slope` is absent from data."))
        raw = getproperty(data, slope)
        raw isa AbstractVector{<:Real} || throw(ArgumentError(
            "Poisson random-slope predictor `$slope` must be numeric."))
        all(isfinite, raw) || throw(ArgumentError(
            "Poisson random-slope predictor `$slope` must contain finite values."))
        Float64.(raw)
    end
    return _withformula(_fit_poisson_sd_regression(fam, y, Xmu, Zg, gidx, G,
        nmmu, nmsd, grp, g_tol; nAGQ = nAGQ, se = se, w = w, offset = off), f)
end

function _drm_poisson_relmat_sd_regression(f::DrmFormula, fam::Poisson; data,
                                           tree = nothing, K = nothing, A = nothing,
                                           coords = nothing, g_tol::Real = 1e-8,
                                           se::Bool = true)
    targets = _sd_target_parts(f)
    length(targets) == 1 || throw(ArgumentError(
        "Poisson relmat SD regression requires exactly one random-effect SD formula."))
    target = only(targets)
    descriptor = target.target
    (descriptor.level === :relmat && descriptor.dpar === :mu &&
     descriptor.member === nothing && descriptor.block === nothing) ||
        throw(ArgumentError(
            "Poisson relmat SD regression targets the sole structured mean intercept."))
    tree === nothing && A === nothing && coords === nothing || throw(ArgumentError(
        "Poisson relmat SD regression uses `K = …` only; do not also supply `tree`, `A`, or `coords`."))
    K === nothing && throw(ArgumentError(
        "relmat(1 | $(descriptor.group)) needs the relatedness/covariance matrix `K = …`"))

    rhs = Dict(f.forms)
    fixed_mu, re, metav, structured = _split_ranef(rhs[:mu])
    metav === nothing || throw(ArgumentError("Poisson relmat SD regression cannot use meta_V()."))
    structured !== nothing && first(structured) === :relmat || throw(ArgumentError(
        "Poisson `sd($(descriptor.group), relmat)` requires `relmat(1 | $(descriptor.group))`."))
    isempty(re) || throw(ArgumentError(
        "Poisson relmat SD regression currently requires one structured coefficient without additional random effects."))
    last(structured) === descriptor.group || throw(ArgumentError(
        "Poisson relmat SD target must match the group in `relmat(1 | $(last(structured)))`."))
    (haskey(rhs, :zi) || haskey(rhs, :hu)) && throw(ArgumentError(
        "Poisson relmat SD regression cannot yet be combined with `zi` or `hu`."))
    fixed_mu, offset_term = _extract_offset(fixed_mu)
    for (pname, form) in f.forms
        (pname === :mu || pname === target.key) && continue
        pname === :sigma && form === ConstantTerm(1) && continue
        throw(ArgumentError(
            "Poisson relmat SD regression supports only `mu` and one related-matrix SD formula."))
    end
    all(_formula_response_observed_mask(f, data)) || throw(ArgumentError(
        "Poisson relmat SD regression requires observed responses; remove incomplete rows before fitting."))

    y, Xmu, nmmu = _design(f.response, fixed_mu, data)
    off = _poisson_sd_offset(offset_term, data, length(y))
    all(yi -> yi >= 0 && isinteger(yi), y) || throw(ArgumentError(
        "Poisson() requires non-negative integer counts as the response"))
    group = descriptor.group
    labels = getproperty(data, group)
    Q, gidx = _general_cov_setup(K, labels)
    G = size(Q, 1)
    Zg, nmsd = _sd_group_design(f.response, target.rhs, data, gidx, G, group;
        schema_cache = f.schema_cache, schema_key = target.key)
    size(Zg, 2) <= G && rank(Zg) == size(Zg, 2) || throw(ArgumentError(
        "Poisson relmat SD target has a rank-deficient group-level design."))
    Zobs = Zg[gidx, :]
    fit = _fit_poisson_covariance_sd_laplace(
        fam, y, Xmu, Zobs, Zg, gidx, Q, nmmu, nmsd, group, g_tol;
        se, offset = off, context = "sparse-Laplace Poisson relmat SD regression")
    return _withformula(fit, f)
end

function _drm_poisson_animal_sd_regression(f::DrmFormula, fam::Poisson; data,
                                           tree = nothing, K = nothing, A = nothing,
                                           Ainv = nothing, coords = nothing,
                                           g_tol::Real = 1e-8,
                                           se::Bool = true)
    targets = _sd_target_parts(f)
    length(targets) == 1 || throw(ArgumentError(
        "Poisson animal SD regression requires exactly one random-effect SD formula."))
    target = only(targets)
    descriptor = target.target
    (descriptor.level === :animal && descriptor.dpar === :mu &&
     descriptor.block === nothing) ||
        throw(ArgumentError(
            "Poisson animal SD regression targets one structured mean coefficient."))
    tree === nothing && K === nothing && coords === nothing || throw(ArgumentError(
        "Poisson animal SD regression uses `A = …` or `Ainv = …`; do not also supply `tree`, `K`, or `coords`."))
    (A === nothing) == (Ainv === nothing) && throw(ArgumentError(
        "Poisson animal SD regression requires exactly one of `A = …` or `Ainv = …`."))

    rhs = Dict(f.forms)
    fixed_mu, re, metav, structured, _, _, animal_slope =
        _split_ranef(rhs[:mu]; allow_animal_slope = true)
    metav === nothing || throw(ArgumentError("Poisson animal SD regression cannot use meta_V()."))
    structured !== nothing && first(structured) === :animal || throw(ArgumentError(
        "Poisson `sd($(descriptor.group), animal)` requires an animal random effect for `$(descriptor.group)`."))
    isempty(re) || throw(ArgumentError(
        "Poisson animal SD regression currently requires one structured coefficient without additional random effects."))
    expected_member = animal_slope === nothing ? :intercept : animal_slope
    descriptor.member in (nothing, expected_member) || throw(ArgumentError(
        "Poisson animal SD target does not match fitted coefficient `$(expected_member)`."))
    last(structured) === descriptor.group || throw(ArgumentError(
        "Poisson animal SD target must match the group in `animal(... | $(last(structured)))`."))
    (haskey(rhs, :zi) || haskey(rhs, :hu)) && throw(ArgumentError(
        "Poisson animal SD regression cannot yet be combined with `zi` or `hu`."))
    fixed_mu, offset_term = _extract_offset(fixed_mu)
    for (pname, form) in f.forms
        (pname === :mu || pname === target.key) && continue
        pname === :sigma && form === ConstantTerm(1) && continue
        throw(ArgumentError(
            "Poisson animal SD regression supports only `mu` and one animal SD formula."))
    end
    all(_formula_response_observed_mask(f, data)) || throw(ArgumentError(
        "Poisson animal SD regression requires observed responses; remove incomplete rows before fitting."))

    y, Xmu, nmmu = _design(f.response, fixed_mu, data)
    off = _poisson_sd_offset(offset_term, data, length(y))
    all(yi -> yi >= 0 && isinteger(yi), y) || throw(ArgumentError(
        "Poisson() requires non-negative integer counts as the response"))
    group = descriptor.group
    labels = getproperty(data, group)
    Q, gidx = Ainv === nothing ? _general_cov_setup(A, labels) :
        _poisson_animal_precision_setup(Ainv, labels, group)
    G = size(Q, 1)
    Zg, nmsd = _sd_group_design(f.response, target.rhs, data, gidx, G, group;
        schema_cache = f.schema_cache, schema_key = target.key)
    size(Zg, 2) <= G && rank(Zg) == size(Zg, 2) || throw(ArgumentError(
        "Poisson animal SD target has a rank-deficient group-level design."))
    Zobs = Zg[gidx, :]
    loading = animal_slope === nothing ? ones(Float64, length(y)) :
        _poisson_animal_slope_loading(data, animal_slope, length(y))
    fit = _fit_poisson_covariance_sd_laplace(
        fam, y, Xmu, Zobs, Zg, gidx, Q, nmmu, nmsd, group, g_tol;
        se, weight = loading, offset = off,
        context = "sparse-Laplace Poisson animal SD regression")
    return _withformula(fit, f)
end

function _poisson_animal_precision_setup(Ainv::AbstractMatrix, labels, group::Symbol)
    gidx, G = _group_index(labels)
    size(Ainv, 1) == size(Ainv, 2) == G || throw(ArgumentError(
        "animal `Ainv` must be a $(G)×$(G) precision matrix ordered by the first-seen levels of `$(group)`."))
    Q = sparse(Float64.(Ainv))
    all(isfinite, nonzeros(Q)) || throw(ArgumentError(
        "animal `Ainv` must contain only finite values."))
    asymmetry = norm(Q - transpose(Q), Inf)
    scale = max(norm(Q, Inf), 1.0)
    asymmetry <= 1e-10 * scale || throw(ArgumentError(
        "animal `Ainv` must be symmetric."))
    Q = sparse(Symmetric((Q + transpose(Q)) / 2))
    qchol = cholesky(Symmetric(Q); check = false)
    issuccess(qchol) || throw(ArgumentError(
        "animal `Ainv` must be positive definite."))
    return Q, gidx
end

function _drm_poisson_phylo_sd_regression(f::DrmFormula, fam::Poisson; data,
                                          tree, K = nothing, A = nothing,
                                          coords = nothing, g_tol::Real = 1e-8,
                                          se::Bool = true)
    (K === nothing && A === nothing && coords === nothing) || throw(ArgumentError(
        "Poisson phylogenetic SD regression takes its covariance from `tree`; do not also supply `K`, `A`, or `coords`."))
    sdpp = _sdphylo_parts(f)
    length(sdpp) == 1 || throw(ArgumentError(
        "Poisson phylogenetic SD regression requires exactly one `sd(group, phylogenetic) ~ …` formula."))
    isempty(_sd_parts(f)) || throw(ArgumentError(
        "Poisson phylogenetic SD regression cannot yet be combined with ordinary `sd(group)` formulas."))
    sgrp, srhs = only(sdpp)
    rhs = Dict(f.forms)
    fixed_mu, re, mv, st = _split_ranef(rhs[:mu])
    mv === nothing || throw(ArgumentError("Poisson phylogenetic SD regression cannot use meta_V()."))
    st !== nothing && first(st) === :phylo || throw(ArgumentError(
        "Poisson `sd($sgrp, phylogenetic)` requires `phylo(1 | $sgrp)` in the location formula."))
    tree === nothing && throw(ArgumentError("phylo(1 | $sgrp) needs `tree = …`"))
    isempty(re) || throw(ArgumentError(
        "Poisson `sd($sgrp, phylogenetic)` currently requires a phylogenetic random intercept without additional random effects."))
    last(st) === sgrp || throw(ArgumentError(
        "Poisson `sd($sgrp, phylogenetic)` must name the group in `phylo(1 | $(last(st)))`."))
    (haskey(rhs, :zi) || haskey(rhs, :hu)) && throw(ArgumentError(
        "Poisson phylogenetic SD regression cannot yet be combined with `zi` or `hu`."))
    fixed_mu, offset_term = _extract_offset(fixed_mu)
    for (pname, r) in f.forms
        (pname === :mu || pname === Symbol("sdphy_", sgrp)) && continue
        pname === :sigma && r === ConstantTerm(1) && continue
        throw(ArgumentError(
            "Poisson phylogenetic SD regression supports only `mu` and one phylogenetic SD formula."))
    end
    all(_formula_response_observed_mask(f, data)) || throw(ArgumentError(
        "Poisson phylogenetic SD regression requires observed responses; remove incomplete rows before fitting."))

    y, Xmu, nmmu = _design(f.response, fixed_mu, data)
    off = _poisson_sd_offset(offset_term, data, length(y))
    all(yi -> yi >= 0 && isinteger(yi), y) || throw(ArgumentError(
        "Poisson() requires non-negative integer counts as the response"))
    labels = getproperty(data, sgrp)
    _, tip_index, G = _lss_phylo_group_index(tree, labels, sgrp)
    group_index, Gdata = _group_index(labels)
    Gdata == G || error("phylogenetic group indexing changed unexpectedly")
    Zg, nmsd = _sd_group_design(f.response, srhs, data, group_index, Gdata, sgrp;
                                schema_cache = f.schema_cache,
                                schema_key = :sd_phylo)
    tip_group = zeros(Int, G)
    @inbounds for i in eachindex(tip_index)
        ti, gi = tip_index[i], group_index[i]
        tip_group[ti] == 0 || tip_group[ti] == gi || throw(ArgumentError(
            "Poisson phylogenetic SD predictors must be constant within each tree tip."))
        tip_group[ti] = gi
    end
    all(!iszero, tip_group) || throw(ArgumentError(
        "Poisson phylogenetic SD regression requires SD predictors for every tree tip."))
    Ztip = Matrix{Float64}(Zg[tip_group, :])
    Zobs = Ztip[tip_index, :]
    return _withformula(_fit_poisson_phylo_sd_laplace(
        fam, y, Xmu, Zobs, labels, tree, nmmu, nmsd, sgrp, g_tol;
        se, offset = off), f)
end

function _poisson_sd_offset(offset_term, data, n::Int)
    off = offset_term === nothing ? zeros(Float64, n) :
          _offset_vector(offset_term, data)
    length(off) == n || throw(ArgumentError(
        "Poisson `offset(...)` must have one value per observation."))
    return off
end

function _poisson_phylo_sd_mode(y, Xmu, Zobs, leaf_node, Q, beta, alpha;
                                offset = zeros(length(y)),
                                weight = ones(length(y)),
                                b0 = nothing, maxiter::Int = 60,
                                tol::Real = 1e-10)
    q = size(Q, 1)
    b = b0 === nothing ? zeros(q) : copy(b0)
    length(offset) == length(y) || throw(ArgumentError(
        "Poisson `offset(...)` must have one value per observation."))
    eta0 = Xmu * beta .+ offset
    length(weight) == length(y) || throw(ArgumentError(
        "Poisson structured random-effect loading must have one value per response."))
    all(isfinite, weight) || throw(ArgumentError(
        "Poisson structured random-effect loading must contain only finite values."))
    loading = Float64.(weight) .* exp.(Zobs * alpha)
    all(isfinite, loading) || return b, nothing, false
    function joint(bb)
        total = 0.5 * dot(bb, Q * bb)
        @inbounds for i in eachindex(eta0)
            eta = eta0[i] + loading[i] * bb[leaf_node[i]]
            total += exp(eta) - y[i] * eta + _logfactorial(round(Int, y[i]))
        end
        total
    end
    for _ in 1:maxiter
        grad = Q * b
        diagH = zeros(Float64, q)
        @inbounds for i in eachindex(eta0)
            li = leaf_node[i]
            eta = eta0[i] + loading[i] * b[li]
            mu = exp(eta)
            grad[li] += loading[i] * (mu - y[i])
            diagH[li] += loading[i]^2 * mu
        end
        H = Q + spdiagm(0 => diagH)
        ch = cholesky(Symmetric(H); check = false)
        issuccess(ch) || return b, ch, false
        step = ch \ grad
        norm(step) <= tol * (1 + norm(b)) && return b, ch, true
        if norm(step) <= 1e-3 * (1 + norm(b))
            b .-= step
            continue
        end
        f0 = joint(b)
        a = 1.0
        accepted = false
        while a >= 1e-5
            trial = b .- a .* step
            if joint(trial) <= f0
                b = trial
                accepted = true
                break
            end
            a *= 0.5
        end
        accepted || return b, ch, false
    end
    return b, nothing, false
end

function _poisson_phylo_sd_laplace(y, Xmu, Zobs, leaf_node, Q, logdetQ,
                                   theta; offset = zeros(length(y)),
                                   weight = ones(length(y)), b0 = nothing)
    pmu = size(Xmu, 2)
    beta = @view theta[1:pmu]
    alpha = @view theta[pmu+1:end]
    b, ch, ok = _poisson_phylo_sd_mode(y, Xmu, Zobs, leaf_node, Q,
                                        beta, alpha; offset, weight, b0 = b0)
    ok || return 1e18, b, false
    length(weight) == length(y) || throw(ArgumentError(
        "Poisson structured random-effect loading must have one value per response."))
    all(isfinite, weight) || throw(ArgumentError(
        "Poisson structured random-effect loading must contain only finite values."))
    loading = Float64.(weight) .* exp.(Zobs * alpha)
    length(offset) == length(y) || throw(ArgumentError(
        "Poisson `offset(...)` must have one value per observation."))
    eta0 = Xmu * beta .+ offset
    total = 0.5 * dot(b, Q * b)
    @inbounds for i in eachindex(y)
        eta = eta0[i] + loading[i] * b[leaf_node[i]]
        total += exp(eta) - y[i] * eta + _logfactorial(round(Int, y[i]))
    end
    return total - 0.5 * logdetQ + 0.5 * logdet(ch), b, true
end

function _fit_poisson_phylo_sd_laplace(fam, y, Xmu, Zobs, labels, tree,
                                       nmmu, nmsd, grp, g_tol;
                                       se::Bool = true, maxiter::Int = 250,
                                       offset = zeros(length(y)))
    Q, leaf_node, _ = _poisson_phylo_setup(tree, labels)
    size(Zobs, 1) == length(y) || throw(ArgumentError(
        "phylogenetic SD design must have one row per response"))
    size(Zobs, 2) == length(nmsd) || throw(ArgumentError(
        "phylogenetic SD names do not match its design"))
    qchol = cholesky(Symmetric(Q); check = false)
    issuccess(qchol) || error(
        "phylo(1 | $grp) tree precision is not positive definite after root conditioning")
    logdetQ = logdet(qchol)
    tip_index = _lss_phylo_group_index(tree, labels, grp)[2]
    return _fit_poisson_structured_sd_laplace(
        fam, y, Xmu, Zobs, leaf_node, Q, logdetQ, nmmu, nmsd, grp, g_tol;
        se, maxiter, sd_block = :sd_phylo, scale_key = :sd_phylo,
        extra_scales = Dict(:tree_tip_index => Float64.(tip_index)),
        offset,
        context = "sparse-Laplace Poisson phylogenetic SD regression")
end

function _fit_poisson_covariance_sd_laplace(fam, y, Xmu, Zobs, Zg, gidx, Q,
                                            nmmu, nmsd, grp, g_tol;
                                            se::Bool = true, maxiter::Int = 250,
                                            weight = ones(length(y)),
                                            offset = zeros(length(y)),
                                            context::String)
    qchol = cholesky(Symmetric(Q); check = false)
    issuccess(qchol) || throw(ArgumentError(
        "relmat(1 | $grp) covariance must be positive definite"))
    return _fit_poisson_structured_sd_laplace(
        fam, y, Xmu, Zobs, gidx, Q, logdet(qchol), nmmu, nmsd, grp, g_tol;
        se, maxiter, sd_block = :sd, scale_key = :sd,
        group_design = Zg, group_index = gidx,
        weight, offset,
        context)
end

function _fit_poisson_structured_sd_laplace(fam, y, Xmu, Zobs, leaf_node, Q,
                                            logdetQ, nmmu, nmsd, grp, g_tol;
                                            se::Bool, maxiter::Int,
                                            sd_block::Symbol, scale_key::Symbol,
                                            group_design = nothing,
                                            group_index = nothing,
                                            extra_scales = Dict{Symbol,Vector{Float64}}(),
                                            weight = ones(length(y)),
                                            offset = zeros(length(y)),
                                            report_scale::Bool = true,
                                            context::String)
    n = length(y)
    length(offset) == n || throw(ArgumentError(
        "Poisson `offset(...)` must have one value per observation."))
    off = Float64.(offset)
    pmu, psd = size(Xmu, 2), size(Zobs, 2)
    last_b = zeros(size(Q, 1))
    function nll(theta)
        value, b, ok = _poisson_phylo_sd_laplace(
            y, Xmu, Zobs, leaf_node, Q, logdetQ, theta;
            offset = off, weight, b0 = last_b)
        if !ok
            value, b, ok = _poisson_phylo_sd_laplace(
                y, Xmu, Zobs, leaf_node, Q, logdetQ, theta;
                offset = off, weight, b0 = zeros(length(last_b)))
        end
        ok || return 1e18
        last_b .= b
        return value
    end
    function grad!(g, theta)
        for j in eachindex(theta)
            h = 2e-4 * (1 + abs(theta[j]))
            e = zeros(length(theta)); e[j] = h
            g[j] = (nll(theta .+ e) - nll(theta .- e)) / (2h)
        end
        return g
    end
    theta0 = zeros(pmu + psd)
    theta0[1:pmu] .= _poisson_fixed_start(y, Xmu)
    theta0[pmu+1] = log(0.4)
    od = Optim.OnceDifferentiable(nll, grad!, theta0)
    res = Optim.optimize(od, theta0,
        Optim.LBFGS(linesearch = Optim.LineSearches.BackTracking()),
        Optim.Options(g_tol = g_tol, iterations = maxiter))
    theta_hat = Optim.minimizer(res)
    value = nll(theta_hat)
    gfinal = zeros(length(theta_hat)); grad!(gfinal, theta_hat)
    converged = _laplace_outer_converged(res, value, gfinal, theta_hat, n, g_tol)
    V = se ? _vcov_from_fd_hessian(
        _finite_hessian(nll, theta_hat; h = _fd_hessian_step(n));
        context = context) :
        fill(NaN, length(theta_hat), length(theta_hat))
    blocks = Pair{Symbol,UnitRange{Int}}[
        :mu => (1:pmu), sd_block => (pmu+1:pmu+psd)]
    names = Pair{Symbol,Vector{String}}[
        :mu => nmmu, sd_block => nmsd]
    means = Dict(:mu => exp.(Xmu * theta_hat[1:pmu] .+ off))
    obs = Dict(:mu => Vector{Float64}(y))
    sdobs = exp.(Zobs * theta_hat[pmu+1:end])
    scales = Dict{Symbol,Vector{Float64}}()
    report_scale && (scales[scale_key] = sdobs)
    if group_design !== nothing
        group_index === nothing && throw(ArgumentError(
            "structured SD group indices are required with a group-level design"))
        sdgroup = exp.(group_design * theta_hat[pmu+1:end])
        scales[:sd_group] = sdgroup
        scales[:sd] = sdgroup[group_index]
        scales[:sd_group_index] = Float64.(group_index)
    end
    merge!(scales, extra_scales)
    fit = DrmFit(fam, blocks, names, theta_hat, Matrix(V), -value, n,
                 converged, means, obs, scales)
    return _withiterations(_withnll(fit, nll), Optim.iterations(res))
end

function _poisson_animal_slope_loading(data, slope::Symbol, n::Int)
    hasproperty(data, slope) || throw(ArgumentError(
        "Poisson animal random-slope predictor `$slope` is absent from data."))
    raw = getproperty(data, slope)
    raw isa AbstractVector{<:Real} && length(raw) == n && all(isfinite, raw) ||
        throw(ArgumentError(
            "Poisson animal random-slope predictor `$slope` must be finite numeric values, one per response."))
    loading = Float64.(raw)
    any(!iszero, loading) || throw(ArgumentError(
        "Poisson animal random-slope predictor `$slope` is zero for every observation, so its SD is not identifiable."))
    return loading
end

function _fit_poisson_animal_slope_laplace(fam::Poisson, y, Xmu, weight, C,
                                            labels, nmmu, grp, g_tol;
                                            se::Bool = true, reml::Bool = false)
    reml && _reject_reml_route(fam, "an animal random slope `(0 + x | group)`")
    Q, gidx = _general_cov_setup(C, labels)
    qchol = cholesky(Symmetric(Q); check = false)
    issuccess(qchol) || throw(ArgumentError(
        "animal(0 + x | $grp) covariance must be positive definite"))
    return _fit_poisson_structured_sd_laplace(
        fam, y, Xmu, ones(Float64, length(y), 1), gidx, Q, logdet(qchol),
        nmmu, [String(grp)], grp, g_tol; se, maxiter = 250,
        sd_block = :resd, scale_key = :resd, weight,
        report_scale = false,
        context = "sparse-Laplace Poisson animal random-slope fit")
end

function _fit_poisson_sd_regression(fam::Poisson, y, Xmu, Zg, gidx, G,
                                     nmmu, nmsd, grp, g_tol; nAGQ::Int = 5,
                                     se::Bool = true,
                                     w::AbstractVector{<:Real} = ones(length(y)),
                                     offset::AbstractVector{<:Real} = zeros(length(y)))
    nAGQ >= 1 || throw(ArgumentError("nAGQ must be ≥ 1; got $nAGQ"))
    n = length(y); pmu = size(Xmu, 2); psd = size(Zg, 2)
    members = [Int[] for _ in 1:G]
    for i in 1:n
        push!(members[gidx[i]], i)
    end
    lf = [_logfactorial(round(Int, yi)) for yi in y]
    rule = _AGHQRule(1, nAGQ)
    length(w) == n || throw(ArgumentError(
        "Poisson random-effect loading must have one value per observation."))
    length(offset) == n || throw(ArgumentError(
        "Poisson offset must have one value per observation."))
    Zre = reshape(Float64.(w), n, 1)
    off = Float64.(offset)
    bcache = zeros(1, G)
    function nll(theta)
        beta = @view theta[1:pmu]
        alpha = @view theta[(pmu+1):(pmu+psd)]
        eta0 = Xmu * beta .+ off
        sdgroup = exp.(Zg * alpha)
        ll = (i, eta) -> begin
            etac = clamp(eta, -30.0, 30.0)
            y[i] * etac - exp(etac) - lf[i]
        end
        total = zero(eltype(theta))
        for gi in 1:G
            Lg = reshape([sdgroup[gi]], 1, 1)
            value, bhat = _aghq_group_logint(ll, members[gi], eta0, Zre, Lg,
                                               rule, @view(bcache[:, gi]))
            bcache[1, gi] = isfinite(bhat[1]) ? bhat[1] : 0.0
            total += value
        end
        return -total
    end
    theta0 = zeros(pmu + psd)
    theta0[1] = log(sum(y) / n + eps())
    theta0[(pmu+1):end] .= Zg \ fill(log(0.5), G)
    res = Optim.optimize(nll, theta0, Optim.LBFGS(),
                         Optim.Options(g_tol = g_tol); autodiff = :forward)
    thetahat = Optim.minimizer(res)
    V = se ? _vcov_from_hessian(ForwardDiff.hessian(nll, thetahat)) :
             fill(NaN, length(thetahat), length(thetahat))
    blocks = [:mu => 1:pmu, :sd => (pmu+1):(pmu+psd)]
    names = [:mu => nmmu, :sd => nmsd]
    sdgroup = exp.(Zg * thetahat[(pmu+1):end])
    means = Dict(:mu => exp.(Xmu * thetahat[1:pmu] .+ off))
    obs = Dict(:mu => Vector{Float64}(y))
    scales = Dict(:sd_group => sdgroup, :sd => sdgroup[gidx],
                  :sd_group_index => Float64.(gidx),
                  :aghq_nodes => [Float64(nAGQ)])
    return _withiterations(
        _withnll(DrmFit(fam, blocks, names, thetahat, V, -nll(thetahat), n,
                        drm_optim_converged(res), means, obs, scales), nll),
        Optim.iterations(res))
end

# Resolve a structured marker (relmat/animal/spatial) for a count family to its
# user-supplied G×G PD covariance from the keyword args. `relmat`/`animal` take
# the matrix directly (`K`/`A`); `spatial` accepts a precomputed covariance via
# `K`, or — handled upstream in `drm(...)` before this is reached — site `coords`
# for coordinate-based joint range estimation (#270). Reaching the `:spatial`
# branch here means neither was supplied. Mirrors `_resolve_structured_matrix`
# (gaussian_structured.jl) but for the count Laplace route.
function _poisson_structured_cov(kind::Symbol, grp::Symbol, K, A, coords)
    if kind === :relmat
        K === nothing && error("relmat(1 | $grp) needs `K = …` (the relatedness/covariance matrix)")
        return Matrix{Float64}(K)
    elseif kind === :animal
        A === nothing && error("animal(1 | $grp) needs the relatedness matrix `A = …`")
        return Matrix{Float64}(A)
    else  # :spatial
        K !== nothing && return Matrix{Float64}(K)
        error("spatial(1 | $grp) for counts needs either a precomputed spatial covariance " *
              "via `K = …`, or site `coords = …` (a G×2 coordinate matrix) for coordinate-based " *
              "exponential-kernel covariance with the range estimated jointly")
    end
end

# Poisson count GLMM with a random intercept (1|g) on log λ. b_g ~ N(0,σ_b²) is
# integrated out per group by K-node Gauss–Hermite quadrature (b = √2 σ_b z), the
# same scheme as the Gaussian σ-RE. O(n·K) per evaluation, fully differentiable.
#
# `reml = true` (public `method = :REML`, #443) switches to the opt-in Cox–Reid adjusted
# profile likelihood ℓ_CR = ℓ_ML − ½·log|I_ββ|, which reduces the ML finite-cluster
# downward bias in σ̂_b. The 32-node quadrature means the integral error is already paid,
# so σ̂_b's residual bias is the ML variance-component bias and nothing else — which is
# what makes this the clean first cell.
#
# Two things are deliberately reused rather than re-derived: `_glsp_reml_penalty` forms
# I_ββ (its FD-of-analytic-gradient construction reduces EXACTLY to Patterson–Thompson
# REML on the Gaussian route — probe Cell B matched the #440 Woodbury path to 2.9e-06),
# and `_glsp_reml_refit_clean` carries the guards production needs: the non-PD-I_ββ
# sentinel (2/60 seeds hit it at G=10) and the line-search fallback. This route has no
# analytic gradient closure, so the exact ForwardDiff gradient supplies `grad_fn`.
#
# ML stays the default: Cox–Reid OVER-corrects once clusters are plentiful (+4.38% at
# G=40 against −12.37% for ML at G=10).
function _fit_poisson_ranef(fam::Poisson, y, Xμ, gidx, G, nmμ, grp, g_tol; reml::Bool = false, K::Int = _RANEF1D_AGHQ_K)
    n = length(y); pμ = size(Xμ, 2)
    members = [Int[] for _ in 1:G]
    for i in 1:n
        push!(members[gidx[i]], i)
    end
    lf = [_logfactorial(round(Int, yi)) for yi in y]
    rule = _AGHQRule(1, K); Zre = ones(n, 1); bcache = zeros(1, G)   # #719: per-group AGHQ
    function nll(θ)
        βμ = θ[1:pμ]; σb = exp(θ[pμ+1])
        η0 = Xμ * βμ
        ll = (i, η) -> (ηc = clamp(η, -30.0, 30.0); y[i] * ηc - exp(ηc) - lf[i])
        L = reshape([σb], 1, 1)
        return -_aghq_marginal_loglik(ll, members, η0, Zre, L, rule, bcache)
    end
    θ0 = zeros(pμ + 1)
    θ0[1] = log(sum(y) / n + eps())
    θ0[pμ+1] = log(0.5)
    res = Optim.optimize(nll, θ0, Optim.LBFGS(), Optim.Options(g_tol = g_tol); autodiff = :forward)
    θ̂ = Optim.minimizer(res); conv = drm_optim_converged(res)
    blocks = [:mu => 1:pμ, :resd => (pμ+1):(pμ+1)]
    names = [:mu => nmμ, :resd => [String(grp)]]
    scales = Dict{Symbol,Vector{Float64}}()
    if reml
        grad_fn = θ -> ForwardDiff.gradient(nll, θ)
        ml_nll = nll(θ̂)
        θ̂, conv, ml_nll, reml_nll, _ =
            _glsp_reml_refit_clean(nll, grad_fn, θ̂, pμ; ml_converged = conv)
        # Wald vcov under a restricted objective must be the inverse Hessian OF THAT
        # objective (#310), not the ML observed information.
        V = _glsp_reml_vcov(grad_fn, θ̂, pμ)
        means = Dict(:mu => exp.(Xμ * θ̂[1:pμ])); obs = Dict(:mu => Vector{Float64}(y))
        fit = _withnll(DrmFit(fam, blocks, names, θ̂, V, -ml_nll, n, conv, means, obs, scales), nll)
        return _withreml(fit, -reml_nll, -ml_nll)
    end
    V = _vcov_from_hessian(ForwardDiff.hessian(nll, θ̂))
    means = Dict(:mu => exp.(Xμ * θ̂[1:pμ])); obs = Dict(:mu => Vector{Float64}(y))   # population λ (b=0)
    return _withiterations(
        _withnll(DrmFit(fam, blocks, names, θ̂, V, -nll(θ̂), n, conv, means, obs, scales), nll),
        Optim.iterations(res))
end

# Opt-in 1-D Liu–Pierce AGHQ for Poisson `(1 | g)` (#448). Same model as
# `_fit_poisson_ranef`, but each group's integral uses the adaptive map around
# the group posterior mode (`_poisson_group_aghq_logint`) instead of
# prior-scaled GHQ-32. Default `:LA` is unchanged. `nAGQ=1` is 1-point Laplace
# plumbing, not a recovery claim. `:REML` is rejected upstream.
function _fit_poisson_ranef_aghq(fam::Poisson, y, Xμ, gidx, G, nmμ, grp, g_tol; nAGQ::Int = 5)
    nAGQ >= 1 || throw(ArgumentError("nAGQ must be ≥ 1; got $nAGQ"))
    n = length(y); pμ = size(Xμ, 2)
    members = [Int[] for _ in 1:G]
    for i in 1:n
        push!(members[gidx[i]], i)
    end
    lf = [_logfactorial(round(Int, yi)) for yi in y]
    function nll(θ)
        βμ = θ[1:pμ]; σb = exp(θ[pμ+1])
        η0 = Xμ * βμ
        s = zero(eltype(θ))
        for idx in members
            isempty(idx) && continue
            s -= _poisson_group_aghq_logint(y, η0, lf, idx, σb, nAGQ)
        end
        return s
    end
    θ0 = zeros(pμ + 1)
    θ0[1] = log(sum(y) / n + eps())
    θ0[pμ+1] = log(0.5)
    res = Optim.optimize(nll, θ0, Optim.LBFGS(), Optim.Options(g_tol = g_tol); autodiff = :forward)
    θ̂ = Optim.minimizer(res); conv = drm_optim_converged(res)
    # A penalised objective at the optimum means some group posterior could not be
    # evaluated there (#1063): fail cleanly rather than report a meaningless fit.
    nll̂ = nll(θ̂)
    (isfinite(nll̂) && nll̂ < -_AGHQ_PENALTY_LOGINT) || error(
        "marginal = :AGHQ could not evaluate the Poisson (1 | $grp) group integrals at the optimum " *
        "(non-finite or non-log-concave group posterior; #1063). " *
        "Use the default marginal = :LA or marginal = :Laplace for this model.")
    blocks = [:mu => 1:pμ, :resd => (pμ+1):(pμ+1)]
    names = [:mu => nmμ, :resd => [String(grp)]]
    scales = Dict{Symbol,Vector{Float64}}()
    V = _vcov_from_hessian(ForwardDiff.hessian(nll, θ̂))
    means = Dict(:mu => exp.(Xμ * θ̂[1:pμ])); obs = Dict(:mu => Vector{Float64}(y))
    return _withiterations(
        _withnll(DrmFit(fam, blocks, names, θ̂, V, -nll(θ̂), n, conv, means, obs, scales), nll),
        Optim.iterations(res))
end

# Poisson count GLMM with a correlated random intercept+slope (1 + x | g) on log λ.
# Per group (b0,b1) ~ N(0, Σ); because groups are disjoint the 2-D integral
# factorises; each group is integrated by per-group ADAPTIVE Gauss–Hermite quadrature
# (`_aghq_marginal_loglik`, #834: nodes b̂_g + √2 C z at each group's mode),
# `nq` nodes per axis (nq = 1 is Laplace). Σ is the log-Cholesky parameterisation
# L = [exp(a) 0; cc exp(b)] (the `vc` convention), so vc(fit) reconstructs Σ = L Lᵀ.
function _fit_poisson_corr_ranef(fam::Poisson, y, Xμ, xs, gidx, G, nmμ, grp, g_tol; nq::Int = _CORR_RANEF_AGHQ_K)
    n = length(y); pμ = size(Xμ, 2)
    members = [Int[] for _ in 1:G]
    for i in 1:n
        push!(members[gidx[i]], i)
    end
    lf = [_logfactorial(round(Int, yi)) for yi in y]
    rule = _AGHQRule(2, nq); Zre = hcat(ones(n), Float64.(xs)); bcache = zeros(2, G)   # #834: per-group AGHQ
    function nll(θ)
        βμ = θ[1:pμ]; L = _corr_ranef_L(θ[pμ+1], θ[pμ+2], θ[pμ+3]); η0 = Xμ * βμ
        ll = (i, η) -> (ηc = clamp(η, -30.0, 30.0); y[i] * ηc - exp(ηc) - lf[i])
        return -_aghq_marginal_loglik(ll, members, η0, Zre, L, rule, bcache)
    end
    θ0 = zeros(pμ + 3)
    θ0[1] = log(sum(y) / n + eps())
    θ0[pμ+1] = log(0.4); θ0[pμ+2] = log(0.4); θ0[pμ+3] = 0.0
    res = Optim.optimize(nll, θ0, Optim.LBFGS(), Optim.Options(g_tol = g_tol); autodiff = :forward)
    θ̂ = Optim.minimizer(res); V = _vcov_from_hessian(ForwardDiff.hessian(nll, θ̂))
    blocks = [:mu => 1:pμ, :recov => (pμ+1):(pμ+3)]
    names = [:mu => nmμ, :recov => ["$(grp):L11", "$(grp):L22", "$(grp):L21"]]
    means = Dict(:mu => exp.(Xμ * θ̂[1:pμ])); obs = Dict(:mu => Vector{Float64}(y))
    scales = Dict{Symbol,Vector{Float64}}()
    return _withiterations(
        _withnll(DrmFit(fam, blocks, names, θ̂, V, -nll(θ̂), n, drm_optim_converged(res), means, obs, scales), nll),
        Optim.iterations(res))
end

# log-logistic helpers (stable): log π and log(1-π) for π = logistic(η).
_log_logistic(η) = -log1p(exp(-η))
_log1m_logistic(η) = -log1p(exp(η))
# log(exp(a) + exp(b)), numerically stable.
_logaddexp(a, b) = (m = max(a, b); m + log1p(exp(-abs(a - b))))
# log(1 - exp(x)) for x ≤ 0, numerically stable (hurdle zero-truncation term).
_log1mexp(x) = x < -log(2) ? log1p(-exp(x)) : log(-expm1(x))

# Zero-inflated Poisson: P(0) = π + (1-π)e^{-λ}, P(k>0) = (1-π)·Poisson(k; λ),
# with π = logistic(Xziᵀβ) (logit link) and λ = exp(Xμᵀβ).
function _fit_poisson_zi(fam::Poisson, y, Xμ, Xzi, nmμ, nmzi, g_tol)
    n = length(y); pμ, pz = size(Xμ, 2), size(Xzi, 2)
    lf = [_logfactorial(round(Int, yi)) for yi in y]
    iszero_y = y .== 0
    function nll(θ)
        βμ = θ[1:pμ]; βz = θ[pμ+1:pμ+pz]
        ημ = clamp.(Xμ * βμ, -30.0, 30.0); ηz = clamp.(Xzi * βz, -30.0, 30.0)
        s = zero(eltype(θ))
        @inbounds for i in 1:n
            λ = exp(ημ[i]); lπ = _log_logistic(ηz[i]); l1mπ = _log1m_logistic(ηz[i])
            if iszero_y[i]
                s -= _logaddexp(lπ, l1mπ - λ)              # log(π + (1-π)e^{-λ})
            else
                s -= l1mπ + (y[i] * ημ[i] - λ - lf[i])
            end
        end
        return s
    end
    pos = y[y.>0]
    θ0 = zeros(pμ + pz)
    θ0[1] = log((isempty(pos) ? sum(y) / n : sum(pos) / length(pos)) + eps())   # λ from non-zeros
    res = Optim.optimize(nll, θ0, Optim.LBFGS(), Optim.Options(g_tol = g_tol); autodiff = :forward)
    θ̂ = Optim.minimizer(res); V = _vcov_from_hessian(ForwardDiff.hessian(nll, θ̂))
    blocks = [:mu => 1:pμ, :zi => (pμ+1):(pμ+pz)]
    names = [:mu => nmμ, :zi => nmzi]
    means = Dict(:mu => exp.(Xμ * θ̂[1:pμ])); obs = Dict(:mu => Vector{Float64}(y))
    scales = Dict(:zi => _logistic.(Xzi * θ̂[(pμ+1):(pμ+pz)]))
    return _withiterations(
        _withnll(DrmFit(fam, blocks, names, θ̂, V, -nll(θ̂), n, drm_optim_converged(res), means, obs, scales), nll),
        Optim.iterations(res))
end

# Hurdle Poisson: P(0) = π, P(k>0) = (1-π)·Poisson(k; λ)/(1-e^{-λ}) [zero-truncated],
# with π = logistic(Xhuᵀβ) the hurdle (zero) probability and λ = exp(Xμᵀβ). All
# zeros are structural; the positive part is the zero-truncated Poisson.
function _fit_poisson_hu(fam::Poisson, y, Xμ, Xhu, nmμ, nmhu, g_tol)
    n = length(y); pμ, ph = size(Xμ, 2), size(Xhu, 2)
    lf = [_logfactorial(round(Int, yi)) for yi in y]
    iszero_y = y .== 0
    function nll(θ)
        βμ = θ[1:pμ]; βh = θ[pμ+1:pμ+ph]
        ημ = clamp.(Xμ * βμ, -30.0, 30.0); ηh = clamp.(Xhu * βh, -30.0, 30.0)
        s = zero(eltype(θ))
        @inbounds for i in 1:n
            lπ = _log_logistic(ηh[i]); l1mπ = _log1m_logistic(ηh[i])
            if iszero_y[i]
                s -= lπ                                        # log π
            else
                λ = exp(ημ[i])
                lpos = y[i] * ημ[i] - λ - lf[i]                # log Poisson(k; λ)
                s -= l1mπ + lpos - _log1mexp(-λ)               # − log(1 − e^{-λ})
            end
        end
        return s
    end
    pos = y[y.>0]
    θ0 = zeros(pμ + ph)
    θ0[1] = log((isempty(pos) ? sum(y) / n : sum(pos) / length(pos)) + eps())   # λ from non-zeros
    res = Optim.optimize(nll, θ0, Optim.LBFGS(), Optim.Options(g_tol = g_tol); autodiff = :forward)
    θ̂ = Optim.minimizer(res); V = _vcov_from_hessian(ForwardDiff.hessian(nll, θ̂))
    blocks = [:mu => 1:pμ, :hu => (pμ+1):(pμ+ph)]
    names = [:mu => nmμ, :hu => nmhu]
    means = Dict(:mu => exp.(Xμ * θ̂[1:pμ])); obs = Dict(:mu => Vector{Float64}(y))
    scales = Dict(:hu => _logistic.(Xhu * θ̂[(pμ+1):(pμ+ph)]))
    return _withiterations(
        _withnll(DrmFit(fam, blocks, names, θ̂, V, -nll(θ̂), n, drm_optim_converged(res), means, obs, scales), nll),
        Optim.iterations(res))
end

function _fit_poisson(fam::Poisson, y, Xμ, nmμ, g_tol; offset::AbstractVector{<:Real} = zeros(length(y)))
    n = length(y); pμ = size(Xμ, 2)
    lf = [_logfactorial(round(Int, yi)) for yi in y]    # constant log y! term
    off = Float64.(offset)
    function nll(θ)
        ημ = Xμ * θ .+ off                              # log λ; offset() coefficient fixed at 1
        s = zero(eltype(θ))
        @inbounds for i in 1:n
            s -= y[i] * ημ[i] - exp(ημ[i]) - lf[i]
        end
        return s
    end
    θ0 = zeros(pμ); θ0[1] = log(sum(y) / n + eps()) - (isempty(off) ? 0.0 : sum(off) / n)
    res = Optim.optimize(nll, θ0, Optim.LBFGS(), Optim.Options(g_tol = g_tol); autodiff = :forward)
    θ̂ = Optim.minimizer(res); V = _vcov_from_hessian(ForwardDiff.hessian(nll, θ̂))
    blocks = [:mu => 1:pμ]; names = [:mu => nmμ]
    means = Dict(:mu => exp.(Xμ * θ̂ .+ off)); obs = Dict(:mu => Vector{Float64}(y))   # response-scale λ
    scales = Dict{Symbol,Vector{Float64}}()
    return _withiterations(
        _withnll(DrmFit(fam, blocks, names, θ̂, V, -nll(θ̂), n, drm_optim_converged(res), means, obs, scales), nll),
        Optim.iterations(res))
end

# ===========================================================================
# Coordinate-based exponential-kernel spatial covariance for Poisson (#270)
# ===========================================================================
# spatial(1 | site) with site coordinates and the range ρ ESTIMATED JOINTLY.
# The spatial correlation among the G sites is C(ρ) = exp(-d/ρ) (+ jitter) built
# from pairwise site distances; the random intercept is b ~ N(0, σ_b² C(ρ)) on
# log λ. The outer parameter vector is θ = [β_μ; log σ_b; log ρ], so ρ is a true
# hyperparameter: its gradient flows through C(ρ) → the Laplace marginal.
#
# Unlike the verified large-p sparse-Laplace spine (`_fit_poisson_relmat_laplace`,
# which freezes a precomputed precision Q and supplies a hand-derived O(p) gradient
# for θ = [β; log σ_b] only), this path must differentiate the marginal w.r.t. ρ
# as well. It does so the same way every other DRModels.jl non-Gaussian family fit does
# (Poisson/NB2/Gamma GHQ paths and the Gaussian coordinate-spatial path
# `_fit_spatial_gaussian`): the marginal NLL is written in AD-traceable operations
# and ForwardDiff supplies the EXACT gradient (and the Hessian for the covariance).
# Because the number of SITES G is the latent dimension here (one effect per site,
# typically modest), a dense per-site inner mode and a dense G×G log-det are
# acceptable and keep the whole marginal differentiable.
#
# The Laplace marginal matches the verified sparse path's convention exactly
# (`_fit_poisson_general_laplace`): with the inner mode b̂ solving
# ∂(data+prior)/∂b = 0 and H = σ_b⁻² C⁻¹ + diag(μ̂),
#     NLL(θ) = Σ_i[μ̂_i − y_i η̂_i + log y_i!]            (data, at the mode)
#            + ½ σ_b⁻² b̂ᵀ C⁻¹ b̂                         (prior quadratic)
#            + G·log σ_b + ½ logdet C(ρ)                  (−½ logdet(σ_b² C))
#            + ½ logdet H.                                 (Laplace curvature)
# AD differentiates through the data/prior/log-det terms AND through b̂(θ) — for
# that the implicit-function relation must hold on the AD (dual) numbers, so the
# inner Newton solve is run to a tight step-norm tolerance on whatever element
# type θ carries. The joint is strictly convex (convex Poisson data term + PD
# prior), so Newton from a warm start lands at the dual-exact mode in a few steps.

# AD-clean inner mode: minimise over b the joint negative log-density
#   f(b) = Σ_i[exp(η0_i + b_{s_i}) − y_i(η0_i + b_{s_i})] + ½ σ_b⁻² bᵀ C⁻¹ b,
# returning the mode b̂ and the Cholesky of H = σ_b⁻² C⁻¹ + diag(μ̂(b̂)). `Cinv` and
# `η0` carry the active element type so the whole solve is differentiable. `gidx`
# maps each observation to its site. Warm-started from `b0`.
function _poisson_spatial_mode(y, η0, gidx, Cinv, invσ2, b0;
                               maxiter::Int = 100, tol::Real = 1e-12)
    T = promote_type(eltype(η0), eltype(Cinv), typeof(invσ2))
    G = size(Cinv, 1)
    b = T.(b0)
    Hch = nothing
    met_tol = false
    last_sn = Inf
    for _ in 1:maxiter
        grad = invσ2 .* (Cinv * b)
        diagH = zeros(T, G)
        @inbounds for i in eachindex(y)
            k = gidx[i]
            μi = exp(clamp(η0[i] + b[k], -30.0, 30.0))
            grad[k] += μi - y[i]
            diagH[k] += μi
        end
        H = invσ2 .* Cinv + Diagonal(diagH)
        Hch = cholesky(Symmetric(H); check = false)
        issuccess(Hch) || return b, Hch, false
        step = Hch \ grad
        b = b .- step
        last_sn = ForwardDiff.value(norm(step))
        if last_sn <= tol * (1 + ForwardDiff.value(norm(b)))
            met_tol = true
            break
        end
    end
    # Cap exhausted (#1024). `tol = 1e-12` can sit below the rounding floor of
    # an ill-conditioned `Cinv`, so a last Newton step at the 1e-8 relative
    # level still counts as the mode (the Laplace value error is O(step^2));
    # anything larger means the loop ran out before reaching the mode.
    if !met_tol && Hch !== nothing
        met_tol = last_sn <= max(tol, 1e-8) * (1 + ForwardDiff.value(norm(b)))
    end
    (Hch === nothing || !met_tol) && return b, Hch, false
    # Refresh μ̂ / H at the final b so the returned Cholesky is exactly H(b̂).
    diagH = zeros(T, G)
    @inbounds for i in eachindex(y)
        k = gidx[i]
        diagH[k] += exp(clamp(η0[i] + b[k], -30.0, 30.0))
    end
    H = invσ2 .* Cinv + Diagonal(diagH)
    Hch = cholesky(Symmetric(H); check = false)
    return b, Hch, issuccess(Hch)
end

# Coordinate-spatial Poisson Laplace marginal NLL at θ = [β_μ; log σ_b; log ρ],
# with the inner mode warm-started from `bref` (a length-G buffer that the fit
# updates across outer iterations). Returns the marginal NLL only; the gradient
# and Hessian are taken by ForwardDiff over this function. `Ddist` is the G×G site
# distance matrix; `jitter` keeps C(ρ) strictly PD.
function _poisson_spatial_marginal(θ, y, Xμ, gidx, Ddist, lf, bref;
                                   jitter::Float64 = 1e-8)
    pμ = size(Xμ, 2)
    G = size(Ddist, 1)
    βμ = θ[1:pμ]
    logσ = clamp(θ[pμ+1], -8.0, 3.0)
    logρ = clamp(θ[pμ+2], -8.0, 8.0)
    invσ2 = exp(-2 * logσ)
    ρ = exp(logρ)
    T = eltype(θ)
    C = exp.(.-Ddist ./ ρ) .+ jitter .* Matrix(I, G, G)     # unit-diagonal spatial correlation
    Cchol = cholesky(Symmetric(C); check = false)
    issuccess(Cchol) || return convert(T, 1e18)
    Cinv = inv(Cchol)
    η0 = Xμ * βμ
    b, Hch, ok = _poisson_spatial_mode(y, η0, gidx, Cinv, invσ2, bref)
    ok || return convert(T, 1e18)
    bref .= ForwardDiff.value.(b)                           # warm start for the next outer eval
    data = zero(T)
    @inbounds for i in eachindex(y)
        ηi = clamp(η0[i] + b[gidx[i]], -30.0, 30.0)
        data += exp(ηi) - y[i] * ηi + lf[i]
    end
    prior = 0.5 * invσ2 * dot(b, Cinv * b)
    # −½ logdet(σ_b² C) = −½(2G logσ_b + logdet C) = −G logσ_b − ½ logdet C; the
    # marginal carries +½ logdet C⁻¹ = −½ logdet C and +G logσ_b enters from the
    # prior normaliser, matching `_fit_poisson_general_laplace` (val = … + q·logσ
    # − ½ logdetQ + ½ logdet H, with logdetQ = logdet C⁻¹ = −logdet C).
    return data + prior + G * logσ + 0.5 * logdet(Cchol) + 0.5 * logdet(Hch)
end

"""
    _fit_poisson_spatial_coord(fam, y, Xμ, labels, coords, nmμ, grp, g_tol; se)

Poisson `spatial(1 | grp)` fit with a coordinate-based exponential-kernel spatial
covariance `C(ρ) = exp(-d/ρ)` and the range `ρ` **estimated jointly**. The
site coordinates (`coords`, a `G×2` matrix, one row per group level in first-seen
order) give the pairwise distances `d`; the random intercept is `b ~ N(0, σ_b² C(ρ))`
on `log λ`. The outer parameter vector is `θ = [β_μ; log σ_b; log ρ]`, so `ρ` is a
genuine hyperparameter whose gradient flows through `C(ρ)` into the Laplace
marginal — not a fixed-range or profile-over-grid approximation.

The marginal is the Poisson Laplace approximation (same convention as the verified
sparse general-covariance path), written in AD-traceable operations so ForwardDiff
supplies the exact outer gradient and the covariance Hessian. Recovered blocks:
`:mu` (fixed effects), `:resd` (`log σ_b`), `:range` (`log ρ`).

!!! note
    The range `ρ` is only weakly identified from a single spatial realization;
    `:resd` (the spatial SD) and the fixed effects are the robustly recoverable
    pieces. For a precomputed spatial covariance, use `spatial(1 | grp)` with
    `K = …` instead (the verified O(p) sparse path).
"""
function _fit_poisson_spatial_coord(fam::Poisson, y, Xμ, labels, coords, nmμ, grp,
                                    g_tol; se::Bool = true)
    n = length(y)
    pμ = size(Xμ, 2)
    gidx, G = _group_index(labels)
    size(coords, 1) == G ||
        error("spatial(1 | $grp) coords must have one row per group level (G = $G), got $(size(coords, 1))")
    size(coords, 2) >= 1 ||
        error("spatial(1 | $grp) coords must have ≥ 1 coordinate column")
    Ddist = [sqrt(sum(abs2, @view(coords[k, :]) .- @view(coords[l, :]))) for k in 1:G, l in 1:G]
    offdiag = [Ddist[k, l] for k in 1:G for l in 1:G if k != l]
    meandist = isempty(offdiag) ? 1.0 : sum(offdiag) / length(offdiag)
    lf = [_logfactorial(round(Int, yi)) for yi in y]

    bref = zeros(G)                                          # inner-mode warm start (Float64 buffer)
    nll(θ) = _poisson_spatial_marginal(θ, y, Xμ, gidx, Ddist, lf, bref)

    θ0 = zeros(pμ + 2)
    θ0[1:pμ] .= _poisson_fixed_start(y, Xμ)
    θ0[pμ+1] = log(0.5)                                      # log σ_b
    θ0[pμ+2] = log(meandist)                                 # log ρ ≈ mean pairwise distance
    res = Optim.optimize(nll, θ0, Optim.LBFGS(), Optim.Options(g_tol = g_tol, iterations = 400);
                         autodiff = :forward)
    θ̂ = Optim.minimizer(res)
    V = if se
        try
            _vcov_from_hessian(ForwardDiff.hessian(nll, θ̂);
                               context = "poisson spatial coordinates")
        catch
            fill(NaN, length(θ̂), length(θ̂))
        end
    else
        fill(NaN, length(θ̂), length(θ̂))
    end

    blocks = [:mu => 1:pμ, :resd => (pμ+1):(pμ+1), :range => (pμ+2):(pμ+2)]
    names = [:mu => nmμ, :resd => [String(grp)], :range => ["range"]]
    means = Dict(:mu => exp.(Xμ * θ̂[1:pμ]))                 # population λ (b = 0)
    obs = Dict(:mu => Vector{Float64}(y))
    scales = Dict{Symbol,Vector{Float64}}()
    fit = DrmFit(fam, blocks, names, θ̂, Matrix(V), -nll(θ̂), n, drm_optim_converged(res), means, obs, scales)
    _warn_at_clamp("spatial Poisson", ["random-effect log SD" => (θ̂[pμ+1:pμ+1], -8.0, 3.0),   # #959
                                       "log range" => (θ̂[pμ+2:pμ+2], -8.0, 8.0)])
    return _withiterations(_withnll(fit, nll), Optim.iterations(res))
end
