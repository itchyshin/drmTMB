# beta.jl — Beta family for responses on the open interval (0,1) (proportions,
# rates, probabilities). Logit link on the mean μ; the `sigma` slot carries σ
# with drmTMB's precision mapping φ = 1/σ² (so coef(:sigma) is log σ). The
# likelihood is Beta(μφ, (1-μ)φ): mean μ, variance μ(1-μ)/(1+φ). Fixed effects,
# ML. `Distributions.Beta` is used qualified — DRModels exports its own `Beta` family.

import Distributions

"""
    Beta()

Beta response family for proportions in `(0,1)`: logit link on the mean `μ`, and
the `sigma` slot carries `σ` with the precision mapping `φ = 1/σ²` (so
`coef(fit, :sigma)` is `log σ`; recover precision as `exp(-2·log σ)`). Likelihood
`Beta(μφ, (1-μ)φ)`. Mirrors `drmTMB`'s `beta_family`.
An ordinary mean random intercept or one independent numeric mean slope also
supports a predictor-dependent SD through `sd(group) ~ predictors`. A slope
targets its coefficient SD with `sd(group, coef(x)) ~ predictor`; the slope
loading is applied at each row. These routes require complete responses and
fixed `sigma ~ 1`; correlated blocks, structured effects, and calibrated
intervals remain unsupported.
Crossed random intercepts on the mean, such as `(1 | g) + (1 | h)`, use the
sparse-Laplace engine when `sigma ~ 1`. A phylogenetic random intercept on the
mean, `phylo(1 | species)`, also uses the sparse-Laplace engine, as do general
user-supplied PD-covariance intercepts — `relmat(1 | id)` with `K = C`, the
`animal(1 | id)` (`A = C`) and `spatial(1 | id)` (`K = C`) aliases.

!!! note
    `DRModels.Beta` shadows `Distributions.Beta`; qualify the latter if you need it.

```julia
fit = drm(bf(y ~ x, sigma ~ 1), Beta(); data = dat)
fit = drm(bf(y ~ x + (1 | g) + (1 | h), sigma ~ 1), Beta(); data = dat)
fit_phy = drm(bf(@formula(y ~ x + phylo(1 | species)), @formula(sigma ~ 1)),
              Beta(); data = dat, tree = tr, se = false)
exp(-2 * coef(fit, :sigma)[1])     # estimated precision φ

# Experimental: Beta random-intercept variational (ELBO) marginal.
# Requires `sigma ~ 1`. Default remains `marginal = :LA` (GHQ-32 on an ordinary `(1 | g)`).
fit_va = drm(bf(@formula(y ~ x + (1 | g)), @formula(sigma ~ 1)), Beta();
             data = dat, marginal = :VA)

# TMB-convention Laplace on an ordinary `(1 | g)`, as native drmTMB fits it.
# Requires `sigma ~ 1`; ML only.
fit_lap = drm(bf(@formula(y ~ x + (1 | g)), @formula(sigma ~ 1)), Beta();
              data = dat, marginal = :Laplace)
```
"""
struct Beta end

_logistic(η) = 1 / (1 + exp(-η))

function drm(f::DrmFormula, fam::Beta; data, tree = nothing, K = nothing,
             A = nothing, coords = nothing, g_tol::Real = 1e-8, se::Bool = true,
             marginal::Symbol = :LA, method = nothing)
    _reject_method_as_marginal(fam, method)
    !isempty(_sd_parts(f)) &&
        return _drm_beta_sd_regression(f, fam; data, tree, K, A, coords,
                                       g_tol, se, marginal)
    _scalar_laplace_requested(marginal) &&     # Arc 2: TMB-convention Laplace, ordinary (1 | g)
        return _drm_ordinary_laplace(f, fam; data = data, tree = tree, K = K, A = A,
                                     coords = coords, g_tol = g_tol, se = se, method = method)
    missing_fit = _fit_observed_response_rows(f, data) do data_observed
        drm(f, fam; data = data_observed, tree = tree, K = K, A = A,
            coords = coords, g_tol = g_tol, se = se, marginal = marginal, method = method)
    end
    missing_fit !== nothing && return missing_fit

    marg = _marginal_method(marginal)                     # :LA (default), :VA (#136), or :AGHQ (#761)
    isaghq = marg isa AGHQ
    isva = marg isa Variational
    _lss_only_gaussian_guard(f, fam)   # #544: refuse, never silently drop, sd() parts
    rhs = Dict(f.forms)
    fixed_mu, re, mv, st = _split_ranef(rhs[:mu])
    isaghq && !(length(re) > 1 && st === nothing) &&
        _aghq_reject(fam, "this model (Beta `marginal = :AGHQ` covers crossed random " *
                          "intercepts `(1 | g) + (1 | h)` only, #761)")
    mv === nothing ||
        error("Beta() does not support meta_V markers")
    for (pname, r) in f.forms          # only the mean may carry a random effect
        pname === :mu && continue
        _, re2, mv2, st2 = _split_ranef(r)
        (isempty(re2) && mv2 === nothing && st2 === nothing) ||
            error("Beta(): only the mean formula may carry a random effect")
    end
    y, Xμ, nmμ = _design(f.response, fixed_mu, data)
    _, Xσ, nmσ = _design(f.response, get(rhs, :sigma, ConstantTerm(1)), data)
    all(yi -> 0 < yi < 1, y) ||
        error("Beta() requires responses strictly in the open interval (0, 1)")
    if st !== nothing
        isva && _va_reject(fam, "a phylogenetic/structured random effect")
        isempty(re) ||
            error("Beta() phylo structured effects cannot be combined with ordinary random effects yet")
        # `sigma ~ 1` keeps the scalar-dispersion spine; a covariate `sigma`
        # formula routes to the per-observation log-dispersion path (#164).
        kind, grp = st
        labels = getproperty(data, grp)
        if kind === :phylo
            tree === nothing && error("phylo(1 | $grp) needs `tree = ...`")
            return _withformula(_fit_beta_phylo_laplace(fam, y, Xμ, Xσ, labels, tree, nmμ, nmσ, grp, g_tol; se = se), f)
        elseif kind === :relmat || kind === :animal || kind === :spatial
            # General user-supplied PD covariance C on the mean (logit) intercept
            # (relatedness / animal model / precomputed spatial), with the Beta
            # precision a fixed nuisance. Reuses the phylo nuisance Laplace spine
            # with the tree precision swapped for C⁻¹ (#167).
            C = _poisson_structured_cov(kind, grp, K, A, coords)
            return _withformula(_fit_beta_relmat_laplace(fam, y, Xμ, Xσ, C, labels, nmμ, nmσ, grp, g_tol; se = se), f)
        else
            error("Beta() supports phylo/relmat/animal/spatial(1 | group) among structured markers")
        end
    end
    if !isempty(re)                    # random effect on the logit mean → GHQ/Laplace or VA (#136)
        if length(re) > 1
            isva && _va_reject(fam, "crossed/multiple random intercepts")
            all(_re_kind(r[1])[1] === :intercept for r in re) ||
                error("Beta() supports multiple random effects only as crossed/nested intercepts, e.g. `(1 | g) + (1 | h)`")
            comps = map(re) do r
                grp = r[2]; gidx, G = _group_index(getproperty(data, grp))
                (ones(length(y)), gidx, G, String(grp))
            end
            isaghq && return _withformula(_fit_beta_crossed_aghq(fam, y, Xμ, Xσ, comps, nmμ, nmσ, g_tol; se = se), f)   # #761
            return _withformula(_fit_beta_crossed_laplace(fam, y, Xμ, Xσ, comps, nmμ, nmσ, g_tol; se = se), f)
        end
        (rk, var) = _re_kind(re[1][1]); grp = re[1][2]
        gidx, G = _group_index(getproperty(data, grp))
        if rk === :intercept            # (1 | g) → 1-D Gauss–Hermite (Laplace) or VA (#136)
            if isva
                size(Xσ, 2) == 1 || _va_reject(fam, "a non-constant `sigma` formula (VA kernels require `sigma ~ 1`)")
                return _withformula(_withmarginal(
                    _fit_beta_ranef_va(fam, y, Xμ, Xσ, gidx, G, nmμ, nmσ, grp, g_tol), :VA), f)
            end
            return _withformula(_fit_beta_ranef(fam, y, Xμ, Xσ, gidx, G, nmμ, nmσ, grp, g_tol), f)
        elseif rk === :corr             # (1 + x | g) → 2-D Gauss–Hermite marginal
            isva && _va_reject(fam, "a correlated random slope `(1 + x | g)`")
            return _withformula(_fit_beta_corr_ranef(fam, y, Xμ, Xσ, Float64.(getproperty(data, var)), gidx, G, nmμ, nmσ, grp, g_tol), f)
        else
            error("Beta() supports `(1 | g)` or `(1 + x | g)` on the mean, not `(0 + x | g)`")
        end
    end
    isva && _va_reject(fam, "no random intercept (fixed-effects-only)")
    return _withformula(_fit_beta(fam, y, Xμ, Xσ, nmμ, nmσ, g_tol), f)
end

function _drm_beta_sd_regression(f::DrmFormula, fam::Beta; data,
                                tree = nothing, K = nothing, A = nothing,
                                coords = nothing, g_tol::Real = 1e-8,
                                se::Bool = true, marginal::Symbol = :LA,
                                nAGQ::Int = _RANEF1D_AGHQ_K)
    marginal === :LA || throw(ArgumentError(
        "Beta `sd(group) ~ …` currently supports `marginal = :LA` only."))
    (tree === nothing && K === nothing && A === nothing && coords === nothing) ||
        throw(ArgumentError("Beta `sd(group) ~ …` currently supports one ordinary independent mean intercept or numeric slope; structured covariance inputs are not used."))
    isempty(_sdphylo_parts(f)) || throw(ArgumentError(
        "Beta `sd(group, phylogenetic) ~ …` is not implemented by the ordinary random-intercept route."))
    targets = _sd_target_parts(f)
    length(targets) == 1 || throw(ArgumentError(
        "Beta random-effect SD regression requires exactly one `sd(group) ~ …` formula."))
    target = only(targets)
    (target.target.level === :iid && target.target.dpar === :mu &&
     target.target.block === nothing) || throw(ArgumentError(
        "Beta SD regression currently targets one ordinary mean intercept or independent slope."))
    sgrp, srhs = target.target.group, target.rhs
    rhs = Dict(f.forms)
    fixed_mu, re, mv, st = _split_ranef(rhs[:mu])
    mv === nothing || throw(ArgumentError("Beta `sd($sgrp)` cannot use meta_V()."))
    st === nothing || throw(ArgumentError(
        "Beta `sd($sgrp)` currently requires one ordinary random-effect term."))
    length(re) == 1 || throw(ArgumentError(
        "Beta `sd($sgrp)` currently requires exactly one ordinary random-effect term."))
    kind, slope = _re_kind(re[1][1])
    member = kind === :intercept ? :intercept : kind === :slope ? slope : nothing
    kind in (:intercept, :slope) || throw(ArgumentError(
        "Beta `sd($sgrp)` supports `(1 | $sgrp)` or one independent numeric slope `(0 + x | $sgrp)`; correlated blocks are not implemented on this route."))
    target.target.member in (nothing, member) || throw(ArgumentError(
        "Beta SD target `coef($(target.target.member))` does not match the fitted random-effect coefficient `$(member)`."))
    grp = re[1][2]
    grp === sgrp || throw(ArgumentError(
        "Beta `sd($sgrp)` must name the random-effect grouping variable `$grp`."))
    sigma_rhs = get(rhs, :sigma, nothing)
    sigma_rhs isa ConstantTerm && sigma_rhs == ConstantTerm(1) || throw(ArgumentError(
        "Beta `sd($grp)` requires a fixed `sigma ~ 1` submodel."))
    for (pname, _) in f.forms
        (pname in (:mu, :sigma, Symbol("sd_", sgrp)) || haskey(f.sd_targets, pname)) && continue
        throw(ArgumentError("Beta `sd($grp)` supports only `mu`, fixed `sigma ~ 1`, and one `sd($grp)` formula."))
    end
    all(_formula_response_observed_mask(f, data)) || throw(ArgumentError(
        "Beta random-effect SD regression requires observed responses; remove incomplete rows before fitting."))
    y, Xmu, nmmu = _design(f.response, fixed_mu, data)
    _, Xsigma, nmsigma = _design(f.response, sigma_rhs, data)
    all(yi -> 0 < yi < 1, y) || throw(ArgumentError(
        "Beta() requires responses strictly in the open interval (0, 1)"))
    gidx, G = _group_index(getproperty(data, grp))
    Zg, nmsd = _sd_group_design(f.response, srhs, data, gidx, G, grp;
                                schema_cache = f.schema_cache,
                                schema_key = target.key)
    size(Zg, 2) <= G && rank(Zg) == size(Zg, 2) || throw(ArgumentError(
        "Beta `sd($grp)` group-level design is rank deficient; use predictors that vary independently across groups."))
    w = if kind === :intercept
        ones(length(y))
    else
        hasproperty(data, slope) || throw(ArgumentError(
            "Beta random-slope predictor `$slope` is absent from data."))
        raw = getproperty(data, slope)
        raw isa AbstractVector{<:Real} || throw(ArgumentError(
            "Beta random-slope predictor `$slope` must be numeric."))
        length(raw) == length(y) && all(isfinite, raw) || throw(ArgumentError(
            "Beta random-slope predictor `$slope` must contain one finite value per retained response."))
        Float64.(raw)
    end
    return _withformula(_fit_beta_sd_regression(fam, y, Xmu, Xsigma, Zg,
        gidx, G, nmmu, nmsigma, nmsd, grp, g_tol; K = nAGQ, se, w), f)
end

function _fit_beta_sd_regression(fam::Beta, y, Xmu, Xsigma, Zg, gidx, G,
                                 nmmu, nmsigma, nmsd, grp, g_tol;
                                 K::Int = _RANEF1D_AGHQ_K, se::Bool = true,
                                 w::AbstractVector{<:Real} = ones(length(y)))
    K >= 1 || throw(ArgumentError("nAGQ must be ≥ 1; got $K"))
    n = length(y); pmu, psigma, psd = size(Xmu, 2), size(Xsigma, 2), size(Zg, 2)
    members = [Int[] for _ in 1:G]
    for i in 1:n
        push!(members[gidx[i]], i)
    end
    rule = _AGHQRule(1, K)
    length(w) == n || throw(ArgumentError(
        "Beta random-effect loading must have one value per observation."))
    Zre = reshape(Float64.(w), n, 1)
    bcache = [zeros(1, G) for _ in 1:Threads.nthreads()]
    function nll(theta)
        beta_mu = @view theta[1:pmu]
        beta_sigma = @view theta[(pmu+1):(pmu+psigma)]
        alpha = @view theta[(pmu+psigma+1):(pmu+psigma+psd)]
        eta_mu = Xmu * beta_mu
        eta_sigma = clamp.(Xsigma * beta_sigma, -15.0, 15.0)
        sdgroup = exp.(Zg * alpha)
        ll = (i, eta) -> begin
            mu = _logistic(clamp(eta, -30.0, 30.0))
            precision = exp(-2 * eta_sigma[i])
            Distributions.logpdf(Distributions.Beta(mu * precision,
                (1 - mu) * precision), y[i])
        end
        cache = bcache[Threads.threadid()]
        total = zero(eltype(theta))
        for gi in 1:G
            Lg = reshape([sdgroup[gi]], 1, 1)
            value, bhat = _aghq_group_logint(ll, members[gi], eta_mu, Zre,
                                             Lg, rule, @view(cache[:, gi]))
            cache[1, gi] = isfinite(bhat[1]) ? bhat[1] : 0.0
            total += value
        end
        return -total
    end
    ybar = sum(y) / n; v = sum(abs2, y .- ybar) / max(n - 1, 1)
    precision0 = max(ybar * (1 - ybar) / max(v, eps()) - 1, 0.5)
    theta0 = zeros(pmu + psigma + psd)
    if all(isone, Zre)
        theta0[1] = log(ybar / (1 - ybar))
    else
        ylogit = log.(clamp.(Float64.(y), 1e-4, 1 - 1e-4) ./
                       (1 .- clamp.(Float64.(y), 1e-4, 1 - 1e-4)))
        theta0[1:pmu] .= Xmu \ ylogit
    end
    theta0[pmu+1] = -0.5 * log(precision0)
    theta0[(pmu+psigma+1):end] .= Zg \ fill(log(0.5), G)
    res = Optim.optimize(nll, theta0, Optim.LBFGS(),
                         Optim.Options(g_tol = g_tol); autodiff = :forward)
    theta_hat = Optim.minimizer(res)
    V = se ? _vcov_from_hessian(ForwardDiff.hessian(nll, theta_hat)) :
             fill(NaN, length(theta_hat), length(theta_hat))
    blocks = [:mu => 1:pmu, :sigma => (pmu+1):(pmu+psigma),
              :sd => (pmu+psigma+1):(pmu+psigma+psd)]
    names = [:mu => nmmu, :sigma => nmsigma, :sd => nmsd]
    sdgroup = exp.(Zg * theta_hat[(pmu+psigma+1):end])
    means = Dict(:mu => _logistic.(Xmu * theta_hat[1:pmu]))
    obs = Dict(:mu => Vector{Float64}(y))
    scales = Dict(:sigma => exp.(Xsigma * theta_hat[(pmu+1):(pmu+psigma)]),
                  :sd_group => sdgroup, :sd => sdgroup[gidx],
                  :sd_group_index => Float64.(gidx), :aghq_nodes => [Float64(K)])
    return _withiterations(_withnll(DrmFit(fam, blocks, names, theta_hat, V,
        -nll(theta_hat), n, Optim.converged(res), means, obs, scales), nll),
        Optim.iterations(res))
end

# Beta GLMM with a random intercept (1|g) on the logit mean. b_g ~ N(0,σ_b²)
# integrated out per group by 32-node Gauss–Hermite quadrature; precision
# φ = 1/σ² is a fixed effect. Same scheme as the count GLMMs.
function _fit_beta_ranef(fam::Beta, y, Xμ, Xσ, gidx, G, nmμ, nmσ, grp, g_tol; K::Int = _RANEF1D_AGHQ_K)
    n = length(y); pμ, pσ = size(Xμ, 2), size(Xσ, 2)
    members = [Int[] for _ in 1:G]
    for i in 1:n
        push!(members[gidx[i]], i)
    end
    rule = _AGHQRule(1, K); Zre = ones(n, 1); bcache = zeros(1, G)   # #719: per-group AGHQ
    function nll(θ)
        βμ = θ[1:pμ]; βσ = θ[pμ+1:pμ+pσ]; σb = exp(θ[pμ+pσ+1])
        η0 = Xμ * βμ; ησ = clamp.(Xσ * βσ, -15.0, 15.0)
        ll = (i, η) -> (μ = _logistic(clamp(η, -30.0, 30.0)); φ = exp(-2 * ησ[i]);
                        Distributions.logpdf(Distributions.Beta(μ * φ, (1 - μ) * φ), y[i]))
        L = reshape([σb], 1, 1)
        return -_aghq_marginal_loglik(ll, members, η0, Zre, L, rule, bcache)
    end
    ȳ = sum(y) / n; v = sum(abs2, y .- ȳ) / max(n - 1, 1)
    φ0 = max(ȳ * (1 - ȳ) / max(v, eps()) - 1, 0.5)
    θ0 = zeros(pμ + pσ + 1)
    θ0[1] = log(ȳ / (1 - ȳ)); θ0[pμ+1] = -0.5 * log(φ0); θ0[pμ+pσ+1] = log(0.5)
    res = Optim.optimize(nll, θ0, Optim.LBFGS(), Optim.Options(g_tol = g_tol); autodiff = :forward)
    θ̂ = Optim.minimizer(res); V = _vcov_from_hessian(ForwardDiff.hessian(nll, θ̂))
    blocks = [:mu => 1:pμ, :sigma => (pμ+1):(pμ+pσ), :resd => (pμ+pσ+1):(pμ+pσ+1)]
    names = [:mu => nmμ, :sigma => nmσ, :resd => [String(grp)]]
    means = Dict(:mu => _logistic.(Xμ * θ̂[1:pμ])); obs = Dict(:mu => Vector{Float64}(y))
    scales = Dict(:sigma => exp.(Xσ * θ̂[(pμ+1):(pμ+pσ)]))
    return _withiterations(
        _withnll(DrmFit(fam, blocks, names, θ̂, V, -nll(θ̂), n, Optim.converged(res), means, obs, scales), nll),
        Optim.iterations(res))
end

# Beta GLMM with a correlated random intercept+slope (1 + x | g) on the logit
# mean: per group (b0,b1) ~ N(0, Σ), Σ = L Lᵀ with L = [l11 0; cc l22] (log-
# Cholesky a=log l11, b=log l22, cc). The 2-D group integral is taken by
# per-group ADAPTIVE Gauss–Hermite quadrature
# (`_aghq_marginal_loglik`, #834: nodes b̂_g + √2 C z at each group's mode),
# `nq` nodes per axis, the same scheme as the count GLMMs; precision φ = 1/σ² is a
# fixed effect. θ = [β_μ; β_σ; a, b, cc].
function _fit_beta_corr_ranef(fam::Beta, y, Xμ, Xσ, xs, gidx, G, nmμ, nmσ, grp, g_tol; nq::Int = _CORR_RANEF_AGHQ_K)
    n = length(y); pμ, pσ = size(Xμ, 2), size(Xσ, 2)
    members = [Int[] for _ in 1:G]
    for i in 1:n
        push!(members[gidx[i]], i)
    end
    rule = _AGHQRule(2, nq); Zre = hcat(ones(n), Float64.(xs)); bcache = zeros(2, G)   # #834: per-group AGHQ
    function nll(θ)
        βμ = θ[1:pμ]; βσ = θ[pμ+1:pμ+pσ]
        L = _corr_ranef_L(θ[pμ+pσ+1], θ[pμ+pσ+2], θ[pμ+pσ+3])
        η0 = Xμ * βμ; ησ = clamp.(Xσ * βσ, -15.0, 15.0)
        ll = (i, η) -> (μ = _logistic(clamp(η, -30.0, 30.0)); φ = exp(-2 * ησ[i]);
                        Distributions.logpdf(Distributions.Beta(μ * φ, (1 - μ) * φ), y[i]))
        return -_aghq_marginal_loglik(ll, members, η0, Zre, L, rule, bcache)
    end
    ȳ = sum(y) / n; v = sum(abs2, y .- ȳ) / max(n - 1, 1)
    φ0 = max(ȳ * (1 - ȳ) / max(v, eps()) - 1, 0.5)
    θ0 = zeros(pμ + pσ + 3)
    θ0[1] = log(ȳ / (1 - ȳ)); θ0[pμ+1] = -0.5 * log(φ0)
    θ0[pμ+pσ+1] = log(0.4); θ0[pμ+pσ+2] = log(0.4); θ0[pμ+pσ+3] = 0.0
    res = Optim.optimize(nll, θ0, Optim.LBFGS(), Optim.Options(g_tol = g_tol); autodiff = :forward)
    θ̂ = Optim.minimizer(res); V = _vcov_from_hessian(ForwardDiff.hessian(nll, θ̂))
    blocks = [:mu => 1:pμ, :sigma => (pμ+1):(pμ+pσ), :recov => (pμ+pσ+1):(pμ+pσ+3)]
    names = [:mu => nmμ, :sigma => nmσ, :recov => ["$(grp):L11", "$(grp):L22", "$(grp):L21"]]
    means = Dict(:mu => _logistic.(Xμ * θ̂[1:pμ])); obs = Dict(:mu => Vector{Float64}(y))
    scales = Dict(:sigma => exp.(Xσ * θ̂[(pμ+1):(pμ+pσ)]))
    return _withiterations(
        _withnll(DrmFit(fam, blocks, names, θ̂, V, -nll(θ̂), n, Optim.converged(res), means, obs, scales), nll),
        Optim.iterations(res))
end

function _fit_beta(fam::Beta, y, Xμ, Xσ, nmμ, nmσ, g_tol)
    n = length(y); pμ, pσ = size(Xμ, 2), size(Xσ, 2)
    function nll(θ)
        βμ = θ[1:pμ]; βσ = θ[pμ+1:pμ+pσ]
        # Soft guards (see `_softclamp` in negbinomial.jl): identity across the
        # original hard band so no legitimate fit is distorted, smooth beyond so
        # the gradient stays live — restoring agreement with drmTMB's smooth guard.
        ημ = _softclamp.(Xμ * βμ, -30.0, 30.0, 3.0)   # μ ∈ (0,1) strictly
        ησ = _softclamp.(Xσ * βσ, -15.0, 15.0, 3.0)   # φ = exp(-2ησ) finite & > 0
        s = zero(eltype(θ))
        @inbounds for i in 1:n
            μ = _logistic(ημ[i]); φ = exp(-2 * ησ[i])
            s -= Distributions.logpdf(Distributions.Beta(μ * φ, (1 - μ) * φ), y[i])
        end
        return s
    end
    ȳ = sum(y) / n; v = sum(abs2, y .- ȳ) / max(n - 1, 1)
    φ0 = max(ȳ * (1 - ȳ) / max(v, eps()) - 1, 0.5)   # method-of-moments precision
    θ0 = zeros(pμ + pσ)
    θ0[1] = log(ȳ / (1 - ȳ))                          # logit mean
    θ0[pμ+1] = -0.5 * log(φ0)                          # σ = 1/√φ ⇒ log σ = -½ log φ
    res = Optim.optimize(nll, θ0, Optim.LBFGS(), Optim.Options(g_tol = g_tol); autodiff = :forward)
    θ̂ = Optim.minimizer(res); V = _vcov_from_hessian(ForwardDiff.hessian(nll, θ̂))
    blocks = [:mu => 1:pμ, :sigma => (pμ+1):(pμ+pσ)]
    names = [:mu => nmμ, :sigma => nmσ]
    means = Dict(:mu => _logistic.(Xμ * θ̂[1:pμ])); obs = Dict(:mu => Vector{Float64}(y))  # response-scale μ̂
    scales = Dict(:sigma => exp.(Xσ * θ̂[(pμ+1):(pμ+pσ)]))
    return _withiterations(
        _withnll(DrmFit(fam, blocks, names, θ̂, V, -nll(θ̂), n, Optim.converged(res), means, obs, scales), nll),
        Optim.iterations(res))
end
