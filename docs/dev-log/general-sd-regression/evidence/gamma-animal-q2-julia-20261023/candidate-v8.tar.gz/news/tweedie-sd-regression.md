Predictor-dependent SD for Tweedie mean random effects in Julia
--------------------------------------------------------------

`Tweedie()` now supports `sd(group) ~ predictors` for one ordinary mean
random intercept, or `sd(group, coef(x)) ~ predictors` for one independent
numeric mean slope. SD predictors must be constant within groups. The route
uses adaptive Gauss–Hermite integration and provides rowwise SD predictions
through `predict_parameters()`. Synthetic recovery and constant-SD equivalence
are checked; interval coverage is not calibrated. Correlated blocks,
structured effects, and missing responses remain unsupported on this route.
