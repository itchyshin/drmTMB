`TruncatedNegBinomial2()` now supports predictor-dependent SDs for one ordinary
mean random intercept or one independent numeric mean slope in the Julia engine.
The slope route has synthetic recovery and an independent scalar-integral
likelihood check. Interval coverage calibration and structured effects remain
outside this implementation slice.
