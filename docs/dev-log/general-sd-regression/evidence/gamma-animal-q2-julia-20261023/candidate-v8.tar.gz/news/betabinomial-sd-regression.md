# Beta-binomial random-effect SD regression

The Julia engine now supports `sd(group) ~ predictors` for one ordinary mean
random intercept or one independent numeric mean slope in a BetaBinomial model,
with fixed `sigma ~ 1`. SD predictors must be constant within group. The slice
includes synthetic recovery, rowwise coefficient-SD predictions, constant-SD
equivalence for the intercept, and independent fixed-parameter integration
checks. Interval coverage is not calibrated; correlated blocks and structured
effects remain unsupported on this route.
