# LogNormal random-effect SD regression

In Julia, `LogNormal()` supports one ordinary mean random intercept or one
independent numeric mean slope with a predictor-dependent coefficient SD. Use
`sd(group) ~ predictors` for an intercept and
`sd(group, coef(x)) ~ predictors` for the slope in `(0 + x | group)`. Both
routes require fixed `sigma ~ 1`, complete responses, and SD predictors that
are constant within group. The exact Gaussian-on-log-response likelihood is
used with the LogNormal Jacobian. The slope SD describes the coefficient, whose
row-level contribution is multiplied by `x`. Correlated blocks, structured SD
effects, and interval coverage calibration remain open.
