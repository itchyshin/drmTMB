# Cumulative-logit random-effect SD regression

`CumulativeLogit()` now supports a predictor-dependent SD for one ordinary
location random intercept or independent numeric slope in Julia. Use
`sd(group) ~ predictors` when that coefficient is unique; add `coef(x)` to select
a slope explicitly. SD predictors must be constant within group. The scale is
defined on the cumulative-logit link scale, and the route requires complete
outcomes. Correlated blocks, structured effects, R/TMB parity, and calibrated
interval coverage remain open.
