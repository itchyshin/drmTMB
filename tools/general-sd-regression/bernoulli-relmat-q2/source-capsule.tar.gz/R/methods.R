#' @export
print.drmTMB <- function(x, ...) {
  label <- switch(
    x$model$model_type,
    gaussian = "Gaussian location-scale",
    student = "Student-t location-scale-shape",
    skew_normal = "skew-normal location-scale-shape",
    lognormal = "Lognormal location-scale",
    gamma = "Gamma mean-CV",
    beta = "Beta mean-scale",
    zero_one_beta = "zero-one beta mean-scale-boundary",
    beta_binomial = "Beta-binomial mean-overdispersion",
    # Name the link. Binomial is the only family admitting more than one, so
    # without it a probit fit prints identically to a logit fit and the user
    # cannot tell from the output which model they fitted.
    # (Emmy, Arc D go/no-go review.)
    binomial = paste0(
      "Binomial event-probability (",
      if (is.null(x$model$link)) "logit" else x$model$link,
      " link)"
    ),
    cumulative_logit = "cumulative-logit ordinal",
    poisson = "Poisson mean",
    zi_poisson = "zero-inflated Poisson mean",
    nbinom2 = "negative binomial 2 mean-dispersion",
    truncated_nbinom2 = "zero-truncated negative binomial 2 mean-dispersion",
    hurdle_nbinom2 = "hurdle negative binomial 2 mean-dispersion",
    zi_nbinom2 = "zero-inflated negative binomial 2 mean-dispersion",
    biv_gaussian = "bivariate Gaussian location-scale-coscale",
    biv_lognormal = "bivariate lognormal location-scale-coscale",
    biv_student = "bivariate Student-t location-scale-shape-coscale",
    "distributional"
  )
  cli::cli_text("<drmTMB {label} fit>")
  cli::cli_text("  observations: {x$nobs}")
  if (!is.null(x$estimator)) {
    cli::cli_text("  estimator: {x$estimator}")
  }
  if (!is.null(x$penalty)) {
    cli::cli_text(
      "  penalty: phylogenetic PC-prior (MAP); logLik shown is unpenalized"
    )
  }
  if (has_mu_random_effects(x)) {
    cli::cli_text("  mu random-effect terms: {n_mu_random_effect_terms(x)}")
  }
  if (has_sigma_random_effects(x)) {
    cli::cli_text("  sigma random-effect terms: {length(x$sdpars$sigma)}")
  }
  if (drm_is_mspl(x)) {
    if (isTRUE(x$mspl$wald$spd)) {
      cli::cli_text(
        "  standard errors: fixed-effect Wald SEs available via {.fn vcov} and {.fn summary}; confidence intervals are not implemented for MSPL fits."
      )
    } else {
      cli::cli_text(
        "  standard errors: unavailable ({.val {x$mspl$wald$status}}); point estimates only."
      )
    }
  } else {
    uncertainty <- drm_uncertainty_status(x)
    if (!identical(uncertainty, "ok")) {
      cli::cli_text(
        "  standard errors: unavailable; point estimates only ({drm_uncertainty_message(x)})"
      )
    }
  }
  if (drm_is_mspl(x)) {
    cli::cli_text(
      "  penalized objective: {format(x$mspl$penalized_objective, digits = 4)}"
    )
    cli::cli_text("  likelihood inference: unavailable for experimental MSPL")
  } else {
    cli::cli_text("  logLik: {format(x$logLik, digits = 4)}")
  }
  if (is.null(drm_convergence_label(x$opt$convergence, x$opt$message))) {
    cli::cli_text("  convergence: {x$opt$convergence}")
  } else {
    cli::cli_text(
      "  convergence: {x$opt$convergence} (not converged; see {.fn check_drm})"
    )
  }
  blocks <- coef(x)
  if (length(blocks)) {
    cli::cli_text("  fixed effects:")
    for (nm in names(blocks)) {
      block <- blocks[[nm]]
      if (length(block)) {
        formatted <- paste0(names(block), " = ", format(signif(block, 4)), collapse = ", ")
        cli::cli_text("    {nm}: {formatted}")
      }
    }
  }
  invisible(x)
}

#' Extract fixed-effect coefficients
#'
#' `fixef()` returns the fixed-effect coefficients for one distributional
#' parameter, or all fixed-effect coefficient blocks when `dpar = NULL`.
#' It is a mixed-model-friendly alias for `coef()`.
#'
#' @param object A `drmTMB` fit.
#' @param dpar Optional distributional parameter name, such as `"mu"`,
#'   `"sigma"`, `"hu"`, `"rho12"`, `"sd(id)"`, or
#'   `"sd_phylo(species)"`.
#' @param ... Reserved for future extractor options.
#'
#' @return A named numeric vector when `dpar` is supplied, otherwise a named
#'   list of coefficient vectors.
#'
#' @examples
#' set.seed(20260525)
#' dat <- data.frame(
#'   y = 0.2 + 0.6 * seq(-1, 1, length.out = 24) + rnorm(24, sd = 0.5),
#'   x = seq(-1, 1, length.out = 24)
#' )
#' fit <- drmTMB(bf(y ~ x, sigma ~ x), data = dat)
#'
#' # One distributional parameter at a time: a named numeric vector.
#' fixef(fit, "mu")
#' coef(fit, "sigma")
#'
#' # Omit `dpar` for every block at once: a named list, one element per
#' # distributional parameter. `coef()` and `fixef()` return the same structure.
#' coef(fit)
#' names(coef(fit))
#' identical(coef(fit), fixef(fit))
#' @rdname fixef
#' @exportS3Method nlme::fixef
fixef.drmTMB <- function(object, dpar = NULL, ...) {
  coef.drmTMB(object, dpar = dpar, ...)
}

#' Extract conditional random-effect estimates
#'
#' `ranef()` returns conditional random-effect estimates for one fitted random
#' effect block, or all fitted random-effect blocks when `dpar = NULL`.
#'
#' The returned blocks use the internal `drmTMB` structure: `values` are on the
#' model scale, `latent` are the corresponding standard-normal latent effects,
#' and `terms` split model-scale values by random-effect term.
#'
#' @param object A `drmTMB` fit.
#' @param dpar Optional random-effect block name, such as `"mu"`, `"sigma"`,
#'   `"phylo_mu"`, or `"spatial_mu"`.
#' @param ... Reserved for future extractor options.
#'
#' @return A named list of random-effect blocks when `dpar = NULL`, otherwise
#'   one random-effect block.
#'
#' @examples
#' set.seed(20260525)
#' id <- factor(rep(letters[1:8], each = 8))
#' x <- rep(seq(-1, 1, length.out = 8), times = 8)
#' u <- rnorm(nlevels(id), sd = 0.9)
#' dat <- data.frame(
#'   y = 0.2 + 0.7 * x + u[id] + rnorm(length(x), sd = 0.3),
#'   x = x,
#'   id = id
#' )
#' fit <- drmTMB(bf(y ~ x + (1 | id), sigma ~ 1), data = dat)
#' names(ranef(fit))
#' head(ranef(fit, "mu")$terms[["(1 | id)"]])
#' @rdname ranef
#' @export
ranef.drmTMB <- function(object, dpar = NULL, ...) {
  blocks <- object$random_effects
  if (is.null(dpar)) {
    return(blocks)
  }
  if (!length(blocks)) {
    cli::cli_abort("This {.cls drmTMB} fit does not contain random effects.")
  }
  if (!dpar %in% names(blocks)) {
    cli::cli_abort(c(
      "Unknown random-effect block {.val {dpar}}.",
      i = "Available blocks: {.val {names(blocks)}}."
    ))
  }
  blocks[[dpar]]
}

#' Extract structured-effect metadata
#'
#' `structured_effects()` returns the structured random-effect markers that
#' `drmTMB` parsed and fitted. It gives downstream tools a stable post-fit
#' metadata table so they do not need to grep or re-parse formula text.
#'
#' The current fitted marker grammar is:
#'
#' * `phylo(1 | species, tree = tree)`
#' * `spatial(1 | site, coords = coords)`
#' * `animal(1 | id, pedigree = pedigree)`,
#'   `animal(1 | id, A = A)`, or `animal(1 | id, Ainv = Ainv)`
#' * `relmat(1 | id, K = K)` or `relmat(1 | id, Q = Q)`
#' * `phylo_interaction(1 | plant:pollinator, tree1 = plant_tree, tree2 = pollinator_tree)`
#' * Binomial only: `phylo_interaction(0 + x | plant:pollinator, tree1 = plant_tree, tree2 = pollinator_tree)`
#'
#' Some Gaussian routes also fit matching location-scale, bivariate, or
#' one-slope structured blocks. Those routes still return one row per parsed
#' structured marker, with `dpars` and `coef_names` stored as list columns.
#'
#' @param object A `drmTMB` fit.
#' @param ... Reserved for future extractor options.
#'
#' @return A data frame with one row per fitted structured-effect marker. The
#'   `args`, `dpars`, `coef_names`, `endpoint_members`, `member_levels`,
#'   `provider_levels`, `observed_levels`, `endpoint_blocks`, and
#'   `endpoint_covariance_labels` columns are list columns. Empty fits return
#'   the same columns with zero rows.
#' @export
#'
#' @examples
#' dat <- data.frame(
#'   y = c(0.1, 0.4, 0.8, 1.1),
#'   x = c(-1, 0, 1, 2)
#' )
#' fit <- drmTMB(bf(y ~ x, sigma ~ 1), data = dat)
#' structured_effects(fit)
structured_effects <- function(object, ...) {
  UseMethod("structured_effects")
}

#' @rdname structured_effects
#' @export
structured_effects.default <- function(object, ...) {
  cli::cli_abort(
    "{.fn structured_effects} is implemented for {.cls drmTMB} fits."
  )
}

#' @rdname structured_effects
#' @export
structured_effects.drmTMB <- function(object, ...) {
  structured <- object$model$structured
  if (!is.list(structured) || length(structured) == 0L) {
    return(empty_structured_effects_table())
  }

  rows <- lapply(
    structured,
    structured_effects_table_row,
    model_type = object$model$model_type
  )
  rows <- rows[vapply(rows, nrow, integer(1L)) > 0L]
  if (length(rows) == 0L) {
    return(empty_structured_effects_table())
  }

  out <- do.call(rbind, rows)
  row.names(out) <- NULL
  out
}

structured_effects_table_row <- function(structured_mu, model_type = NULL) {
  if (!is.list(structured_mu) || !isTRUE(structured_mu$has)) {
    return(empty_structured_effects_table())
  }

  marker <- structured_mu_type(structured_mu)
  args <- structured_effects_args(structured_mu, marker)
  endpoint_members <- structured_effects_endpoint_members(structured_mu)

  data.frame(
    marker = marker,
    provider = marker,
    grouping_variable = structured_effects_group(structured_mu, marker),
    matrix_attachment = structured_effects_matrix_attachment(args),
    matrix_id = structured_effects_matrix_id(structured_mu, marker, args),
    matrix_slot = structured_effects_matrix_slot(structured_mu, marker),
    matrix_source = structured_effects_matrix_source(args),
    matrix_role = structured_effects_matrix_role(structured_mu, marker),
    matrix_digest = structured_effects_matrix_digest(structured_mu),
    input_scale = structured_effects_input_scale(structured_mu, marker),
    level_alignment = structured_effects_level_alignment(structured_mu, marker),
    missing_level_policy = structured_effects_missing_level_policy(
      structured_mu,
      marker
    ),
    bridge_marshalling = structured_effects_bridge_marshalling(
      structured_mu,
      marker
    ),
    provenance_contract = structured_effects_provenance_contract(),
    structure = structured_effects_structure(structured_mu, marker),
    group1 = structured_effects_scalar(structured_mu$group1),
    group2 = structured_effects_scalar(structured_mu$group2),
    label = structured_effects_scalar(structured_mu$label),
    block = phylo_mu_block(structured_mu),
    block_label = phylo_mu_block(structured_mu),
    covariance_layout = phylo_mu_covariance_mode(structured_mu),
    endpoint_set = paste(unique(phylo_mu_dpars(structured_mu)), collapse = "+"),
    coefficient_set = paste(
      as.character(structured_mu$coef_names),
      collapse = "+"
    ),
    endpoint_member_set = paste(endpoint_members, collapse = "+"),
    endpoint_member_count = length(endpoint_members),
    q = structured_mu_q(structured_mu),
    n_re = structured_effects_integer(structured_mu$n_re),
    member_count = length(structured_effects_member_levels(structured_mu)),
    provider_level_count = length(
      structured_effects_provider_levels(structured_mu, marker)
    ),
    observed_level_count = length(
      structured_effects_observed_levels(structured_mu, marker)
    ),
    random_effect_block = structured_mu_random_effect_key(
      structured_mu,
      model_type
    ),
    correlation_level = structured_mu_corpair_level(structured_mu),
    dpars = I(list(phylo_mu_dpars(structured_mu))),
    coef_names = I(list(as.character(structured_mu$coef_names))),
    endpoint_members = I(list(endpoint_members)),
    member_levels = I(list(structured_effects_member_levels(structured_mu))),
    provider_levels = I(list(
      structured_effects_provider_levels(structured_mu, marker)
    )),
    observed_levels = I(list(
      structured_effects_observed_levels(structured_mu, marker)
    )),
    endpoint_blocks = I(list(phylo_mu_endpoint_blocks(structured_mu))),
    endpoint_covariance_labels = I(list(
      phylo_mu_endpoint_covariance_labels(structured_mu)
    )),
    args = I(list(args)),
    stringsAsFactors = FALSE
  )
}

empty_structured_effects_table <- function() {
  data.frame(
    marker = character(),
    provider = character(),
    grouping_variable = character(),
    matrix_attachment = character(),
    matrix_id = character(),
    matrix_slot = character(),
    matrix_source = character(),
    matrix_role = character(),
    matrix_digest = character(),
    input_scale = character(),
    level_alignment = character(),
    missing_level_policy = character(),
    bridge_marshalling = character(),
    provenance_contract = character(),
    structure = character(),
    group1 = character(),
    group2 = character(),
    label = character(),
    block = character(),
    block_label = character(),
    covariance_layout = character(),
    endpoint_set = character(),
    coefficient_set = character(),
    endpoint_member_set = character(),
    endpoint_member_count = integer(),
    q = integer(),
    n_re = integer(),
    member_count = integer(),
    provider_level_count = integer(),
    observed_level_count = integer(),
    random_effect_block = character(),
    correlation_level = character(),
    dpars = I(vector("list", 0L)),
    coef_names = I(vector("list", 0L)),
    endpoint_members = I(vector("list", 0L)),
    member_levels = I(vector("list", 0L)),
    provider_levels = I(vector("list", 0L)),
    observed_levels = I(vector("list", 0L)),
    endpoint_blocks = I(vector("list", 0L)),
    endpoint_covariance_labels = I(vector("list", 0L)),
    args = I(vector("list", 0L)),
    stringsAsFactors = FALSE
  )
}

structured_effects_endpoint_members <- function(structured_mu) {
  q <- structured_mu_q(structured_mu)
  if (q == 0L) {
    return(character())
  }
  dpars <- phylo_mu_endpoint_dpars(structured_mu)
  coef_names <- as.character(structured_mu$coef_names)
  if (length(dpars) == 1L && q > 1L) {
    dpars <- rep(dpars, q)
  }
  if (length(coef_names) == 1L && q > 1L) {
    coef_names <- rep(coef_names, q)
  }
  if (length(dpars) != q || length(coef_names) != q) {
    return(character())
  }
  paste0(dpars, ":", coef_names)
}

structured_effects_group <- function(structured_mu, marker) {
  if (identical(marker, "phylo_interaction")) {
    return(paste0(structured_mu$group1, ":", structured_mu$group2))
  }
  structured_effects_scalar(structured_mu$group)
}

structured_effects_structure <- function(structured_mu, marker) {
  switch(
    marker,
    phylo = "tree",
    phylo_interaction = "tree_pair",
    structured_effects_scalar(structured_mu$structure)
  )
}

structured_effects_args <- function(structured_mu, marker) {
  switch(
    marker,
    phylo = list(tree = structured_effects_scalar(structured_mu$tree)),
    phylo_interaction = list(
      tree1 = structured_effects_scalar(structured_mu$tree1),
      tree2 = structured_effects_scalar(structured_mu$tree2),
      group1 = structured_effects_scalar(structured_mu$group1),
      group2 = structured_effects_scalar(structured_mu$group2)
    ),
    {
      structure <- structured_effects_scalar(structured_mu$structure)
      object <- structured_effects_scalar(structured_mu$object)
      stats::setNames(list(object), structure)
    }
  )
}

structured_effects_matrix_attachment <- function(args) {
  values <- unlist(
    args[
      names(args) %in%
        c(
          "tree",
          "coords",
          "mesh",
          "pedigree",
          "A",
          "Ainv",
          "K",
          "Q",
          "tree1",
          "tree2"
        )
    ],
    use.names = FALSE
  )
  values <- values[!is.na(values) & nzchar(values)]
  if (length(values) == 0L) {
    return(NA_character_)
  }
  paste(values, collapse = ":")
}

structured_effects_matrix_id <- function(structured_mu, marker, args) {
  group <- structured_effects_group(structured_mu, marker)
  slot <- structured_effects_matrix_slot(structured_mu, marker)
  source <- structured_effects_matrix_source(args)
  paste(c(marker, slot, source, group), collapse = "::")
}

structured_effects_matrix_slot <- function(structured_mu, marker) {
  switch(
    marker,
    phylo = "tree",
    phylo_interaction = "tree_pair",
    structured_effects_structure(structured_mu, marker)
  )
}

structured_effects_matrix_source <- function(args) {
  source <- structured_effects_matrix_attachment(args)
  if (is.na(source) || !nzchar(source)) {
    return(NA_character_)
  }
  source
}

structured_effects_matrix_role <- function(structured_mu, marker) {
  switch(
    marker,
    phylo = "tree_precision",
    phylo_interaction = "tree_pair_precision",
    spatial = if (identical(structured_mu$structure, "coords")) {
      "coordinate_covariance"
    } else {
      "mesh_precision"
    },
    animal = switch(
      structured_mu$structure,
      pedigree = "pedigree_covariance",
      A = "covariance",
      Ainv = "precision",
      "unknown"
    ),
    relmat = switch(
      structured_mu$structure,
      K = "covariance",
      Q = "precision",
      "unknown"
    ),
    "unknown"
  )
}

structured_effects_input_scale <- function(structured_mu, marker) {
  switch(
    marker,
    phylo = "ultrametric_tree_branch_lengths",
    phylo_interaction = "two_ultrametric_tree_branch_lengths",
    spatial = if (identical(structured_mu$structure, "coords")) {
      "coordinates_to_fixed_range_covariance"
    } else {
      "fixed_kappa_mesh_precision"
    },
    animal = switch(
      structured_mu$structure,
      pedigree = "pedigree_to_additive_covariance",
      A = "additive_covariance",
      Ainv = "additive_precision",
      "unknown"
    ),
    relmat = switch(
      structured_mu$structure,
      K = "user_covariance",
      Q = "user_precision",
      "unknown"
    ),
    "unknown"
  )
}

structured_effects_level_alignment <- function(structured_mu, marker) {
  provider <- structured_effects_provider_levels(structured_mu, marker)
  observed <- structured_effects_observed_levels(structured_mu, marker)
  if (length(provider) == 0L || length(observed) == 0L) {
    return("not_available")
  }
  if (!all(observed %in% provider)) {
    return("observed_levels_missing_from_provider")
  }
  if (setequal(provider, observed)) {
    return("observed_levels_equal_provider_levels")
  }
  "observed_levels_subset_of_provider_levels"
}

structured_effects_missing_level_policy <- function(structured_mu, marker) {
  switch(
    marker,
    phylo = paste(
      "error_if_observed_species_absent_from_tree;",
      "extra_tree_tips_allowed",
      sep = ""
    ),
    phylo_interaction = paste(
      "error_if_observed_partner_absent_from_tree;",
      "extra_tree_tips_allowed",
      sep = ""
    ),
    spatial = paste(
      "error_if_coords_missing_observed_group_or_vary_within_group;",
      "extra_coordinate_rows_not_supported",
      sep = ""
    ),
    animal = if (identical(structured_mu$structure, "pedigree")) {
      paste(
        "error_if_observed_id_absent_from_pedigree_or_parent_missing;",
        "extra_pedigree_ids_allowed",
        sep = ""
      )
    } else {
      paste(
        "error_if_observed_id_absent_from_matrix;",
        "extra_matrix_levels_allowed",
        sep = ""
      )
    },
    relmat = paste(
      "error_if_observed_id_absent_from_matrix;",
      "extra_matrix_levels_allowed",
      sep = ""
    ),
    "unknown"
  )
}

structured_effects_bridge_marshalling <- function(structured_mu, marker) {
  switch(
    marker,
    phylo = "tree_serialized_by_phylo_bridge_fixture",
    phylo_interaction = "not_marshaled_by_bridge;use_relmat_Q_escape_hatch",
    spatial = if (identical(structured_mu$structure, "coords")) {
      paste(
        "gaussian_bridge_converts_coords_to_fixed_covariance_K;",
        "range_estimating_spatial_not_promoted",
        sep = ""
      )
    } else {
      "not_marshaled_by_bridge;mesh_spde_planned"
    },
    animal = switch(
      structured_mu$structure,
      pedigree = "not_marshaled_by_bridge;use_A_covariance_or_native_tmb",
      A = "bridge_marshals_A_covariance_fixture_only",
      Ainv = "not_marshaled_by_bridge;Ainv_precision_native_tmb_only",
      "unknown"
    ),
    relmat = switch(
      structured_mu$structure,
      K = "bridge_marshals_K_covariance_fixture_only",
      Q = "not_marshaled_by_bridge;Q_precision_native_tmb_only",
      "unknown"
    ),
    "unknown"
  )
}

structured_effects_provenance_contract <- function() {
  paste0(
    "provider;matrix_slot;matrix_source;matrix_role;matrix_digest;",
    "provider_levels;observed_levels;level_alignment"
  )
}

structured_effects_matrix_digest <- function(structured_mu, digits = 12L) {
  precision <- structured_mu$precision
  matrix <- precision$precision
  if (is.null(matrix) || is.null(dim(matrix))) {
    return(NA_character_)
  }
  dims <- dim(matrix)
  nnzero <- if (inherits(matrix, "Matrix")) {
    Matrix::nnzero(matrix)
  } else {
    sum(matrix != 0)
  }
  log_det <- structured_effects_numeric_scalar(
    precision$log_det_precision,
    default = NA_real_
  )
  matrix_sum <- sum(matrix)
  diag_sum <- sum(Matrix::diag(matrix))
  paste0(
    "precision:",
    dims[[1L]],
    "x",
    dims[[2L]],
    ";nnzero=",
    nnzero,
    ";sum=",
    structured_effects_format_number(matrix_sum, digits = digits),
    ";diag_sum=",
    structured_effects_format_number(diag_sum, digits = digits),
    ";logdet=",
    structured_effects_format_number(log_det, digits = digits)
  )
}

structured_effects_format_number <- function(x, digits = 12L) {
  if (!is.finite(x)) {
    return(NA_character_)
  }
  formatC(x, digits = as.integer(digits), format = "fg")
}

structured_effects_numeric_scalar <- function(x, default = NA_real_) {
  if (is.null(x) || length(x) == 0L || !is.finite(x[[1L]])) {
    return(default)
  }
  as.numeric(x[[1L]])
}

structured_effects_member_levels <- function(structured_mu) {
  levels <- structured_mu$group_levels
  if (is.character(levels) && length(levels) > 0L) {
    return(levels)
  }
  levels <- structured_mu$node_labels
  if (is.character(levels) && length(levels) > 0L) {
    return(levels)
  }
  character()
}

structured_effects_provider_levels <- function(structured_mu, marker) {
  precision <- structured_mu$precision
  if (identical(marker, "phylo")) {
    levels <- precision$tip_label
    if (is.character(levels) && length(levels) > 0L) {
      return(levels)
    }
  }
  if (identical(marker, "spatial")) {
    levels <- precision$site_levels
    if (is.character(levels) && length(levels) > 0L) {
      return(levels)
    }
  }
  levels <- structured_mu$node_labels
  if (is.character(levels) && length(levels) > 0L) {
    return(levels)
  }
  character()
}

structured_effects_observed_levels <- function(structured_mu, marker) {
  if (identical(marker, "phylo_interaction")) {
    index <- unique(structured_mu$observation_node_index)
    levels <- structured_mu$node_labels
    if (
      is.numeric(index) &&
        length(index) > 0L &&
        is.character(levels) &&
        length(levels) >= max(index)
    ) {
      return(levels[index])
    }
  }
  levels <- structured_mu$species_levels
  if (is.character(levels) && length(levels) > 0L) {
    return(levels)
  }
  levels <- structured_mu$group_levels
  if (is.character(levels) && length(levels) > 0L) {
    return(levels)
  }
  character()
}

structured_effects_scalar <- function(x) {
  if (is.null(x) || length(x) == 0L || is.na(x[[1L]])) {
    return(NA_character_)
  }
  as.character(x[[1L]])
}

structured_effects_integer <- function(x) {
  if (is.null(x) || length(x) == 0L || is.na(x[[1L]])) {
    return(NA_integer_)
  }
  as.integer(x[[1L]])
}

#' Extract likelihood weights
#'
#' `weights()` returns the row likelihood multipliers used by a fitted
#' `drmTMB` model after model-row filtering. These weights multiply
#' log-likelihood contributions. They are not known sampling variances or known
#' sampling covariance; use [meta_V()] for that meta-analytic role.
#'
#' @param object A `drmTMB` fit.
#' @param ... Reserved for future extractor options.
#'
#' @return A numeric vector with one weight per modelled response row, or per
#'   complete response pair for bivariate Gaussian, bivariate lognormal, and
#'   bivariate Student-t models. The two exact-special development families
#'   currently expose implicit unit weights only.
#' @importFrom stats weights
#' @export
#'
#' @examples
#' dat <- data.frame(
#'   y = c(0.2, 0.5, 1.1, 1.4),
#'   x = c(-1, 0, 1, 2),
#'   w = c(1, 1, 0.5, 2)
#' )
#' fit <- drmTMB(bf(y ~ x, sigma ~ 1), data = dat, weights = w)
#' weights(fit)
weights.drmTMB <- function(object, ...) {
  object$model$weights
}

#' Extract residual correlation rho12
#'
#' `rho12()` returns the residual response-response correlation from a
#' bivariate Gaussian, bivariate lognormal, or bivariate Student-t `drmTMB`
#' fit. For a bivariate Gaussian fit this is a response-scale residual
#' correlation; for `biv_lognormal()` it is correlation of the log-response
#' residuals, not a raw-scale correlation. For `biv_student()` it is the
#' scatter/residual correlation; at finite shared `nu`, zero correlation does
#' not imply independent margins. Use `type = "link"` for the Fisher-z-like
#' linear predictor whose response transform is
#' `0.999999 * tanh(eta)`.
#'
#' @param object A `drmTMB` fit.
#' @param newdata Optional data frame for prediction.
#' @param type Scale of returned values: `"response"` for correlation values or
#'   `"link"` for Fisher-z-like linear predictors.
#' @param ... Reserved for future extractor options.
#'
#' @return A numeric vector of residual correlations, or Fisher-z-like linear
#'   predictors when `type = "link"`.
#' @export
#'
#' @examples
#' set.seed(20260525)
#' n <- 36
#' x <- seq(-1, 1, length.out = n)
#' e1 <- rnorm(n)
#' e2 <- 0.4 * e1 + sqrt(1 - 0.4^2) * rnorm(n)
#' dat <- data.frame(
#'   y1 = 0.2 + 0.5 * x + e1,
#'   y2 = -0.1 + 0.3 * x + e2,
#'   x = x
#' )
#' fit <- drmTMB(
#'   bf(mu1 = y1 ~ x, mu2 = y2 ~ x, sigma1 = ~ 1, sigma2 = ~ 1, rho12 = ~ x),
#'   family = biv_gaussian(),
#'   data = dat
#' )
#' head(rho12(fit))
#' rho12(fit, newdata = data.frame(x = c(-0.5, 0, 0.5)))
rho12 <- function(object, ...) {
  UseMethod("rho12")
}

#' @rdname rho12
#' @export
rho12.drmTMB <- function(
  object,
  newdata = NULL,
  type = c("response", "link"),
  ...
) {
  type <- match.arg(type)
  if (!"rho12" %in% names(object$coefficients)) {
    cli::cli_abort(
      "This {.cls drmTMB} fit does not contain residual correlation {.code rho12}."
    )
  }
  predict.drmTMB(object, newdata = newdata, dpar = "rho12", type = type, ...)
}

#' Extract fitted correlation pairs
#'
#' `corpairs()` returns a long table of fitted correlation pairs from a
#' `drmTMB` model. The current implementation reports correlations that are
#' already fitted elsewhere: residual bivariate `rho12`, ordinary univariate
#' group-level `mu` random-effect correlations, matched univariate and
#' same-response bivariate `mu`/`sigma` covariance blocks, matched bivariate
#' `mu1`/`mu2` random-intercept and slope-only covariance blocks, and matched
#' bivariate `sigma1`/`sigma2` random-intercept and slope-only covariance
#' blocks from `corpars`, plus fitted bivariate phylogenetic,
#' coordinate-spatial, animal-model, and `relmat()` correlation rows. Full q4
#' phylogenetic, coordinate-spatial, animal-model, and `relmat()` blocks report
#' six derived endpoint correlations; block-diagonal q4 fallback fits report
#' the direct `mu1`/`mu2` and `sigma1`/`sigma2` block correlations.
#'
#' Use `corpairs()` when the question is about correlations among fitted
#' residual, ordinary group-level, phylogenetic, coordinate-spatial,
#' animal-model, or `relmat()` latent effects. Use [rho12()] when the only
#' target is the residual correlation curve of a bivariate model.
#'
#' The table is intentionally more explicit than `rho12()` or `corpars` because
#' double-hierarchical, phylogenetic, spatial, animal-model, and lower-level
#' relatedness models can contain several scientifically different
#' correlations. Profile intervals are opt-in and can be slow; filter with
#' `level`, `group`, `block`, or `class` before requesting `conf.int = TRUE` on
#' large models. Bootstrap intervals are not a `corpairs()` route.
#'
#' @param object A `drmTMB` fit.
#' @param level Optional character vector of correlation levels to keep, such
#'   as `"residual"`, `"group"`, `"phylogenetic"`, or `"spatial"`.
#' @param group Optional character vector of grouping factors to keep, such as
#'   `"id"`. Residual rows have no grouping factor and are removed by this
#'   filter.
#' @param block Optional character vector of covariance-block labels to keep,
#'   such as `"p"`. Residual rows have no block label and are removed by this
#'   filter.
#' @param class Optional character vector of pair classes to keep, such as
#'   `"residual"` or `"mean-slope"`. Location aliases such as
#'   `"location-location"` and `"location-scale"` are accepted as filters for
#'   the current `"mean-mean"` and `"mean-scale"` rows.
#' @param conf.int Logical; include profile-likelihood confidence intervals
#'   where the correlation target is currently profile-ready. Unsupported
#'   derived targets receive an explicit interval status instead of silent
#'   missing bounds.
#' @param conf.level Confidence level used when `conf.int = TRUE`. This is
#'   named separately from the `level` filter to avoid ambiguity with
#'   correlation levels such as `"phylogenetic"`.
#' @param method Interval method used when `conf.int = TRUE`. Only
#'   `"profile"` is currently supported for correlation-pair intervals.
#' @param trace Logical; passed to [TMB::tmbprofile()] when profile intervals
#'   are requested.
#' @param ... Additional arguments passed to [TMB::tmbprofile()] when
#'   `conf.int = TRUE`.
#'
#' @return A data frame with one row per fitted correlation pair or pair
#'   summary. Predictor-dependent `rho12` is summarized by its mean, minimum,
#'   and maximum over the fitted rows. Rows include `conf.status` and
#'   `interval_source` so point-only and interval-aware pair tables use the same
#'   provenance vocabulary as prediction tables.
#'
#' @examples
#' set.seed(1)
#' n <- 40
#' x <- rnorm(n)
#' z1 <- rnorm(n)
#' z2 <- rnorm(n)
#' mu1 <- 0.2 + 0.5 * x
#' mu2 <- -0.1 + 0.4 * x
#' sigma1 <- exp(-0.2 + 0.15 * z1)
#' sigma2 <- exp(0.1 - 0.1 * z2)
#' rho <- 0.35
#' e1 <- rnorm(n)
#' e2 <- rho * e1 + sqrt(1 - rho^2) * rnorm(n)
#' dat <- data.frame(
#'   y1 = mu1 + sigma1 * e1,
#'   y2 = mu2 + sigma2 * e2,
#'   x = x,
#'   z1 = z1,
#'   z2 = z2
#' )
#' fit <- drmTMB(
#'   bf(
#'     mu1 = y1 ~ x,
#'     mu2 = y2 ~ x,
#'     sigma1 = ~ z1,
#'     sigma2 = ~ z2,
#'     rho12 = ~ 1
#'   ),
#'   family = c(gaussian(), gaussian()),
#'   data = dat
#' )
#' pairs <- corpairs(fit)
#' pairs
#' corpairs(fit, level = "residual")
#'
#' # Profile intervals are opt-in and can be slow for large models.
#' # corpairs(fit, level = "residual", conf.int = TRUE)
#' @export
corpairs <- function(object, ...) {
  UseMethod("corpairs")
}

#' @rdname corpairs
#' @export
corpairs.drmTMB <- function(
  object,
  level = NULL,
  group = NULL,
  block = NULL,
  class = NULL,
  conf.int = FALSE,
  conf.level = 0.95,
  method = "profile",
  trace = FALSE,
  ...
) {
  validate_summary_conf_int(conf.int)
  method <- validate_interval_method(method, "profile", "corpairs()")
  if (
    conf.int &&
      identical(object$model$model_type, "biv_student")
  ) {
    cli::cli_abort(
      "{.fn corpairs} profile intervals are not implemented for model type {.val {object$model$model_type}}; interval and profile claims are deferred."
    )
  }
  if (!conf.int && length(list(...)) > 0L) {
    cli::cli_abort(
      "Additional arguments in {.arg ...} are only used when {.code conf.int = TRUE}."
    )
  }

  rows <- list()

  if ("rho12" %in% names(object$coefficients)) {
    rows[[length(rows) + 1L]] <- residual_rho12_corpair(object)
  }

  phylo_rows <- phylo_mu_corpairs(object)
  if (length(phylo_rows) > 0L) {
    rows <- c(rows, phylo_rows)
  }

  registry_rows <- random_effect_registry_corpairs(object)
  if (length(registry_rows) > 0L) {
    rows <- c(rows, registry_rows)
  }
  structured_exclude <- structured_mu_corpars_keys(object)
  label_rows <- random_effect_label_corpairs(
    object,
    exclude = c(
      covariance_block_corpars_keys(
        object$model$random$covariance_blocks
      ),
      structured_exclude
    )
  )
  if (length(label_rows) > 0L) {
    rows <- c(rows, label_rows)
  }

  out <- if (length(rows) == 0L) {
    empty_corpairs()
  } else {
    do.call(rbind, rows)
  }

  if (!is.null(level)) {
    out <- out[out$level %in% level, , drop = FALSE]
  }
  if (!is.null(group)) {
    out <- out[out$group %in% group, , drop = FALSE]
  }
  if (!is.null(block)) {
    out <- out[out$block %in% block, , drop = FALSE]
  }
  if (!is.null(class)) {
    class <- normalize_corpairs_class_filter(class)
    out <- out[out$class %in% class, , drop = FALSE]
  }
  row.names(out) <- NULL
  out <- corpairs_add_default_interval_provenance(out)
  if (conf.int) {
    out <- corpairs_add_confint(
      object,
      out,
      level = conf.level,
      trace = trace,
      ...
    )
  }
  out
}

corpairs_add_confint <- function(object, pairs, level, trace, ...) {
  validate_profile_level(level)
  if (nrow(pairs) == 0L) {
    pairs$profile_target <- character()
    pairs$conf.low <- numeric()
    pairs$conf.high <- numeric()
    pairs$conf.level <- numeric()
    pairs$conf.method <- character()
    pairs$conf.status <- character()
    pairs$interval_source <- character()
    return(pairs)
  }

  targets <- drm_profile_targets(object)
  target_index <- corpairs_match_profile_targets(pairs, targets)
  target_rows <- targets[target_index, , drop = FALSE]

  profile_targets <- rep(NA_character_, nrow(pairs))
  has_target <- !is.na(target_index)
  profile_targets[has_target] <- target_rows$parm[has_target]
  profile_ready <- rep(FALSE, nrow(pairs))
  profile_ready[has_target] <- target_rows$profile_ready[has_target]
  ready_parms <- unique(profile_targets[profile_ready])

  ci <- empty_summary_confint()
  if (length(ready_parms) > 0L) {
    ci <- drm_profile_confint(
      object,
      parm = ready_parms,
      level = level,
      trace = trace,
      ...
    )
  }

  pairs$profile_target <- profile_targets
  pairs$conf.low <- NA_real_
  pairs$conf.high <- NA_real_
  pairs$conf.level <- level
  pairs$conf.method <- NA_character_
  pairs$conf.status <- corpairs_conf_status(pairs, target_rows, target_index)
  pairs$interval_source <- rep("not_available", nrow(pairs))

  if (nrow(ci) > 0L) {
    matched <- match(pairs$profile_target, ci$parm)
    has_ci <- !is.na(matched)
    pairs$conf.low[has_ci] <- ci$lower[matched[has_ci]]
    pairs$conf.high[has_ci] <- ci$upper[matched[has_ci]]
    pairs$conf.method[has_ci] <- ci$method[matched[has_ci]]
    pairs$conf.status[has_ci] <- "profile"
    pairs$interval_source[has_ci] <- "profile"
  }

  pairs
}

corpairs_add_default_interval_provenance <- function(pairs) {
  if (!"conf.status" %in% names(pairs)) {
    pairs$conf.status <- rep("not_requested", nrow(pairs))
  }
  if (!"interval_source" %in% names(pairs)) {
    pairs$interval_source <- rep("not_available", nrow(pairs))
  }
  pairs
}

corpairs_match_profile_targets <- function(pairs, targets) {
  if (nrow(pairs) == 0L) {
    return(integer())
  }
  if (nrow(targets) == 0L) {
    return(rep(NA_integer_, nrow(pairs)))
  }

  vapply(
    seq_len(nrow(pairs)),
    function(i) {
      pair <- pairs[i, , drop = FALSE]
      if (
        identical(pair$level[[1L]], "residual") &&
          identical(pair$parameter[[1L]], "rho12") &&
          !isTRUE(pair$modelled[[1L]])
      ) {
        hit <- which(targets$parm == "rho12")
        return(if (length(hit) == 1L) hit[[1L]] else NA_integer_)
      }

      if (
        identical(pair$level[[1L]], "residual") &&
          identical(pair$parameter[[1L]], "rho12")
      ) {
        return(NA_integer_)
      }

      hit <- which(
        targets$target_class == "random-effect-correlation" &
          targets$term == pair$parameter[[1L]]
      )
      structured_prefixes <- c(
        phylogenetic = "cor:phylo:",
        spatial = "cor:spatial:",
        animal = "cor:animal:",
        relmat = "cor:relmat:"
      )
      if (pair$level[[1L]] %in% names(structured_prefixes)) {
        hit <- hit[startsWith(
          targets$parm[hit],
          structured_prefixes[[pair$level[[1L]]]]
        )]
      } else if (identical(pair$level[[1L]], "group")) {
        hit <- hit[
          !Reduce(
            `|`,
            lapply(
              unname(structured_prefixes),
              function(prefix) startsWith(targets$parm[hit], prefix)
            )
          )
        ]
      }
      if (length(hit) == 1L) {
        return(hit[[1L]])
      }
      NA_integer_
    },
    integer(1L)
  )
}

corpairs_conf_status <- function(pairs, target_rows, target_index) {
  vapply(
    seq_len(nrow(pairs)),
    function(i) {
      if (is.na(target_index[[i]])) {
        if (
          isTRUE(pairs$modelled[[i]]) &&
            (identical(pairs$level[[i]], "residual") ||
              identical(pairs$level[[i]], "group") ||
              identical(pairs$level[[i]], "phylogenetic"))
        ) {
          # `corpairs()` summarizes a modelled surface over fitted rows. A
          # supplied `newdata` can profile a particular row via `confint()`,
          # but cannot turn this aggregate summary into a scalar target.
          return("derived_interval_unavailable")
        }
        return("target_unavailable")
      }
      target <- target_rows[i, , drop = FALSE]
      if (isTRUE(target$profile_ready[[1L]])) {
        return("profile_ready")
      }
      if (identical(target$target_type[[1L]], "derived")) {
        return("derived_interval_unavailable")
      }
      interval_status_from_profile_note(
        profile_ready = target$profile_ready[[1L]],
        profile_note = target$profile_note[[1L]]
      )
    },
    character(1L)
  )
}

normalize_corpairs_class_filter <- function(class) {
  aliases <- c(
    "location-location" = "mean-mean",
    "location-scale" = "mean-scale",
    "location-slope" = "mean-slope",
    "slope-location" = "mean-slope"
  )
  mapped <- unname(aliases[class])
  class[!is.na(mapped)] <- mapped[!is.na(mapped)]
  unique(class)
}

empty_corpairs <- function() {
  data.frame(
    level = character(),
    group = character(),
    block = character(),
    from_dpar = character(),
    to_dpar = character(),
    from_coef = character(),
    to_coef = character(),
    from_response = character(),
    to_response = character(),
    class = character(),
    parameter = character(),
    estimate = numeric(),
    min = numeric(),
    max = numeric(),
    n_values = integer(),
    link_estimate = numeric(),
    link_min = numeric(),
    link_max = numeric(),
    modelled = logical(),
    conf.status = character(),
    interval_source = character(),
    stringsAsFactors = FALSE
  )
}

residual_rho12_corpair <- function(object) {
  rho <- predict(object, dpar = "rho12", type = "response")
  eta <- predict(object, dpar = "rho12", type = "link")
  n_coef <- length(coef(object, dpar = "rho12"))
  response_names <- bivariate_response_names(object)
  new_corpair_row(
    level = "residual",
    group = NA_character_,
    block = NA_character_,
    from_dpar = "residual",
    to_dpar = "residual",
    from_coef = NA_character_,
    to_coef = NA_character_,
    from_response = response_names[[1L]],
    to_response = response_names[[2L]],
    class = "residual",
    parameter = "rho12",
    estimate = mean(rho),
    min = min(rho),
    max = max(rho),
    n_values = length(rho),
    link_estimate = mean(eta),
    link_min = min(eta),
    link_max = max(eta),
    modelled = n_coef > 1L
  )
}

phylo_mu_corpairs <- function(object) {
  if (
    !object$model$model_type %in% c("gaussian", "biv_gaussian") ||
      !isTRUE(object$model$structured$phylo_mu$has)
  ) {
    return(list())
  }

  phylo_mu <- object$model$structured$phylo_mu
  cor_key <- structured_mu_correlation_key(phylo_mu)
  corpars <- object$corpars[[cor_key]]
  if (is.null(corpars) || length(corpars) == 0L) {
    return(list())
  }
  level <- structured_mu_corpair_level(phylo_mu)
  pair_table <- phylo_mu_pair_table(phylo_mu)
  # A modelled phylogenetic correlation stores one value per level in
  # corpars$phylo (issue #698 phylogenetic sibling); those levels are a single
  # fitted correlation regression, summarised by one corpair row via the
  # recomputed predict() path below, so iterate only the representative index
  # here rather than one row per level.
  indices <- if (has_modelled_phylo_correlation(object$model)) {
    unique(object$model$random$mu$cor_model$target_cor)
  } else {
    seq_along(corpars)
  }
  lapply(indices, function(i) {
    estimate <- unname(corpars[[i]])
    parameter <- phylo_mu_correlation_parameter(object, i)
    pair <- pair_table[i, , drop = FALSE]
    model_dpar <- random_effect_correlation_model_dpar(object, cor_key, i)
    if (!is.na(model_dpar)) {
      rho <- predict(object, dpar = model_dpar, type = "response")
      eta <- predict(object, dpar = model_dpar, type = "link")
      estimate <- mean(rho)
      min_value <- min(rho)
      max_value <- max(rho)
      n_values <- length(rho)
      link_estimate <- mean(eta)
      link_min <- min(eta)
      link_max <- max(eta)
      modelled <- TRUE
    } else {
      min_value <- estimate
      max_value <- estimate
      n_values <- 1L
      link_estimate <- guarded_correlation_link(estimate, guard = 0.999999)
      link_min <- guarded_correlation_link(estimate, guard = 0.999999)
      link_max <- guarded_correlation_link(estimate, guard = 0.999999)
      modelled <- FALSE
    }
    new_corpair_row(
      level = level,
      group = phylo_mu$group,
      block = pair$block[[1L]],
      from_dpar = pair$from_dpar[[1L]],
      to_dpar = pair$to_dpar[[1L]],
      from_coef = pair$from_coef[[1L]],
      to_coef = pair$to_coef[[1L]],
      from_response = random_effect_response_name(object, pair$from_dpar[[1L]]),
      to_response = random_effect_response_name(object, pair$to_dpar[[1L]]),
      class = random_correlation_class(
        pair$from_dpar[[1L]],
        pair$from_coef[[1L]],
        pair$to_coef[[1L]],
        to_dpar = pair$to_dpar[[1L]]
      ),
      parameter = parameter,
      estimate = estimate,
      min = min_value,
      max = max_value,
      n_values = n_values,
      link_estimate = link_estimate,
      link_min = link_min,
      link_max = link_max,
      modelled = modelled
    )
  })
}

phylo_mu_correlation_parameter <- function(object, i = 1L) {
  phylo_mu <- object$model$structured$phylo_mu
  cor_key <- structured_mu_correlation_key(phylo_mu)
  phylo_names <- names(object$corpars[[cor_key]])
  parameter <- if (is.null(phylo_names) || length(phylo_names) < i) {
    NA_character_
  } else {
    phylo_names[[i]]
  }
  if (is.null(parameter) || is.na(parameter) || !nzchar(parameter)) {
    pair_table <- phylo_mu_pair_table(phylo_mu)
    parameter <- pair_table$parameter[[i]]
  }
  parameter
}

random_effect_registry_corpairs <- function(object) {
  registry <- object$model$random$covariance_blocks
  if (
    !is.list(registry) ||
      is.null(registry$pairs) ||
      nrow(registry$pairs) == 0L
  ) {
    return(list())
  }

  pairs <- registry$pairs
  pair_is_fitted <- !is.na(pairs$tmb_parameter) & !is.na(pairs$tmb_index)
  pairs <- pairs[pair_is_fitted, , drop = FALSE]
  if (nrow(pairs) == 0L) {
    return(list())
  }

  lapply(seq_len(nrow(pairs)), function(i) {
    pair <- pairs[i, , drop = FALSE]
    block <- registry$blocks[
      registry$blocks$block_id0 == pair$block_id0[[1L]],
      ,
      drop = FALSE
    ]
    if (nrow(block) != 1L) {
      cli::cli_abort(
        "Internal error: covariance-block registry pair has no matching block."
      )
    }
    cor_key <- covariance_block_corpars_key(pair$tmb_parameter[[1L]])
    cor_values <- object$corpars[[cor_key]]
    cor_index <- pair$tmb_index[[1L]]
    if (
      is.null(cor_values) || cor_index < 1L || cor_index > length(cor_values)
    ) {
      cli::cli_abort(
        "Internal error: covariance-block registry pair has no fitted correlation."
      )
    }
    estimate <- unname(cor_values[[cor_index]])
    model_dpar <- random_effect_correlation_model_dpar(
      object,
      cor_key,
      cor_index
    )
    if (!is.na(model_dpar)) {
      rho <- predict(object, dpar = model_dpar, type = "response")
      eta <- predict(object, dpar = model_dpar, type = "link")
      estimate <- mean(rho)
      min_value <- min(rho)
      max_value <- max(rho)
      n_values <- length(rho)
      link_estimate <- mean(eta)
      link_min <- min(eta)
      link_max <- max(eta)
      modelled <- TRUE
    } else {
      min_value <- estimate
      max_value <- estimate
      n_values <- 1L
      link_estimate <- guarded_correlation_link(estimate, guard = 0.999999)
      link_min <- guarded_correlation_link(estimate, guard = 0.999999)
      link_max <- guarded_correlation_link(estimate, guard = 0.999999)
      modelled <- FALSE
    }
    new_corpair_row(
      level = block$level[[1L]],
      group = block$group[[1L]],
      block = block$block_label[[1L]],
      from_dpar = pair$from_dpar[[1L]],
      to_dpar = pair$to_dpar[[1L]],
      from_coef = pair$from_coef[[1L]],
      to_coef = pair$to_coef[[1L]],
      from_response = random_effect_response_name(object, pair$from_dpar[[1L]]),
      to_response = random_effect_response_name(object, pair$to_dpar[[1L]]),
      class = pair$class[[1L]],
      parameter = pair$parameter[[1L]],
      estimate = estimate,
      min = min_value,
      max = max_value,
      n_values = n_values,
      link_estimate = link_estimate,
      link_min = link_min,
      link_max = link_max,
      modelled = modelled
    )
  })
}

random_effect_covariance_summaries <- function(object, intervals = NULL) {
  rows <- list(
    phylo_mu_covariance_summaries(object, intervals = intervals),
    registry_random_effect_covariance_summaries(object, intervals = intervals)
  )
  rows <- rows[vapply(rows, nrow, integer(1L)) > 0L]
  if (length(rows) == 0L) {
    return(empty_random_effect_covariance_summaries())
  }

  out <- do.call(rbind, rows)
  row.names(out) <- NULL
  out
}

phylo_mu_covariance_summaries <- function(object, intervals = NULL) {
  if (
    !object$model$model_type %in% c("gaussian", "biv_gaussian") ||
      !isTRUE(object$model$structured$phylo_mu$has)
  ) {
    return(empty_random_effect_covariance_summaries())
  }

  phylo_mu <- object$model$structured$phylo_mu
  cor_key <- structured_mu_correlation_key(phylo_mu)
  corpars <- object$corpars[[cor_key]]
  if (is.null(corpars) || length(corpars) == 0L) {
    return(empty_random_effect_covariance_summaries())
  }
  level <- structured_mu_corpair_level(phylo_mu)
  group <- phylo_mu$group
  pair_table <- phylo_mu_pair_table(phylo_mu)
  sd_parameters <- phylo_mu_sd_labels(phylo_mu, object$model$model_type)
  covariance_interval_status <- covariance_summary_interval_status(intervals)

  rows <- lapply(seq_len(nrow(pair_table)), function(i) {
    pair <- pair_table[i, , drop = FALSE]
    parameter <- phylo_mu_correlation_parameter(object, i)
    correlation_target <- paste0("cor:", cor_key, ":", parameter)
    from_sd_parameter <- sd_parameters[[pair$from_index[[1L]]]]
    to_sd_parameter <- sd_parameters[[pair$to_index[[1L]]]]
    from_sd_summary <- phylo_mu_sd_summary(
      object,
      endpoint_index = pair$from_index[[1L]],
      scalar_parameter = from_sd_parameter
    )
    to_sd_summary <- phylo_mu_sd_summary(
      object,
      endpoint_index = pair$to_index[[1L]],
      scalar_parameter = to_sd_parameter
    )
    from_sd_parameter <- from_sd_summary$parameter
    to_sd_parameter <- to_sd_summary$parameter
    from_sd_target <- from_sd_summary$target
    to_sd_target <- to_sd_summary$target
    from_sd <- from_sd_summary$value
    to_sd <- to_sd_summary$value
    correlation <- unname(corpars[[i]])
    correlation_interval <- covariance_summary_interval(
      intervals,
      correlation_target
    )
    from_sd_interval <- covariance_summary_interval(intervals, from_sd_target)
    to_sd_interval <- covariance_summary_interval(intervals, to_sd_target)
    data.frame(
      level = level,
      group = group,
      block = pair$block[[1L]],
      from_dpar = pair$from_dpar[[1L]],
      to_dpar = pair$to_dpar[[1L]],
      from_coef = pair$from_coef[[1L]],
      to_coef = pair$to_coef[[1L]],
      from_response = random_effect_response_name(object, pair$from_dpar[[1L]]),
      to_response = random_effect_response_name(object, pair$to_dpar[[1L]]),
      class = random_correlation_class(
        pair$from_dpar[[1L]],
        pair$from_coef[[1L]],
        pair$to_coef[[1L]],
        to_dpar = pair$to_dpar[[1L]]
      ),
      parameter = parameter,
      correlation_target = correlation_target,
      from_sd_target = from_sd_target,
      to_sd_target = to_sd_target,
      correlation = correlation,
      from_sd_parameter = from_sd_parameter,
      to_sd_parameter = to_sd_parameter,
      from_sd = from_sd,
      to_sd = to_sd,
      from_variance = from_sd^2,
      to_variance = to_sd^2,
      covariance = correlation * from_sd * to_sd,
      from_scale = covariance_registry_member_scale(data.frame(
        dpar = pair$from_dpar[[1L]]
      )),
      to_scale = covariance_registry_member_scale(data.frame(
        dpar = pair$to_dpar[[1L]]
      )),
      correlation_conf.low = correlation_interval$lower,
      correlation_conf.high = correlation_interval$upper,
      correlation_conf.method = correlation_interval$method,
      from_sd_conf.low = from_sd_interval$lower,
      from_sd_conf.high = from_sd_interval$upper,
      from_sd_conf.method = from_sd_interval$method,
      to_sd_conf.low = to_sd_interval$lower,
      to_sd_conf.high = to_sd_interval$upper,
      to_sd_conf.method = to_sd_interval$method,
      covariance_conf.low = NA_real_,
      covariance_conf.high = NA_real_,
      covariance_conf.method = NA_character_,
      covariance_conf.status = covariance_interval_status,
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

phylo_mu_sd_parameter <- function(dpar, group) {
  paste0(dpar, ":phylo(1 | ", group, ")")
}

phylo_mu_sd_value <- function(object, parameter, dpar = "mu") {
  value <- object$sdpars[[dpar]][[parameter]]
  if (is.null(value) && !identical(dpar, "mu")) {
    value <- object$sdpars$mu[[parameter]]
  }
  if (is.null(value)) {
    return(NA_real_)
  }
  unname(value)
}

phylo_mu_sd_summary <- function(object, endpoint_index, scalar_parameter) {
  direct_dpar <- phylo_mu_direct_sd_dpar(object, endpoint_index)
  if (!is.na(direct_dpar)) {
    values <- unname(object$sdpars[[direct_dpar]])
    values <- values[is.finite(values)]
    value <- if (length(values) > 0L) stats::median(values) else NA_real_
    return(list(
      parameter = paste0(direct_dpar, ":median"),
      target = paste0("sd:", direct_dpar, ":(median)"),
      value = value
    ))
  }

  phylo_mu <- object$model$structured$phylo_mu
  endpoint_dpar <- phylo_mu_endpoint_dpars(phylo_mu)[[endpoint_index]]
  sd_dpar <- phylo_mu_sd_dpar_for_parameter(
    object,
    endpoint_dpar = endpoint_dpar,
    parameter = scalar_parameter
  )

  list(
    parameter = scalar_parameter,
    target = paste0("sd:", sd_dpar, ":", scalar_parameter),
    value = phylo_mu_sd_value(object, scalar_parameter, dpar = sd_dpar)
  )
}

phylo_mu_sd_dpar_for_parameter <- function(object, endpoint_dpar, parameter) {
  if (!is.null(object$sdpars[[endpoint_dpar]][[parameter]])) {
    return(endpoint_dpar)
  }
  if (
    identical(object$model$model_type, "biv_gaussian") &&
      !is.null(object$sdpars$mu[[parameter]])
  ) {
    return("mu")
  }
  endpoint_dpar
}

phylo_mu_direct_sd_dpar <- function(object, endpoint_index) {
  sd_phylo <- object$model$random_scale$phylo
  if (
    !is.list(sd_phylo) ||
      is.null(sd_phylo$n_models) ||
      sd_phylo$n_models == 0L
  ) {
    return(NA_character_)
  }
  hit <- which(unname(sd_phylo$target_endpoint) == endpoint_index)
  if (length(hit) == 0L) {
    return(NA_character_)
  }
  sd_phylo$dpars[[hit[[1L]]]]
}

registry_random_effect_covariance_summaries <- function(
  object,
  intervals = NULL
) {
  registry <- object$model$random$covariance_blocks
  if (
    !is.list(registry) ||
      is.null(registry$pairs) ||
      is.null(registry$members) ||
      is.null(registry$blocks) ||
      nrow(registry$pairs) == 0L
  ) {
    return(empty_random_effect_covariance_summaries())
  }

  pairs <- registry$pairs
  pair_is_fitted <- !is.na(pairs$tmb_parameter) & !is.na(pairs$tmb_index)
  pairs <- pairs[pair_is_fitted, , drop = FALSE]
  if (nrow(pairs) == 0L) {
    return(empty_random_effect_covariance_summaries())
  }

  rows <- lapply(seq_len(nrow(pairs)), function(i) {
    pair <- pairs[i, , drop = FALSE]
    block <- registry$blocks[
      registry$blocks$block_id0 == pair$block_id0[[1L]],
      ,
      drop = FALSE
    ]
    from_member <- covariance_registry_member_by_id(
      registry,
      block_id0 = pair$block_id0[[1L]],
      member_id0 = pair$from_member_id0[[1L]]
    )
    to_member <- covariance_registry_member_by_id(
      registry,
      block_id0 = pair$block_id0[[1L]],
      member_id0 = pair$to_member_id0[[1L]]
    )
    if (
      nrow(block) != 1L ||
        nrow(from_member) != 1L ||
        nrow(to_member) != 1L
    ) {
      cli::cli_abort(
        "Internal error: covariance-block registry pair has incomplete summary metadata."
      )
    }

    cor_key <- covariance_block_corpars_key(pair$tmb_parameter[[1L]])
    correlation_target <- paste0("cor:", cor_key, ":", pair$parameter[[1L]])
    from_sd_target <- covariance_registry_member_sd_target(from_member)
    to_sd_target <- covariance_registry_member_sd_target(to_member)
    cor_values <- object$corpars[[cor_key]]
    cor_index <- pair$tmb_index[[1L]]
    correlation <- if (
      is.null(cor_values) || cor_index < 1L || cor_index > length(cor_values)
    ) {
      NA_real_
    } else {
      unname(cor_values[[cor_index]])
    }
    from_sd <- covariance_registry_member_sd(object, from_member)
    to_sd <- covariance_registry_member_sd(object, to_member)
    from_variance <- from_sd^2
    to_variance <- to_sd^2
    covariance <- correlation * from_sd * to_sd
    correlation_interval <- covariance_summary_interval(
      intervals,
      correlation_target
    )
    from_sd_interval <- covariance_summary_interval(intervals, from_sd_target)
    to_sd_interval <- covariance_summary_interval(intervals, to_sd_target)
    covariance_interval_status <- covariance_summary_interval_status(intervals)

    data.frame(
      level = block$level[[1L]],
      group = block$group[[1L]],
      block = block$block_label[[1L]],
      from_dpar = pair$from_dpar[[1L]],
      to_dpar = pair$to_dpar[[1L]],
      from_coef = pair$from_coef[[1L]],
      to_coef = pair$to_coef[[1L]],
      from_response = random_effect_response_name(object, pair$from_dpar[[1L]]),
      to_response = random_effect_response_name(object, pair$to_dpar[[1L]]),
      class = pair$class[[1L]],
      parameter = pair$parameter[[1L]],
      correlation_target = correlation_target,
      from_sd_target = from_sd_target,
      to_sd_target = to_sd_target,
      correlation = correlation,
      from_sd_parameter = from_member$label[[1L]],
      to_sd_parameter = to_member$label[[1L]],
      from_sd = from_sd,
      to_sd = to_sd,
      from_variance = from_variance,
      to_variance = to_variance,
      covariance = covariance,
      from_scale = covariance_registry_member_scale(from_member),
      to_scale = covariance_registry_member_scale(to_member),
      correlation_conf.low = correlation_interval$lower,
      correlation_conf.high = correlation_interval$upper,
      correlation_conf.method = correlation_interval$method,
      from_sd_conf.low = from_sd_interval$lower,
      from_sd_conf.high = from_sd_interval$upper,
      from_sd_conf.method = from_sd_interval$method,
      to_sd_conf.low = to_sd_interval$lower,
      to_sd_conf.high = to_sd_interval$upper,
      to_sd_conf.method = to_sd_interval$method,
      covariance_conf.low = NA_real_,
      covariance_conf.high = NA_real_,
      covariance_conf.method = NA_character_,
      covariance_conf.status = covariance_interval_status,
      stringsAsFactors = FALSE
    )
  })

  out <- do.call(rbind, rows)
  row.names(out) <- NULL
  out
}

empty_random_effect_covariance_summaries <- function() {
  data.frame(
    level = character(),
    group = character(),
    block = character(),
    from_dpar = character(),
    to_dpar = character(),
    from_coef = character(),
    to_coef = character(),
    from_response = character(),
    to_response = character(),
    class = character(),
    parameter = character(),
    correlation_target = character(),
    from_sd_target = character(),
    to_sd_target = character(),
    correlation = numeric(),
    from_sd_parameter = character(),
    to_sd_parameter = character(),
    from_sd = numeric(),
    to_sd = numeric(),
    from_variance = numeric(),
    to_variance = numeric(),
    covariance = numeric(),
    from_scale = character(),
    to_scale = character(),
    correlation_conf.low = numeric(),
    correlation_conf.high = numeric(),
    correlation_conf.method = character(),
    from_sd_conf.low = numeric(),
    from_sd_conf.high = numeric(),
    from_sd_conf.method = character(),
    to_sd_conf.low = numeric(),
    to_sd_conf.high = numeric(),
    to_sd_conf.method = character(),
    covariance_conf.low = numeric(),
    covariance_conf.high = numeric(),
    covariance_conf.method = character(),
    covariance_conf.status = character(),
    stringsAsFactors = FALSE
  )
}

covariance_registry_member_by_id <- function(registry, block_id0, member_id0) {
  registry$members[
    registry$members$block_id0 == block_id0 &
      registry$members$member_id0 == member_id0,
    ,
    drop = FALSE
  ]
}

covariance_registry_member_sd <- function(object, member) {
  sd_key <- covariance_registry_member_sd_key(member)
  sd_values <- object$sdpars[[sd_key]]
  if (is.null(sd_values)) {
    return(NA_real_)
  }
  value <- sd_values[[member$label[[1L]]]]
  if (is.null(value)) {
    return(NA_real_)
  }
  unname(value)
}

covariance_registry_member_sd_target <- function(member) {
  paste0(
    "sd:",
    covariance_registry_member_sd_key(member),
    ":",
    member$label[[1L]]
  )
}

covariance_registry_member_sd_key <- function(member) {
  dpar_family <- sub("[0-9]+$", "", member$dpar[[1L]])
  switch(
    dpar_family,
    mu = "mu",
    sigma = "sigma",
    dpar_family
  )
}

covariance_summary_interval <- function(intervals, parm) {
  if (is.null(intervals)) {
    return(covariance_summary_empty_interval())
  }
  if (!is.data.frame(intervals) || !"parm" %in% names(intervals)) {
    cli::cli_abort(
      "Internal error: covariance summary intervals must be a profile interval table."
    )
  }
  if (nrow(intervals) == 0L) {
    return(covariance_summary_empty_interval())
  }
  row <- intervals[intervals$parm == parm, , drop = FALSE]
  if (nrow(row) == 0L) {
    return(covariance_summary_empty_interval())
  }
  if (nrow(row) > 1L) {
    cli::cli_abort(
      "Internal error: covariance summary intervals contain duplicate targets."
    )
  }
  list(
    lower = if ("lower" %in% names(row)) row$lower[[1L]] else NA_real_,
    upper = if ("upper" %in% names(row)) row$upper[[1L]] else NA_real_,
    method = if ("method" %in% names(row)) {
      as.character(row$method[[1L]])
    } else {
      NA_character_
    }
  )
}

covariance_summary_empty_interval <- function() {
  list(lower = NA_real_, upper = NA_real_, method = NA_character_)
}

covariance_summary_interval_status <- function(intervals) {
  if (is.null(intervals)) {
    return("not_requested")
  }
  "derived_interval_unavailable"
}

covariance_registry_member_scale <- function(member) {
  dpar_family <- sub("[0-9]+$", "", member$dpar[[1L]])
  switch(
    dpar_family,
    mu = "identity",
    sigma = "log",
    "link"
  )
}

covariance_block_corpars_key <- function(tmb_parameter) {
  key <- switch(
    tmb_parameter,
    eta_cor_mu = "mu",
    eta_cor_sigma = "sigma",
    eta_cor_mu_sigma = "mu_sigma",
    theta_re_cov = "re_cov",
    NA_character_
  )
  if (is.na(key)) {
    cli::cli_abort(
      "Internal error: covariance-block registry pair uses an unknown correlation parameter."
    )
  }
  key
}

covariance_block_corpars_keys <- function(registry) {
  if (
    !is.list(registry) ||
      is.null(registry$pairs) ||
      nrow(registry$pairs) == 0L
  ) {
    return(character())
  }

  pairs <- registry$pairs
  pair_is_fitted <- !is.na(pairs$tmb_parameter) & !is.na(pairs$tmb_index)
  pairs <- pairs[pair_is_fitted, , drop = FALSE]
  if (nrow(pairs) == 0L) {
    return(character())
  }

  cor_keys <- vapply(
    pairs$tmb_parameter,
    covariance_block_corpars_key,
    character(1L)
  )
  paste(cor_keys, pairs$tmb_index, sep = ":")
}

random_effect_label_corpairs <- function(object, exclude = character()) {
  rows <- list()
  for (dpar in names(object$corpars)) {
    if (identical(dpar, "phylo")) {
      next
    }
    cor_values <- object$corpars[[dpar]]
    # A modelled group mu correlation stores one value per group level in
    # corpars$mu (issue #698); those levels are a single fitted correlation
    # regression, summarised by one corpair row via the registry path, so we
    # iterate only the representative index here rather than one row per level.
    indices <- if (
      identical(dpar, "mu") &&
        corpair_model_is_group(object$model$random$mu$cor_model)
    ) {
      unique(object$model$random$mu$cor_model$target_cor)
    } else {
      seq_along(cor_values)
    }
    for (i in indices) {
      if (paste(dpar, i, sep = ":") %in% exclude) {
        next
      }
      rows[[length(rows) + 1L]] <- random_effect_corpair(
        object = object,
        dpar = dpar,
        label = names(cor_values)[[i]],
        estimate = unname(cor_values[[i]]),
        index = i
      )
    }
  }
  rows
}

structured_mu_corpars_keys <- function(object) {
  if (
    !object$model$model_type %in% c("gaussian", "biv_gaussian") ||
      !isTRUE(object$model$structured$phylo_mu$has)
  ) {
    return(character())
  }
  cor_key <- structured_mu_correlation_key(object$model$structured$phylo_mu)
  cor_values <- object$corpars[[cor_key]]
  if (is.null(cor_values) || length(cor_values) == 0L) {
    return(character())
  }
  # A modelled phylogenetic correlation stores one value per level (issue #698
  # sibling); those levels are a single fitted correlation regression, so only
  # the representative index is a structured corpar key.
  indices <- if (has_modelled_phylo_correlation(object$model)) {
    unique(object$model$random$mu$cor_model$target_cor)
  } else {
    seq_along(cor_values)
  }
  paste(cor_key, indices, sep = ":")
}

random_effect_corpair <- function(
  object,
  dpar,
  label,
  estimate,
  index = NA_integer_
) {
  parsed <- parse_random_correlation_label(label)
  from <- parse_random_correlation_endpoint(parsed$from_coef, dpar)
  to <- parse_random_correlation_endpoint(parsed$to_coef, dpar)
  model_dpar <- random_effect_correlation_model_dpar(object, dpar, index)
  if (!is.na(model_dpar)) {
    rho <- predict(object, dpar = model_dpar, type = "response")
    eta <- predict(object, dpar = model_dpar, type = "link")
    estimate <- mean(rho)
    min_value <- min(rho)
    max_value <- max(rho)
    n_values <- length(rho)
    link_estimate <- mean(eta)
    link_min <- min(eta)
    link_max <- max(eta)
    modelled <- TRUE
  } else {
    min_value <- estimate
    max_value <- estimate
    n_values <- 1L
    link_estimate <- guarded_correlation_link(estimate, guard = 0.999999)
    link_min <- guarded_correlation_link(estimate, guard = 0.999999)
    link_max <- guarded_correlation_link(estimate, guard = 0.999999)
    modelled <- FALSE
  }
  new_corpair_row(
    level = "group",
    group = parsed$group,
    block = parsed$block,
    from_dpar = from$dpar,
    to_dpar = to$dpar,
    from_coef = from$coef,
    to_coef = to$coef,
    from_response = random_effect_response_name(object, from$dpar),
    to_response = random_effect_response_name(object, to$dpar),
    class = random_correlation_class(
      from$dpar,
      from$coef,
      to$coef,
      to_dpar = to$dpar
    ),
    parameter = label,
    estimate = estimate,
    min = min_value,
    max = max_value,
    n_values = n_values,
    link_estimate = link_estimate,
    link_min = link_min,
    link_max = link_max,
    modelled = modelled
  )
}

random_effect_correlation_model_dpar <- function(object, dpar, index) {
  if (is.na(index)) {
    return(NA_character_)
  }
  model <- object$model$random$mu$cor_model
  if (!is.list(model) || model$n_models == 0L) {
    return(NA_character_)
  }
  if (identical(dpar, "mu") && !corpair_model_is_group(model)) {
    return(NA_character_)
  }
  if (identical(dpar, "phylo") && !corpair_model_is_phylogenetic(model)) {
    return(NA_character_)
  }
  if (!dpar %in% c("mu", "phylo")) {
    return(NA_character_)
  }
  if (index %in% model$target_cor) {
    return(model$dpar)
  }
  NA_character_
}

random_effect_correlation_is_modelled <- function(object, dpar, index) {
  !is.na(random_effect_correlation_model_dpar(object, dpar, index))
}

parse_random_correlation_endpoint <- function(value, default_dpar) {
  parts <- strsplit(value, ":", fixed = TRUE)[[1L]]
  if (
    length(parts) >= 2L &&
      parts[[1L]] %in% c("mu", "mu1", "mu2", "sigma", "sigma1", "sigma2")
  ) {
    return(list(
      dpar = parts[[1L]],
      coef = paste(parts[-1L], collapse = ":")
    ))
  }
  list(dpar = default_dpar, coef = value)
}

new_corpair_row <- function(
  level,
  group,
  block,
  from_dpar,
  to_dpar,
  from_coef,
  to_coef,
  from_response,
  to_response,
  class,
  parameter,
  estimate,
  min,
  max,
  n_values,
  link_estimate,
  link_min,
  link_max,
  modelled
) {
  data.frame(
    level = level,
    group = group,
    block = block,
    from_dpar = from_dpar,
    to_dpar = to_dpar,
    from_coef = from_coef,
    to_coef = to_coef,
    from_response = from_response,
    to_response = to_response,
    class = class,
    parameter = parameter,
    estimate = estimate,
    min = min,
    max = max,
    n_values = n_values,
    link_estimate = link_estimate,
    link_min = link_min,
    link_max = link_max,
    modelled = modelled,
    stringsAsFactors = FALSE
  )
}

parse_random_correlation_label <- function(label) {
  if (!startsWith(label, "cor(") || !endsWith(label, ")")) {
    return(list(
      from_coef = NA_character_,
      to_coef = NA_character_,
      group = NA_character_,
      block = NA_character_
    ))
  }

  inner <- substring(label, 5L, nchar(label) - 1L)
  pair_and_group <- strsplit(inner, " \\| ", fixed = FALSE)[[1L]]
  if (length(pair_and_group) < 2L) {
    return(list(
      from_coef = NA_character_,
      to_coef = NA_character_,
      group = NA_character_,
      block = NA_character_
    ))
  }

  pair <- pair_and_group[[1L]]
  pair_parts <- strsplit(pair, ",", fixed = TRUE)[[1L]]
  if (length(pair_parts) != 2L) {
    return(list(
      from_coef = NA_character_,
      to_coef = NA_character_,
      group = NA_character_,
      block = NA_character_
    ))
  }

  group_parts <- pair_and_group[-1L]
  if (length(group_parts) == 2L) {
    block <- group_parts[[1L]]
    group <- group_parts[[2L]]
  } else {
    block <- NA_character_
    group <- paste(group_parts, collapse = " | ")
  }

  list(
    from_coef = trimws(pair_parts[[1L]]),
    to_coef = trimws(pair_parts[[2L]]),
    group = trimws(group),
    block = trimws(block)
  )
}

random_correlation_class <- function(dpar, from_coef, to_coef, to_dpar = dpar) {
  from_family <- sub("[0-9]+$", "", dpar)
  to_family <- sub("[0-9]+$", "", to_dpar)
  from_intercept <- identical(from_coef, "(Intercept)")
  to_intercept <- identical(to_coef, "(Intercept)")
  if (identical(from_family, "mu") && identical(to_family, "mu")) {
    if (from_intercept && to_intercept) {
      return("mean-mean")
    }
    if (!from_intercept && !to_intercept) {
      return("slope-slope")
    }
    return("mean-slope")
  }
  if (identical(from_family, "sigma") && identical(to_family, "sigma")) {
    if (!identical(dpar, to_dpar)) {
      return("scale-scale")
    }
    if (from_intercept && to_intercept) {
      return("scale-scale")
    }
    if (!from_intercept && !to_intercept) {
      return("malleability")
    }
    return("scale-slope")
  }
  if (
    (identical(from_family, "mu") && identical(to_family, "sigma")) ||
      (identical(from_family, "sigma") && identical(to_family, "mu"))
  ) {
    if (from_intercept && to_intercept) {
      return("mean-scale")
    }
    if (identical(from_family, "mu") && !from_intercept && to_intercept) {
      return("slope-scale")
    }
    if (identical(from_family, "sigma") && from_intercept && !to_intercept) {
      return("slope-scale")
    }
    return("mean-scale-slope")
  }
  paste0(dpar, "-", dpar)
}

guarded_correlation_link <- function(x, guard) {
  atanh(pmax(pmin(x / guard, 1 - 1e-12), -1 + 1e-12))
}

bivariate_response_names <- function(object) {
  c(
    response_name_from_model_frame(object, "mu1", fallback = "y1"),
    response_name_from_model_frame(object, "mu2", fallback = "y2")
  )
}

univariate_response_name <- function(object, dpar) {
  response_name_from_model_frame(object, "mu", fallback = NA_character_)
}

random_effect_response_name <- function(object, dpar) {
  if (
    object$model$model_type %in%
      c("biv_gaussian", "biv_lognormal", "biv_student")
  ) {
    response_names <- bivariate_response_names(object)
    if (dpar %in% c("mu1", "sigma1")) {
      return(response_names[[1L]])
    }
    if (dpar %in% c("mu2", "sigma2")) {
      return(response_names[[2L]])
    }
  }
  univariate_response_name(object, dpar)
}

response_name_from_model_frame <- function(object, dpar, fallback) {
  response_name <- object$model$response_names[[dpar]]
  if (
    is.character(response_name) &&
      length(response_name) == 1L &&
      !is.na(response_name)
  ) {
    return(response_name)
  }
  mf <- object$model$model_frame[[dpar]]
  if (is.data.frame(mf) && ncol(mf) > 0L) {
    return(names(mf)[[1L]])
  }
  fallback
}

#' Extract fitted response values
#'
#' `fitted()` returns fitted response values from a `drmTMB` model. For
#' univariate Gaussian, Student-t, Gamma, Tweedie, beta, beta-binomial,
#' ordinary Poisson, ordinary negative-binomial, and cumulative-logit ordinal
#' fits this is the fitted response summary. For Tweedie fits, that summary is
#' the unconditional response mean `mu`. For beta-binomial fits, that summary is
#' the fitted success probability `mu`. For ordinal fits, that summary is the expected
#' ordered category score, `sum_k k * Pr(y_i = k)`. For zero-truncated
#' negative-binomial 2 fits this is the positive-count mean
#' `mu / (1 - Pr_NB2(0))`, where `mu` is the untruncated NB2 component mean.
#' For hurdle negative-binomial 2 fits this is the unconditional response mean
#' `(1 - hu) * mu / (1 - Pr_NB2(0))`.
#' For zero-inflated Poisson and zero-inflated negative-binomial 2 fits this is
#' the unconditional response mean `(1 - zi) * mu`, where `mu` is the
#' conditional count mean. For bivariate Gaussian fits this is a two-column
#' matrix with `mu1` and `mu2`. The same two-column marginal-mean contract
#' applies to bivariate Student-t fits because their shared `nu` is greater
#' than 2. For bivariate lognormal fits it is a two-column matrix of arithmetic
#' marginal means. For lognormal fits this is the arithmetic response mean,
#' `exp(mu + sigma^2 / 2)`.
#'
#' Fitted values are returned for the original fitted rows. Use [predict()] for
#' new data or for non-location distributional parameters such as `sigma` or
#' `rho12`.
#'
#' @param object A `drmTMB` fit.
#' @param ... Reserved for future fitted-value options.
#'
#' @return A numeric vector for univariate fits, or a two-column matrix for
#'   bivariate Gaussian, bivariate lognormal, or bivariate Student-t fits.
#' @export
#'
#' @examples
#' dat <- data.frame(y = c(0.2, 0.5, 1.1, 1.4), x = c(-1, 0, 1, 2))
#' fit <- drmTMB(bf(y ~ x, sigma ~ 1), data = dat)
#' fitted(fit)
fitted.drmTMB <- function(object, ...) {
  drm_fitted_response(object)
}

#' @rdname fixef
#' @export
coef.drmTMB <- function(object, dpar = NULL, ...) {
  if (is.null(dpar)) {
    return(object$coefficients)
  }
  dpar <- match.arg(dpar, names(object$coefficients))
  object$coefficients[[dpar]]
}

#' @rdname model-fit-extractors
#' @export
vcov.drmTMB <- function(object, ..., type = "model", robust = FALSE) {
  if (identical(type, "robust") || isTRUE(robust)) {
    cli::cli_abort(
      c(
        "Robust (sandwich) standard errors are not implemented for {.cls drmTMB} fits.",
        "x" = "{.fn vcov} has no {.code type = \"robust\"} route, so requesting it must not silently fall back to the model-based matrix.",
        "i" = "Try {.fn confint} with {.code method = \"boot\"} for a resampling-based interval, or refit with a heavier-tailed family (e.g. {.fn student}) if the concern is family misspecification."
      ),
      class = "drmTMB_vcov_robust_unsupported"
    )
  }
  if (drm_is_mspl(object)) {
    return(drm_mspl_vcov(object))
  }
  cov_primary <- drm_sdreport_cov_coefficients(object)
  labels <- coefficient_labels(object)
  targets <- drm_profile_targets(object)
  targets <- targets[targets$target_class == "fixed-effect", , drop = FALSE]
  matched <- match(paste0("fixef:", labels), targets$parm)
  jacobian <- vapply(matched, function(row) {
    if (is.na(row)) NA_real_ else summary_parameter_delta_derivative(targets[row, , drop = FALSE])
  }, numeric(1L))
  out <- matrix(
    NA_real_,
    nrow = length(labels),
    ncol = length(labels),
    dimnames = list(labels, labels)
  )
  # Fill (co)variances for coefficients whose TMB parameter is found in `src_names`,
  # reading from `cov_src`. Only fills cells still NA, so an earlier source wins for
  # parameters present in more than one source.
  fill_from <- function(out, cov_src, src_names) {
    if (!is.matrix(cov_src)) {
      return(out)
    }
    pos <- rep(NA_integer_, length(labels))
    for (i in seq_along(labels)) {
      row <- matched[[i]]
      if (is.na(row)) {
        next
      }
      hits <- which(src_names == targets$tmb_parameter[[row]])
      index <- targets$index[[row]]
      if (!is.na(index) && index >= 1L && index <= length(hits)) {
        pos[[i]] <- hits[[index]]
      }
    }
    ok <- which(!is.na(pos) & pos <= nrow(cov_src))
    for (a in ok) {
      for (b in ok) {
        if (is.na(out[a, b])) {
          # Apply the public-coordinate derivative on both axes, including
          # cross-covariance with ordinary response/predictor coefficients.
          out[a, b] <- jacobian[[a]] * cov_src[pos[[a]], pos[[b]]] * jacobian[[b]]
        }
      }
    }
    out
  }
  out <- fill_from(
    out,
    cov_primary,
    drm_sdreport_coefficient_parameter_names(object)
  )
  # Under REML the outer variance-structure coefficients (e.g. the sd_phylo betas)
  # are not ADREPORTed into `sdr$value`, so they are absent from the joint `sdr$cov`
  # used above; their (co)variances live in `cov.fixed` / `opt$par`. Fill those gaps.
  if (isTRUE(object$REML) && anyNA(diag(out))) {
    out <- fill_from(out, object$sdr$cov.fixed, names(object$opt$par))
  }
  out
}

drm_sdreport_cov_fixed <- function(object) {
  if (!drm_has_sdreport_covariance(object)) {
    cli::cli_abort(c(
      drm_sdreport_unavailable_message(object),
      "i" = "Refit with {.code control = drm_control(se = TRUE)} for {.fn vcov}, Wald standard errors, or Wald confidence intervals."
    ))
  }
  object$sdr$cov.fixed
}

drm_sdreport_cov_coefficients <- function(object) {
  if (!drm_has_sdreport_covariance(object)) {
    cli::cli_abort(c(
      drm_sdreport_unavailable_message(object),
      "i" = "Refit with {.code control = drm_control(se = TRUE)} for {.fn vcov}, Wald standard errors, or Wald confidence intervals."
    ))
  }
  if (isTRUE(object$REML)) {
    if (!is.matrix(object$sdr$cov)) {
      cli::cli_abort(
        "Fixed-effect covariance is unavailable because the REML sdreport does not contain a full covariance matrix."
      )
    }
    return(object$sdr$cov)
  }
  object$sdr$cov.fixed
}

drm_sdreport_coefficient_parameter_names <- function(object) {
  if (isTRUE(object$REML)) {
    return(names(object$sdr$value))
  }
  names(object$opt$par)
}

drm_has_sdreport_covariance <- function(object) {
  drm_has_sdreport_covariance_matrix(object) &&
    isTRUE(object$sdr$pdHess)
}

drm_has_sdreport_covariance_matrix <- function(object) {
  !is.null(object$sdr) &&
    !is.null(object$sdr$cov.fixed) &&
    is.matrix(object$sdr$cov.fixed)
}

drm_uncertainty_status <- function(object) {
  state <- object$uncertainty
  if (
    is.list(state) &&
      is.character(state$status) &&
      length(state$status) == 1L &&
      !is.na(state$status) &&
      nzchar(state$status)
  ) {
    return(state$status)
  }
  if (!is.null(object$sdr)) {
    return("ok")
  }
  "unavailable"
}

drm_uncertainty_message <- function(object) {
  state <- object$uncertainty
  if (
    is.list(state) &&
      is.character(state$message) &&
      length(state$message) == 1L &&
      !is.na(state$message) &&
      nzchar(state$message)
  ) {
    return(state$message)
  }
  switch(
    drm_uncertainty_status(object),
    ok = "TMB::sdreport() completed successfully.",
    unsupported = paste(
      "Wald uncertainty is intentionally unavailable for experimental",
      "MSPL point-estimation fits."
    ),
    skipped = paste(
      "TMB::sdreport() was skipped because",
      "drm_control(se = FALSE) was used."
    ),
    failed = "TMB::sdreport() failed.",
    "This fit does not contain a TMB::sdreport() object."
  )
}

drm_sdreport_unavailable_message <- function(object) {
  status <- drm_uncertainty_status(object)
  if (identical(status, "skipped")) {
    return(paste(
      "Fixed-effect covariance is unavailable because TMB::sdreport()",
      "was skipped by drm_control(se = FALSE)."
    ))
  }
  if (identical(status, "failed")) {
    return(paste(
      "Fixed-effect covariance is unavailable because",
      drm_uncertainty_message(object)
    ))
  }
  if (!is.null(object$sdr) && !isTRUE(object$sdr$pdHess)) {
    return(paste(
      "Fixed-effect covariance is unavailable because TMB::sdreport()",
      "did not report a positive-definite Hessian."
    ))
  }
  "Fixed-effect covariance is unavailable because this drmTMB fit does not contain a TMB::sdreport() object."
}

drm_uncertainty_check_status <- function(object) {
  if (drm_uncertainty_status(object) %in% c("skipped", "unsupported")) {
    return("note")
  }
  "warning"
}

drm_standard_error_status <- function(object) {
  if (
    identical(drm_uncertainty_status(object), "ok") &&
      !is.null(object$sdr) &&
      !isTRUE(object$sdr$pdHess)
  ) {
    return("sdreport_non_pd_hessian")
  }
  switch(
    drm_uncertainty_status(object),
    unsupported = "mspl_inference_unsupported",
    skipped = "sdreport_skipped",
    failed = "sdreport_failed",
    ok = "ok",
    "sdreport_unavailable"
  )
}

#' Extract standard model-fit quantities
#'
#' These methods expose `drmTMB` fits to standard base-R model summary and
#' comparison helpers.
#'
#' `logLik()` returns a `"logLik"` object with `df` and `nobs` attributes so
#' [stats::AIC()] and [stats::BIC()] use the fitted likelihood, optimized
#' top-level parameter count, and fitted-row count consistently.
#' `nobs()` returns the number of fitted rows after complete-case filtering.
#' `df.residual()` returns `nobs - df`, where `df` is the number of optimized
#' top-level parameters recorded in `logLik()`. `deviance()` returns
#' `-2 * logLik`; for these likelihood-based distributional models this is an
#' absolute negative twice log-likelihood value, not a saturated-model GLM
#' deviance. `vcov()` returns the fixed-effect covariance matrix from
#' `TMB::sdreport()` when the fit contains an `sdreport` object with
#' `pdHess = TRUE`; the same object is available as `fit$sdr` and
#' `fit$sdreport`. If `sdreport()` was skipped, failed, or returned
#' `pdHess = FALSE`, Wald standard errors and Wald confidence intervals are
#' unavailable while point estimates remain usable. `vcov()` intentionally does
#' not include random-effect conditional modes or derived response-scale
#' quantities.
#'
#' @param object A `drmTMB` fit.
#' @param ... Reserved for future extractor options.
#' @param k Numeric penalty per parameter for `AIC()`; the default is `2`.
#' @param type For `vcov()`, `"model"` (the default) for the model-based
#'   covariance matrix. `"robust"` is not implemented and errors rather than
#'   silently falling back to the model-based matrix.
#' @param robust For `vcov()`, a `TRUE`/`FALSE` alias for
#'   `type = "robust"`/`type = "model"`; also errors when `TRUE`.
#'
#' @return `logLik()` returns an object of class `"logLik"`. `vcov()` returns a
#'   numeric covariance matrix. `nobs()`, `df.residual()`, and `deviance()`
#'   return numeric scalars.
#'
#' @examples
#' set.seed(20260524)
#' n <- 36
#' x <- seq(-1.5, 1.5, length.out = n)
#' dat <- data.frame(
#'   y = 0.3 + 0.6 * x + rnorm(n, sd = 0.7),
#'   x = x
#' )
#' fit <- drmTMB(bf(y ~ x, sigma ~ 1), data = dat)
#'
#' logLik(fit)
#' nobs(fit)
#' df.residual(fit)
#' deviance(fit)
#' AIC(fit)
#' BIC(fit)
#' vcov(fit)
#'
#' @section Experimental MSPL fits:
#' For a fit made with `estimator = "mspl"`, `vcov()` behaves differently from
#' an ordinary maximum-likelihood fit in two ways worth knowing before you use
#' it.
#'
#' First, **the shape differs**. It returns the full outer-parameter covariance
#' after Laplace marginalisation — the fixed effects *and* the covariance
#' parameters in their frozen Cholesky coordinates (`log_sd_mu`, and
#' `eta_cor_mu` for a q = 2 block) — not the fixed-effect-only block an ordinary
#' fit returns. Code that assumes `vcov(fit)` has the same dimension across
#' estimators will break.
#'
#' Second, **it is a standard error, not an interval**. The matrix inverts the
#' Hessian of the *unpenalized* Laplace log-likelihood evaluated at the MSPL
#' estimate: the penalty obtains a finite estimate but does not describe
#' sampling variability. Do not form `coef ± 1.96 * se`. Kosmidis and Firth show
#' that Wald intervals in this setting fail to cover regardless of the nominal
#' level, and that the failure persists even for profile penalized-likelihood
#' intervals; the mechanism is the finiteness of the penalized estimator and its
#' standard error, not separation as such. A second reason applies here: the
#' MSPL estimate maximises the *penalized* criterion, so the unpenalized score
#' is not zero at it and the usual "evaluate at the maximum likelihood estimate"
#' justification does not transfer. The size of that departure is recorded in
#' `fit$mspl$wald$unpenalized_gradient_max_abs`.
#'
#' Accordingly `confint()`, `profile()`, `logLik()`, `AIC`, `BIC`, and `anova()`
#' deliberately error for MSPL fits. When the information matrix is not
#' positive definite — which happens on exactly the strongly separated designs
#' MSPL exists to handle — the standard errors are `NA` and a
#' `drmTMB_mspl_wald_unavailable` warning is signalled, rather than a
#' fabricated number.
#' @name model-fit-extractors
NULL

#' @rdname model-fit-extractors
#' @export
logLik.drmTMB <- function(object, ...) {
  drm_abort_mspl_inference(object, "logLik")
  out <- object$logLik
  attr(out, "df") <- object$df
  attr(out, "nobs") <- object$nobs
  if (!is.null(object$estimator)) {
    attr(out, "estimator") <- object$estimator
  }
  if (isTRUE(object$REML)) {
    attr(out, "REML") <- TRUE
  }
  class(out) <- "logLik"
  out
}

# Warn when an information criterion is requested for a fit where it is not a
# valid comparison. `stats::AIC()`/`BIC()` default methods read the logLik value
# and ignore the estimator, so the guard lives in the drmTMB methods below.
drm_ic_fixed_effect_signature <- function(object) {
  blocks <- coef(object)
  # Sort the block names: native fits list dpar blocks in model order (mu1, mu2,
  # sigma1, sigma2, rho12) while engine = "julia" fits come out of split() in
  # alphabetical order, so list order alone made identical bivariate fixed
  # effects look different across engines.
  block_names <- sort(names(blocks), method = "radix")
  paste(
    vapply(
      block_names,
      function(nm) {
        paste0(nm, ":", paste(names(blocks[[nm]]), collapse = ","))
      },
      character(1L)
    ),
    collapse = "|"
  )
}

# Fits whose estimator the information-criterion guard can read: native fits
# and `engine = "julia"` bridge fits (#1498), which record `estimator` and
# `REML` the same way but do not inherit "drmTMB".
drm_ic_guarded_fit <- function(o) {
  inherits(o, c("drmTMB", "drmTMB_julia"))
}

drm_warn_information_criterion <- function(fits, what) {
  fits <- fits[vapply(fits, drm_ic_guarded_fit, logical(1L))]
  drm_fits <- fits
  estimators <- vapply(
    fits,
    function(o) if (is.null(o$estimator)) "ML" else o$estimator,
    character(1L)
  )
  if (any(estimators == "MAP")) {
    cli::cli_warn(
      c(
        "{what} is not a standard information criterion for a penalized (MAP) fit.",
        "i" = "{.fn logLik} returns the unpenalized data log-likelihood and a penalized parameter does not contribute a full degree of freedom."
      ),
      class = "drmTMB_ic_map_warning"
    )
  }
  if (any(estimators == "REML")) {
    reml_comparison_invalid <- length(drm_fits) < 2L ||
      any(estimators != "REML") ||
      length(unique(vapply(
        drm_fits[estimators == "REML"],
        drm_ic_fixed_effect_signature,
        character(1L)
      ))) > 1L
    if (reml_comparison_invalid) {
      cli::cli_warn(
        c(
          "{what} from a REML fit is comparable only across models with identical fixed effects.",
          "i" = "Never compare ML with REML, or different mean structures, by {what}; refit with {.code REML = FALSE} for fixed-effect model selection."
        ),
        class = "drmTMB_ic_reml_warning"
      )
    }
  }
  invisible(NULL)
}

# `o` may be a drmTMB fit or a foreign fit (e.g. `lm`, `gls`) passed in `...`;
# foreign fits are read through `stats::logLik()`/`stats::nobs()` like
# `stats::AIC.default` does, so they keep their own row instead of being
# silently dropped from the comparison table.
drm_ic_loglik_df <- function(o) {
  if (inherits(o, "drmTMB")) {
    return(list(value = as.numeric(o$logLik), df = as.numeric(o$df)))
  }
  ll <- stats::logLik(o)
  list(value = as.numeric(ll), df = as.numeric(attr(ll, "df")))
}

drm_ic_nobs <- function(o) {
  if (inherits(o, "drmTMB")) as.numeric(o$nobs) else as.numeric(stats::nobs(o))
}

drm_information_criterion <- function(fits, penalty, what) {
  mspl <- which(vapply(fits, drm_is_mspl, logical(1L)))
  if (length(mspl)) {
    drm_abort_mspl_inference(fits[[mspl[[1L]]]], what)
  }
  drm_warn_information_criterion(fits, what)
  computed <- lapply(fits, function(o) {
    ll_df <- drm_ic_loglik_df(o)
    list(value = -2 * ll_df$value + penalty(o) * ll_df$df, df = ll_df$df)
  })
  if (length(fits) == 1L) {
    return(computed[[1L]]$value)
  }
  data.frame(
    df = vapply(computed, `[[`, numeric(1L), "df"),
    stats::setNames(list(vapply(computed, `[[`, numeric(1L), "value")), what)
  )
}

#' @rdname model-fit-extractors
#' @export
AIC.drmTMB <- function(object, ..., k = 2) {
  fits <- c(list(object), list(...))
  drm_information_criterion(fits, function(o) k, "AIC")
}

#' @rdname model-fit-extractors
#' @export
BIC.drmTMB <- function(object, ...) {
  fits <- c(list(object), list(...))
  drm_information_criterion(fits, function(o) log(drm_ic_nobs(o)), "BIC")
}

#' Likelihood-ratio comparison of drmTMB fits
#'
#' `anova(m0, m1, ...)` tests nested [drmTMB()] fits with a likelihood-ratio
#' test. The fits are ordered by their number of parameters and each model is
#' tested against the one before it, as in `lme4` and `glmmTMB`. The statistic
#' is \eqn{2 (\ell_{\mathrm{full}} - \ell_{\mathrm{reduced}})} with
#' `df(full) - df(reduced)` degrees of freedom, and the table has columns
#' `npar`, `logLik`, `deviance`, `Chisq`, `Df` and `Pr(>Chisq)`.
#'
#' Guards, all of which abort with a message saying what to do next:
#' * the fits must be on the same observations;
#' * ML and REML fits are never mixed, and REML fits must share their
#'   fixed-effect (mean) structure, because restricted likelihoods are
#'   comparable only across variance structures;
#' * penalized (MAP) fits abort, as their variance components are shrunk by
#'   the prior;
#' * experimental MSPL fits abort, as for every likelihood method;
#' * `engine = "julia"` fits are not supported, and neither are models with
#'   the same number of parameters (compare those with [AIC()]).
#'
#' **Boundary tests.** When the larger model adds a random-effect standard
#' deviation, the null value 0 sits on the edge of the parameter space and the
#' usual chi-square reference is conservative. A
#' `drmTMB_anova_boundary_warning` is signalled for such a pair. If exactly one
#' or two standard deviations are added and nothing else, `Pr(>Chisq)` is the
#' chi-bar-square mixture from [lrt_boundary()]; the attribute `"p.method"`
#' records `"chibar"` or `"chisq"` per row. Otherwise the naive chi-square
#' p-value is reported and the warning says it is conservative.
#'
#' A negative statistic (the smaller model fitted better) is reported as is
#' and gives a p-value of 1 (or the boundary value); it signals non-nested
#' models or a fit that did not converge.
#'
#' @param object A `drmTMB` fit.
#' @param ... Further `drmTMB` fits to compare with `object`.
#' @param test `NULL` (the default), `"Chisq"` or `"LRT"`; only the
#'   likelihood-ratio test is offered.
#'
#' @return An object of class `c("anova", "data.frame")` with one row per
#'   fit, in order of increasing number of parameters.
#' @seealso [lrt_boundary()], [AIC()], [model-comparison]
#' @examples
#' \donttest{
#' set.seed(1)
#' n <- 80
#' dat <- data.frame(x = rnorm(n))
#' dat$y <- 0.2 + 0.6 * dat$x + rnorm(n)
#' m0 <- drmTMB(bf(y ~ 1, sigma ~ 1), family = gaussian(), data = dat)
#' m1 <- drmTMB(bf(y ~ x, sigma ~ 1), family = gaussian(), data = dat)
#' anova(m0, m1)
#' }
#' @export
anova.drmTMB <- function(object, ..., test = NULL) {
  dots <- list(...)
  dot_exprs <- as.list(substitute(list(...)))[-1L]
  labels <- c(
    paste(deparse(substitute(object)), collapse = ""),
    vapply(dot_exprs, function(e) paste(deparse(e), collapse = ""), character(1L))
  )
  given <- names(dots)
  if (!is.null(given)) {
    labels[-1L][nzchar(given)] <- given[nzchar(given)]
  }
  drm_anova_lrt(c(list(object), dots), labels, test = test)
}

#' @rdname model-fit-extractors
#' @export
nobs.drmTMB <- function(object, ...) {
  object$nobs
}

#' @rdname model-fit-extractors
#' @export
df.residual.drmTMB <- function(object, ...) {
  object$nobs - object$df
}

#' @rdname model-fit-extractors
#' @export
deviance.drmTMB <- function(object, ...) {
  -2 * as.numeric(stats::logLik(object))
}

#' Predict distributional parameters
#'
#' `predict()` returns fitted or predicted values for one distributional
#' parameter of a `drmTMB` fit.
#'
#' By default, predictions are returned on the distributional parameter's
#' response scale. For positive scale parameters such as `sigma`, this means
#' the exponentiated value. For bivariate residual correlation `rho12` or a
#' fitted `corpair()` model, this means the correlation scale. Use
#' `type = "link"` to return the linear predictor instead.
#'
#' When `newdata = NULL`, predictions are for the fitted rows and include
#' currently implemented conditional random-effect contributions for `mu`,
#' including registry-backed q > 2 ordinary covariance blocks, bivariate
#' `mu1`/`mu2`, phylogenetic `mu`, and residual-scale `sigma` including
#' bivariate `sigma1`/`sigma2` blocks. Fitted-row predictions also include
#' ordinary zero-one-beta `zoi` and `coi` random-effect contributions. When
#' `newdata` is supplied, predictions are fixed-effect, population-level
#' predictions for the supplied rows.
#'
#' `type = "quantile"` returns per-row conditional quantiles of the fitted
#' RESPONSE distribution (not of a linear predictor): `qnorm`-style inverse
#' CDF evaluation via [fitted_distribution()]`$q()` at [predict_parameters()]'s
#' fixed-effect, population-level parameter estimates -- see
#' [fitted_distribution()] for the fixed-effect-only scope and the
#' `"spike"`/`"unimplemented"` status gate this inherits (a `"spike"`-status
#' family emits a one-time warning; an unregistered `model_type` raises a
#' clear error). For bivariate `biv_gaussian` fits, `dpar` selects which
#' response's MARGINAL quantile to return (`"mu1"`/`"sigma1"` for response 1,
#' `"mu2"`/`"sigma2"` for response 2); the joint `rho12` correlation, any joint
#' tail structure, and any known bivariate sampling covariance are ignored --
#' this is a marginal-only computation, not a joint bivariate quantile. The
#' result carries `attr(., "calibrated") <- FALSE`: this is a distributional
#' (plug-in) interval at the point estimate `theta_hat`, not a
#' calibrated-coverage interval, and it does not propagate `theta_hat`
#' uncertainty.
#'
#' @param object A `drmTMB` fit.
#' @param newdata Optional data frame for prediction. If omitted, fitted rows
#'   are used. When supplied, `newdata` must include the predictors used by the
#'   requested `dpar`; required predictor values must be complete, required
#'   numeric predictors must be finite, and factor predictors must use fitted
#'   levels. Transformed predictor terms, such as `log(size)`, must also
#'   evaluate to finite design-matrix values.
#' @param dpar Distributional parameter to predict. If `NULL`, the first
#'   fitted distributional parameter is used. For `type = "quantile"` on a
#'   bivariate `biv_gaussian` fit, `dpar` instead selects which response's
#'   marginal quantile to compute (see Details).
#' @param type Prediction scale: `"response"`, `"link"`, or `"quantile"`.
#' @param prob Numeric vector of probabilities in (0, 1), used only when
#'   `type = "quantile"`.
#' @param ... Reserved for future prediction options.
#'
#' @return A numeric vector for `type` `"response"`/`"link"`. For
#'   `type = "quantile"`, a numeric matrix with one row per observation and
#'   one column per `prob` (columns named as percentages, e.g. `"2.5%"`), with
#'   `attr(., "calibrated") == FALSE`.
#' @details
#' For retained training data with a modelled missing predictor, prediction uses
#' that predictor's finalized conditional plug-in in the fixed-effect design.
#' This is a distributional-parameter prediction, not an integrated response
#' mean, and fixed-effect covariance does not propagate imputation-parameter
#' uncertainty through the design basis.
#'
#' More generally, `type = "response"` means "on the response scale of the
#' requested distributional parameter", not always `E[Y]`. For
#' zero-inflated and hurdle count families it returns the component count mean
#' when `dpar = "mu"`, not the unconditional mean after structural-zero or
#' hurdle mixing. For lognormal fits it returns `mu` on the log-response scale,
#' not `exp(mu + sigma^2 / 2)`. For cumulative-logit fits it returns the
#' location linear predictor on its response scale, not an expected ordinal
#' score. Use [fitted.drmTMB()] for fitted-row response means or expected
#' scores; use explicit distributional-parameter predictions when a new-data
#' mean must be assembled outside the fitted rows.
#'
#' Binary predictor labels follow the fitted encoding, regardless of the levels
#' present in the new batch. Numeric new values match raw numeric fitted labels;
#' for nonnumeric fitted labels, numeric 0/1 values specify the encoded states.
#' If distinct labels become identical as numbers (for example, "01" and "1"),
#' supply character or factor values to preserve their identity.
#'
#' For families in `drm_clamped_scale_families()`, the `log(sigma)` linear
#' predictor is soft-clamped inside the TMB likelihood to keep the objective
#' finite. `predict(dpar = "sigma")` (and the bivariate `sigma1`/`sigma2`)
#' reports that same clamped scale, on both `type = "link"` and
#' `type = "response"`, so the value matches what the likelihood actually
#' evaluated. When `check_drm()` reports the clamp active, this makes the
#' fit's own diagnostics honest, not correct: the estimate itself is still
#' unreliable near the clamp (see the rescaling advice there).
#' @seealso [fitted.drmTMB()], [rho12()], [stats::sigma()], [fitted_distribution()],
#'   [exceedance()]
#'
#' @examples
#' dat <- data.frame(
#'   y = c(0.2, 0.5, 1.1, 1.4, 1.8, 2.2),
#'   x = c(-1, -0.5, 0, 0.5, 1, 1.5)
#' )
#' fit <- drmTMB(bf(y ~ x, sigma ~ x), data = dat)
#' predict(fit, dpar = "mu")
#' predict(fit, dpar = "sigma")
#' predict(fit, dpar = "sigma", type = "link")
#' predict(fit, newdata = data.frame(x = c(0, 1)), dpar = "mu")
#' predict(fit, type = "quantile", prob = c(0.025, 0.5, 0.975))
#' @export
predict.drmTMB <- function(
  object,
  newdata = NULL,
  dpar = NULL,
  type = c("response", "link", "quantile"),
  prob = c(0.025, 0.5, 0.975),
  ...
) {
  if (is.null(dpar)) {
    dpar <- object$model$dpars[[1L]]
  }
  dpar <- match.arg(dpar, names(object$coefficients))
  type <- match.arg(type)
  if (identical(type, "quantile")) {
    return(drm_predict_quantile(object, newdata = newdata, dpar = dpar, prob = prob))
  }
  if (is_random_scale_dpar(object, dpar)) {
    return(predict_random_scale_dpar(
      object,
      dpar,
      newdata = newdata,
      type = type
    ))
  }
  basis <- drm_fixed_effect_basis(object, newdata = newdata, dpar = dpar)
  eta <- basis$eta
  if (
    is.null(newdata) &&
      dpar %in% mu_random_effect_dpars(object) &&
      has_ordinary_mu_random_effects(object)
  ) {
    eta <- eta + mu_random_effect_contribution(object, dpar = dpar)
  }
  if (
    is.null(newdata) &&
      dpar %in% c("mu", "mu1", "mu2") &&
      has_covariance_block_random_effects(object)
  ) {
    eta <- eta +
      covariance_block_random_effect_contribution(
        object,
        dpar = dpar
      )
  }
  if (
    is.null(newdata) &&
      dpar %in% phylo_mu_dpars(object$model$structured$phylo_mu) &&
      has_structured_mu_effect(object)
  ) {
    eta <- eta + phylo_mu_contribution(object, dpar = dpar)
  }
  if (
    is.null(newdata) &&
      dpar %in% sigma_random_effect_dpars(object) &&
      has_sigma_random_effects(object)
  ) {
    eta <- eta + sigma_random_effect_contribution(object, dpar = dpar)
  }
  if (
    is.null(newdata) &&
      dpar %in% c("zoi", "coi") &&
      has_atom_probability_random_effects(object, dpar)
  ) {
    eta <- eta + atom_probability_random_effect_contribution(
      object,
      dpar = dpar
    )
  }
  if (
    is.null(newdata) &&
      dpar %in% c("sigma", "sigma1", "sigma2") &&
      has_covariance_block_random_effects(object)
  ) {
    eta <- eta +
      covariance_block_random_effect_contribution(
        object,
        dpar = dpar
      )
  }

  eta <- drm_clamped_sigma_eta(object, dpar, eta)
  if (type == "link") {
    return(eta)
  }
  drm_inverse_link(object, dpar, eta)
}

#' Simulate from a fitted model
#'
#' `simulate()` draws new response values from the fitted `drmTMB` model. For
#' univariate Gaussian models with known sampling covariance, simulation uses
#' the total observation covariance implied by the known sampling covariance
#' plus the fitted residual scale. For Student-t models, simulation uses fitted
#' `mu`, `sigma`, and `nu`. For lognormal models, simulation uses fitted
#' log-scale `mu` and `sigma`. For Gamma models, simulation uses fitted mean
#' `mu` and coefficient of variation `sigma`. For beta models, simulation uses
#' fitted mean `mu` and public scale `sigma` with internal
#' `phi = 1 / sigma^2`. For Tweedie models, simulation uses fitted `mu`,
#' public `sigma`, and power `nu`, with internal dispersion `phi = sigma^2`.
#' For zero-one beta models, simulation draws exact
#' boundary values from the fitted `zoi`/`coi` probabilities and interior
#' values from the fitted beta component. For beta-binomial models, simulation
#' draws latent success probabilities from the fitted beta distribution and then
#' success counts from the stored trial denominators. For binomial models,
#' simulation draws success counts from the fitted event probability and stored
#' trial denominators. For cumulative-logit ordinal models, simulation draws
#' ordered categories from the fitted cumulative-logit
#' probabilities. For Poisson models, simulation uses the fitted mean `mu`. For
#' zero-inflated Poisson models, simulation uses
#' fitted conditional mean `mu` and structural-zero probability `zi`. For
#' negative-binomial 2 models, simulation uses fitted `mu` and overdispersion
#' scale `sigma`, with `Var(y) = mu + sigma^2 * mu^2`; zero-truncated NB2
#' models draw from this NB2 component conditional on positive counts. The
#' zero-inflated NB2 path adds structural-zero probability `zi`; the hurdle NB2
#' path adds hurdle-zero probability `hu` and draws nonzero counts from the
#' zero-truncated NB2 component. For bivariate
#' Gaussian models without known
#' sampling covariance, simulation uses the fitted `mu1`, `mu2`, `sigma1`,
#' `sigma2`, and residual `rho12`. If a dense bivariate known `V` was supplied,
#' simulation uses the full row-paired observation covariance `V + Omega`.
#' For bivariate Student-t models, simulation instead uses one shared
#' chi-squared scale-mixture draw per response pair together with the fitted
#' shared `nu`; independent marginal t draws would be a different model.
#'
#' `re.form` follows the `lme4::simulate.merMod()` convention. By default
#' (`re.form = NA`, or equivalently `re.form = ~0`), models with ordinary
#' grouped random effects draw a **fresh** random-effect realization for every
#' replicate, so replicate-to-replicate variability reflects both the
#' between-group and the residual sources of variance. Pass `re.form = NULL`
#' to simulate conditionally on the fitted random effects instead (holding
#' every random effect fixed at its conditional-mode estimate). Marginal
#' simulation for ordinary location random effects with an admitted
#' predictor-dependent SD uses the fitted group-specific SD for each fresh
#' link-scale draw. For native Bernoulli phylogenetic and relatedness-matrix
#' (`relmat`) intercepts, it applies each tip or group's fitted SD to the fresh
#' structured draw. Julia Gamma animal models also support marginal simulation
#' for a complete-data animal intercept or an animal intercept plus one numeric
#' slope, with separate coefficient-specific SD formulas. The Julia fitter
#' normalizes the supplied relationship matrix to a correlation matrix, and
#' simulation follows that same convention. These Gamma routes use location
#' SDs and fixed `sigma ~ 1`; conditional simulation with `re.form = NULL` is
#' unavailable for Julia Laplace fits.
#' A native Bernoulli `relmat()` model with one intercept, one numeric slope,
#' and a separate predictor-dependent SD formula for each coefficient also
#' supports marginal simulation; the two fields are drawn independently with
#' their fitted group-specific covariance scales.
#'
#' It also redraws a single-endpoint
#' (`q == 1`) phylogenetic, spatial, relatedness-matrix (`relmat`),
#' animal-model, or `phylo_interaction` structured `mu` random effect from its
#' fitted covariance `sd^2 * Q^-1`. Other modelled structured-effect scales
#' are not yet supported outside the explicitly listed Bernoulli and Julia
#' Gamma routes. It does not yet support a structured mu
#' random effect correlated across more than one trait or distributional
#' parameter (`q > 1`, including a multi-endpoint `phylo_interaction` term),
#' correlated covariance-block random effects, predictor-dependent
#' random-effect correlation (`corpair`) regression, or other modelled
#' structured (heteroscedastic) random-effect scales; `simulate()` throws an
#' informative error naming the unsupported structure for those models and
#' directs the user to `re.form = NULL`. Models without random effects are
#' unaffected by `re.form`.
#'
#' Earlier versions of drmTMB gave the explicit values the reverse meaning
#' (`NULL` drew fresh random effects and `NA` held them fixed; #1487). The default output is
#' unchanged, but code that passed `re.form` explicitly now runs the other
#' simulation, so the first explicit `re.form` in a session prints a one-time
#' message (class `drmTMB_re_form_semantics_message`).
#'
#' For a fit made with `missing = miss_control(response = "include")`,
#' `simulate()` returns `NA` at masked rows for every family, matching
#' `residuals()`, so posterior-predictive tools such as
#' `DHARMa::createDHARMa()` see draws only where a response was observed.
#'
#' @param object A `drmTMB` fit.
#' @param nsim Number of simulated data sets.
#' @param seed Optional random-number seed. The previous `.Random.seed` state
#'   is restored after simulation.
#' @param re.form `NA` (the default) or `~0` draws fresh random effects for
#'   every replicate (marginal simulation). `NULL` holds every random effect
#'   fixed at its fitted conditional-mode estimate (conditional simulation).
#'   These meanings match `lme4::simulate.merMod()`; earlier drmTMB versions
#'   reversed them (see Details).
#' @param ... Reserved for future simulation options.
#'
#' @return A data frame. Univariate models return one column per simulation.
#'   Bivariate models return paired columns named `sim_<j>_y1` and
#'   `sim_<j>_y2`.
#'
#' @examples
#' dat <- data.frame(y = c(0.2, 0.5, 1.1, 1.4), x = c(-1, 0, 1, 2))
#' fit <- drmTMB(bf(y ~ x, sigma ~ 1), data = dat)
#' simulate(fit, nsim = 2, seed = 1)
#' @export
simulate.drmTMB <- function(object, nsim = 1, seed = NULL, re.form = NA, ...) {
  if (!base::missing(re.form)) {
    drm_simulate_re_form_semantics_message()
  }
  marginal <- drm_simulate_re_form_marginal(re.form)
  if (marginal) {
    unsupported <- drm_simulate_marginal_unsupported(object)
    if (!is.null(unsupported)) {
      cli::cli_abort(c(
        "Marginal simulation ({.code re.form = NA}, the default) does not yet support {unsupported}.",
        "i" = "Pass {.code re.form = NULL} to simulate conditionally on the fitted random effects instead."
      ))
    }
  }
  if (!is.null(seed)) {
    had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    old_seed <- if (had_seed) {
      get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    } else {
      NULL
    }
    on.exit(
      {
        if (had_seed) {
          assign(".Random.seed", old_seed, envir = .GlobalEnv)
        } else if (
          exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
        ) {
          rm(".Random.seed", envir = .GlobalEnv)
        }
      },
      add = TRUE
    )
    set.seed(seed)
  }

  if (identical(object$model$model_type, "student")) {
    nu <- predict(object, dpar = "nu")
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        sigma <- drm_marginal_predict(object, "sigma", re_draws)
        mu + sigma * stats::rt(length(mu), df = nu)
      })
    } else {
      mu <- predict(object, dpar = "mu")
      sigma <- predict(object, dpar = "sigma")
      sims <- replicate(nsim, mu + sigma * stats::rt(length(mu), df = nu))
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "biv_student")) {
    mu1 <- predict(object, dpar = "mu1")
    mu2 <- predict(object, dpar = "mu2")
    sigma1 <- predict(object, dpar = "sigma1")
    sigma2 <- predict(object, dpar = "sigma2")
    nu <- predict(object, dpar = "nu")
    rho12 <- predict(object, dpar = "rho12")
    out <- vector("list", nsim * 2L)
    names(out) <- as.vector(rbind(
      paste0("sim_", seq_len(nsim), "_y1"),
      paste0("sim_", seq_len(nsim), "_y2")
    ))
    for (j in seq_len(nsim)) {
      z1 <- stats::rnorm(length(mu1))
      z2 <- rho12 * z1 +
        sqrt(1 - rho12^2) * stats::rnorm(length(mu1))
      shared_scale <- sqrt(nu / stats::rchisq(length(mu1), df = nu))
      out[[paste0("sim_", j, "_y1")]] <-
        mu1 + sigma1 * z1 * shared_scale
      out[[paste0("sim_", j, "_y2")]] <-
        mu2 + sigma2 * z2 * shared_scale
    }
    return(as.data.frame(out))
  }

  if (identical(object$model$model_type, "skew_normal")) {
    sigma <- predict(object, dpar = "sigma")
    nu <- predict(object, dpar = "nu")
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        rskew_normal_public(length(mu), mu = mu, sigma = sigma, nu = nu)
      })
    } else {
      mu <- predict(object, dpar = "mu")
      sims <- replicate(
        nsim,
        rskew_normal_public(length(mu), mu = mu, sigma = sigma, nu = nu)
      )
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "lognormal")) {
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        sigma <- drm_marginal_predict(object, "sigma", re_draws)
        stats::rlnorm(length(mu), meanlog = mu, sdlog = sigma)
      })
    } else {
      mu <- predict(object, dpar = "mu")
      sigma <- predict(object, dpar = "sigma")
      sims <- replicate(
        nsim,
        stats::rlnorm(length(mu), meanlog = mu, sdlog = sigma)
      )
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "gamma")) {
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        sigma <- drm_marginal_predict(object, "sigma", re_draws)
        native <- drm_gamma_shape_scale(mu, sigma)
        stats::rgamma(length(mu), shape = native$shape, scale = native$scale)
      })
    } else {
      mu <- predict(object, dpar = "mu")
      sigma <- predict(object, dpar = "sigma")
      native <- drm_gamma_shape_scale(mu, sigma)
      sims <- replicate(
        nsim,
        stats::rgamma(length(mu), shape = native$shape, scale = native$scale)
      )
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "tweedie")) {
    sigma <- predict(object, dpar = "sigma")
    nu <- predict(object, dpar = "nu")
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        rtweedie_compound(length(mu), mu = mu, phi = sigma^2, power = nu)
      })
    } else {
      mu <- predict(object, dpar = "mu")
      sims <- replicate(
        nsim,
        rtweedie_compound(length(mu), mu = mu, phi = sigma^2, power = nu)
      )
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "beta")) {
    sigma <- predict(object, dpar = "sigma")
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        native <- drm_beta_shapes(mu, sigma)
        stats::rbeta(
          length(mu),
          shape1 = native$shape1,
          shape2 = native$shape2
        )
      })
    } else {
      mu <- predict(object, dpar = "mu")
      native <- drm_beta_shapes(mu, sigma)
      sims <- replicate(
        nsim,
        stats::rbeta(
          length(mu),
          shape1 = native$shape1,
          shape2 = native$shape2
        )
      )
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "zero_one_beta")) {
    sigma <- predict(object, dpar = "sigma")
    zoi <- predict(object, dpar = "zoi")
    coi <- predict(object, dpar = "coi")
    # SAME conversion drm_family_dpq_zero_one_beta() (R/family-dpq.R) uses --
    # closed in DO-T3 batch C (Emmy's dedup; batch A/B left this inline).
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        native <- drm_beta_shapes(mu, sigma)
        boundary <- stats::runif(length(mu)) < zoi
        one <- stats::runif(length(mu)) < coi
        interior <- stats::rbeta(
          length(mu),
          shape1 = native$shape1,
          shape2 = native$shape2
        )
        ifelse(boundary, as.numeric(one), interior)
      })
    } else {
      mu <- predict(object, dpar = "mu")
      native <- drm_beta_shapes(mu, sigma)
      sims <- replicate(nsim, {
        boundary <- stats::runif(length(mu)) < zoi
        one <- stats::runif(length(mu)) < coi
        interior <- stats::rbeta(
          length(mu),
          shape1 = native$shape1,
          shape2 = native$shape2
        )
        ifelse(boundary, as.numeric(one), interior)
      })
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "beta_binomial")) {
    # SAME conversion drm_family_dpq_beta_binomial() (R/family-dpq.R) uses --
    # closed in DO-T3 batch B (Emmy's dedup; batch A left this inline).
    trials <- object$model$trials
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        sigma <- drm_marginal_predict(object, "sigma", re_draws)
        native <- drm_beta_shapes(mu, sigma)
        p <- stats::rbeta(
          length(mu),
          shape1 = native$shape1,
          shape2 = native$shape2
        )
        stats::rbinom(length(mu), size = trials, prob = p)
      })
    } else {
      mu <- predict(object, dpar = "mu")
      sigma <- predict(object, dpar = "sigma")
      native <- drm_beta_shapes(mu, sigma)
      sims <- replicate(nsim, {
        p <- stats::rbeta(
          length(mu),
          shape1 = native$shape1,
          shape2 = native$shape2
        )
        stats::rbinom(length(mu), size = trials, prob = p)
      })
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "binomial")) {
    trials <- object$model$trials
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        stats::rbinom(length(mu), size = trials, prob = mu)
      })
    } else {
      mu <- predict(object, dpar = "mu")
      sims <- replicate(nsim, stats::rbinom(length(mu), size = trials, prob = mu))
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "cumulative_logit")) {
    levels <- object$ordinal$levels
    draw_categories <- function(prob) {
      draw <- vapply(
        seq_len(nrow(prob)),
        function(i) {
          sample.int(ncol(prob), size = 1L, prob = prob[i, ])
        },
        integer(1)
      )
      ordered(levels[draw], levels = levels)
    }
    if (marginal) {
      sims <- lapply(seq_len(nsim), function(j) {
        re_draws <- drm_ordinary_random_effect_draws(object)
        eta <- drm_marginal_predict(object, "mu", re_draws, type = "link")
        draw_categories(ordinal_category_probabilities(object, eta = eta))
      })
    } else {
      prob <- ordinal_category_probabilities(object)
      sims <- lapply(seq_len(nsim), function(j) draw_categories(prob))
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "poisson")) {
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        stats::rpois(length(mu), lambda = mu)
      })
    } else {
      mu <- predict(object, dpar = "mu")
      sims <- replicate(nsim, stats::rpois(length(mu), lambda = mu))
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "zi_poisson")) {
    zi <- predict(object, dpar = "zi")
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        structural_zero <- stats::runif(length(mu)) < zi
        ifelse(structural_zero, 0L, stats::rpois(length(mu), lambda = mu))
      })
    } else {
      mu <- predict(object, dpar = "mu")
      sims <- replicate(nsim, {
        structural_zero <- stats::runif(length(mu)) < zi
        ifelse(structural_zero, 0L, stats::rpois(length(mu), lambda = mu))
      })
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "nbinom2")) {
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        sigma <- drm_marginal_predict(object, "sigma", re_draws)
        stats::rnbinom(length(mu), size = drm_nbinom2_size(sigma), mu = mu)
      })
    } else {
      mu <- predict(object, dpar = "mu")
      sigma <- predict(object, dpar = "sigma")
      sims <- replicate(
        nsim,
        stats::rnbinom(length(mu), size = drm_nbinom2_size(sigma), mu = mu)
      )
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "truncated_nbinom2")) {
    # SAME conversion drm_nbinom2_size() (R/family-dpq.R) uses -- closed in
    # DO-T3 batch C (Emmy's dedup; batch A left this inline).
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        sigma <- drm_marginal_predict(object, "sigma", re_draws)
        size <- drm_nbinom2_size(sigma)
        p0 <- truncated_nbinom2_p0(mu, sigma)
        u <- p0 + pmax(stats::runif(length(mu)), .Machine$double.eps) * (1 - p0)
        stats::qnbinom(u, size = size, mu = mu)
      })
    } else {
      mu <- predict(object, dpar = "mu")
      sigma <- predict(object, dpar = "sigma")
      size <- drm_nbinom2_size(sigma)
      p0 <- truncated_nbinom2_p0(mu, sigma)
      sims <- replicate(nsim, {
        u <- p0 + pmax(stats::runif(length(mu)), .Machine$double.eps) * (1 - p0)
        stats::qnbinom(u, size = size, mu = mu)
      })
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "hurdle_nbinom2")) {
    hu <- predict(object, dpar = "hu")
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        sigma <- drm_marginal_predict(object, "sigma", re_draws)
        size <- drm_nbinom2_size(sigma)
        p0 <- truncated_nbinom2_p0(mu, sigma)
        hurdle_zero <- stats::runif(length(mu)) < hu
        u <- p0 + pmax(stats::runif(length(mu)), .Machine$double.eps) * (1 - p0)
        ifelse(
          hurdle_zero,
          0L,
          stats::qnbinom(u, size = size, mu = mu)
        )
      })
    } else {
      mu <- predict(object, dpar = "mu")
      sigma <- predict(object, dpar = "sigma")
      size <- drm_nbinom2_size(sigma)
      p0 <- truncated_nbinom2_p0(mu, sigma)
      sims <- replicate(nsim, {
        hurdle_zero <- stats::runif(length(mu)) < hu
        u <- p0 + pmax(stats::runif(length(mu)), .Machine$double.eps) * (1 - p0)
        ifelse(
          hurdle_zero,
          0L,
          stats::qnbinom(u, size = size, mu = mu)
        )
      })
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "zi_nbinom2")) {
    zi <- predict(object, dpar = "zi")
    if (marginal) {
      sims <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu <- drm_marginal_predict(object, "mu", re_draws)
        sigma <- drm_marginal_predict(object, "sigma", re_draws)
        size <- drm_nbinom2_size(sigma)
        structural_zero <- stats::runif(length(mu)) < zi
        ifelse(
          structural_zero,
          0L,
          stats::rnbinom(length(mu), size = size, mu = mu)
        )
      })
    } else {
      mu <- predict(object, dpar = "mu")
      sigma <- predict(object, dpar = "sigma")
      size <- drm_nbinom2_size(sigma)
      sims <- replicate(nsim, {
        structural_zero <- stats::runif(length(mu)) < zi
        ifelse(
          structural_zero,
          0L,
          stats::rnbinom(length(mu), size = size, mu = mu)
        )
      })
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  if (identical(object$model$model_type, "gaussian")) {
    if (marginal) {
      if (identical(object$model$V_known_type, "matrix")) {
        sims <- replicate(nsim, {
          re_draws <- drm_ordinary_random_effect_draws(object)
          mu <- drm_marginal_predict(object, "mu", re_draws)
          sigma <- drm_marginal_predict(object, "sigma", re_draws)
          Sigma <- observation_covariance(object, sigma = sigma)
          chol_Sigma <- chol(Sigma)
          as.vector(mu + t(chol_Sigma) %*% stats::rnorm(length(mu)))
        })
      } else {
        sims <- replicate(nsim, {
          re_draws <- drm_ordinary_random_effect_draws(object)
          mu <- drm_marginal_predict(object, "mu", re_draws)
          sigma <- drm_marginal_predict(object, "sigma", re_draws)
          stats::rnorm(
            length(mu),
            mean = mu,
            sd = observation_sigma(object, sigma = sigma)
          )
        })
      }
    } else {
      mu <- predict(object, dpar = "mu")
      if (identical(object$model$V_known_type, "matrix")) {
        Sigma <- observation_covariance(object)
        chol_Sigma <- chol(Sigma)
        sims <- replicate(
          nsim,
          as.vector(mu + t(chol_Sigma) %*% stats::rnorm(length(mu)))
        )
      } else {
        sigma <- observation_sigma(object)
        sims <- replicate(nsim, stats::rnorm(length(mu), mean = mu, sd = sigma))
      }
    }
    sims <- as.data.frame(sims)
    names(sims) <- paste0("sim_", seq_len(nsim))
    sims[] <- lapply(sims, function(col) drm_mask_missing_response_values(object, col))
    return(sims)
  }

  rho12 <- predict(object, dpar = "rho12")
  if (identical(object$model$V_known_type, "matrix")) {
    if (marginal) {
      sims_stack <- replicate(nsim, {
        re_draws <- drm_ordinary_random_effect_draws(object)
        mu1 <- drm_marginal_predict(object, "mu1", re_draws)
        mu2 <- drm_marginal_predict(object, "mu2", re_draws)
        sigma1 <- drm_marginal_predict(object, "sigma1", re_draws)
        sigma2 <- drm_marginal_predict(object, "sigma2", re_draws)
        mu_stack <- stack_biv_response(mu1, mu2)
        Sigma <- bivariate_observation_covariance(
          object,
          sigma1 = sigma1,
          sigma2 = sigma2
        )
        chol_Sigma <- chol(Sigma)
        as.vector(mu_stack + t(chol_Sigma) %*% stats::rnorm(length(mu_stack)))
      })
    } else {
      mu1 <- predict(object, dpar = "mu1")
      mu2 <- predict(object, dpar = "mu2")
      mu_stack <- stack_biv_response(mu1, mu2)
      Sigma <- bivariate_observation_covariance(object)
      chol_Sigma <- chol(Sigma)
      sims_stack <- replicate(
        nsim,
        as.vector(mu_stack + t(chol_Sigma) %*% stats::rnorm(length(mu_stack)))
      )
    }
    out <- vector("list", nsim * 2L)
    names(out) <- as.vector(rbind(
      paste0("sim_", seq_len(nsim), "_y1"),
      paste0("sim_", seq_len(nsim), "_y2")
    ))
    for (j in seq_len(nsim)) {
      sim_j <- unstack_biv_response(sims_stack[, j])
      out[[paste0("sim_", j, "_y1")]] <- sim_j[, "y1"]
      out[[paste0("sim_", j, "_y2")]] <- sim_j[, "y2"]
    }
    return(as.data.frame(out))
  }
  out <- vector("list", nsim * 2L)
  names(out) <- as.vector(rbind(
    paste0("sim_", seq_len(nsim), "_y1"),
    paste0("sim_", seq_len(nsim), "_y2")
  ))
  if (!marginal) {
    mu1 <- predict(object, dpar = "mu1")
    mu2 <- predict(object, dpar = "mu2")
    sigma1 <- predict(object, dpar = "sigma1")
    sigma2 <- predict(object, dpar = "sigma2")
  }
  for (j in seq_len(nsim)) {
    if (marginal) {
      re_draws <- drm_ordinary_random_effect_draws(object)
      mu1 <- drm_marginal_predict(object, "mu1", re_draws)
      mu2 <- drm_marginal_predict(object, "mu2", re_draws)
      sigma1 <- drm_marginal_predict(object, "sigma1", re_draws)
      sigma2 <- drm_marginal_predict(object, "sigma2", re_draws)
    }
    z1 <- stats::rnorm(length(mu1))
    z2_ind <- stats::rnorm(length(mu1))
    z2 <- rho12 * z1 + sqrt(1 - rho12^2) * z2_ind
    log_y1 <- mu1 + sigma1 * z1
    log_y2 <- mu2 + sigma2 * z2
    if (identical(object$model$model_type, "biv_lognormal")) {
      out[[paste0("sim_", j, "_y1")]] <- exp(log_y1)
      out[[paste0("sim_", j, "_y2")]] <- exp(log_y2)
    } else {
      out[[paste0("sim_", j, "_y1")]] <- log_y1
      out[[paste0("sim_", j, "_y2")]] <- log_y2
    }
  }
  as.data.frame(out)
}

rskew_normal_public <- function(n, mu, sigma, nu) {
  mu <- rep(mu, length.out = n)
  sigma <- rep(sigma, length.out = n)
  nu <- rep(nu, length.out = n)
  # (xi, omega, alpha, delta) moment inversion: SAME helper
  # drm_skew_normal_native() (R/family-dpq.R) uses for the {d,p,q} closures,
  # so the two routes cannot silently drift apart (Emmy's dedup, DO-T3
  # batch B).
  native <- drm_skew_normal_moments(mu, sigma, nu)
  native$xi +
    native$omega * (
      native$delta * abs(stats::rnorm(n)) +
        sqrt(1 - native$delta^2) * stats::rnorm(n)
    )
}

rtweedie_compound <- function(n, mu, phi, power) {
  mu <- rep(mu, length.out = n)
  phi <- rep(phi, length.out = n)
  power <- rep(power, length.out = n)
  lambda <- mu^(2 - power) / (phi * (2 - power))
  shape_multiplier <- (2 - power) / (power - 1)
  scale <- phi * (power - 1) * mu^(power - 1)
  count <- stats::rpois(n, lambda = lambda)
  out <- numeric(n)
  positive <- count > 0L
  out[positive] <- stats::rgamma(
    sum(positive),
    shape = shape_multiplier[positive] * count[positive],
    scale = scale[positive]
  )
  out
}

#' Extract model residuals
#'
#' `residuals()` returns response residuals or Pearson-style residuals from a
#' `drmTMB` fit.
#'
#' For univariate Gaussian models, response residuals are `y - mu`. Pearson
#' residuals divide by the fitted observation standard deviation. Student-t
#' Pearson residuals use the fitted Student-t scale; this is not the marginal
#' residual standard deviation when `nu > 2`. Skew-normal Pearson residuals use
#' the public response-standard-deviation parameter. If a dense known sampling
#' covariance was used, Pearson residuals are whitened by the fitted total
#' observation covariance.
#'
#' For lognormal models, response residuals are `y - fitted_mean`. Pearson
#' residuals are computed on the log-response scale as `(log(y) - mu) / sigma`.
#' For Gamma models, response residuals are `y - mu` and Pearson residuals
#' divide by the fitted Gamma standard deviation `mu * sigma`, where `sigma` is
#' the coefficient of variation. For Tweedie models, response residuals are
#' `y - mu` and Pearson residuals divide by
#' `sqrt(sigma^2 * mu^nu)`. For beta models, response residuals are `y - mu`
#' and Pearson residuals divide by
#' `sqrt(mu * (1 - mu) * sigma^2 / (1 + sigma^2))`. For zero-one beta models,
#' response residuals are observed proportions minus the unconditional fitted
#' mean, including exact zero-one boundary mass. For beta-binomial models,
#' response residuals are
#' observed success proportions minus fitted `mu`, and Pearson residuals
#' divide by the fitted beta-binomial proportion standard deviation. For
#' binomial models, response residuals are observed success proportions minus
#' fitted event probability, and Pearson residuals divide by
#' `sqrt(mu * (1 - mu) / trials)`. For
#' cumulative-logit ordinal models, response residuals are the observed
#' ordered-category score minus the fitted expected score, and Pearson
#' residuals divide by the fitted category-score standard deviation. For
#' Poisson models, response residuals are `y - mu` and Pearson residuals divide
#' by `sqrt(mu)`. For zero-inflated
#' Poisson models, response residuals are `y - (1 - zi) * mu`, and Pearson
#' residuals divide by `sqrt((1 - zi) * mu * (1 + zi * mu))`. For
#' negative-binomial 2 models, Pearson residuals divide by
#' `sqrt(mu + sigma^2 * mu^2)`. For zero-truncated NB2 models, response
#' residuals are `y - mu / (1 - Pr_NB2(0))`, and Pearson residuals divide by
#' the conditional positive-count standard deviation. For hurdle NB2 models,
#' response residuals are `y - (1 - hu) * mu / (1 - Pr_NB2(0))`, and Pearson
#' residuals divide by the unconditional standard deviation implied by the
#' hurdle-zero mixture. For zero-inflated NB2 models, response residuals are
#' `y - (1 - zi) * mu`, and Pearson residuals divide by the unconditional
#' standard deviation implied by the structural-zero mixture.
#'
#' For bivariate Gaussian models, response residuals are returned as a
#' two-column matrix. Pearson residuals are standardized and whitened using the
#' fitted residual `sigma1`, `sigma2`, and `rho12`, or using the full row-paired
#' observation covariance when a dense bivariate known `V` was supplied.
#'
#' `type = "quantile"` returns Dunn-Smyth randomized quantile residuals from
#' [drm_quantile_residuals()]: `qnorm(F(y; theta_hat))` at the fitted,
#' fixed-effect distributional parameters. As of DO-T3 batch D, all 18 fitted
#' `model_type` values have a promoted entry in [drm_family_dpq()], so
#' `type = "quantile"` is available for every family, including bivariate
#' `biv_gaussian` (where `response` -- `1` or `2` -- is REQUIRED and selects
#' which response's MARGINAL residuals to compute; omitting it errors
#' clearly, as does supplying it for a univariate fit; see
#' [fitted_distribution()]). Spike-status families (feasibility-only, not yet
#' DG2/DG3-verified) emit a one-time warning that the residual is
#' exploratory, not DG-verified; none currently have this status. See
#' [drm_quantile_residuals()] for the fixed-effect-only adequacy caveat: for
#' random-effect or structured fits, these residuals are conditional on the
#' fixed-effect prediction, not marginal, so a departure (or its absence) is
#' evidence about fixed-effect adequacy only -- never a general validity
#' claim. Pass `seed`, `nsim`, and/or `response` through `...` to
#' [drm_quantile_residuals()].
#'
#' **What this detects -- and does not.** Evidence: a 400-seed gated
#' simulation campaign across all 18 fitted families (tweedie: 99 of 400
#' seeds locally, 66/99 dispersion-arm non-convergence, full run deferred to
#' Totoro)
#' (`docs/dev-log/simulation-artifacts/2026-07-12-dg3-power-arm-gated/`).
#' Under a correctly specified fixed-effect model, type-I error stays at or
#' below the nominal rate (0.0025-0.025 at alpha = 0.05 across families); the
#' underlying KS+PIT statistic is conservative, so power is understated, not
#' overstated. `type = "quantile"` **detects** distributional shape and atom
#' mis-specification that a family cannot reabsorb through its own free
#' parameters -- heavy tails fit as Gaussian, overdispersion or
#' zero-inflation ignored by a family with no free dispersion parameter,
#' truncation ignored, a missing zero/one atom -- with gated power >= 0.8 at
#' n = 300-400 per arm (commonly 0.9-1.0). It has a genuine **structural
#' blind spot**, not a bug: a mis-specification that a fitted family's own
#' free nuisance/dispersion/inflation parameter absorbs leaves the
#' fitted-model residual marginally N(0,1) and is **not detectable** here --
#' for example heteroscedasticity absorbed by Student-t `nu` (power 0.035 at
#' n = 300, versus 1.0 for the same heteroscedasticity under Gaussian, which
#' has no absorbing parameter), missing zero-inflation absorbed by `nbinom2`
#' `sigma` (power 0.035, versus 0.9625 under Poisson), and zero-inflation/
#' hurdle/zero-one-inflation *mechanism* mis-specification (a constant
#' inflation probability fit when it truly varies with a covariate), which
#' splits into two patterns under the n-ladder (tested to n = 3000): for
#' `hurdle_nbinom2`/`zero_one_beta`, power stays flat at or below about 0.01
#' at every n -- a genuine structural blind spot; for
#' `zi_nbinom2`/`zi_poisson`, power rises with n (to about 0.11/0.06 at
#' n = 3000), so the marginal is not identical under the mechanism mis-spec,
#' but power stays far below the >= 0.8 detectable benchmark even at
#' n = 3000, so it remains impractical to detect at realistic sample sizes.
#' A mean-structure diagnostic, not this one, is what catches
#' an absorbed mis-specification. Separately, `gamma`-vs-`lognormal`
#' wrong-family detection is sample-size limited rather than structurally
#' blind: power rises from about 0.19 at n = 300 to 0.79 at n = 1000 and 1.0
#' at n = 3000, so that specific mis-specification needs n well above 1000 to
#' be reliably caught. A distributional-output/adequacy tick on a family
#' never changes or implies anything about that family's own inference-tier
#' status; see `tests/testthat/test-dg-firewall.R`.
#'
#' @param object A `drmTMB` fit.
#' @param type Residual type: `"response"`, `"pearson"`, or `"quantile"`.
#' @param ... Reserved for future residual options; for `type = "quantile"`,
#'   forwarded to [drm_quantile_residuals()] (`seed`, `nsim`, `response`).
#'
#' @return A numeric vector for univariate models, or a two-column matrix for
#'   bivariate Gaussian models. For `type = "quantile"` with `nsim > 1`, an
#'   `n`-by-`nsim` matrix (see [drm_quantile_residuals()]).
#'
#' @examples
#' dat <- data.frame(y = c(0.2, 0.5, 1.1, 1.4), x = c(-1, 0, 1, 2))
#' fit <- drmTMB(bf(y ~ x, sigma ~ 1), data = dat)
#' residuals(fit)
#' residuals(fit, type = "pearson")
#' residuals(fit, type = "quantile")
#' if (requireNamespace("DHARMa", quietly = TRUE)) {
#'   sims <- simulate(fit, nsim = 20)
#'   dh <- DHARMa::createDHARMa(
#'     simulatedResponse = as.matrix(sims),
#'     observedResponse = fit$model$y,
#'     fittedPredictedResponse = fitted(fit),
#'     integerResponse = FALSE
#'   )
#'   DHARMa::testUniformity(dh)
#' }
#' @export
residuals.drmTMB <- function(
  object,
  type = c("response", "pearson", "quantile"),
  ...
) {
  type <- match.arg(type)
  if (
    object$model$model_type %in% c("biv_lognormal", "biv_student")
  ) {
    cli::cli_abort(
      "{.fn residuals} is not implemented for model type {.val {object$model$model_type}}; residual and adequacy claims are deferred."
    )
  }
  if (identical(type, "quantile")) {
    return(drm_quantile_residuals(object, ...))
  }
  if (identical(object$model$model_type, "lognormal")) {
    if (type == "response") {
      return(drm_mask_missing_response_values(
        object,
        object$model$y - stats::fitted(object)
      ))
    }
    return(drm_mask_missing_response_values(
      object,
      (log(object$model$y) - predict(object, dpar = "mu")) /
        predict(object, dpar = "sigma")
    ))
  }
  if (identical(object$model$model_type, "gamma")) {
    response <- object$model$y - predict(object, dpar = "mu")
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    return(drm_mask_missing_response_values(
      object,
      response /
        (predict(object, dpar = "mu") * predict(object, dpar = "sigma"))
    ))
  }
  if (identical(object$model$model_type, "tweedie")) {
    mu <- predict(object, dpar = "mu")
    sigma <- predict(object, dpar = "sigma")
    nu <- predict(object, dpar = "nu")
    response <- object$model$y - mu
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    return(drm_mask_missing_response_values(
      object,
      response / sqrt(sigma^2 * mu^nu)
    ))
  }
  if (identical(object$model$model_type, "beta")) {
    mu <- predict(object, dpar = "mu")
    sigma <- predict(object, dpar = "sigma")
    response <- object$model$y - mu
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    return(drm_mask_missing_response_values(
      object,
      response / sqrt(mu * (1 - mu) * sigma^2 / (1 + sigma^2))
    ))
  }
  if (identical(object$model$model_type, "zero_one_beta")) {
    mu <- predict(object, dpar = "mu")
    sigma <- predict(object, dpar = "sigma")
    zoi <- predict(object, dpar = "zoi")
    coi <- predict(object, dpar = "coi")
    fitted_mean <- zero_one_beta_mean(mu, zoi, coi)
    response <- object$model$y - fitted_mean
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    return(drm_mask_missing_response_values(
      object,
      response / sqrt(zero_one_beta_variance(mu, sigma, zoi, coi))
    ))
  }
  if (identical(object$model$model_type, "beta_binomial")) {
    mu <- predict(object, dpar = "mu")
    sigma <- predict(object, dpar = "sigma")
    trials <- object$model$trials
    observed <- object$model$y / trials
    response <- observed - mu
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    return(drm_mask_missing_response_values(
      object,
      response / sqrt(beta_binomial_proportion_variance(mu, sigma, trials))
    ))
  }
  if (identical(object$model$model_type, "binomial")) {
    mu <- predict(object, dpar = "mu")
    trials <- object$model$trials
    observed <- object$model$y / trials
    response <- observed - mu
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    return(drm_mask_missing_response_values(
      object,
      response / sqrt(pmax(mu * (1 - mu) / trials, .Machine$double.eps))
    ))
  }
  if (identical(object$model$model_type, "cumulative_logit")) {
    expected <- ordinal_expected_score(object)
    response <- object$model$y - expected
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    return(drm_mask_missing_response_values(
      object,
      response / sqrt(pmax(ordinal_score_variance(object), .Machine$double.eps))
    ))
  }
  if (identical(object$model$model_type, "poisson")) {
    mu <- predict(object, dpar = "mu")
    response <- object$model$y - mu
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    return(drm_mask_missing_response_values(object, response / sqrt(mu)))
  }
  if (identical(object$model$model_type, "zi_poisson")) {
    mu <- predict(object, dpar = "mu")
    zi <- predict(object, dpar = "zi")
    fitted_mean <- (1 - zi) * mu
    response <- object$model$y - fitted_mean
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    return(drm_mask_missing_response_values(
      object,
      response / sqrt((1 - zi) * mu * (1 + zi * mu))
    ))
  }
  if (identical(object$model$model_type, "nbinom2")) {
    mu <- predict(object, dpar = "mu")
    sigma <- predict(object, dpar = "sigma")
    response <- object$model$y - mu
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    return(drm_mask_missing_response_values(
      object,
      response / sqrt(mu + sigma^2 * mu^2)
    ))
  }
  if (identical(object$model$model_type, "truncated_nbinom2")) {
    mu <- predict(object, dpar = "mu")
    sigma <- predict(object, dpar = "sigma")
    fitted_mean <- truncated_nbinom2_mean(mu, sigma)
    response <- object$model$y - fitted_mean
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    return(drm_mask_missing_response_values(
      object,
      response / sqrt(truncated_nbinom2_variance(mu, sigma))
    ))
  }
  if (identical(object$model$model_type, "hurdle_nbinom2")) {
    mu <- predict(object, dpar = "mu")
    sigma <- predict(object, dpar = "sigma")
    hu <- predict(object, dpar = "hu")
    fitted_mean <- hurdle_nbinom2_mean(mu, sigma, hu)
    response <- object$model$y - fitted_mean
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    return(drm_mask_missing_response_values(
      object,
      response / sqrt(hurdle_nbinom2_variance(mu, sigma, hu))
    ))
  }
  if (identical(object$model$model_type, "zi_nbinom2")) {
    mu <- predict(object, dpar = "mu")
    sigma <- predict(object, dpar = "sigma")
    zi <- predict(object, dpar = "zi")
    fitted_mean <- (1 - zi) * mu
    response <- object$model$y - fitted_mean
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    component_var <- mu + sigma^2 * mu^2
    unconditional_var <- (1 - zi) * component_var + zi * (1 - zi) * mu^2
    return(drm_mask_missing_response_values(
      object,
      response / sqrt(unconditional_var)
    ))
  }
  if (
    identical(object$model$model_type, "gaussian") ||
      identical(object$model$model_type, "student") ||
      identical(object$model$model_type, "skew_normal")
  ) {
    response <- object$model$y - predict(object, dpar = "mu")
    if (type == "response") {
      return(drm_mask_missing_response_values(object, response))
    }
    if (identical(object$model$V_known_type, "matrix")) {
      return(drm_mask_missing_response_values(
        object,
        as.vector(forwardsolve(
          t(chol(observation_covariance(object))),
          response
        ))
      ))
    }
    return(drm_mask_missing_response_values(
      object,
      response / observation_sigma(object)
    ))
  }

  response <- cbind(
    y1 = object$model$y1 - predict(object, dpar = "mu1"),
    y2 = object$model$y2 - predict(object, dpar = "mu2")
  )
  response <- drm_mask_biv_missing_response_values(object, response)
  if (type == "response") {
    return(response)
  }
  if (identical(object$model$V_known_type, "matrix")) {
    response_stack <- stack_biv_response(response[, "y1"], response[, "y2"])
    white <- as.vector(forwardsolve(
      t(chol(bivariate_observation_covariance(object))),
      response_stack
    ))
    return(unstack_biv_response(white))
  }
  sigma1 <- predict(object, dpar = "sigma1")
  sigma2 <- predict(object, dpar = "sigma2")
  rho12 <- predict(object, dpar = "rho12")
  e1 <- response[, "y1"] / sigma1
  e2_raw <- response[, "y2"] / sigma2
  e2 <- (e2_raw - rho12 * e1) / sqrt(1 - rho12^2)
  out <- cbind(y1 = e1, y2 = e2)
  missing_data <- object$missing_data
  if (
    is.list(missing_data) &&
      identical(missing_data$response_policy, "include") &&
      !is.null(missing_data$observed_y1) &&
      !is.null(missing_data$observed_y2) &&
      length(missing_data$observed_y1) == nrow(out) &&
      length(missing_data$observed_y2) == nrow(out)
  ) {
    observed_y1 <- as.logical(missing_data$observed_y1)
    observed_y2 <- as.logical(missing_data$observed_y2)
    y2_only <- !observed_y1 & observed_y2
    out[y2_only, "y2"] <- e2_raw[y2_only]
    out[!observed_y1, "y1"] <- NA_real_
    out[!observed_y2, "y2"] <- NA_real_
  }
  out
}

#' Extract fitted scale or dispersion
#'
#' `sigma()` returns the fitted scale-like parameter from a `drmTMB` model. For
#' univariate Gaussian location-scale models this is the fitted residual
#' `sigma_i` vector on the response scale. For Student-t models this is the
#' Student-t scale parameter; when `nu > 2`, the residual standard deviation is
#' `sigma * sqrt(nu / (nu - 2))`. For skew-normal models this is the response
#' standard deviation under the public moment parameterization, not the native
#' Azzalini scale `omega`. For lognormal models this is the fitted
#' standard deviation of `log(y)`. For Gamma models this is the fitted
#' coefficient of variation. For Tweedie models this is the public scale
#' parameter where internal dispersion is `phi = sigma^2`. For beta,
#' zero-one beta, and beta-binomial models this is the public scale parameter
#' where internal precision is `phi = 1 / sigma^2`.
#' Cumulative-logit ordinal, binomial, Poisson, and zero-inflated Poisson models have no
#' fitted residual scale parameter and return a fixed unit dispersion vector
#' for consistency with base-R `sigma()` conventions. For
#' negative-binomial 2, zero-truncated negative-binomial 2, hurdle
#' negative-binomial 2, and zero-inflated negative-binomial 2 models this is
#' the fitted overdispersion scale in the untruncated NB2 component
#' `Var(y | component) = mu + sigma^2 * mu^2`. For bivariate Gaussian,
#' bivariate lognormal, and bivariate Student-t models it returns a roundable
#' list with fitted `sigma1` and `sigma2` vectors. The bivariate-lognormal
#' values are log-response SDs; the bivariate-Student values are Student-t
#' scales, not marginal SDs.
#'
#' In meta-analytic models fitted with `meta_V(V = V)`, this is the
#' modelled residual heterogeneity scale, not the square root of the known
#' sampling variance plus residual variance. Simulation and Pearson residuals
#' combine known sampling covariance with residual scale internally.
#'
#' For families in `drm_clamped_scale_families()`, `sigma()` reports the
#' soft-clamped scale the TMB likelihood actually evaluated (see
#' [predict.drmTMB()]), the same scale that [residuals.drmTMB()], `fitted()`,
#' and `simulate()` use. When `check_drm()` reports the clamp active, this
#' makes the fit honest about what it evaluated, not correct: the estimate
#' itself is still unreliable near the clamp.
#'
#' `sigma()` follows `drmTMB`'s distributional-regression contract, not the
#' scalar summary contract some generic tools expect from [stats::sigma()].
#' When the scale formula contains fitted-row variation, such as `sigma ~ x`,
#' `sigma()` returns one scale value per observation. Generic helpers that
#' assume a scalar residual scale, including `insight::get_sigma()`, may
#' summarize that vector and hide the fitted heterogeneity; inspect
#' `range(sigma(fit))` or [predict.drmTMB()] with `dpar = "sigma"` when the
#' scale model is part of the scientific question.
#'
#' @param object A `drmTMB` fit.
#' @param ... Reserved for future scale-extractor options.
#'
#' @return A numeric vector for univariate models, or a named, roundable list
#'   of numeric vectors for bivariate Gaussian, bivariate lognormal, or
#'   bivariate Student-t models.
#'
#' @examples
#' dat <- data.frame(y = c(0.2, 0.5, 1.1, 1.4), x = c(-1, 0, 1, 2))
#' fit <- drmTMB(bf(y ~ x, sigma ~ x), data = dat)
#' sigma(fit)
#' @export
sigma.drmTMB <- function(object, ...) {
  if (
    identical(object$model$model_type, "gaussian") ||
      identical(object$model$model_type, "student") ||
      identical(object$model$model_type, "skew_normal") ||
      identical(object$model$model_type, "lognormal") ||
      identical(object$model$model_type, "gamma") ||
      identical(object$model$model_type, "tweedie") ||
      identical(object$model$model_type, "beta") ||
      identical(object$model$model_type, "zero_one_beta") ||
      identical(object$model$model_type, "beta_binomial") ||
      identical(object$model$model_type, "nbinom2") ||
      identical(object$model$model_type, "truncated_nbinom2") ||
      identical(object$model$model_type, "hurdle_nbinom2") ||
      identical(object$model$model_type, "zi_nbinom2")
  ) {
    return(predict(object, dpar = "sigma"))
  }
  if (
    identical(object$model$model_type, "poisson") ||
      identical(object$model$model_type, "zi_poisson") ||
      identical(object$model$model_type, "binomial") ||
      identical(object$model$model_type, "cumulative_logit")
  ) {
    return(rep(1, length(object$model$y)))
  }
  if (
    object$model$model_type %in%
      c("biv_gaussian", "biv_lognormal", "biv_student")
  ) {
    return(new_biv_sigma(
      sigma1 = predict(object, dpar = "sigma1"),
      sigma2 = predict(object, dpar = "sigma2")
    ))
  }
  cli::cli_abort(
    "Internal error: no {.fn sigma} rule for model type {.val {object$model$model_type}}."
  )
}

new_biv_sigma <- function(sigma1, sigma2) {
  structure(
    list(sigma1 = sigma1, sigma2 = sigma2),
    class = c("drmTMB_biv_sigma", "list")
  )
}

#' @export
round.drmTMB_biv_sigma <- function(x, digits = 0) {
  out <- lapply(unclass(x), round, digits = digits)
  structure(out, class = class(x))
}

#' Summarize a fitted model
#'
#' `summary()` returns a compact summary of fixed-effect estimates,
#' response-scale distributional, scale, shape, random-effect SD, correlation,
#' and fitted random-effect covariance quantities when they are present.
#' The covariance component reports currently fitted registry-backed rows and
#' fitted bivariate phylogenetic covariance rows, including q=2 mean-mean and
#' q=4 endpoint rows where present.
#' The derived component reports simple point-estimate variance ratios --
#' `total_variance_share` for a Gaussian random-intercept mu component and
#' `phylo_total_variance_share` for a phylogenetic mu component -- when the
#' ingredients are unambiguous. Both divide by the TOTAL variance (every mu
#' random-effect variance plus the residual variance), which is a different
#' denominator from the `icc()`/`repeatability()` accessors (focal component
#' variance over that component plus the residual only); see
#' `?heritability` and `docs/design/259-heritability-icc-repeatability.md`
#' for the distinction. Both rows are computed only for Gaussian fits with an
#' identity-link mean, where the latent, expected-data, and observed-data
#' scales of de Villemereuil, Schielzeth, Nakagawa & Morrissey (2016,
#' *Genetics* 204:1281-1294) coincide, so there is no separate latent- or
#' liability-scale value to distinguish. `residual_variance` is `sigma^2`
#' when `sigma`'s fixed part reduces to a single log-link intercept; when
#' `sigma` additionally carries an ordinary random intercept, or a
#' phylogenetic random intercept with a unit-diagonal correlation (the
#' default `phylo(...)` route), `residual_variance` is instead the *marginal*
#' residual variance `exp(2*b0 + 2*sum_k(omega_k^2))` -- `E[sigma^2]`, not the
#' squared median `exp(2*b0)` -- where `omega_k` are the working-scale
#' (log-SD) standard deviations of those effects. A random slope on `sigma`,
#' a structured `sigma` effect without a verified unit-diagonal correlation
#' (measured on the rows the design uses), or a fit that carries a `sigma`
#' random effect while the `log(sigma)` soft clamp bent the assembled
#' predictor for at least one observation (`clamp_limited`; a clamp-active
#' `sigma ~ 1` fit still returns its constant clamped scale), has no
#' closed-form marginal residual variance here and is
#' refused (a `residual_variance.message` attribute on the empty result names
#' the reason, and is also shown under the (empty) derived table when
#' printed); see
#' `docs/design/275-repeatability-scale-and-residual-variance.md`. Derived
#' confidence intervals are marked as unavailable until a nonlinear interval
#' method is implemented.
#' The derived table's `residual_sd` column is `sqrt(residual_variance)` --
#' i.e. `sqrt(E[sigma^2]) = exp(b0 + sum_k(omega_k^2))` -- and this is a
#' DIFFERENT quantity from the `sigma` row in the `parameters` component,
#' which is always the conditional/median scale `exp(b0)`. The two coincide
#' only when `sigma` carries no random effect; when it does, `residual_sd` is
#' larger (e.g. 1.0144 vs a `sigma` row of 0.7599 on one fixture), and both
#' are labelled `scale = "response"` because both genuinely are on the
#' response scale -- they are not alternative scales of the same quantity,
#' they are two different quantities.
#' When `TMB::sdreport()` succeeds, direct response-scale parameter rows also
#' include delta-method standard errors; descriptive fitted ranges and derived
#' variance ratios do not.
#' Confidence intervals are opt-in: fast Wald intervals are available for fixed
#' effects and direct response-scale parameter rows, and slower
#' profile-likelihood intervals are available for selected direct profile
#' targets. Profile summaries keep Wald intervals for fixed effects unless
#' fixed-effect profile targets are selected. Interval-aware tables include
#' `conf.status` so rows without intervals can say whether an interval was not
#' requested, needs `newdata`, is ready but unselected, or is currently
#' unavailable. Use `summary(fit, conf.int = TRUE)` for fixed-effect and direct
#' parameter Wald confidence intervals, and use `method = "profile"` with
#' `ci_parm` for direct response-scale targets such as `sigma`, `rho12`, or a
#' random-effect SD. Correlation Wald intervals use the fitted TMB
#' correlation-link scale, equivalent to a guarded Fisher z/atanh transform,
#' before returning lower and upper bounds on the correlation scale.
#'
#' @param object A `drmTMB` fit.
#' @param conf.int Logical; include confidence intervals when `TRUE`.
#' @param level Confidence level for intervals.
#' @param method Interval method used when `conf.int = TRUE`: `"wald"` for
#'   fast direct intervals or `"profile"` for profile-likelihood intervals on
#'   selected direct targets. `summary()` does not run bootstrap intervals yet;
#'   use `confint(..., method = "bootstrap")` for the current direct-target
#'   bootstrap route.
#' @param ci_parm Optional character or integer vector selecting confidence
#'   interval targets. For `method = "wald"` and `method = "profile"`, targets
#'   use the [profile_targets()] namespace, such as `"sigma"`, `"rho12"`,
#'   `"sd:mu:(1 | id)"`, or `"cor:mu:cor((Intercept),x | id)"`. `NULL` selects
#'   all direct Wald-ready targets for Wald intervals and currently ready direct
#'   non-fixed targets for profile intervals. This keeps large profile runs
#'   focused on scale, variance-component, and correlation rows unless
#'   fixed-effect profile targets are requested explicitly.
#' @param trace Logical; passed to [TMB::tmbprofile()] for profile intervals.
#' @param profile_precision Profile-control shortcut used with
#'   `method = "profile"`. `"default"` leaves [TMB::tmbprofile()] controls
#'   unchanged, while `"fast"` supplies `ystep = 0.5` and `ytol = 2` unless the
#'   caller supplies those controls in `...`.
#' @param ... Additional arguments passed to [TMB::tmbprofile()] when
#'   `conf.int = TRUE` and `method = "profile"`.
#'
#' @return An object of class `summary.drmTMB`.
#'
#' @seealso The tier definitions and per-cell evidence behind these interval
#'   targets, including random-effect standard-deviation rows, are curated in
#'   \code{vignette("capability-and-limits", package = "drmTMB")}: `summary()`
#'   computes intervals generically for any target, and the tier a given cell
#'   belongs to is a documentation-level curation, not a runtime guard.
#'   The optional \pkg{emmeans} package can compute estimated marginal means
#'   from supported fixed-effect `drmTMB` fits using the package registration
#'   installed at load time.
#'
#' @examples
#' dat <- data.frame(y = c(0.2, 0.5, 1.1, 1.4), x = c(-1, 0, 1, 2))
#' fit <- drmTMB(bf(y ~ x, sigma ~ 1), data = dat)
#' summary(fit)
#' summary(fit, conf.int = TRUE)
#' summary(
#'   fit,
#'   conf.int = TRUE,
#'   method = "profile",
#'   ci_parm = "sigma",
#'   profile_precision = "fast"
#' )
#' if (requireNamespace("emmeans", quietly = TRUE)) {
#'   emmeans::emmeans(fit, specs = "x", at = list(x = c(-1, 0, 1)))
#' }
#' @export
summary.drmTMB <- function(
  object,
  conf.int = FALSE,
  level = 0.95,
  method = c("wald", "profile"),
  ci_parm = NULL,
  trace = FALSE,
  profile_precision = c("default", "fast"),
  ...
) {
  profile_precision_missing <- missing(profile_precision)
  validate_summary_conf_int(conf.int)
  if (isTRUE(conf.int)) {
    drm_abort_mspl_inference(object, "summary(conf.int = TRUE)")
  }
  if (
    conf.int &&
      identical(object$model$model_type, "biv_student")
  ) {
    cli::cli_abort(
      "{.fn summary} confidence intervals are not implemented for model type {.val {object$model$model_type}}; interval and profile claims are deferred."
    )
  }
  validate_summary_trace(trace)
  validate_profile_level(level)
  method <- validate_interval_method(method, c("wald", "profile"), "summary()")
  profile_precision <- resolve_profile_precision(
    profile_precision,
    missing_arg = profile_precision_missing
  )

  dots <- list(...)
  if (!conf.int && length(dots) > 0L) {
    cli::cli_abort(
      "Additional arguments in {.arg ...} are only used when {.arg conf.int = TRUE} and {.code method = \"profile\"}."
    )
  }
  if (!conf.int && !is.null(ci_parm)) {
    cli::cli_abort("{.arg ci_parm} is only used when {.arg conf.int = TRUE}.")
  }
  if (conf.int && !identical(method, "profile") && length(dots) > 0L) {
    cli::cli_abort(
      "Additional arguments in {.arg ...} are only used when {.code method = \"profile\"}."
    )
  }

  coefficients <- drm_summary_coefficients(object)
  parameters <- drm_summary_parameters(object)
  ci <- NULL
  coefficient_ci <- NULL
  parameter_ci <- NULL
  coefficient_ci_method <- method
  ci_unavailable_status <- "not_requested"
  if (conf.int) {
    if (identical(method, "wald")) {
      if (drm_has_sdreport_covariance(object)) {
        ci <- drm_wald_confint(object, parm = ci_parm, level = level)
      } else {
        ci_unavailable_status <- "wald_unavailable"
        ci <- empty_summary_confint()
      }
      coefficient_ci <- ci
      parameter_ci <- ci
    } else {
      parameter_ci <- drm_summary_profile_confint(
        object,
        ci_parm = ci_parm,
        level = level,
        trace = trace,
        profile_precision = profile_precision,
        ...
      )
      coefficient_ci <- summary_profile_coefficient_ci(
        object,
        parameter_ci,
        level = level
      )
      coefficient_ci_method <- if (
        is.null(coefficient_ci) ||
          nrow(coefficient_ci) == 0L ||
          all(coefficient_ci$method == "wald")
      ) {
        "wald"
      } else {
        "profile"
      }
      if (
        !drm_has_sdreport_covariance(object) &&
          (is.null(coefficient_ci) || nrow(coefficient_ci) == 0L)
      ) {
        ci_unavailable_status <- "wald_unavailable"
      }
      ci <- rbind(
        coefficient_ci,
        parameter_ci[
          !parameter_ci$parm %in% coefficient_ci$parm,
          ,
          drop = FALSE
        ]
      )
    }
    coefficients <- drm_summary_add_coefficient_ci(
      coefficients,
      coefficient_ci,
      level = level,
      method = coefficient_ci_method,
      unavailable_status = ci_unavailable_status
    )
    parameters <- drm_summary_add_parameter_ci(
      parameters,
      parameter_ci,
      level = level,
      method = method
    )
  }

  covariance <- random_effect_covariance_summaries(
    object,
    intervals = if (conf.int && identical(method, "profile")) {
      parameter_ci
    } else {
      NULL
    }
  )
  derived <- drm_summary_derived_parameters(
    object,
    interval_requested = conf.int
  )

  out <- list(
    call = object$call,
    nobs = stats::nobs(object),
    coefficients = coefficients,
    parameters = parameters,
    covariance = covariance,
    derived = derived,
    sdpars = object$sdpars,
    corpars = object$corpars,
    ordinal = object$ordinal,
    uncertainty = object$uncertainty,
    logLik = if (drm_is_mspl(object)) NA_real_ else stats::logLik(object),
    mspl = if (drm_is_mspl(object)) object$mspl else NULL,
    estimator = object$estimator,
    estimator_exact = object$estimator_exact,
    convergence = object$opt$convergence,
    conf.int = conf.int,
    conf.level = if (conf.int) level else NA_real_,
    conf.method = if (conf.int) method else NA_character_,
    confint = ci
  )
  class(out) <- "summary.drmTMB"
  out
}

#' @export
print.summary.drmTMB <- function(x, ...) {
  cli::cli_text("<summary.drmTMB>")
  if (!is.null(x$estimator)) {
    estimator_detail <- if (identical(x$estimator, "REML") &&
        !is.null(x$estimator_exact) && !is.na(x$estimator_exact)) {
      if (isTRUE(x$estimator_exact)) {
        "exact restricted likelihood"
      } else {
        "Laplace/Cox-Reid adjusted profile"
      }
    } else {
      NULL
    }
    if (is.null(estimator_detail)) {
      cli::cli_text("estimator: {x$estimator}")
    } else {
      cli::cli_text("estimator: {x$estimator} ({estimator_detail})")
    }
  }
  if (isTRUE(x$conf.int)) {
    cli::cli_text(
      "confidence intervals: {x$conf.method}, level = {format(x$conf.level)}"
    )
  }
  if (identical(x$estimator, "MSPL")) {
    if (isTRUE(x$mspl$wald$spd)) {
      cli::cli_text(
        "standard errors: fixed-effect Wald SEs reported (unpenalized Laplace Hessian at the MSPL estimate); confidence intervals are not implemented for MSPL fits."
      )
    } else {
      cli::cli_text(
        "standard errors: unavailable ({.val {x$mspl$wald$status}}); coefficient table is point estimates only."
      )
    }
  } else {
    uncertainty <- drm_uncertainty_status(x)
    if (!identical(uncertainty, "ok")) {
      cli::cli_text(
        "standard errors: unavailable; coefficient and parameter tables are point estimates only ({drm_uncertainty_message(x)})"
      )
    }
  }
  print(x$coefficients)
  if (nrow(x$parameters) > 0L) {
    cli::cli_text(
      "Distributional, random-effect, scale, and correlation parameters:"
    )
    print(drm_summary_print_parameters(x$parameters))
  }
  if (is.data.frame(x$covariance) && nrow(x$covariance) > 0L) {
    cli::cli_text("Random-effect covariance summaries:")
    print(drm_summary_print_covariance(x$covariance))
  }
  if (is.data.frame(x$derived) && nrow(x$derived) > 0L) {
    cli::cli_text("Derived summaries:")
    print(drm_summary_print_derived(x$derived))
  } else if (
    is.data.frame(x$derived) &&
      is.character(attr(x$derived, "residual_variance.message"))
  ) {
    # Name the reason instead of a silent empty derived block (2026-09-14
    # ruling, S2b item 5): `residual_variance.message` was previously written
    # by drm_derived_summary_rows() but had no reader anywhere in the
    # package.
    cli::cli_text(
      "Derived summaries: {attr(x$derived, 'residual_variance.message')}"
    )
  }
  if (!is.null(x$ordinal)) {
    cli::cli_text("Ordinal cutpoints:")
    print(x$ordinal$cutpoints)
  }
  if (identical(x$estimator, "MSPL")) {
    cli::cli_text(
      "penalized objective: {format(x$mspl$penalized_objective, digits = 6)}"
    )
    cli::cli_text(
      "unpenalized Laplace log objective (diagnostic): {format(x$mspl$unpenalized_laplace_logLik, digits = 6)}"
    )
    ## Two different gradients, and conflating them is a real hazard: the
    ## penalized one is near zero by optimizer construction and says nothing
    ## about the Wald estimand, while the unpenalized one is non-zero BY
    ## CONSTRUCTION (the MSPL estimate maximises the penalized criterion) and is
    ## the quantity that qualifies the standard errors. Label both.
    cli::cli_text(
      "max penalized-criterion gradient (convergence): {format(x$mspl$numerical$gradient_max_abs, digits = 4)}"
    )
    if (!is.null(x$mspl$wald$unpenalized_gradient_max_abs)) {
      cli::cli_text(
        "max unpenalized-likelihood gradient at the MSPL estimate (non-zero by construction): {format(x$mspl$wald$unpenalized_gradient_max_abs, digits = 4)}"
      )
    }
    cli::cli_text(
      "MSPL outer Hessian positive definite: {x$mspl$numerical$hessian_positive_definite}"
    )
    cli::cli_text(
      "minimum random-effect SD: {format(x$mspl$boundary$min_sd, digits = 4)}"
    )
    if (identical(x$mspl$q, 2L)) {
      cli::cli_text(
        "absolute random-effect correlation: {format(x$mspl$boundary$max_abs_rho, digits = 4)}"
      )
    }
  } else {
    cli::cli_text("logLik: {format(as.numeric(x$logLik), digits = 4)}")
  }
  cli::cli_text("convergence: {x$convergence}")
  invisible(x)
}

validate_summary_conf_int <- function(conf.int) {
  if (
    !is.logical(conf.int) ||
      length(conf.int) != 1L ||
      is.na(conf.int)
  ) {
    cli::cli_abort(
      "{.arg conf.int} must be a single {.code TRUE} or {.code FALSE}."
    )
  }
  invisible(conf.int)
}

validate_summary_trace <- function(trace) {
  if (
    !is.logical(trace) ||
      length(trace) != 1L ||
      is.na(trace)
  ) {
    cli::cli_abort(
      "{.arg trace} must be a single {.code TRUE} or {.code FALSE}."
    )
  }
  invisible(trace)
}

drm_summary_coefficients <- function(object) {
  labels <- coefficient_labels(object)
  est <- unlist(object$coefficients, use.names = FALSE)
  if (length(est) == 0L) {
    return(data.frame(
      estimate = numeric(),
      std_error = numeric(),
      row.names = character(),
      check.names = FALSE
    ))
  }
  if (drm_is_mspl(object)) {
    return(drm_mspl_summary_coefficients(object, labels, est))
  }
  vcov <- tryCatch(stats::vcov(object), error = function(e) e)
  if (inherits(vcov, "error")) {
    out <- data.frame(
      estimate = est,
      std_error = rep(NA_real_, length(est)),
      row.names = labels,
      check.names = FALSE
    )
    out$std_error.status <- drm_standard_error_status(object)
    attr(out, "std_error.message") <- conditionMessage(vcov)
    return(out)
  }
  variances <- diag(vcov)
  se <- rep(NA_real_, length(variances))
  ok <- is.finite(variances) & variances >= 0
  se[ok] <- sqrt(variances[ok])
  data.frame(
    estimate = est,
    std_error = se,
    row.names = labels,
    check.names = FALSE
  )
}

drm_summary_parameters <- function(object) {
  rows <- list(
    drm_summary_direct_parameters(object),
    drm_summary_fitted_range_parameters(object)
  )
  rows <- rows[vapply(rows, nrow, integer(1)) > 0L]
  if (!length(rows)) {
    return(empty_summary_parameters())
  }
  out <- do.call(rbind, rows)
  out <- drm_summary_add_parameter_standard_errors(object, out)
  row.names(out) <- out$parm
  out
}

drm_summary_derived_parameters <- function(
  object,
  interval_requested = FALSE
) {
  out <- drm_derived_summary_rows(object)
  if (nrow(out) == 0L) {
    return(out)
  }
  out$conf.low <- NA_real_
  out$conf.high <- NA_real_
  out$conf.method <- NA_character_
  out$conf.status <- if (isTRUE(interval_requested)) {
    "derived_interval_unavailable"
  } else {
    "not_requested"
  }
  row.names(out) <- out$parm
  out
}

drm_derived_summary_rows <- function(object) {
  if (!identical(object$model$model_type, "gaussian")) {
    return(empty_derived_summary_parameters())
  }
  sigma <- drm_constant_residual_sigma(object)
  if (!is.finite(sigma)) {
    # Name the reason instead of a silent empty frame (Fisher's 2026-09-14
    # ruling on docs/design/275, "Concrete change" item 3): a random slope on
    # sigma, or a structured sigma effect without a verified unit-diagonal
    # correlation, is a different situation from an ordinary heteroscedastic
    # sigma ~ x fit, and the reader should be told which.
    out <- empty_derived_summary_parameters()
    attr(out, "residual_variance.message") <-
      drm_residual_sigma_na_reason_text(attr(sigma, "reason"))
    return(out)
  }
  sd_values <- object$sdpars$mu
  if (is.null(sd_values) || length(sd_values) == 0L) {
    return(empty_derived_summary_parameters())
  }

  # These rows ("total_variance_share" and "phylo_total_variance_share")
  # are defined against the TOTAL variance, so the denominator must include
  # every mu random-effect variance plus the residual variance. Summing only
  # the current term's variance overstates each ratio whenever multiple mu
  # random effects are present (see issue #695). This is a DIFFERENT
  # denominator from the icc()/repeatability() accessors in
  # R/heritability.R, which divide the focal component's variance by that
  # component plus the residual only -- do not rename these rows back to
  # "repeatability" (see docs/design/259-heritability-icc-repeatability.md).
  numeric_sd <- vapply(sd_values, function(v) unname(v)[[1L]], numeric(1))
  valid_sd <- is.finite(numeric_sd) & numeric_sd >= 0
  residual_variance <- sigma^2
  total_re_var <- sum(numeric_sd[valid_sd]^2)

  rows <- lapply(seq_along(sd_values), function(i) {
    term <- names(sd_values)[[i]]
    sd_value <- unname(sd_values[[i]])
    if (!is.finite(sd_value) || sd_value < 0) {
      return(NULL)
    }
    kind <- derived_summary_random_effect_kind(term)
    if (is.null(kind)) {
      return(NULL)
    }
    re_variance <- sd_value^2
    denominator <- total_re_var + residual_variance
    if (!is.finite(denominator) || denominator <= 0) {
      return(NULL)
    }
    data.frame(
      quantity = kind$quantity,
      level = kind$level,
      group = kind$group,
      dpar = "mu",
      term = term,
      estimate = re_variance / denominator,
      random_effect_sd = sd_value,
      random_effect_variance = re_variance,
      residual_sd = sigma,
      residual_variance = residual_variance,
      scale = "response",
      parm = kind$parm,
      target_type = "derived",
      profile_ready = FALSE,
      profile_note = "derived_target",
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  })
  rows <- Filter(Negate(is.null), rows)
  if (!length(rows)) {
    return(empty_derived_summary_parameters())
  }
  out <- do.call(rbind, rows)
  row.names(out) <- NULL
  out
}

empty_derived_summary_parameters <- function() {
  data.frame(
    quantity = character(),
    level = character(),
    group = character(),
    dpar = character(),
    term = character(),
    estimate = numeric(),
    random_effect_sd = numeric(),
    random_effect_variance = numeric(),
    residual_sd = numeric(),
    residual_variance = numeric(),
    scale = character(),
    parm = character(),
    target_type = character(),
    profile_ready = logical(),
    profile_note = character(),
    conf.low = numeric(),
    conf.high = numeric(),
    conf.method = character(),
    conf.status = character(),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

# The residual scale exp(b0) is exact only when `sigma` is a constant (a
# single log-link intercept, no random effect). When `sigma` additionally
# carries an ordinary random intercept, or a phylogenetic random intercept
# with a unit-diagonal correlation, exp(b0) is sigma's *median*, not its RMS;
# the correct marginal residual variance is exp(2*b0 + 2*sum_k(omega_k^2))
# (docs/design/275-repeatability-scale-and-residual-variance.md sections 4-5,
# Fisher's 2026-09-14 ruling on that note). The return value is `NA_real_`
# with a `reason` attribute -- consumed by drm_residual_sigma_na_reason_text()
# -- when no closed-form scalar residual variance exists: more than one fixed
# coefficient on sigma, a non-log link, a known-dispersion override, a random
# SLOPE on sigma, or a structured sigma effect without a verified
# unit-diagonal correlation.
drm_constant_residual_sigma <- function(object) {
  beta <- object$coefficients$sigma
  if (
    is.null(beta) ||
      length(beta) != 1L ||
      !identical(names(beta), "(Intercept)") ||
      !identical(drm_dpar_link(object, "sigma"), "log")
  ) {
    return(structure(NA_real_, reason = "non_constant_sigma_predictor"))
  }
  known_v <- known_v_diag(object)
  if (
    length(known_v) > 0L &&
      any(is.finite(known_v) & abs(known_v) > sqrt(.Machine$double.eps))
  ) {
    return(structure(NA_real_, reason = "known_residual_variance"))
  }
  # The likelihood evaluates the soft-clamped log-scale predictor for the
  # clamped-scale families, and sigma() reports that value (Dinnage audit
  # M2); the residual variance must sit on the same scale or summary()'s
  # residual_sd and sigma() disagree on a clamp-active fit.
  b0 <- drm_clamped_sigma_eta(object, "sigma", unname(beta[[1L]]))
  if (!has_sigma_random_effects(object)) {
    return(exp(b0))
  }
  # The kernel clamps the ASSEMBLED predictor log_sigma = X*beta + u, not
  # just the intercept (src/drmTMB.cpp:2437, applied after every
  # random-effect contribution at 811/994/1033), so under an active clamp
  # the quantity the likelihood integrates is E[exp(2*c(b0+u))] -- bounded
  # by exp(2*(hi+margin)) -- not exp(2*c(b0) + 2*sum omega_k^2) below, which
  # is unbounded in omega and is the moment of no distribution the
  # likelihood uses (measured 1.47x high on a partly-bent clamp-active fit;
  # exact, ratio 1.001, when the clamp is inactive -- Fisher's 2026-09-14
  # S2b follow-up ruling on docs/design/275). Refuse rather than ship a
  # hybrid, matching e86359fe2's conf.status = "clamp_limited" treatment of
  # the same defect in predict_parameters().
  if (isTRUE(object$model$model_type %in% drm_clamped_scale_families())) {
    report <- tryCatch(
      object$obj$report(object$tmb_state$last.par.best),
      error = function(e) NULL
    )
    if (
      !is.null(report) &&
        !is.null(drm_logsigma_clamp_active(report, object$model$tmb_data))
    ) {
      return(structure(NA_real_, reason = "clamp_limited"))
    }
  }
  omega2_sum <- drm_sigma_random_effect_omega2_sum(object)
  if (!is.finite(omega2_sum)) {
    return(structure(NA_real_, reason = attr(omega2_sum, "reason")))
  }
  exp(b0 + omega2_sum)
}

# Sum of squared working-scale SDs (omega_k^2) across every random effect
# living on sigma's log-link linear predictor: ordinary random intercepts
# (`object$model$random$sigma`) and a phylogenetic random intercept
# (`phylo(1 | group, tree = tree)`, whose default `correlation = TRUE`
# tree-height normalisation gives a unit correlation diagonal --
# R/phylo-utils.R:250-252). Returns `NA_real_` with a `reason` attribute --
# "random_slope_on_sigma", "structured_sigma_non_unit_diagonal", or
# "structured_sigma_diagonal_not_checked" -- when the sum is not a
# well-defined scalar: a random SLOPE on sigma (a design-dependent variance,
# not a single omega), or a structured sigma effect whose correlation matrix
# is MEASURED to not have a unit diagonal, or one whose diagonal could not be
# measured at all. The diagonal is measured, not inferred from
# `structured_mu_type()`'s label (2026-09-14 ruling on
# docs/design/275-repeatability-scale-and-residual-variance.md: "the refusal
# should be conditioned on the diagonal of the structured matrix, not on the
# word 'phylogenetic'") -- see drm_structured_sigma_unit_diagonal(). Every
# sigma-side working-scale SD (ordinary or phylogenetic) is already
# aggregated into `object$sdpars$sigma` by split_tmb_sdpars(), so once the
# slope/unit-diagonal checks pass this just sums that vector.
drm_sigma_random_effect_omega2_sum <- function(object) {
  random_sigma <- object$model$random$sigma
  if (is.list(random_sigma) && isTRUE(random_sigma$n_re > 0L)) {
    coef_names <- random_sigma$coef_names
    if (any(!is.na(coef_names) & coef_names != "(Intercept)")) {
      return(structure(NA_real_, reason = "random_slope_on_sigma"))
    }
  }
  phylo_mu <- object$model$structured$phylo_mu
  if (isTRUE(phylo_mu$has)) {
    endpoint_dpars <- sub("[0-9]+$", "", phylo_mu_endpoint_dpars(phylo_mu))
    sigma_idx <- which(endpoint_dpars == "sigma")
    if (length(sigma_idx) > 0L) {
      coef_names <- phylo_mu$coef_names
      if (
        !is.null(coef_names) &&
          any(
            !is.na(coef_names[sigma_idx]) &
              coef_names[sigma_idx] != "(Intercept)"
          )
      ) {
        return(structure(NA_real_, reason = "random_slope_on_sigma"))
      }
      unit_diagonal <- drm_structured_sigma_unit_diagonal(phylo_mu)
      if (is.na(unit_diagonal)) {
        return(structure(
          NA_real_,
          reason = "structured_sigma_diagonal_not_checked"
        ))
      }
      if (!unit_diagonal) {
        return(structure(
          NA_real_,
          reason = "structured_sigma_non_unit_diagonal"
        ))
      }
    }
  }
  sd_sigma <- object$sdpars$sigma
  if (is.null(sd_sigma) || length(sd_sigma) == 0L) {
    return(0)
  }
  sum(sd_sigma^2)
}

# Whether a structured effect's IMPLIED correlation matrix has a unit
# diagonal, measured by inverting its precision matrix -- not inferred from
# `structured_mu_type(phylo_mu)`'s label. The 2026-09-14 ruling on
# docs/design/275-repeatability-scale-and-residual-variance.md found the
# label-based check false for a measured case
# (`sigma ~ spatial(1 | site, coords = coords)`, diag(Sigma) = 1.000001 --
# unit, but refused as "phylogenetic-only"); this checks the actual matrix
# instead.
#
# The diagonal is measured on the MODELLED-UNIT rows, not necessarily the
# whole matrix (Fisher's 2026-09-14 S2b follow-up review,
# docs/dev-log/audits/2026-09-14-dinnage-wave3-review.md "### S2b follow-up
# (4ae2f5d99, d61f65183)"): a `phylo()` term's precision
# (`drm_phylo_augmented_precision()`, R/phylo-utils.R:258) is AUGMENTED with
# a latent internal-node basis -- 38x38 for a 20-tip tree -- and only its
# tip/species rows are the ones the design matrix actually multiplies;
# measured directly, those rows have a unit diagonal (`[1, 1]`) even for
# `phylo()` on `sigma` ALONE, while the whole augmented diagonal ranges over
# `[0.554, 1]` and would falsely refuse a fit whose modelled units really
# are unit-diagonal. Every structured builder records the rows its design
# loads on as `observation_node_index` (`phylo()`, `phylo_interaction()`,
# `spatial()`, `animal()`/`relmat()`; R/drmTMB.R ~14111, ~14216, ~14329,
# ~14592), and the tree-based precisions additionally carry
# `precision$species_node_index` / `precision$tip_node_index`; the helper
# measures on the design rows first and the species/tip index as fallback,
# never over a whole augmented matrix. This indexing is independent of `structured_mu_q()`: a
# `phylo()` term shared across two endpoints (`q > 1`, e.g. the same term on
# both `mu` and `sigma`) reuses the identical per-tree precision object
# (measured: `phylo_mu$precision` is built once in
# `build_phylo_mu_structure()`, R/drmTMB.R:14083, before `q` is computed),
# so its tip rows are exactly as measurable there -- this retires the old
# `q > 1L && type == "phylo"` trusted-by-construction branch entirely. Any
# block, whatever its `q`, is measured on `observation_node_index` (the rows
# the design loads on, present on every structured builder), so a Kronecker
# `phylo_interaction()` block is measured on its used rows too; a block with
# no row index at all reports "not checked" rather than a guess.
#
# Returns `TRUE`/`FALSE` when the diagonal was measured (within `tol`), or
# `NA` when it could not be measured (no precision matrix, non-square, the
# inversion failed, or no row index of any kind, whatever the block's `q`) --
# callers must report an `NA` result as "the diagonal was not checked",
# never as "the diagonal is not unit" (D-252: a refusal is a claim, and a
# false one is a defect).
drm_structured_sigma_unit_diagonal <- function(phylo_mu, tol = 1e-3) {
  precision_obj <- phylo_mu$precision
  precision <- precision_obj$precision
  if (
    is.null(precision) ||
      is.null(dim(precision)) ||
      nrow(precision) != ncol(precision) ||
      nrow(precision) == 0L
  ) {
    return(NA)
  }
  # Measure on the rows the DESIGN uses: every structured builder records
  # `observation_node_index` (the precision rows each observation loads on);
  # the species/tip index is the tree-specific fallback. With no row index at
  # all the diagonal is NOT measured -- whole-matrix inversion of an augmented
  # (tips + internal nodes, or Kronecker) precision reads latent rows and
  # reports a false "not unit" (Fisher, review of 1c44d2f12: phylo_interaction()
  # whole-matrix range [0.505, 1] while its 30 used rows are exactly 1).
  index <- phylo_mu$observation_node_index
  if (is.null(index) || length(index) == 0L) {
    index <- precision_obj$species_node_index
  }
  if (is.null(index) || length(index) == 0L) {
    index <- precision_obj$tip_node_index
  }
  if (is.null(index) || length(index) == 0L) {
    return(NA)
  }
  index <- unique(unname(as.integer(index)))
  if (length(index) == 0L || anyNA(index)) {
    return(NA)
  }
  covariance <- tryCatch(
    as.matrix(Matrix::solve(precision)),
    error = function(e) NULL
  )
  if (is.null(covariance)) {
    return(NA)
  }
  d <- diag(covariance)[index]
  if (length(d) == 0L || anyNA(d) || !all(is.finite(d))) {
    return(NA)
  }
  all(abs(d - 1) <= tol)
}

# Human-readable reason a constant/closed-form residual-scale sigma is not
# available, shared by drm_derived_summary_rows() (attached as a
# `residual_variance.message` attribute on the empty result, following the
# `std_error.message` convention above) and drm_variance_ratio() (used in its
# abort message) so the two callers name the SAME defect
# (docs/design/275-repeatability-scale-and-residual-variance.md, Fisher's
# 2026-09-14 ruling).
drm_residual_sigma_na_reason_text <- function(reason) {
  switch(
    reason,
    non_constant_sigma_predictor = paste(
      "This fit has a sigma predictor, a non-log link, or a",
      "known-dispersion override, so a single scalar residual variance is",
      "not defined. Random-effect SD estimates remain available in $sdpars."
    ),
    known_residual_variance = paste(
      "This fit has a known-dispersion override, so a single scalar",
      "residual variance is not defined."
    ),
    random_slope_on_sigma = paste(
      "This fit has a random slope on sigma (a design-dependent variance,",
      "not a single scalar), so a single scalar residual variance is not",
      "defined."
    ),
    structured_sigma_non_unit_diagonal = paste(
      "This fit has a structured sigma random effect whose correlation",
      "matrix was measured and does not have a unit diagonal, so a single",
      "scalar residual variance is not defined."
    ),
    structured_sigma_diagonal_not_checked = paste(
      "This fit has a structured sigma random effect whose correlation",
      "matrix's diagonal was not checked, so a single scalar residual",
      "variance is not defined."
    ),
    clamp_limited = paste(
      "This fit's log(sigma) soft clamp is active at the optimum, so the",
      "closed-form marginal residual variance (which assumes an unclamped",
      "random effect) is not defined; see check_drm() for the clamp",
      "diagnostic."
    ),
    paste(
      "This fit does not have a constant residual scale (sigma ~ 1) or a",
      "closed-form marginal residual variance, so a single scalar residual",
      "variance is not defined."
    )
  )
}

derived_summary_random_effect_kind <- function(term) {
  # split_tmb_sdpars() prefixes the label with `mu:`/`sigma:` once the SAME
  # structured term also has a sibling on the other endpoint (e.g.
  # "mu:phylo(1 | species)" when phylo() is on both mu and sigma) -- strip it
  # before matching, or a phylo()-on-mu-and-sigma fit yields no row here
  # (2026-09-14 ruling, S2b item 2; mirrors the same fix in
  # R/heritability.R's drm_variance_ratio_positions()).
  term <- sub("^(mu|sigma):", "", term)
  if (startsWith(term, "phylo(")) {
    group <- random_intercept_group_from_call(term, "phylo")
    if (is.na(group)) {
      return(NULL)
    }
    return(list(
      quantity = "phylo_total_variance_share",
      level = "phylogenetic",
      group = group,
      parm = paste0("derived:phylo_total_variance_share(", group, ")")
    ))
  }
  group <- random_intercept_group_from_term(term)
  if (is.na(group)) {
    return(NULL)
  }
  list(
    quantity = "total_variance_share",
    level = "group",
    group = group,
    parm = paste0("derived:total_variance_share(", group, ")")
  )
}

random_intercept_group_from_call <- function(term, fun) {
  prefix <- paste0(fun, "(")
  if (!startsWith(term, prefix) || !endsWith(term, ")")) {
    return(NA_character_)
  }
  inner <- substr(term, nchar(prefix) + 1L, nchar(term) - 1L)
  random_intercept_group_from_inner(inner)
}

random_intercept_group_from_term <- function(term) {
  if (!startsWith(term, "(") || !endsWith(term, ")")) {
    return(NA_character_)
  }
  inner <- substr(term, 2L, nchar(term) - 1L)
  random_intercept_group_from_inner(inner)
}

random_intercept_group_from_inner <- function(inner) {
  parts <- trimws(strsplit(inner, "\\|", fixed = FALSE)[[1L]])
  if (length(parts) < 2L || !identical(parts[[1L]], "1")) {
    return(NA_character_)
  }
  group <- parts[[length(parts)]]
  if (!nzchar(group)) {
    return(NA_character_)
  }
  group
}

drm_summary_direct_parameters <- function(object) {
  targets <- drm_profile_targets(object)
  keep <- targets$target_class %in%
    c(
      "distributional-scale",
      "residual-correlation",
      "random-effect-sd",
      "random-effect-correlation"
    )
  targets <- targets[keep, , drop = FALSE]
  if (nrow(targets) == 0L) {
    return(empty_summary_parameters())
  }
  if (identical(object$model$model_type, "biv_student")) {
    targets$profile_ready <- FALSE
    targets$profile_note <- "family_interval_deferred"
  }
  out <- data.frame(
    component = targets$target_class,
    dpar = targets$dpar,
    term = targets$term,
    estimate = targets$estimate,
    minimum = NA_real_,
    maximum = NA_real_,
    scale = targets$scale,
    parm = targets$parm,
    profile_ready = targets$profile_ready,
    profile_note = targets$profile_note,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  row.names(out) <- NULL
  out
}

drm_summary_fitted_range_parameters <- function(object) {
  dpars <- setdiff(names(object$coefficients), c("mu", "mu1", "mu2"))
  if (!length(dpars)) {
    return(empty_summary_parameters())
  }
  direct_parms <- drm_summary_direct_parameters(object)$parm
  rows <- lapply(dpars, function(dpar) {
    if (dpar %in% direct_parms) {
      return(NULL)
    }
    values <- tryCatch(
      predict(object, dpar = dpar, type = "response"),
      error = function(e) NULL
    )
    if (is.null(values) || length(values) == 0L || !all(is.finite(values))) {
      return(NULL)
    }
    values <- as.numeric(values)
    data.frame(
      component = drm_dpar_component(dpar),
      dpar = dpar,
      term = "fitted range",
      estimate = mean(values),
      minimum = min(values),
      maximum = max(values),
      scale = "response",
      parm = paste0("fitted:", dpar),
      profile_ready = FALSE,
      profile_note = drm_summary_range_profile_note(dpar),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  })
  rows <- Filter(Negate(is.null), rows)
  if (!length(rows)) {
    return(empty_summary_parameters())
  }
  out <- do.call(rbind, rows)
  row.names(out) <- NULL
  out
}

drm_summary_range_profile_note <- function(dpar) {
  if (
    dpar %in%
      c("sigma", "sigma1", "sigma2", "rho12") ||
      startsWith(dpar, "corpair(")
  ) {
    return("use_confint_newdata")
  }
  "fitted_range_only"
}

empty_summary_parameters <- function() {
  data.frame(
    component = character(),
    dpar = character(),
    term = character(),
    estimate = numeric(),
    std_error = numeric(),
    minimum = numeric(),
    maximum = numeric(),
    scale = character(),
    parm = character(),
    profile_ready = logical(),
    profile_note = character(),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

drm_summary_add_parameter_standard_errors <- function(object, parameters) {
  parameters$std_error <- NA_real_
  if (nrow(parameters) == 0L || !drm_has_sdreport_covariance(object)) {
    return(summary_parameter_order_columns(parameters))
  }

  targets <- drm_profile_targets(object)
  matched <- match(parameters$parm, targets$parm)
  cov_fixed <- object$sdr$cov.fixed

  for (i in seq_len(nrow(parameters))) {
    target_row <- matched[[i]]
    if (is.na(target_row)) {
      next
    }
    target <- targets[target_row, , drop = FALSE]
    if (!identical(target$target_type[[1L]], "direct")) {
      next
    }
    position <- summary_parameter_opt_position(object, target)
    if (is.na(position) || position > nrow(cov_fixed)) {
      next
    }
    variance <- cov_fixed[position, position]
    if (!is.finite(variance) || variance < 0) {
      next
    }
    derivative <- summary_parameter_delta_derivative(target)
    if (!is.finite(derivative)) {
      next
    }
    parameters$std_error[[i]] <- abs(derivative) * sqrt(variance)
  }
  parameters <- summary_parameter_order_columns(parameters)
  parameters
}

summary_parameter_order_columns <- function(parameters) {
  preferred <- c(
    "component",
    "dpar",
    "term",
    "estimate",
    "std_error",
    "minimum",
    "maximum",
    "scale",
    "parm",
    "profile_ready",
    "profile_note"
  )
  parameters[,
    c(
      intersect(preferred, names(parameters)),
      setdiff(names(parameters), preferred)
    ),
    drop = FALSE
  ]
}

summary_parameter_opt_position <- function(object, target) {
  internal <- target$tmb_parameter[[1L]]
  index <- target$index[[1L]]
  if (is.na(internal) || is.na(index)) {
    return(NA_integer_)
  }
  positions <- which(names(object$opt$par) == internal)
  if (length(positions) < index) {
    return(NA_integer_)
  }
  positions[[index]]
}

summary_parameter_delta_derivative <- function(target) {
  eta <- target$link_estimate[[1L]]
  if (!is.finite(eta)) {
    return(NA_real_)
  }
  switch(
    target$transformation[[1L]],
    linear_predictor = 1,
    exp = exp(eta),
    plogis = stats::plogis(eta) * stats::plogis(-eta),
    tanh = profile_correlation_guard(target$tmb_parameter) * (1 - tanh(eta)^2),
    rho12_tanh = 0.999999 * (1 - tanh(eta)^2),
    NA_real_
  )
}

drm_summary_profile_confint <- function(
  object,
  ci_parm,
  level,
  trace,
  profile_precision = c("default", "fast"),
  ...
) {
  targets <- drm_profile_targets(object)
  if (is.null(ci_parm)) {
    targets <- targets[
      targets$target_type == "direct" &
        targets$profile_ready &
        targets$target_class != "fixed-effect",
      ,
      drop = FALSE
    ]
    if (nrow(targets) == 0L) {
      return(empty_summary_confint())
    }
    ci_parm <- targets$parm
  }
  profile_args <- profile_precision_args(profile_precision, list(...))
  do.call(
    drm_profile_confint,
    c(
      list(
        object = object,
        parm = ci_parm,
        level = level,
        trace = trace
      ),
      profile_args
    )
  )
}

summary_profile_coefficient_ci <- function(object, profile_ci, level) {
  if (!is.null(profile_ci) && nrow(profile_ci) > 0L) {
    fixed_profile <- startsWith(profile_ci$parm, "fixef:")
    if (any(fixed_profile)) {
      return(profile_ci[fixed_profile, , drop = FALSE])
    }
  }
  if (!drm_has_sdreport_covariance(object)) {
    return(empty_summary_confint())
  }
  drm_wald_confint(object, parm = NULL, level = level)
}

empty_summary_confint <- function() {
  data.frame(
    parm = character(),
    level = numeric(),
    lower = numeric(),
    upper = numeric(),
    scale = character(),
    transformation = character(),
    tmb_parameter = character(),
    index = integer(),
    method = character(),
    conf.status = character(),
    profile.boundary = logical(),
    profile.message = character(),
    stringsAsFactors = FALSE
  )
}

drm_summary_add_coefficient_ci <- function(
  coefficients,
  ci,
  level,
  method,
  unavailable_status = "not_requested"
) {
  n <- nrow(coefficients)
  coefficients$conf.low <- rep(NA_real_, n)
  coefficients$conf.high <- rep(NA_real_, n)
  coefficients$conf.level <- rep(level, n)
  coefficients$conf.method <- rep(method, n)
  coefficients$conf.status <- rep(unavailable_status, n)
  coefficients$profile.boundary <- rep(NA, n)
  coefficients$profile.message <- rep(NA_character_, n)
  if (is.null(ci) || nrow(ci) == 0L) {
    return(coefficients)
  }
  keys <- paste0("fixef:", row.names(coefficients))
  matched <- match(keys, ci$parm)
  has_ci <- !is.na(matched)
  coefficients$conf.low[has_ci] <- ci$lower[matched[has_ci]]
  coefficients$conf.high[has_ci] <- ci$upper[matched[has_ci]]
  coefficients$conf.status[has_ci] <- summary_ci_status(
    ci,
    matched[has_ci],
    method
  )
  coefficients$profile.boundary[has_ci] <- summary_ci_column(
    ci,
    matched[has_ci],
    column = "profile.boundary",
    default = NA
  )
  coefficients$profile.message[has_ci] <- summary_ci_column(
    ci,
    matched[has_ci],
    column = "profile.message",
    default = NA_character_
  )
  coefficients
}

drm_summary_add_parameter_ci <- function(parameters, ci, level, method) {
  n <- nrow(parameters)
  parameters$conf.low <- rep(NA_real_, n)
  parameters$conf.high <- rep(NA_real_, n)
  parameters$conf.level <- rep(level, n)
  parameters$conf.method <- rep(method, n)
  parameters$conf.status <- summary_parameter_conf_status(
    parameters,
    method = method
  )
  parameters$profile.boundary <- rep(NA, n)
  parameters$profile.message <- rep(NA_character_, n)
  if (nrow(parameters) == 0L || is.null(ci) || nrow(ci) == 0L) {
    return(parameters)
  }
  matched <- match(parameters$parm, ci$parm)
  has_ci <- !is.na(matched)
  parameters$conf.low[has_ci] <- ci$lower[matched[has_ci]]
  parameters$conf.high[has_ci] <- ci$upper[matched[has_ci]]
  parameters$conf.status[has_ci] <- summary_ci_status(
    ci,
    matched[has_ci],
    method
  )
  parameters$profile.boundary[has_ci] <- summary_ci_column(
    ci,
    matched[has_ci],
    column = "profile.boundary",
    default = NA
  )
  parameters$profile.message[has_ci] <- summary_ci_column(
    ci,
    matched[has_ci],
    column = "profile.message",
    default = NA_character_
  )
  parameters
}

summary_ci_status <- function(ci, matched, method) {
  if ("conf.status" %in% names(ci)) {
    return(ci$conf.status[matched])
  }
  rep(method, length(matched))
}

summary_ci_column <- function(ci, matched, column, default) {
  if (column %in% names(ci)) {
    return(ci[[column]][matched])
  }
  rep(default, length(matched))
}

summary_parameter_conf_status <- function(parameters, method) {
  if (nrow(parameters) == 0L) {
    return(character())
  }
  if (identical(method, "wald")) {
    return(rep("wald_unavailable", nrow(parameters)))
  }
  mapply(
    function(profile_ready, profile_note) {
      interval_status_from_profile_note(
        profile_ready = profile_ready,
        profile_note = profile_note
      )
    },
    parameters$profile_ready,
    parameters$profile_note,
    USE.NAMES = FALSE
  )
}

interval_status_from_profile_note <- function(profile_ready, profile_note) {
  if (isTRUE(profile_ready)) {
    return("profile_ready")
  }
  if (is.na(profile_note) || !nzchar(profile_note)) {
    return("profile_unavailable")
  }
  switch(
    profile_note,
    ready = "profile_ready",
    use_confint_newdata = "newdata_required",
    derived_target = "derived_interval_unavailable",
    derived_unstructured_correlation = "derived_interval_unavailable",
    fitted_range_only = "target_unavailable",
    profile_note
  )
}

drm_summary_print_parameters <- function(parameters) {
  keep <- c(
    "component",
    "dpar",
    "term",
    "estimate",
    "std_error",
    "minimum",
    "maximum",
    "scale"
  )
  if (
    "std_error" %in%
      names(parameters) &&
      !any(is.finite(parameters$std_error))
  ) {
    keep <- setdiff(keep, "std_error")
  }
  if (
    all(c("minimum", "maximum") %in% names(parameters)) &&
      !any(
        is.finite(parameters$minimum) &
          is.finite(parameters$maximum) &
          parameters$minimum != parameters$maximum
      )
  ) {
    keep <- setdiff(keep, c("minimum", "maximum"))
  }
  if ("conf.low" %in% names(parameters)) {
    has_interval <- any(is.finite(parameters$conf.low)) ||
      any(is.finite(parameters$conf.high))
    if (has_interval) {
      keep <- c(keep, "conf.low", "conf.high")
    }
  }
  if (
    "conf.status" %in%
      names(parameters) &&
      any(parameters$conf.status != "profile", na.rm = TRUE)
  ) {
    keep <- c(keep, "conf.status")
  }
  if (
    "profile.message" %in%
      names(parameters) &&
      any(
        !is.na(parameters$profile.message) & parameters$profile.message != "ok"
      )
  ) {
    keep <- c(keep, "profile.message")
  }
  out <- parameters[, keep, drop = FALSE]
  row.names(out) <- row.names(parameters)
  out
}

drm_summary_print_covariance <- function(covariance) {
  keep <- c(
    "level",
    "group",
    "block",
    "from_dpar",
    "to_dpar",
    "class",
    "correlation",
    "from_sd",
    "to_sd",
    "covariance"
  )
  out <- covariance[, keep, drop = FALSE]
  if (
    "correlation_conf.low" %in%
      names(covariance) &&
      any(is.finite(covariance$correlation_conf.low))
  ) {
    out$correlation_conf.low <- covariance$correlation_conf.low
    out$correlation_conf.high <- covariance$correlation_conf.high
  }
  if (
    "covariance_conf.status" %in%
      names(covariance) &&
      any(
        covariance$covariance_conf.status == "derived_interval_unavailable",
        na.rm = TRUE
      )
  ) {
    out$covariance_conf.status <- covariance$covariance_conf.status
  }
  out
}

drm_summary_print_derived <- function(derived) {
  keep <- c(
    "quantity",
    "level",
    "group",
    "term",
    "estimate",
    "random_effect_variance",
    "residual_variance"
  )
  out <- derived[, keep, drop = FALSE]
  if (
    "conf.status" %in%
      names(derived) &&
      any(
        derived$conf.status == "derived_interval_unavailable",
        na.rm = TRUE
      )
  ) {
    out$conf.status <- derived$conf.status
  }
  out
}

drm_missing_predictor_prediction_entries <- function(object, dpar) {
  if (!identical(dpar, "mu")) {
    return(list())
  }
  missing_data <- object$missing_data
  if (!is.list(missing_data) || is.null(missing_data$predictors)) {
    return(list())
  }
  predictors <- missing_data$predictors
  predictor_names <- names(predictors)
  if (!is.list(predictors) || length(predictor_names) != length(predictors) ||
      anyNA(predictor_names) || any(!nzchar(predictor_names))) {
    cli::cli_abort("Missing-predictor prediction metadata must be a named list.")
  }
  for (entry in predictors) {
    if (!is.list(entry) || !is.character(entry$variable) ||
        length(entry$variable) != 1L || is.na(entry$variable) || !nzchar(entry$variable) ||
        !is.character(entry$family) || length(entry$family) != 1L ||
        is.na(entry$family) || !nzchar(entry$family)) {
      cli::cli_abort("Missing-predictor prediction metadata has an invalid variable or family.")
    }
  }
  predictors
}

drm_prediction_binary_values <- function(value, variable, levels) {
  if (length(levels) != 2L || anyNA(levels) || any(!nzchar(levels)) ||
      anyDuplicated(levels) || anyNA(value)) {
    cli::cli_abort("Binary missing-predictor prediction metadata or values are incomplete.")
  }
  if (is.factor(value) || is.character(value)) {
    labels <- as.character(value)
    unknown <- setdiff(unique(labels), levels)
    if (length(unknown) > 0L) {
      cli::cli_abort(c(
        "New prediction data contains unknown binary predictor level{?s} for {.var {variable}}.",
        "i" = "Unknown level{?s}: {.val {unknown}}.",
        "i" = "Fitted level{?s}: {.val {levels}}."
      ))
    }
    return(as.numeric(match(labels, levels) - 1L))
  }
  if (is.logical(value)) {
    if (!identical(levels, c("FALSE", "TRUE")) && !identical(levels, c("0", "1"))) {
      cli::cli_abort("Logical binary prediction values do not match the fitted predictor levels.")
    }
    return(as.numeric(value))
  }
  if (is.numeric(value) || is.integer(value)) {
    if (any(!is.finite(value))) {
      cli::cli_abort("Binary missing-predictor prediction values must be finite.")
    }
    numeric_levels <- suppressWarnings(as.numeric(levels))
    if (all(is.finite(numeric_levels))) {
      if (anyDuplicated(numeric_levels)) {
        cli::cli_abort("Binary missing-predictor prediction metadata has ambiguous fitted numeric levels.")
      }
      if (any(!value %in% numeric_levels)) {
        cli::cli_abort("Binary missing-predictor prediction values must match the fitted numeric levels.")
      }
      return(as.numeric(match(value, numeric_levels) - 1L))
    }
    if (any(!value %in% c(0, 1))) {
      cli::cli_abort("Binary missing-predictor prediction values must be finite 0/1 values.")
    }
    return(as.numeric(value))
  }
  cli::cli_abort("Binary missing-predictor prediction values must be numeric 0/1, logical, factor, or character.")
}

drm_prepare_missing_predictor_prediction_newdata <- function(object, newdata, dpar) {
  predictors <- drm_missing_predictor_prediction_entries(object, dpar)
  for (entry in predictors) {
    if (!identical(entry$family, "bernoulli")) {
      next
    }
    variable <- entry$variable
    if (!variable %in% names(newdata)) {
      cli::cli_abort("New prediction data is missing modelled binary predictor {.var {variable}}.")
    }
    newdata[[variable]] <- drm_prediction_binary_values(
      newdata[[variable]], variable, as.character(entry$levels)
    )
  }
  newdata
}

drm_prepare_missing_predictor_prediction_template <- function(object, template, dpar) {
  predictors <- drm_missing_predictor_prediction_entries(object, dpar)
  for (entry in predictors) {
    if (!identical(entry$family, "bernoulli") || !entry$variable %in% names(template)) {
      next
    }
    if (is.factor(template[[entry$variable]])) {
      template[[entry$variable]] <- rep.int(0, nrow(template))
    }
  }
  template
}

drm_prediction_metadata_logical <- function(value, label, n) {
  if (!is.logical(value) || length(value) != n || anyNA(value)) {
    cli::cli_abort("Missing-predictor prediction {label} must be a complete logical vector of length {n}.")
  }
  value
}

drm_prediction_metadata_rows <- function(value, label) {
  if (!is.numeric(value) || any(!is.finite(value)) || any(value != floor(value)) ||
      any(value < 1L) || any(value > .Machine$integer.max)) {
    cli::cli_abort("Missing-predictor prediction {label} must contain finite positive integer rows.")
  }
  as.integer(value)
}

drm_missing_predictor_prediction_rows <- function(entry, original_row, n) {
  observed <- drm_prediction_metadata_logical(entry$observed, "observed metadata", n)
  missing_rows <- which(!observed)
  entry_model_row <- drm_prediction_metadata_rows(entry$model_row, "model-row metadata")
  entry_original_row <- drm_prediction_metadata_rows(entry$original_row, "original-row metadata")
  if (!identical(entry_model_row, missing_rows) ||
      !identical(entry_original_row, original_row[missing_rows])) {
    cli::cli_abort("Missing-predictor prediction model-row metadata does not match the stored design matrix.")
  }
  missing_rows
}

drm_missing_predictor_state_model <- function(object, variable) {
  candidates <- list(
    object$model$missing_predictor,
    object$model$missing_predictor2
  )
  matches <- Filter(
    function(model) {
      is.list(model) && isTRUE(model$enabled) && identical(model$variable, variable)
    },
    candidates
  )
  if (length(matches) != 1L) {
    cli::cli_abort("Missing-predictor state metadata has no unique fitted predictor model.")
  }
  matches[[1L]]
}

drm_reconcile_missing_predictor_state_matrix <- function(
  object,
  X,
  entry,
  original_row,
  n
) {
  model <- drm_missing_predictor_state_model(object, entry$variable)
  n_state <- model$n_state
  levels <- as.character(model$levels)
  if (!is.numeric(n_state) || length(n_state) != 1L || is.na(n_state) ||
      n_state < 2L || n_state != floor(n_state) || length(levels) != n_state ||
      anyNA(levels) || any(!nzchar(levels)) || anyDuplicated(levels)) {
    cli::cli_abort("Missing-predictor state metadata has invalid fitted state levels.")
  }
  missing_rows <- drm_missing_predictor_prediction_rows(entry, original_row, n)
  entry_levels <- as.character(entry$levels)
  if (!identical(entry_levels, levels) || !identical(entry$n_state, as.integer(n_state))) {
    cli::cli_abort("Missing-predictor state metadata does not match the fitted states.")
  }
  probability <- entry$conditional_probabilities
  if (!is.matrix(probability) || !identical(dim(probability), c(length(missing_rows), n_state)) ||
      !identical(colnames(probability), levels) || any(!is.finite(probability)) ||
      any(probability < 0)) {
    cli::cli_abort("Missing-predictor state probabilities must be finite, row-matched, and named by fitted states.")
  }
  totals <- rowSums(probability)
  if (any(!is.finite(totals)) || any(totals <= 0) || any(abs(totals - 1) > 1e-8)) {
    cli::cli_abort("Missing-predictor state probabilities must be normalized by model row.")
  }
  state_X <- model$X_mu_state
  if (!(is.matrix(state_X) || inherits(state_X, "Matrix")) ||
      nrow(state_X) != n * n_state || ncol(state_X) != ncol(X) ||
      !identical(colnames(state_X), colnames(X)) ||
      any(!is.finite(state_X))) {
    cli::cli_abort("Missing-predictor state design must be observation-major and align with the fitted mu design.")
  }
  for (i in seq_along(missing_rows)) {
    row <- missing_rows[[i]]
    state_rows <- (row - 1L) * n_state + seq_len(n_state)
    X[row, ] <- as.numeric(crossprod(probability[i, ] / totals[[i]], state_X[state_rows, , drop = FALSE]))
  }
  X
}

drm_reconcile_missing_predictor_matrix <- function(object, X, dpar) {
  predictors <- drm_missing_predictor_prediction_entries(object, dpar)
  if (length(predictors) == 0L) {
    return(X)
  }
  n <- nrow(X)
  missing_data <- object$missing_data
  original_row <- drm_prediction_metadata_rows(missing_data$original_row, "original-row metadata")
  model_row <- drm_prediction_metadata_rows(missing_data$model_row, "model-row metadata")
  if (length(original_row) != n || length(model_row) != n ||
      !identical(model_row, seq_len(n))) {
    cli::cli_abort("Missing-predictor prediction row metadata does not match the stored design matrix.")
  }
  for (entry in predictors) {
    if (entry$family %in% c("ordinal", "categorical")) {
      X <- drm_reconcile_missing_predictor_state_matrix(
        object, X, entry, original_row, n
      )
      next
    }
    missing_rows <- drm_missing_predictor_prediction_rows(entry, original_row, n)
    if (!is.numeric(entry$value)) {
      cli::cli_abort("Missing-predictor prediction values must be numeric for non-state predictor metadata.")
    }
    values <- as.numeric(entry$value)
    if (length(values) != n || any(!is.finite(values[missing_rows]))) {
      cli::cli_abort("Missing-predictor prediction values must be finite for every missing model row.")
    }
    column <- paste0("mi(", entry$variable, ")")
    if (!column %in% colnames(X) || sum(colnames(X) == column) != 1L) {
      cli::cli_abort("Missing-predictor prediction metadata has no unique {.code {column}} design column.")
    }
    X[missing_rows, column] <- values[missing_rows]
  }
  X
}

drm_prediction_matrix <- function(object, newdata, dpar) {
  if (is.null(newdata)) {
    return(drm_reconcile_missing_predictor_matrix(
      object, object$model$X[[dpar]], dpar
    ))
  }
  if (!is.data.frame(newdata)) {
    cli::cli_abort("{.arg newdata} must be a data frame.")
  }
  if (
    identical(object$model$model_type, "cumulative_logit") &&
      identical(dpar, "mu")
  ) {
    return(ordinal_mu_model_matrix(object$model$terms[[dpar]], newdata))
  }
  drm_fixed_effect_matrix(
    object$model$terms[[dpar]],
    newdata,
    sparse = drm_fixed_effect_is_sparse(object, dpar)
  )
}

drm_fixed_effect_basis <- function(
  object,
  newdata = NULL,
  dpar = NULL,
  covariance = FALSE
) {
  if (is.null(dpar)) {
    dpar <- object$model$dpars[[1L]]
  }
  dpar <- match.arg(dpar, names(object$coefficients))
  validate_fixed_effect_basis_covariance(covariance)
  if (is_random_scale_dpar(object, dpar)) {
    cli::cli_abort(c(
      "Fixed-effect basis matrices are not defined for random-effect scale parameter {.val {dpar}}.",
      i = "Use {.fn predict} for fitted random-effect scale predictions."
    ))
  }
  supplied_newdata <- !is.null(newdata)
  if (!is.null(newdata)) {
    newdata <- drm_prepare_prediction_newdata(object, newdata, dpar)
  }

  X <- drm_prediction_matrix(object, newdata, dpar)
  if (isTRUE(supplied_newdata)) {
    drm_validate_prediction_matrix_finite(X, dpar)
  }
  beta <- object$coefficients[[dpar]]
  if (!identical(colnames(X), names(beta))) {
    cli::cli_abort(c(
      "Could not align the {.val {dpar}} design matrix with fitted coefficients.",
      i = "Check that factor levels and predictor columns match the fitted model."
    ))
  }

  offset <- drm_prediction_offset(object, newdata, dpar)
  if (length(offset) != nrow(X)) {
    cli::cli_abort(
      "Internal error: fixed-effect basis offsets do not match design-matrix rows."
    )
  }

  V <- NULL
  if (isTRUE(covariance)) {
    V <- drm_fixed_effect_basis_covariance(object, dpar, names(beta))
  }

  list(
    dpar = dpar,
    X = X,
    bhat = beta,
    V = V,
    offset = offset,
    eta = as.vector(X %*% beta) + offset,
    link = drm_dpar_link(object, dpar),
    coefficient_labels = paste0(dpar, ":", names(beta))
  )
}

drm_prepare_prediction_newdata <- function(object, newdata, dpar) {
  if (!is.data.frame(newdata)) {
    return(newdata)
  }
  newdata <- drm_prepare_missing_predictor_prediction_newdata(object, newdata, dpar)
  template <- drm_prediction_template_data(object, dpar)
  if (!is.data.frame(template)) {
    return(newdata)
  }
  template <- drm_prepare_missing_predictor_prediction_template(object, template, dpar)

  drm_prepare_model_matrix_newdata(
    newdata = newdata,
    dpar = dpar,
    terms = object$model$terms[[dpar]],
    template = template
  )
}

drm_prepare_model_matrix_newdata <- function(newdata, dpar, terms, template) {
  needed <- all.vars(stats::delete.response(terms))
  missing <- setdiff(needed, names(newdata))
  if (length(missing) > 0L) {
    cli::cli_abort(c(
      "New prediction data is missing required predictor{?s} for {.code dpar = \"{dpar}\"}.",
      i = "Missing predictor{?s}: {.var {missing}}."
    ))
  }
  for (name in intersect(names(newdata), needed)) {
    if (anyNA(newdata[[name]])) {
      cli::cli_abort(c(
        "New prediction data contains missing value{?s} for required predictor {.var {name}}.",
        i = "Supply complete prediction rows before calling {.fn predict} or {.pkg emmeans}."
      ))
    }
    if (is.numeric(newdata[[name]]) && any(!is.finite(newdata[[name]]))) {
      cli::cli_abort(c(
        "New prediction data contains non-finite value{?s} for required predictor {.var {name}}.",
        i = "Supply finite prediction values before calling {.fn predict} or {.pkg emmeans}."
      ))
    }
  }
  bare_only <- drm_bare_only_term_variables(terms)
  for (name in intersect(intersect(names(newdata), names(template)), needed)) {
    source <- template[[name]]
    if (is.character(source) && name %in% bare_only) {
      # model.matrix() builds levels from the rows it is given, so a character
      # training column used as a bare term must be rebuilt with the fitted
      # levels before a partial prediction grid reaches it (#1497). A column
      # that also appears inside a transform (as.numeric(x), I(x * z), mi(x))
      # is left alone: the transform must see the raw values.
      source <- factor(source)
    }
    if (!is.factor(source)) {
      next
    }
    value <- as.character(newdata[[name]])
    unknown <- setdiff(unique(value), levels(source))
    if (length(unknown) > 0L) {
      cli::cli_abort(c(
        "New prediction data contains unknown factor level{?s} for {.var {name}}.",
        i = "Unknown level{?s}: {.val {unknown}}.",
        i = "Fitted level{?s}: {.val {levels(source)}}."
      ))
    }
    newdata[[name]] <- factor(
      value,
      levels = levels(source),
      ordered = is.ordered(source)
    )
  }
  newdata
}

# Variables that enter the right-hand side only as bare names, never inside a
# transform or marker call (#1497 review).
drm_bare_only_term_variables <- function(terms) {
  vars <- as.list(attr(stats::delete.response(terms), "variables"))[-1L]
  if (length(vars) == 0L) {
    return(character())
  }
  bare <- vapply(vars, is.name, logical(1L))
  bare_names <- vapply(vars[bare], as.character, character(1L))
  inside <- unique(unlist(lapply(vars[!bare], all.vars), use.names = FALSE))
  setdiff(bare_names, inside)
}

drm_prepare_random_scale_newdata <- function(sd_target, newdata, dpar) {
  template <- sd_target$model_frame_list[[dpar]]
  if (!is.data.frame(template)) {
    return(newdata)
  }
  drm_prepare_model_matrix_newdata(
    newdata = newdata,
    dpar = dpar,
    terms = sd_target$terms_list[[dpar]],
    template = template
  )
}

drm_validate_prediction_matrix_finite <- function(X, dpar) {
  terms <- drm_nonfinite_prediction_matrix_terms(X)
  if (length(terms) == 0L) {
    return(invisible(X))
  }
  cli::cli_abort(c(
    "New prediction data produces non-finite design-matrix value{?s} for {.code dpar = \"{dpar}\"}.",
    i = "Affected model column{?s}: {.val {terms}}.",
    i = "Check transformed predictors such as {.code log(x)} or {.code sqrt(x)} before prediction or post-fit grid helpers."
  ))
}

drm_nonfinite_prediction_matrix_terms <- function(X) {
  if (inherits(X, "sparseMatrix")) {
    bad <- !is.finite(X@x)
    if (!any(bad)) {
      return(character())
    }
    columns <- unique(findInterval(which(bad) - 1L, X@p[-1L]) + 1L)
    return(drm_prediction_matrix_term_names(X, columns))
  }
  bad <- !is.finite(as.matrix(X))
  if (!any(bad)) {
    return(character())
  }
  drm_prediction_matrix_term_names(X, which(colSums(bad) > 0L))
}

drm_prediction_matrix_term_names <- function(X, columns) {
  names <- colnames(X)
  if (is.null(names)) {
    return(paste0("column ", columns))
  }
  names[columns]
}

drm_prediction_template_data <- function(object, dpar) {
  model_frames <- object$model$model_frame
  if (is.list(model_frames) && is.data.frame(model_frames[[dpar]])) {
    return(model_frames[[dpar]])
  }
  if (is.data.frame(object$data)) {
    return(object$data)
  }
  if (is.data.frame(object$model$data)) {
    return(object$model$data)
  }
  NULL
}

validate_fixed_effect_basis_covariance <- function(covariance) {
  if (
    !is.logical(covariance) ||
      length(covariance) != 1L ||
      is.na(covariance)
  ) {
    cli::cli_abort(
      "{.arg covariance} must be a single {.code TRUE} or {.code FALSE}."
    )
  }
  invisible(covariance)
}

drm_fixed_effect_basis_covariance <- function(object, dpar, terms) {
  labels <- paste0(dpar, ":", terms)
  V <- vcov(object)
  missing <- setdiff(labels, row.names(V))
  if (length(missing) > 0L) {
    cli::cli_abort(c(
      "Could not align the {.val {dpar}} covariance matrix with fitted coefficients.",
      i = "Missing coefficient label{?s}: {.val {missing}}."
    ))
  }
  out <- V[labels, labels, drop = FALSE]
  if (anyNA(out)) {
    cli::cli_abort(c(
      "Fixed-effect covariance for {.val {dpar}} contains unavailable entries.",
      i = "Refit with standard errors enabled and check the fitted coefficient map."
    ))
  }
  dimnames(out) <- list(terms, terms)
  out
}

drm_prediction_offset <- function(object, newdata, dpar) {
  offset <- object$model$offset[[dpar]]
  if (is.null(offset)) {
    if (is.null(newdata)) {
      return(rep(0, nrow(object$model$X[[dpar]])))
    }
    return(rep(0, nrow(newdata)))
  }
  if (is.null(newdata)) {
    return(offset)
  }
  mf <- stats::model.frame(
    object$model$terms[[dpar]],
    data = newdata,
    na.action = stats::na.pass
  )
  out <- stats::model.offset(mf)
  if (is.null(out)) {
    return(rep(0, nrow(newdata)))
  }
  out <- as.numeric(out)
  if (length(out) != nrow(newdata) || any(!is.finite(out))) {
    cli::cli_abort(c(
      "Offset terms in {.arg newdata} must evaluate to one finite value per row.",
      "i" = "For exposure prediction, supply positive finite exposure values used by {.code offset(log(exposure))}."
    ))
  }
  out
}

# Shared gaussian total-observation-SD formula: sqrt(known sampling variance +
# sigma^2). Both observation_sigma() (this file) and
# drm_gaussian_obs_sigma() (R/family-dpq.R, the {d,p,q} params-table path)
# route through this single source of truth instead of independently
# re-deriving sqrt(V_known + sigma^2) (Emmy's dedup, DO-T3 batch A prelude).
drm_total_obs_sd <- function(v_known, sigma) {
  sqrt(v_known + sigma^2)
}

observation_sigma <- function(object, sigma = NULL) {
  if (is.null(sigma)) {
    sigma <- predict(object, dpar = "sigma")
  }
  drm_total_obs_sd(known_v_diag(object), sigma)
}

observation_covariance <- function(object, sigma = NULL) {
  if (is.null(sigma)) {
    sigma <- predict(object, dpar = "sigma")
  }
  sigma2 <- sigma^2
  if (identical(object$model$V_known_type, "matrix")) {
    out <- object$model$V_known
    diag(out) <- diag(out) + sigma2
    return(out)
  }
  diag(known_v_diag(object) + sigma2, nrow = length(sigma2))
}

bivariate_observation_covariance <- function(object, sigma1 = NULL, sigma2 = NULL) {
  n <- length(object$model$y1)
  out <- if (identical(object$model$V_known_type, "matrix")) {
    object$model$V_known
  } else {
    matrix(0, nrow = 2L * n, ncol = 2L * n)
  }
  if (is.null(sigma1)) {
    sigma1 <- predict(object, dpar = "sigma1")
  }
  if (is.null(sigma2)) {
    sigma2 <- predict(object, dpar = "sigma2")
  }
  rho12 <- predict(object, dpar = "rho12")
  i1 <- seq.int(1L, by = 2L, length.out = n)
  i2 <- i1 + 1L
  cov12 <- rho12 * sigma1 * sigma2
  out[cbind(i1, i1)] <- out[cbind(i1, i1)] + sigma1^2
  out[cbind(i2, i2)] <- out[cbind(i2, i2)] + sigma2^2
  out[cbind(i1, i2)] <- out[cbind(i1, i2)] + cov12
  out[cbind(i2, i1)] <- out[cbind(i2, i1)] + cov12
  out
}

stack_biv_response <- function(y1, y2) {
  as.vector(rbind(y1, y2))
}

unstack_biv_response <- function(y) {
  n <- length(y) / 2L
  cbind(
    y1 = y[seq.int(1L, by = 2L, length.out = n)],
    y2 = y[seq.int(2L, by = 2L, length.out = n)]
  )
}

known_v_diag <- function(object) {
  if (!is.null(object$model$V_known_diag)) {
    return(object$model$V_known_diag)
  }
  if (is.matrix(object$model$V_known)) {
    return(diag(object$model$V_known))
  }
  object$model$V_known
}

lognormal_mean <- function(object) {
  mu <- predict(object, dpar = "mu")
  sigma <- predict(object, dpar = "sigma")
  exp(mu + 0.5 * sigma^2)
}

truncated_nbinom2_p0 <- function(mu, sigma) {
  # SAME conversion drm_nbinom2_size() (R/family-dpq.R) uses -- closed in
  # DO-T3 batch C (Emmy's dedup; batch A left this inline).
  stats::dnbinom(0, size = drm_nbinom2_size(sigma), mu = mu)
}

truncated_nbinom2_prob_positive <- function(mu, sigma) {
  pmax(1 - truncated_nbinom2_p0(mu, sigma), .Machine$double.eps)
}

truncated_nbinom2_mean <- function(mu, sigma) {
  mu / truncated_nbinom2_prob_positive(mu, sigma)
}

truncated_nbinom2_variance <- function(mu, sigma) {
  q <- truncated_nbinom2_prob_positive(mu, sigma)
  second_moment <- (mu + (1 + sigma^2) * mu^2) / q
  pmax(second_moment - (mu / q)^2, .Machine$double.eps)
}

hurdle_nbinom2_mean <- function(mu, sigma, hu) {
  (1 - hu) * truncated_nbinom2_mean(mu, sigma)
}

hurdle_nbinom2_variance <- function(mu, sigma, hu) {
  positive_mean <- truncated_nbinom2_mean(mu, sigma)
  positive_var <- truncated_nbinom2_variance(mu, sigma)
  pmax(
    (1 - hu) * positive_var + hu * (1 - hu) * positive_mean^2,
    .Machine$double.eps
  )
}

beta_binomial_proportion_variance <- function(mu, sigma, trials) {
  pmax(
    mu * (1 - mu) * (1 + trials * sigma^2) / (trials * (1 + sigma^2)),
    .Machine$double.eps
  )
}

zero_one_beta_mean <- function(mu, zoi, coi) {
  (1 - zoi) * mu + zoi * coi
}

zero_one_beta_variance <- function(mu, sigma, zoi, coi) {
  beta_var <- mu * (1 - mu) * sigma^2 / (1 + sigma^2)
  second_moment <- (1 - zoi) * (beta_var + mu^2) + zoi * coi
  pmax(second_moment - zero_one_beta_mean(mu, zoi, coi)^2, .Machine$double.eps)
}

ordinal_category_probabilities <- function(object, newdata = NULL, eta = NULL) {
  if (is.null(eta)) {
    eta <- predict(object, newdata = newdata, dpar = "mu", type = "link")
  }
  cutpoints <- unname(object$ordinal$cutpoints)
  n <- length(eta)
  n_categories <- length(cutpoints) + 1L
  z <- matrix(
    cutpoints,
    nrow = n,
    ncol = length(cutpoints),
    byrow = TRUE
  ) -
    eta
  log_cumulative <- stats::plogis(z, log.p = TRUE)
  log_prob <- matrix(NA_real_, nrow = n, ncol = n_categories)
  log_prob[, 1L] <- log_cumulative[, 1L]
  if (n_categories > 2L) {
    upper <- z[, 2L:(n_categories - 1L), drop = FALSE]
    lower <- z[, 1L:(n_categories - 2L), drop = FALSE]
    log_prob[, 2L:(n_categories - 1L)] <-
      ordinal_log_inv_logit_diff(upper, lower)
  }
  log_prob[, n_categories] <- stats::plogis(
    z[, n_categories - 1L],
    lower.tail = FALSE,
    log.p = TRUE
  )
  out <- exp(log_prob)
  out <- pmax(out, 0)
  out <- out / rowSums(out)
  colnames(out) <- object$ordinal$levels
  out
}

ordinal_log_inv_logit_diff <- function(upper, lower) {
  upper +
    ordinal_log1mexp(lower - upper) -
    ordinal_log1pexp(upper) -
    ordinal_log1pexp(lower)
}

ordinal_log1pexp <- function(x) {
  ifelse(x > 0, x + log1p(exp(-x)), log1p(exp(x)))
}

ordinal_log1mexp <- function(log_p) {
  ifelse(
    log_p < log(0.5),
    log1p(-exp(log_p)),
    log(-expm1(log_p))
  )
}

ordinal_expected_score <- function(object, newdata = NULL) {
  prob <- ordinal_category_probabilities(object, newdata = newdata)
  as.vector(prob %*% seq_len(ncol(prob)))
}

ordinal_score_variance <- function(object, newdata = NULL) {
  prob <- ordinal_category_probabilities(object, newdata = newdata)
  scores <- seq_len(ncol(prob))
  mean_score <- as.vector(prob %*% scores)
  second_moment <- as.vector(prob %*% (scores^2))
  second_moment - mean_score^2
}

drm_fitted_response <- function(object) {
  if (identical(object$model$model_type, "biv_gaussian")) {
    return(cbind(
      mu1 = predict.drmTMB(object, dpar = "mu1"),
      mu2 = predict.drmTMB(object, dpar = "mu2")
    ))
  }
  if (identical(object$model$model_type, "biv_student")) {
    return(cbind(
      mu1 = predict.drmTMB(object, dpar = "mu1"),
      mu2 = predict.drmTMB(object, dpar = "mu2")
    ))
  }
  if (identical(object$model$model_type, "biv_lognormal")) {
    mu1 <- predict.drmTMB(object, dpar = "mu1")
    mu2 <- predict.drmTMB(object, dpar = "mu2")
    sigma1 <- predict.drmTMB(object, dpar = "sigma1")
    sigma2 <- predict.drmTMB(object, dpar = "sigma2")
    return(cbind(
      mu1 = exp(mu1 + sigma1^2 / 2),
      mu2 = exp(mu2 + sigma2^2 / 2)
    ))
  }
  if (identical(object$model$model_type, "lognormal")) {
    return(lognormal_mean(object))
  }
  if (identical(object$model$model_type, "gamma")) {
    return(predict.drmTMB(object, dpar = "mu"))
  }
  if (identical(object$model$model_type, "tweedie")) {
    return(predict.drmTMB(object, dpar = "mu"))
  }
  if (identical(object$model$model_type, "beta")) {
    return(predict.drmTMB(object, dpar = "mu"))
  }
  if (identical(object$model$model_type, "zero_one_beta")) {
    mu <- predict.drmTMB(object, dpar = "mu")
    zoi <- predict.drmTMB(object, dpar = "zoi")
    coi <- predict.drmTMB(object, dpar = "coi")
    return(zero_one_beta_mean(mu, zoi, coi))
  }
  if (identical(object$model$model_type, "beta_binomial")) {
    return(predict.drmTMB(object, dpar = "mu"))
  }
  if (identical(object$model$model_type, "binomial")) {
    return(predict.drmTMB(object, dpar = "mu"))
  }
  if (identical(object$model$model_type, "cumulative_logit")) {
    return(ordinal_expected_score(object))
  }
  if (identical(object$model$model_type, "poisson")) {
    return(predict.drmTMB(object, dpar = "mu"))
  }
  if (identical(object$model$model_type, "zi_poisson")) {
    mu <- predict.drmTMB(object, dpar = "mu")
    zi <- predict.drmTMB(object, dpar = "zi")
    return((1 - zi) * mu)
  }
  if (identical(object$model$model_type, "nbinom2")) {
    return(predict.drmTMB(object, dpar = "mu"))
  }
  if (identical(object$model$model_type, "truncated_nbinom2")) {
    mu <- predict.drmTMB(object, dpar = "mu")
    sigma <- predict.drmTMB(object, dpar = "sigma")
    return(truncated_nbinom2_mean(mu, sigma))
  }
  if (identical(object$model$model_type, "hurdle_nbinom2")) {
    mu <- predict.drmTMB(object, dpar = "mu")
    sigma <- predict.drmTMB(object, dpar = "sigma")
    hu <- predict.drmTMB(object, dpar = "hu")
    return(hurdle_nbinom2_mean(mu, sigma, hu))
  }
  if (identical(object$model$model_type, "zi_nbinom2")) {
    mu <- predict.drmTMB(object, dpar = "mu")
    zi <- predict.drmTMB(object, dpar = "zi")
    return((1 - zi) * mu)
  }
  if (
    identical(object$model$model_type, "gaussian") ||
      identical(object$model$model_type, "student") ||
      identical(object$model$model_type, "skew_normal")
  ) {
    return(predict.drmTMB(object, dpar = "mu"))
  }
  cli::cli_abort(
    "Internal error: no fitted-response rule for model type {.val {object$model$model_type}}."
  )
}

# Route a sigma-type linear predictor through the same soft clamp the TMB
# likelihood applies for scale-bearing families (Dinnage audit M2, issue
# #1308), so predict()/sigma()/residuals()/fitted()/simulate() report the
# scale the likelihood actually evaluated instead of the raw, unclamped
# predictor. A no-op for every other dpar and for families the clamp does not
# cover; see drm_clamped_scale_families() and drm_softclamp_log_sd()
# (R/drmTMB.R).
drm_clamped_sigma_eta <- function(object, dpar, eta) {
  if (
    !dpar %in% c("sigma", "sigma1", "sigma2") ||
      !isTRUE(object$model$model_type %in% drm_clamped_scale_families())
  ) {
    return(eta)
  }
  drm_softclamp_log_sd(eta, object$model$tmb_data)
}

drm_inverse_link <- function(object, dpar, eta) {
  link <- drm_dpar_link(object, dpar)
  switch(
    link,
    identity = eta,
    log = exp(eta),
    logit = stats::plogis(eta),
    probit = stats::pnorm(eta),
    cloglog = -expm1(-exp(eta)),
    logm2 = 2 + exp(eta),
    logit12 = 1 + stats::plogis(eta),
    atanh_guarded = rho_response(eta),
    atanh_re_guarded = rho_response(eta, guard = DRM_RE_CORR_GUARD),
    atanh_phylo_guarded = rho_response(eta, guard = 0.999999),
    cli::cli_abort("Internal error: unknown inverse link {.val {link}}.")
  )
}

drm_dpar_link <- function(object, dpar) {
  # Canonical runtime link table (issue #713.2). Every runtime link query
  # (predict-parameters.R, profile.R, and elsewhere in methods.R) routes through
  # this function, so this model_type -> per-dpar-link switch is the single
  # source of truth for link resolution. It intentionally covers more model
  # types than the per-family `links` fields in R/family.R (poisson, binomial,
  # gamma, tweedie, the zero-inflated / hurdle counts, etc. reach a fitted spec
  # without a matching R/family.R constructor) and adds the corpair() /
  # atanh_re_guarded cases. When you add or change a family's links, update BOTH
  # this switch and the corresponding `links = c(...)` field in R/family.R so the
  # constructor metadata and the runtime table stay consistent. Documented, not
  # refactored: unifying the two would require every model_type to carry a
  # drm_family object and is deferred to avoid destabilizing link resolution.
  if (is_random_scale_dpar(object, dpar)) {
    return("log")
  }
  if (startsWith(dpar, "corpair(")) {
    # A modelled phylogenetic correlation keeps TMB's 0.999999 guard (rho_node);
    # a modelled group correlation uses the random-effect guard (#1190).
    if (isTRUE(has_modelled_phylo_correlation(object$model))) {
      return("atanh_phylo_guarded")
    }
    return("atanh_re_guarded")
  }
  links <- switch(
    object$model$model_type,
    gaussian = c(mu = "identity", sigma = "log"),
    student = c(mu = "identity", sigma = "log", nu = "logm2"),
    skew_normal = c(mu = "identity", sigma = "log", nu = "identity"),
    lognormal = c(mu = "identity", sigma = "log"),
    gamma = c(mu = "log", sigma = "log"),
    tweedie = c(mu = "log", sigma = "log", nu = "logit12"),
    beta = c(mu = "logit", sigma = "log"),
    zero_one_beta = c(
      mu = "logit",
      sigma = "log",
      zoi = "logit",
      coi = "logit"
    ),
    beta_binomial = c(mu = "logit", sigma = "log"),
    binomial = c(mu = if (is.null(object$model$link)) "logit" else object$model$link),
    cumulative_logit = c(mu = "identity"),
    poisson = c(mu = "log"),
    zi_poisson = c(mu = "log", zi = "logit"),
    nbinom2 = c(mu = "log", sigma = "log"),
    truncated_nbinom2 = c(mu = "log", sigma = "log"),
    hurdle_nbinom2 = c(mu = "log", sigma = "log", hu = "logit"),
    zi_nbinom2 = c(mu = "log", sigma = "log", zi = "logit"),
    biv_gaussian = c(
      mu1 = "identity",
      mu2 = "identity",
      sigma1 = "log",
      sigma2 = "log",
      rho12 = "atanh_guarded"
    ),
    biv_lognormal = c(
      mu1 = "identity",
      mu2 = "identity",
      sigma1 = "log",
      sigma2 = "log",
      rho12 = "atanh_guarded"
    ),
    biv_student = c(
      mu1 = "identity",
      mu2 = "identity",
      sigma1 = "log",
      sigma2 = "log",
      nu = "logm2",
      rho12 = "atanh_guarded"
    ),
    NULL
  )
  if (is.null(links)) {
    cli::cli_abort(
      "Internal error: no link table for model type {.val {object$model$model_type}}."
    )
  }
  if (!dpar %in% names(links)) {
    cli::cli_abort(
      "Internal error: no link entry for distributional parameter {.val {dpar}}."
    )
  }
  unname(links[[dpar]])
}

# Guard for random-effect correlations, rho = DRM_RE_CORR_GUARD * tanh(eta).
# Must equal the Type(0.99999999) at the rho_mu_re / rho_sigma_re /
# rho_mu_sigma_re / rho_mu_group sites in src/drmTMB.cpp, so the R-side
# response scale reproduces TMB's reported correlation (#1190). The residual
# rho12 and phylogenetic correlations keep 0.999999.
DRM_RE_CORR_GUARD <- 0.99999999

rho_response <- function(eta, guard = 0.999999) {
  guard * tanh(eta)
}

coefficient_labels <- function(object) {
  unlist(
    lapply(names(object$coefficients), function(dpar) {
      paste0(dpar, ":", names(object$coefficients[[dpar]]))
    }),
    use.names = FALSE
  )
}

has_mu_random_effects <- function(object) {
  has_ordinary_mu_random_effects(object) ||
    (has_structured_mu_effect(object) &&
      any(sub("[0-9]+$", "", phylo_mu_endpoint_dpars(
        object$model$structured$phylo_mu
      )) == "mu")) ||
    has_mu_covariance_block_random_effects(object)
}

has_ordinary_mu_random_effects <- function(object) {
  length(object$random_effects$mu$values) > 0L
}

has_mu_random_intercepts <- has_mu_random_effects

has_phylo_mu_effect <- function(object) {
  object$model$model_type %in%
    c(
      "gaussian", "biv_gaussian", "poisson", "nbinom2", "zi_nbinom2", "lognormal",
      "gamma", "beta", "zero_one_beta"
    ) &&
    isTRUE(object$model$structured$phylo_mu$has) &&
    identical(structured_mu_type(object$model$structured$phylo_mu), "phylo")
}

has_spatial_mu_effect <- function(object) {
  object$model$model_type %in%
    c("gaussian", "biv_gaussian", "poisson", "nbinom2") &&
    isTRUE(object$model$structured$phylo_mu$has) &&
    identical(structured_mu_type(object$model$structured$phylo_mu), "spatial")
}

has_structured_mu_effect <- function(object) {
  object$model$model_type %in%
    c(
      "gaussian", "biv_gaussian", "binomial", "poisson", "nbinom2", "lognormal",
      "gamma", "beta", "zero_one_beta"
    ) &&
    (isTRUE(object$model$structured$phylo_mu$has) ||
      isTRUE(object$model$structured$phylo_mu2$has))
}

n_mu_random_effect_terms <- function(object) {
  length(object$model$random$mu$labels) +
    n_mu_covariance_block_random_effect_terms(object) +
    if (has_structured_mu_effect(object) &&
      any(sub("[0-9]+$", "", phylo_mu_endpoint_dpars(
        object$model$structured$phylo_mu
      )) == "mu")) {
      structured_mu_q(object$model$structured$phylo_mu)
    } else {
      0L
    }
}

has_sigma_random_effects <- function(object) {
  object$model$model_type %in%
    c("gaussian", "biv_gaussian", "nbinom2", "zi_nbinom2", "lognormal", "gamma", "beta_binomial") &&
    (length(object$random_effects$sigma$values) > 0L ||
      (isTRUE(object$model$structured$phylo_mu$has) &&
        any(sub("[0-9]+$", "", phylo_mu_endpoint_dpars(
          object$model$structured$phylo_mu
        )) == "sigma")))
}

has_covariance_block_random_effects <- function(object) {
  is.list(object$random_effects$covariance_blocks) &&
    !is.null(object$random_effects$covariance_blocks$contribution) &&
    ncol(object$random_effects$covariance_blocks$contribution) > 0L
}

has_atom_probability_random_effects <- function(object, dpar) {
  identical(object$model$model_type, "zero_one_beta") &&
    dpar %in% c("zoi", "coi") &&
    is.list(object$random_effects[[dpar]]) &&
    length(object$random_effects[[dpar]]$values) > 0L
}

has_mu_covariance_block_random_effects <- function(object) {
  has_covariance_block_random_effects(object) &&
    n_mu_covariance_block_random_effect_terms(object) > 0L
}

n_mu_covariance_block_random_effect_terms <- function(object) {
  registry <- object$model$random$covariance_blocks
  if (!is.list(registry)) {
    return(0L)
  }
  members <- qgt2_covariance_members(registry)
  if (nrow(members) == 0L) {
    return(0L)
  }
  sum(grepl("^mu", members$dpar))
}

sigma_random_effect_dpars <- function(object) {
  dpars <- object$model$random$sigma$dpars
  if (length(dpars) == 0L) {
    character()
  } else {
    unique(dpars)
  }
}

mu_random_effect_dpars <- function(object) {
  dpars <- object$model$random$mu$dpars
  if (length(dpars) == 0L) {
    character()
  } else {
    unique(dpars)
  }
}

is_random_scale_dpar <- function(object, dpar) {
  # The fitted target registry, rather than the response family, determines
  # whether this is a latent-SD submodel. Family builders own admission.
  ordinary <- object$model$random_scale$mu
  if (
    is.list(ordinary) && isTRUE(ordinary$n_models > 0L) &&
      dpar %in% ordinary$dpars
  ) {
    return(TRUE)
  }
  sigma <- object$model$random_scale$sigma
  if (
    is.list(sigma) && isTRUE(sigma$n_models > 0L) &&
      dpar %in% sigma$dpars
  ) {
    return(TRUE)
  }
  structured <- object$model$random_scale$phylo
  if (is.list(structured) && isTRUE(structured$n_models > 0L) &&
      dpar %in% structured$dpars) {
    return(TRUE)
  }
  structured2 <- object$model$random_scale$phylo2
  is.list(structured2) && isTRUE(structured2$n_models > 0L) &&
    dpar %in% structured2$dpars
}

predict_random_scale_dpar <- function(
  object,
  dpar,
  newdata = NULL,
  type = c("response", "link")
) {
  type <- match.arg(type)
  sd_target <- if (dpar %in% object$model$random_scale$mu$dpars) {
    object$model$random_scale$mu
  } else if (
    is.list(object$model$random_scale$sigma) &&
      dpar %in% object$model$random_scale$sigma$dpars
  ) {
    object$model$random_scale$sigma
  } else if (
    is.list(object$model$random_scale$phylo) &&
      dpar %in% object$model$random_scale$phylo$dpars
  ) {
    object$model$random_scale$phylo
  } else if (
    is.list(object$model$random_scale$phylo2) &&
      dpar %in% object$model$random_scale$phylo2$dpars
  ) {
    object$model$random_scale$phylo2
  } else {
    NULL
  }
  if (is.null(sd_target)) {
    cli::cli_abort("Unknown random-effect scale parameter {.val {dpar}}.")
  }
  if (is.null(newdata)) {
    X <- sd_target$X_list[[dpar]]
    names_out <- sd_target$group_levels_list[[dpar]]
  } else {
    if (!is.data.frame(newdata)) {
      cli::cli_abort("{.arg newdata} must be a data frame.")
    }
    newdata <- drm_prepare_random_scale_newdata(sd_target, newdata, dpar)
    X <- stats::model.matrix(sd_target$terms_list[[dpar]], data = newdata)
    drm_validate_prediction_matrix_finite(X, dpar)
    names_out <- rownames(newdata)
  }
  eta <- as.vector(X %*% object$coefficients[[dpar]])
  # The kernel soft-clamps this same log(sd) predictor before exponentiating
  # it (src/drmTMB.cpp ~2482-2485, drm_softclamp_log_sd), and the fit's own
  # summary agrees: sd_mu_group_values()/sd_phylo_group_values()
  # (R/drmTMB.R:23062-23092) apply drm_softclamp_log_sd() then
  # drm_exp_sd_logscale_guarded() to the identical eta. Without the same
  # clamp here, predict(dpar = "sd(...)") reported the raw, unclamped
  # predictor and disagreed with fit$sdpars by up to ~25x on a fixture where
  # the clamp band binds (Dinnage audit M2 review, item 2).
  eta <- drm_softclamp_log_sd(eta, object$model$tmb_data)
  if (type == "link") {
    stats::setNames(eta, names_out)
  } else {
    stats::setNames(drm_exp_sd_logscale_guarded(eta), names_out)
  }
}

mu_random_effect_contribution <- function(object, dpar = NULL) {
  values <- object$random_effects$mu$values
  index <- object$model$random$mu$index
  design_value <- object$model$random$mu$value
  if (!is.null(dpar)) {
    terms <- which(object$model$random$mu$dpars %in% dpar)
    index <- index[, terms, drop = FALSE]
    design_value <- design_value[, terms, drop = FALSE]
  }
  rowSums(matrix(values[index], nrow = nrow(index)) * design_value)
}

mu_random_intercept_contribution <- mu_random_effect_contribution

phylo_mu_contribution <- function(object, dpar = NULL) {
  contribution <- phylo_mu_primary_contribution(object, dpar = dpar)
  phylo_mu2 <- object$model$structured$phylo_mu2
  if (
    identical(object$model$model_type, "binomial") &&
      isTRUE(phylo_mu2$has) && (is.null(dpar) || "mu" %in% dpar)
  ) {
    contribution <- contribution + phylo_mu2_contribution(object)
  }
  contribution
}

phylo_mu2_contribution <- function(object) {
  phylo_mu2 <- object$model$structured$phylo_mu2
  if (!is.list(phylo_mu2) || !isTRUE(phylo_mu2$has)) {
    return(rep(0, object$nobs))
  }
  key <- structured_mu_random_effect_key(
    phylo_mu2,
    object$model$model_type
  )
  values <- object$random_effects[[key]]$values
  index <- phylo_mu2$observation_node_index
  design_value <- as.numeric(phylo_mu2$value[, 1L])
  unname(values[index] * design_value)
}

phylo_mu_primary_contribution <- function(object, dpar = NULL) {
  phylo_mu <- object$model$structured$phylo_mu
  key <- structured_mu_random_effect_key(phylo_mu, object$model$model_type)
  values <- object$random_effects[[key]]$values
  index <- phylo_mu$observation_node_index
  if (identical(object$model$model_type, "biv_gaussian")) {
    dpars <- phylo_mu_endpoint_dpars(phylo_mu)
    q <- structured_mu_q(phylo_mu)
    dpar <- match.arg(dpar, unique(dpars))
    endpoint <- which(dpars %in% dpar)
    value_matrix <- matrix(
      unname(values[seq_len(q * phylo_mu$n_re)]),
      nrow = phylo_mu$n_re,
      ncol = q
    )
    return(unname(rowSums(
      value_matrix[index, endpoint, drop = FALSE] *
        phylo_mu$value[, endpoint, drop = FALSE]
    )))
  }
  q <- structured_mu_q(phylo_mu)
  if (q > 1L && is.matrix(phylo_mu$value)) {
    n_re <- phylo_mu$n_re
    endpoint <- seq_len(q)
    if (!is.null(dpar)) {
      endpoint_dpars <- phylo_mu_endpoint_dpars(phylo_mu)
      endpoint <- which(endpoint_dpars %in% dpar)
    }
    if (length(endpoint) == 0L) {
      return(rep(0, object$nobs))
    }
    value_matrix <- matrix(
      unname(values[seq_len(q * n_re)]),
      nrow = n_re,
      ncol = q
    )
    return(unname(rowSums(
      value_matrix[index, endpoint, drop = FALSE] *
        phylo_mu$value[, endpoint, drop = FALSE]
    )))
  }
  design_value <- phylo_mu$value
  if (is.matrix(design_value)) {
    design_value <- design_value[, 1L]
  }
  if (length(design_value) != length(index)) {
    cli::cli_abort(
      "Internal error: structured-effect design values do not align with observation nodes."
    )
  }
  unname(values[index] * design_value)
}

sigma_random_effect_contribution <- function(object, dpar = NULL) {
  values <- object$random_effects$sigma$values
  index <- object$model$random$sigma$index
  design_value <- object$model$random$sigma$value
  if (!is.null(dpar)) {
    terms <- which(object$model$random$sigma$dpars %in% dpar)
    index <- index[, terms, drop = FALSE]
    design_value <- design_value[, terms, drop = FALSE]
  }
  rowSums(matrix(values[index], nrow = nrow(index)) * design_value)
}

atom_probability_random_effect_contribution <- function(object, dpar) {
  dpar <- match.arg(dpar, c("zoi", "coi"))
  values <- object$random_effects[[dpar]]$values
  re <- object$model$random[[dpar]]
  rowSums(
    matrix(values[re$index], nrow = nrow(re$index)) * re$value
  )
}

covariance_block_random_effect_contribution <- function(object, dpar) {
  block_re <- object$random_effects$covariance_blocks
  members <- block_re$members
  cols <- which(members$dpar == dpar)
  if (length(cols) == 0L) {
    return(rep(0, object$nobs))
  }
  rowSums(block_re$contribution[, cols, drop = FALSE])
}

# `re.form` follows lme4 (#1487): NA or ~0 = marginal (fresh random effects),
# NULL = conditional on the fitted random effects. Returns TRUE for marginal.
drm_simulate_re_form_marginal <- function(re.form) {
  if (is.null(re.form)) {
    return(FALSE)
  }
  if (identical(re.form, NA) || drm_is_zero_re_formula(re.form)) {
    return(TRUE)
  }
  cli::cli_abort(c(
    "{.arg re.form} must be {.code NA}, {.code ~0}, or {.code NULL}.",
    "i" = "{.code NA} (the default) or {.code ~0} draws fresh random effects for every replicate (marginal simulation).",
    "i" = "{.code NULL} holds every random effect fixed at its fitted conditional-mode estimate (conditional simulation)."
  ))
}

drm_is_zero_re_formula <- function(x) {
  if (!inherits(x, "formula") || length(x) != 2L) {
    return(FALSE)
  }
  rhs <- x[[2L]]
  is.numeric(rhs) && length(rhs) == 1L && identical(as.numeric(rhs), 0)
}

# The explicit values swapped meaning in #1487; say so once per session to
# anyone who passes `re.form` explicitly.
drm_simulate_re_form_semantics_message <- function() {
  cli::cli_inform(
    c(
      "{.fn simulate} now follows the lme4 {.arg re.form} convention.",
      "*" = "{.code re.form = NA} (the default) or {.code ~0} draws fresh random effects.",
      "*" = "{.code re.form = NULL} holds the fitted random effects fixed.",
      "i" = "Earlier drmTMB versions gave the explicit values the reverse meaning; check code written for them."
    ),
    class = "drmTMB_re_form_semantics_message",
    .frequency = "once",
    .frequency_id = "drmTMB_simulate_re_form_semantics"
  )
}

# ---- Marginal (re.form = NA) random-effect redraw helpers -----------------
#
# `simulate.drmTMB(..., re.form = NA)` draws a FRESH random-effect
# realization for every replicate instead of reusing the fitted conditional-
# mode random effects that `mu_random_effect_contribution()` /
# `sigma_random_effect_contribution()` add to `predict()` when `newdata` is
# NULL. `drm_fresh_ordinary_random_effect_values()` mirrors the TMB-side
# transforms `transform_mu_random_effects()` / `transform_sigma_random_effects()`
# (drmTMB.R) exactly, substituting a fresh standard-normal latent draw for the
# fitted latent vector, so the intra-block (random-slope/intercept) and
# cross-dpar (labelled `(1 | p | id)` mu/sigma) correlation structure of the
# fit is preserved in every replicate.

drm_simulate_marginal_unsupported <- function(object) {
  structured_reason <- drm_structured_mu_marginal_unsupported(object)
  if (!is.null(structured_reason)) {
    return(structured_reason)
  }
  if (has_covariance_block_random_effects(object)) {
    return("correlated covariance-block random effects")
  }
  if (
    has_atom_probability_random_effects(object, "zoi") ||
      has_atom_probability_random_effects(object, "coi")
  ) {
    return("zero-one-beta atom-probability random effects")
  }
  if (isTRUE(object$model$random$mu$cor_model$n_models > 0L)) {
    return("predictor-dependent random-effect correlation (corpair) regression")
  }
  if (
    is.list(object$model$random_scale$phylo) &&
      isTRUE(object$model$random_scale$phylo$n_models > 0L)
  ) {
    phylo_mu <- object$model$structured$phylo_mu
    mesh_mu <- object$model$structured$mesh_spatial_mu
    mesh_sd <- object$model$random_scale$phylo
    mesh_sd_dpars <- mesh_sd$dpars
    supported_mesh_sd <- identical(object$model$model_type, "binomial") &&
      isTRUE(mesh_mu$has) && isTRUE(mesh_sd$n_models == 1L) &&
      length(mesh_sd_dpars) == 1L &&
      identical(
        unname(mesh_sd$target_dpar[[mesh_sd_dpars[[1L]]]]),
        "mu"
      )
    supported_q1_structured_sd <-
      object$model$model_type %in% c(
        "gaussian", "binomial", "poisson", "beta_binomial"
      ) &&
      isTRUE(phylo_mu$has) &&
      structured_mu_type(phylo_mu) %in% c(
        "phylo", "spatial", "relmat", "animal", "phylo_interaction"
      ) &&
      structured_mu_q(phylo_mu) == 1L
    supported_q2_structured_sd <- !is.null(
      drm_binomial_q2_structured_sd_by_node(object, phylo_mu)
    )
    if (
      !supported_q1_structured_sd && !supported_q2_structured_sd &&
        !supported_mesh_sd
    ) {
      return("modelled (heteroscedastic) random-effect scale")
    }
  }
  NULL
}

# Draws a fresh realization of one ordinary (mu or sigma) random-effect
# registry `re` (an `object$model$random$mu` / `$sigma` list). `sd_lookup` is
# the matching named `object$sdpars$mu` / `$sigma` vector; `rho_lookup` is the
# matching named `object$corpars$mu` / `$sigma` vector for any intra-block
# (random-slope/intercept) correlation. `cross_latent` / `cross_rho_lookup` /
# `cross_re` carry a fresh mu latent draw plus `object$corpars$mu_sigma` and
# `object$model$random$mu_sigma` into the sigma draw, for labelled
# `(1 | p | id)` mu/sigma cross-correlated random effects.
# `sd_by_effect_override` supplies fitted group-specific scales for explicitly
# supported direct-SD routes.
drm_fresh_ordinary_random_effect_values <- function(
  re,
  sd_lookup,
  rho_lookup,
  eta_lookup = NULL,
  cross_latent = NULL,
  cross_rho_lookup = NULL,
  cross_re = NULL,
  sd_by_effect_override = NULL
) {
  if (re$n_re == 0L) {
    return(list(latent = numeric(0), values = numeric(0)))
  }
  sd_by_term <- if (is.null(sd_lookup)) {
    rep(NA_real_, length(re$labels))
  } else {
    unname(sd_lookup[re$labels])
  }
  sd_by_effect <- sd_by_term[re$term_id0 + 1L]
  if (!is.null(sd_by_effect_override)) {
    if (
      !is.numeric(sd_by_effect_override) ||
        length(sd_by_effect_override) != re$n_re ||
        any(!is.na(sd_by_effect_override) &
          (!is.finite(sd_by_effect_override) | sd_by_effect_override <= 0))
    ) {
      cli::cli_abort(
        "Internal error: marginal random-effect SD overrides must be positive and match the random-effect vector."
      )
    }
    has_override <- !is.na(sd_by_effect_override)
    sd_by_effect[has_override] <- sd_by_effect_override[has_override]
  }
  if (anyNA(sd_by_effect)) {
    cli::cli_abort(c(
      "Marginal simulation could not find a fitted random-effect SD for every {.field {re$labels}} term.",
      "i" = "This usually means the random-effect scale is itself modelled (heteroscedastic).",
      "i" = "Pass {.code re.form = NULL} to simulate conditionally on the fitted random effects instead."
    ))
  }
  rho <- rep(NA_real_, re$n_cors)
  if (re$n_cors > 0L && !is.null(rho_lookup)) {
    rho <- unname(rho_lookup[re$cor_labels])
  }
  if (re$n_cors > 0L && anyNA(rho)) {
    cli::cli_abort(c(
      "Marginal simulation could not find a fitted correlation for every {.field {re$cor_labels}} random-effect block.",
      "i" = "Pass {.code re.form = NULL} to simulate conditionally on the fitted random effects instead."
    ))
  }
  has_cross <- !is.null(cross_re) && isTRUE(cross_re$n_cors > 0L)
  latent <- stats::rnorm(re$n_re)
  values <- numeric(re$n_re)
  for (idx in seq_len(re$n_re)) {
    term <- re$term_id0[[idx]] + 1L
    cor_id <- re$re_cor_id0[[idx]] + 1L
    is_cor_slope <- cor_id > 0L && re$re_pos0[[idx]] == 1L
    u <- latent[[idx]]
    is_cor_q3 <- cor_id > 0L &&
      max(re$re_pos0[re$re_cor_id0 == cor_id - 1L]) == 2L
    if (is_cor_q3) {
      position <- re$re_pos0[[idx]]
      pair <- re$re_pair_index0[[idx]] + 1L
      group_size <- length(re$groups[[term]])
      eta <- if (is.null(eta_lookup)) rep(NA_real_, re$n_cors) else eta_lookup
      partial21 <- if (is.finite(eta[[cor_id]])) {
        tanh(eta[[cor_id]])
      } else {
        rho[[cor_id]]
      }
      partial31 <- if (is.finite(eta[[cor_id + 1L]])) {
        tanh(eta[[cor_id + 1L]])
      } else {
        rho[[cor_id + 1L]]
      }
      partial32 <- if (is.finite(eta[[cor_id + 2L]])) {
        tanh(eta[[cor_id + 2L]])
      } else {
        (rho[[cor_id + 2L]] - partial21 * partial31) /
          (sqrt(max(0, 1 - partial21^2)) *
             sqrt(max(0, 1 - partial31^2)))
      }
      s21 <- sqrt(max(0, 1 - partial21^2))
      s31 <- sqrt(max(0, 1 - partial31^2))
      s32 <- sqrt(max(0, 1 - partial32^2))
      if (position == 1L) {
        u <- partial21 * latent[[pair]] + s21 * latent[[idx]]
      } else if (position == 2L) {
        u <- partial31 * latent[[pair]] +
          s31 * partial32 * latent[[pair + group_size]] +
          s31 * s32 * latent[[idx]]
      }
    } else if (is_cor_slope) {
      pair <- re$re_pair_index0[[idx]] + 1L
      rho_i <- rho[[cor_id]]
      eta_i <- if (is.null(eta_lookup)) NA_real_ else eta_lookup[[cor_id]]
      innovation_scale <- if (is.finite(eta_i)) {
        exp(log(2) - abs(eta_i) - log1p(exp(-2 * abs(eta_i))))
      } else {
        sqrt(max(0, 1 - rho_i^2))
      }
      u <- rho_i * latent[[pair]] + innovation_scale * latent[[idx]]
    }
    if (has_cross) {
      cross_cor_id <- cross_re$sigma_cross_cor_id0[[idx]] + 1L
      if (cross_cor_id > 0L) {
        cross_label <- cross_re$cor_labels[[cross_cor_id]]
        rho_i <- if (is.null(cross_rho_lookup)) {
          NA_real_
        } else {
          unname(cross_rho_lookup[[cross_label]])
        }
        if (is.null(rho_i) || is.na(rho_i)) {
          cli::cli_abort(c(
            "Marginal simulation could not find a fitted mu/sigma cross-correlation for {.field {cross_label}}.",
            "i" = "Pass {.code re.form = NULL} to simulate conditionally on the fitted random effects instead."
          ))
        }
        mu_idx <- cross_re$sigma_cross_mu_index0[[idx]] + 1L
        u <- rho_i * cross_latent[[mu_idx]] + sqrt(1 - rho_i^2) * u
      }
    }
    values[[idx]] <- sd_by_effect[[idx]] * u
  }
  list(latent = latent, values = values)
}

# Returns a per-coefficient SD override for fitted ordinary location SD models.
# The stored registry's zero-based row map aligns each random coefficient with
# the group-level scale prediction; NA entries leave unrelated terms unchanged.
drm_ordinary_sd_effect_override <- function(
  object,
  re,
  endpoint = c("mu", "sigma")
) {
  endpoint <- match.arg(endpoint)
  sd_model <- object$model$random_scale[[endpoint]]
  if (!is.list(sd_model) || !isTRUE(sd_model$n_models > 0L)) {
    return(NULL)
  }
  row_map <- sd_model$re_sd_row0
  if (length(row_map) != re$n_re) {
    cli::cli_abort(
      "Internal error: ordinary SD rows do not align with random effects."
    )
  }
  target <- which(row_map >= 0L)
  if (length(target) == 0L) {
    return(NULL)
  }
  group_sd <- rep(NA_real_, nrow(sd_model$X))
  for (dpar in sd_model$dpars) {
    rows <- sd_model$row_index[[dpar]]
    values <- predict_random_scale_dpar(object, dpar, type = "response")
    if (length(rows) != length(values)) {
      cli::cli_abort(
        "Internal error: ordinary SD predictions do not align with scale rows."
      )
    }
    group_sd[rows] <- unname(values)
  }
  group_row <- row_map[target] + 1L
  if (
    anyNA(group_row) || any(group_row < 1L | group_row > length(group_sd)) ||
      anyNA(group_sd[group_row])
  ) {
    cli::cli_abort(
      "Internal error: ordinary SD target map points to an unavailable group scale."
    )
  }
  out <- rep(NA_real_, re$n_re)
  out[target] <- group_sd[group_row]
  out
}

# Retain the tested internal spelling for existing binomial callers.
drm_binomial_sd_effect_override <- drm_ordinary_sd_effect_override

# Reduces a flat vector of fresh random-effect values (in the same layout as
# `re$index`/`re$value`) to a per-observation contribution for one dpar,
# mirroring `mu_random_effect_contribution()` / `sigma_random_effect_contribution()`.
drm_random_effect_contribution_from_values <- function(values, re, dpar) {
  terms <- which(re$dpars %in% dpar)
  if (length(terms) == 0L) {
    return(NULL)
  }
  index <- re$index[, terms, drop = FALSE]
  design_value <- re$value[, terms, drop = FALSE]
  rowSums(matrix(values[index], nrow = nrow(index)) * design_value)
}

# Returns a reason string when marginal simulation cannot yet redraw this
# object's structured mu random effect, or NULL when it can. The existing
# q1 routes use a single fitted SD with covariance `sd^2 * Q^-1`. A separate
# native Bernoulli relmat q2 route draws its two independent coefficient
# fields with their own group-specific SD predictions. Other q2 terms remain
# unsupported because their cross-field covariance is not reconstructed.
drm_structured_mu_marginal_unsupported <- function(object) {
  phylo_mu <- object$model$structured$phylo_mu
  if (!isTRUE(phylo_mu$has)) {
    return(NULL)
  }
  type <- structured_mu_type(phylo_mu)
  if (!type %in% c("phylo", "spatial", "relmat", "animal", "phylo_interaction")) {
    return("phylogenetic-interaction structured mu random effects")
  }
  q2_scale <- drm_binomial_q2_structured_sd_by_node(object, phylo_mu)
  if (structured_mu_q(phylo_mu) > 1L && is.null(q2_scale)) {
    return(
      "structured mu random effects correlated across more than one trait or distributional parameter"
    )
  }
  NULL
}

drm_binomial_q2_structured_sd_by_node <- function(object, phylo_mu) {
  if (
    !identical(object$model$model_type, "binomial") ||
      !identical(structured_mu_type(phylo_mu), "relmat") ||
      structured_mu_q(phylo_mu) != 2L ||
      length(object$corpars) > 0L
  ) {
    return(NULL)
  }
  sd_registry <- object$model$random_scale$phylo
  if (
    !is.list(sd_registry) || !identical(sd_registry$n_models, 2L) ||
      length(sd_registry$dpars) != 2L ||
      length(phylo_mu$coef_names) != 2L
  ) {
    return(NULL)
  }
  target_coef <- vapply(sd_registry$dpars, function(dpar) {
    target_call <- tryCatch(str2lang(dpar), error = function(e) NULL)
    if (!is.call(target_call) || !identical(target_call[[1L]], quote(sd_relmat))) {
      return(NA_character_)
    }
    args <- as.list(target_call)[-1L]
    coef <- args$coef
    if (!is.character(coef) || length(coef) != 1L || is.na(coef)) {
      return(NA_character_)
    }
    coef
  }, character(1L))
  coefficient <- match(target_coef, phylo_mu$coef_names)
  if (anyNA(coefficient) || anyDuplicated(coefficient)) {
    return(NULL)
  }
  node_labels <- phylo_mu$precision$node_labels
  if (length(node_labels) != phylo_mu$n_re || anyNA(node_labels)) {
    return(NULL)
  }
  sd_by_node <- matrix(
    NA_real_, nrow = phylo_mu$n_re, ncol = 2L,
    dimnames = list(node_labels, phylo_mu$coef_names)
  )
  for (i in seq_along(sd_registry$dpars)) {
    scale_dpar <- sd_registry$dpars[[i]]
    scale_by_group <- predict_random_scale_dpar(object, scale_dpar)
    node_index <- match(node_labels, names(scale_by_group))
    if (anyNA(node_index)) {
      return(NULL)
    }
    sd_by_node[, coefficient[[i]]] <- unname(scale_by_group[node_index])
  }
  if (any(!is.finite(sd_by_node)) || any(sd_by_node <= 0)) {
    cli::cli_abort(
      "Internal error: predictor-dependent q2 structured SDs do not align with the latent fields."
    )
  }
  sd_by_node
}

# Draws fresh structured mu effects using the fitted precision `Q` and SDs.
# For one field, `sd` is scalar or node-specific. For independent q2 fields,
# it is a node-by-coefficient matrix and each column gets an independent draw
# with covariance `D_j Q^-1 D_j`. A dense Cholesky factor `R` of `Q`
# (`t(R) %*% R == Q`) and triangular solve avoid an explicit inverse: if
# `z ~ N(0, I)` and `R %*% u = z`, then `u = R^-1 %*% z` has covariance
# `R^-1 %*% t(R^-1) == (t(R) %*% R)^-1 == Q^-1`.
drm_fresh_structured_mu_values <- function(phylo_mu, sd) {
  if (is.matrix(sd)) {
    expected <- c(phylo_mu$n_re, structured_mu_q(phylo_mu))
    if (!identical(dim(sd), expected)) {
      cli::cli_abort(
        "Internal error: structured-effect SD matrix dimensions must match the latent-effect dimensions."
      )
    }
    root <- chol(as.matrix(phylo_mu$precision$precision))
    z <- matrix(stats::rnorm(length(sd)), nrow = phylo_mu$n_re)
    return(as.vector(backsolve(root, z) * sd))
  }
  if (length(sd) != 1L && length(sd) != phylo_mu$n_re) {
    cli::cli_abort(
      "Internal error: structured-effect SDs ({length(sd)}) must be scalar or match the latent-effect dimension ({phylo_mu$n_re})."
    )
  }
  root <- chol(as.matrix(phylo_mu$precision$precision))
  z <- stats::rnorm(phylo_mu$n_re)
  backsolve(root, z) * sd
}

# Draws ONE fresh realization of the (single-endpoint) structured mu random
# effect this object has, returning a named list keyed by dpar of
# per-observation link-scale contributions -- mirroring
# `drm_ordinary_random_effect_draws()` below. Reuses `phylo_mu_contribution()`
# for the observation mapping (design multiply and node index) by substituting
# the fresh draw for the fitted values in a shallow copy of `object`, so
# conditional and marginal differ only in whether the values are the fitted
# BLUPs or a fresh draw. Returns an empty list when there is no structured mu
# term (callers must use `drm_structured_mu_marginal_unsupported()` first to
# rule out unsupported structured terms).
drm_structured_mu_random_effect_draws <- function(object) {
  mesh_mu <- object$model$structured$mesh_spatial_mu
  if (is.list(mesh_mu) && isTRUE(mesh_mu$has)) {
    return(drm_mesh_spatial_mu_random_effect_draws(object))
  }
  phylo_mu <- object$model$structured$phylo_mu
  if (!isTRUE(phylo_mu$has)) {
    return(list())
  }
  model_type <- object$model$model_type
  dpar <- unique(phylo_mu_endpoint_dpars(phylo_mu))
  sd_key <- if (identical(model_type, "biv_gaussian")) "mu" else dpar
  label <- phylo_mu_sd_labels(phylo_mu, model_type)
  sd_matrix <- drm_binomial_q2_structured_sd_by_node(object, phylo_mu)
  sd_val <- if (!is.null(sd_matrix)) {
    sd_matrix
  } else {
    unname(object$sdpars[[sd_key]][label])
  }
  if (length(sd_val) == 0L || anyNA(sd_val)) {
    sd_registry <- object$model$random_scale$phylo
    modeled_scale_dpars <- if (
      is.list(sd_registry) && isTRUE(sd_registry$n_models > 0L)
    ) {
      Filter(function(scale_dpar) {
        target <- sd_registry$target_dpar[[scale_dpar]]
        if (is.null(target) || is.na(target)) target <- "mu"
        target %in% dpar
      }, sd_registry$dpars)
    } else {
      character()
    }
    if (length(modeled_scale_dpars) != 1L) {
      cli::cli_abort(c(
        "Marginal simulation could not find a unique fitted structured-effect SD for {.field {label}}.",
        "i" = "Pass {.code re.form = NULL} to simulate conditionally on the fitted random effects instead."
      ))
    }
    scale_dpar <- modeled_scale_dpars[[1L]]
    scale_by_level <- predict_random_scale_dpar(object, scale_dpar)
    node_sd_row0 <- sd_registry$node_sd_row0[seq_len(phylo_mu$n_re)]
    modeled_rows <- sd_registry$row_index[[scale_dpar]]
    node_sd <- rep(1, phylo_mu$n_re)
    direct <- node_sd_row0 >= 0L
    local_row <- match(node_sd_row0[direct] + 1L, modeled_rows)
    node_sd[direct] <- unname(scale_by_level[local_row])
    sd_val <- node_sd
    if (
      length(sd_val) != phylo_mu$n_re || anyNA(sd_val) ||
        any(!is.finite(sd_val)) || any(sd_val <= 0)
    ) {
      cli::cli_abort(
        "Internal error: modeled structured-effect SDs do not align with the latent-effect nodes."
      )
    }
  }
  key <- structured_mu_random_effect_key(phylo_mu, model_type)
  draw_object <- object
  draw_object$random_effects[[key]]$values <- drm_fresh_structured_mu_values(
    phylo_mu,
    sd_val
  )
  out <- stats::setNames(
    lapply(dpar, function(d) {
      phylo_mu_primary_contribution(draw_object, dpar = d)
    }),
    dpar
  )
  phylo_mu2 <- object$model$structured$phylo_mu2
  if (identical(model_type, "binomial") && isTRUE(phylo_mu2$has)) {
    sd2 <- object$model$random_scale$phylo2
    if (!is.list(sd2) || sd2$n_models != 1L) {
      cli::cli_abort(
        "Marginal simulation requires one predictor-dependent SD formula for the second structured Binomial field."
      )
    }
    sd_dpar <- sd2$dpars[[1L]]
    group_sd <- unname(predict_random_scale_dpar(object, sd_dpar))
    node_row <- sd2$node_sd_row0
    node_sd <- rep(NA_real_, phylo_mu2$n_re)
    observed <- node_row >= 0L
    node_sd[observed] <- group_sd[node_row[observed] + 1L]
    if (anyNA(node_sd) || any(!is.finite(node_sd)) || any(node_sd <= 0)) {
      cli::cli_abort(
        "Internal error: second structured-effect SDs do not align with the latent nodes."
      )
    }
    draw_object2 <- object
    key2 <- structured_mu_random_effect_key(phylo_mu2, model_type)
    draw_object2$random_effects[[key2]]$values <-
      drm_fresh_structured_mu_values(phylo_mu2, node_sd)
    out$mu <- out$mu + phylo_mu2_contribution(draw_object2)
  }
  out
}

# Draw one fixed-kappa mesh field from its sparse precision and scale each
# projected observation by the fitted SD formula for its latent group.
drm_mesh_spatial_mu_random_effect_draws <- function(object) {
  mesh <- object$model$structured$mesh_spatial_mu
  if (!is.list(mesh) || !isTRUE(mesh$has)) return(list())
  sd_registry <- object$model$random_scale$phylo
  if (
    !is.list(sd_registry) || !isTRUE(sd_registry$n_models == 1L) ||
      length(sd_registry$dpars) != 1L
  ) {
    cli::cli_abort(
      "Internal error: mesh marginal simulation requires one fitted spatial location SD model."
    )
  }
  sd_dpar <- sd_registry$dpars[[1L]]
  if (!identical(unname(sd_registry$target_dpar[[sd_dpar]]), "mu")) {
    cli::cli_abort(
      "Internal error: mesh marginal simulation currently requires a location SD target."
    )
  }
  scale_by_group <- unname(predict_random_scale_dpar(object, sd_dpar))
  sd_row0 <- sd_registry$observation_sd_row0
  if (
    length(sd_row0) != nrow(mesh$projection) || anyNA(sd_row0) ||
      any(sd_row0 < 0L) || any(sd_row0 >= length(scale_by_group))
  ) {
    cli::cli_abort(
      "Internal error: mesh observations do not align with their fitted spatial SD rows."
    )
  }
  factor <- mesh$precision$cholesky
  if (is.null(factor) || is.null(factor$L) || is.null(factor$P)) {
    factor <- Matrix::expand(Matrix::Cholesky(
      mesh$precision$precision,
      LDL = FALSE,
      perm = TRUE
    ))
  }
  z <- stats::rnorm(mesh$n_re)
  permuted <- as.numeric(Matrix::solve(Matrix::t(factor$L), z))
  latent <- as.numeric(Matrix::t(factor$P) %*% permuted)
  projected <- as.numeric(mesh$projection %*% latent)
  contribution <- mesh$value * projected * scale_by_group[sd_row0 + 1L]
  stats::setNames(list(contribution), "mu")
}

# Draws ONE fresh realization of every ordinary mu/sigma random effect this
# object has, returning a named list keyed by dpar (e.g. `mu`/`sigma`, or
# `mu1`/`mu2`/`sigma1`/`sigma2` for bivariate Gaussian fits) of per-observation
# link-scale contributions. Must be called once per simulation replicate (not
# once per dpar) so a labelled mu/sigma cross-correlation shares the same
# fresh mu latent draw within that replicate. Also merges in a fresh
# structured mu draw (see `drm_structured_mu_random_effect_draws()`) when
# present. Returns an empty list for models with no ordinary or structured
# random effects.
drm_ordinary_random_effect_draws <- function(object) {
  out <- list()
  has_mu <- has_ordinary_mu_random_effects(object)
  has_sig <- has_sigma_random_effects(object)
  has_structured <- isTRUE(object$model$structured$phylo_mu$has) ||
    isTRUE(object$model$structured$phylo_mu2$has) ||
    isTRUE(object$model$structured$mesh_spatial_mu$has)
  if (!has_mu && !has_sig && !has_structured) {
    return(out)
  }
  mu_latent <- NULL
  if (has_mu) {
    re_mu <- object$model$random$mu
    eta_mu <- NULL
    if (identical(object$model$model_type, "binomial") && re_mu$n_cors > 0L) {
      eta_mu <- tryCatch(
        as.numeric(object$obj$env$parList(object$opt$par)$eta_cor_mu)[
          seq_len(re_mu$n_cors)
        ],
        error = function(e) NULL
      )
      if (is.null(eta_mu) && !is.null(object$corpars$mu)) {
        eta_mu <- atanh(pmax(-1 + .Machine$double.eps,
          pmin(1 - .Machine$double.eps, unname(object$corpars$mu))))
      }
    }
    draw <- drm_fresh_ordinary_random_effect_values(
      re_mu,
      object$sdpars$mu,
      object$corpars$mu,
      eta_lookup = eta_mu,
      sd_by_effect_override = drm_ordinary_sd_effect_override(object, re_mu)
    )
    mu_latent <- draw$latent
    for (dpar in unique(re_mu$dpars)) {
      out[[dpar]] <- drm_random_effect_contribution_from_values(
        draw$values,
        re_mu,
        dpar
      )
    }
  }
  if (has_sig) {
    re_sigma <- object$model$random$sigma
    draw <- drm_fresh_ordinary_random_effect_values(
      re_sigma,
      object$sdpars$sigma,
      object$corpars$sigma,
      eta_lookup = NULL,
      cross_latent = mu_latent,
      cross_rho_lookup = object$corpars$mu_sigma,
      cross_re = object$model$random$mu_sigma,
      sd_by_effect_override = drm_ordinary_sd_effect_override(
        object, re_sigma, endpoint = "sigma"
      )
    )
    for (dpar in unique(re_sigma$dpars)) {
      contrib <- drm_random_effect_contribution_from_values(
        draw$values,
        re_sigma,
        dpar
      )
      out[[dpar]] <- if (is.null(out[[dpar]])) {
        contrib
      } else {
        out[[dpar]] + contrib
      }
    }
  }
  if (has_structured) {
    structured_draws <- drm_structured_mu_random_effect_draws(object)
    for (dpar in names(structured_draws)) {
      out[[dpar]] <- if (is.null(out[[dpar]])) {
        structured_draws[[dpar]]
      } else {
        out[[dpar]] + structured_draws[[dpar]]
      }
    }
  }
  out
}

# Response- or link-scale prediction for one dpar under marginal simulation:
# fixed effects only, plus this replicate's fresh random-effect draw (if any).
drm_marginal_predict <- function(
  object,
  dpar,
  re_draws,
  type = c("response", "link")
) {
  type <- match.arg(type)
  eta <- drm_fixed_effect_basis(object, newdata = NULL, dpar = dpar)$eta
  contrib <- re_draws[[dpar]]
  if (!is.null(contrib)) {
    eta <- eta + contrib
  }
  eta <- drm_clamped_sigma_eta(object, dpar, eta)
  if (identical(type, "link")) {
    return(eta)
  }
  drm_inverse_link(object, dpar, eta)
}
